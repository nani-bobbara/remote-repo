#!/usr/bin/env bash
# Create GitHub issues for the 2026-07-20 architecture review, labelled and in priority order.
# Prereqs: `gh` CLI installed and authenticated (`gh auth login`), run from the repo root.
# Optional: set PROJECT_NUMBER to also add every issue to a GitHub Project (v2) board.
#
#   REPO=Nani-Bobbara_CUDL/jairus-plugin PROJECT_NUMBER=1 bash scripts/create-review-issues.sh
#
# Idempotency: re-running creates duplicate issues. Run once, or delete prior issues first.
set -euo pipefail

REPO="${REPO:-Nani-Bobbara_CUDL/jairus-plugin}"
PROJECT_NUMBER="${PROJECT_NUMBER:-}"   # e.g. 1 ; leave empty to skip project add
REPORT="docs/reviews/2026-07-20-architecture-review.md"

echo "Repo: $REPO"
command -v gh >/dev/null || { echo "gh CLI not found. Install + 'gh auth login' first."; exit 1; }

# ---- labels (create if missing) --------------------------------------------
ensure_label() { gh label create "$1" --repo "$REPO" --color "$2" --description "$3" 2>/dev/null || true; }
ensure_label "severity:critical" "B60205" "Fix before real use — data loss / bypass"
ensure_label "severity:high"     "D93F0B" "Likely failure in practice"
ensure_label "severity:medium"   "FBCA04" "Gap / hardening"
ensure_label "severity:low"      "0E8A16" "Polish"
ensure_label "area:gate"         "5319E7" "Pipeline gate integrity"
ensure_label "area:security"     "1D76DB" "Security guidance"
ensure_label "area:consistency"  "C5DEF5" "Consistency / correctness"
ensure_label "review:2026-07-20" "BFD4F2" "From the 2026-07-20 architecture review"

# ---- helper -----------------------------------------------------------------
mk() { # mk "<title>" "<labels csv>" "<body>"
  local url
  url=$(gh issue create --repo "$REPO" --title "$1" --label "$2" --body "$3")
  echo "  created: $url"
  if [ -n "$PROJECT_NUMBER" ]; then
    gh project item-add "$PROJECT_NUMBER" --owner "${REPO%%/*}" --url "$url" >/dev/null 2>&1 \
      && echo "    added to project $PROJECT_NUMBER" || echo "    (project add skipped/failed)"
  fi
}
B="See $REPORT for full detail, affected files, and the recommended fix."

echo "Creating issues (priority order)..."

# ---- CRITICAL ---------------------------------------------------------------
mk "JAIRUS-001: Neon RLS is fail-open (owner role bypasses RLS)" \
   "severity:critical,area:security,review:2026-07-20" \
   "App connects as the table-owner role; Postgres exempts owners from RLS unless FORCE is set, so withUser() gives zero isolation and unset context returns ALL rows. Fix: dedicated NOBYPASSRLS runtime role + FORCE ROW LEVEL SECURITY on every table + verify runtime role != owner. $B"
mk "JAIRUS-002: Developer agent applies irreversible schema/Stripe changes before Gate 4/5" \
   "severity:critical,area:gate,review:2026-07-20" \
   "Developer holds live write-MCP scopes and its exit tests require the migration to exist, forcing the write pre-approval. Fix: return gate_required before any write; defer integration tests to post-approval re-dispatch. $B"
mk "JAIRUS-003: Gate 6 merge auto-deploys production, bypassing Gate 7/8" \
   "severity:critical,area:gate,review:2026-07-20" \
   "pipeline.md merges PR to main at Gate 6; on Vercel that auto-deploys prod, skipping staging/prod gates. Fix: Gate 6 leaves PR open; merge only in Gate 8 sequence; protect main. $B"
mk "JAIRUS-004: Gates unenforced — no required human turn or approval artifact" \
   "severity:critical,area:gate,review:2026-07-20" \
   "Orchestrator presents gate and writes approval flag in one turn; no required human token, no provenance. Fix: require a quotable APPROVE token in a new human message, echoed into state; ship delegates to hardened gates. $B"

# ---- HIGH -------------------------------------------------------------------
mk "JAIRUS-005: Root .mcp.json missing neon — Neon projects get no backend MCP server" \
   "severity:high,area:consistency,review:2026-07-20" \
   "Root .mcp.json has 5 servers (no neon); init skip-if-exists + trim leaves a Neon project with zero backend MCP. Fix: add neon; source trim from templates/mcp.json. $B"
mk "JAIRUS-006: No enforced secret-commit block; deny list too narrow" \
   "severity:high,area:security,review:2026-07-20" \
   "Only a post-commit git status hook exists; git add/commit of .env.local is permitted. Fix: PreToolUse hook grepping staged files for .env*/serviceAccount*.json/key patterns; widen deny list; ensure .gitignore. $B"
mk "JAIRUS-007: Neon MCP has no read-only guardrail (can delete projects / drop tables)" \
   "severity:high,area:security,review:2026-07-20" \
   "Supabase MCP runs --read-only; Neon MCP has no equivalent, mitigated only by prose. Fix: read-only default, opt-in for migrations, scoped API key, hard gate before writes. $B"
mk "JAIRUS-008: Firebase auth contradicts HTTP-only-cookie mandate; Server Components can't auth" \
   "severity:high,area:security,review:2026-07-20" \
   "getSession(request) reads an Authorization header (XSS-exposed); Server Components carry none. Fix: Admin-SDK session cookies read via cookies(), matching Supabase/Neon. $B"
mk "JAIRUS-009: INTENT.md approval flags are forgeable (no provenance)" \
   "severity:high,area:gate,review:2026-07-20" \
   "design_approved/code_review_passed are plain booleans written by the orchestrator. Fix: add approver/timestamp/score/gate_ref provenance; refuse to proceed if flag true but provenance absent. $B"
mk "JAIRUS-010: Safety-critical preconditions are non-executable prose" \
   "severity:high,area:gate,review:2026-07-20" \
   "design-before-develop and review-before-deploy are prose tables, not grep checks like board.md. Fix: concrete grep-against-INTENT.md verification per command; fail closed. $B"
mk "JAIRUS-011: Reviewer score/blocker_count self-reported and trusted verbatim" \
   "severity:high,area:gate,review:2026-07-20" \
   "The >=8-no-BLOCKER gate trusts the reviewer's own numbers. Fix: orchestrator recomputes from dimensions/findings; reject inconsistent reports. $B"

# ---- MEDIUM -----------------------------------------------------------------
mk "JAIRUS-012: Stripe webhook idempotency is non-atomic (TOCTOU)" \
   "severity:medium,area:security,review:2026-07-20" \
   "check-then-mark lets concurrent retries double-process. Fix: INSERT event.id ON CONFLICT DO NOTHING before handling. $B"
mk "JAIRUS-013: Firebase broad 'allow write' defeats field-validated create rule" \
   "severity:medium,area:security,review:2026-07-20" \
   "OR-combined rules let a broad write bypass ownerUid/shape checks. Fix: enumerate read/create/update/delete separately; drop catch-all write. $B"
mk "JAIRUS-014: Over-broad permissions in settings.json" \
   "severity:medium,area:security,review:2026-07-20" \
   "Unscoped Read/Edit/Write + Bash(npx *) + Bash(git *); deny rules bypassable. Fix: scope away from secret files; narrow git/npx. $B"
mk "JAIRUS-015: Supabase MCP --read-only contradicts apply_migration instructions" \
   "severity:medium,area:security,review:2026-07-20" \
   "Read-only server can't apply migrations, pushing users to unaudited paths. Fix: document sanctioned apply path (gated write invocation or supabase db push). $B"
mk "JAIRUS-016: Neon API key passed as a CLI argument" \
   "severity:medium,area:security,review:2026-07-20" \
   "start \${NEON_API_KEY} in argv is visible via ps/proc. Fix: pass via env if supported. $B"
mk "JAIRUS-017: mcp-usage.md mislabels backend-schema gate as Gate 5 (should be Gate 4)" \
   "severity:medium,area:consistency,review:2026-07-20" \
   "Supabase/Firebase sections say Gate 5 for schema; pipeline.md says Gate 4. Fix: change to Gate 4. $B"
mk "JAIRUS-018: doctor.md allowed-tools omits mcp__neon__*" \
   "severity:medium,area:consistency,review:2026-07-20" \
   "Step 4 tests Neon connectivity but can't call the tool. Fix: add mcp__neon__* to frontmatter. $B"
mk "JAIRUS-019: doctor.md plugin-integrity counts are stale" \
   "severity:medium,area:consistency,review:2026-07-20" \
   "Lists 5 agents (missing extender) and 7 skills (missing ai/email/feature-flags). Fix: correct expected sets. $B"
mk "JAIRUS-020: plugin.json / marketplace.json descriptions omit Neon" \
   "severity:medium,area:consistency,review:2026-07-20" \
   "User-facing strings say 'Supabase or Firebase'. Fix: 'Supabase, Firebase, or Neon'; add neon keyword. $B"
mk "JAIRUS-021: CLAUDE.md and README describe a two-backend harness" \
   "severity:medium,area:consistency,review:2026-07-20" \
   "CLAUDE.md (authoritative every session) omits Neon in backend table/skills/overview. Fix: add Neon throughout. $B"
mk "JAIRUS-022: Fix-loop counters live only in model memory" \
   "severity:medium,area:gate,review:2026-07-20" \
   "Iteration/decline counters not persisted; drift across long ship runs. Fix: persist per-feature in CHECKLIST/INTENT; read/increment/write each round. $B"
mk "JAIRUS-023: Designer [BLOCKS GATE] / open-questions not grep-enforced" \
   "severity:medium,area:gate,review:2026-07-20" \
   "Gate 3 says open questions block it, but only {{ and AC-[0-9] are grepped. Fix: grep unresolved markers and fail the gate. $B"
mk "JAIRUS-024: Harden Gate 7/8 staging confirmation + ship batching" \
   "severity:medium,area:gate,review:2026-07-20" \
   "Self-ticked staging checkbox and batched gates amplify JAIRUS-004. Fix: require quotable human confirmation naming the staging URL before Gate 8. $B"

# ---- LOW --------------------------------------------------------------------
mk "JAIRUS-025: getSession() naming invites the unvalidated-JWT mistake (Supabase)" \
   "severity:low,area:security,review:2026-07-20" \
   "Rename to requireUser()/getAuthenticatedUser(); comment it must call getUser(), never the SDK getSession(). $B"
mk "JAIRUS-026: No rate-limit / CSRF reference implementation" \
   "severity:low,area:security,review:2026-07-20" \
   "security.md requires them but no skill shows one. Add sliding-window on /api/auth/* + billing; show Better Auth trustedOrigins. $B"
mk "JAIRUS-027: migrations.yml has no active Neon job" \
   "severity:low,area:consistency,review:2026-07-20" \
   "Neon CI migration is commented-only. Fix: ship a real Neon job or generate per-backend at init. $B"
mk "JAIRUS-028: Firebase MCP env differs between plugin and template configs" \
   "severity:low,area:consistency,review:2026-07-20" \
   ".jairus/.mcp.json passes FIREBASE_TOKEN; template does not. Fix: align the firebase env block. $B"
mk "JAIRUS-029: Dangling reference to /jairus:health" \
   "severity:low,area:consistency,review:2026-07-20" \
   "No such command. Fix: use /jairus:doctor in rules/mcp-usage.md. $B"
mk "JAIRUS-030: Reviewer BLOCKER list narrower than quality-gate.md" \
   "severity:low,area:gate,review:2026-07-20" \
   "Reviewer under-tags vs quality-gate.md. Fix: reference quality-gate.md's BLOCKER catalog as single source of truth. $B"

echo "Done. 30 issues created in $REPO."
