# Jairus — Deep Architecture Review (Gates + Security + Consistency)

Date: 2026-07-20 · Scope: `.jairus/` plugin harness · Reviewers: 3 parallel agents
(gate integrity, security, consistency) · Backends in scope: Supabase, Firebase, Neon.

This backlog is ordered for the pipeline to pick and close top-down: **Critical → High →
Medium → Low**. Each item is an independently closeable issue with a suggested label set.

Labels used: `severity:{critical,high,medium,low}` · `area:{gate,security,consistency}` ·
`review:2026-07-20`.

---

## Critical

### JAIRUS-001 · Neon RLS is fail-open (owner role bypasses RLS)
`severity:critical` `area:security`
**Problem:** The app connects via `DATABASE_URL` as the Neon primary/owner role, which owns the
tables. Postgres exempts the owner from RLS unless `ALTER TABLE … FORCE ROW LEVEL SECURITY` is
set. So every policy keyed on `current_setting('app.user_id', true)` is skipped — `withUser()`
gives zero isolation and an unset context returns **all** rows, not zero. The Stripe webhook
"privileged query outside withUser()" only works *because* the role bypasses RLS, confirming it.
Docs assert "fail-closed"; it is fail-open.
**Files:** `skills/neon/SKILL.md` (RLS, withUser), `rules/security.md` (Neon RLS).
**Fix:** Add a dedicated non-owner runtime role (`CREATE ROLE app_user NOBYPASSRLS`; grant DML;
put it in `DATABASE_URL`), AND `ALTER TABLE <t> FORCE ROW LEVEL SECURITY` in every migration.
Add a post-migration verification that the runtime role is not the owner and lacks `rolbypassrls`.

### JAIRUS-002 · Developer agent applies irreversible schema/Stripe changes before Gate 4/5
`severity:critical` `area:gate`
**Problem:** Gate 4 (migrations/RLS) and Gate 5 (live Stripe) are signaled via return JSON, but
the developer holds live write-MCP scopes and its exit contract requires integration tests
against a real DB — forcing it to apply the migration before any human sees the gate.
**Files:** `agents/developer.md` (impl order + exit checks), `commands/develop.md`.
**Fix:** Require the developer to return `status: gate_required` **before** writing any migration
or touching backend/Stripe MCP; allow deferring integration tests to a post-approval re-dispatch.
Or strip live-write MCP scopes from the developer and route writes through a post-approval step.

### JAIRUS-003 · Gate 6 merge auto-deploys production, bypassing Gate 7/8
`severity:critical` `area:gate`
**Problem:** `pipeline.md` Stage 4 handover says the PR is merged to main on Gate 6. On a
Vercel git-integrated project, merging to main auto-deploys production — shipping before Gate 7
(staging) and Gate 8 (prod approval), and skipping the live-Stripe/migration sequencing Gate 8
owns. `deploy.md` contradicts this (merge at Gate 8).
**Files:** `rules/pipeline.md` (Stage 4 handover) vs `commands/deploy.md`, `commands/review.md`.
**Fix:** Gate 6 marks review passed and leaves the PR open; main is protected; merge happens
only in the Gate 8 production sequence. Resolve the contradiction in favor of deploy owning merge.

### JAIRUS-004 · Gates are unenforced — no required human turn or approval artifact
`severity:critical` `area:gate`
**Problem:** The orchestrator presents a gate and writes the approval flag in the same turn;
nothing forces an intervening human message, and approval leaves no verifiable record. The strong
"implicit approval is never valid" rule lives only in `pipeline.md`, not at any actual gate.
`/jairus:ship` batches gates and maximizes the incentive to infer approval. Gate 7/8's "human has
reviewed staging URL" is a self-ticked checkbox before irreversible prod changes.
**Files:** every command gate block; `rules/pipeline.md`; `commands/ship.md`.
**Fix:** End every gate block with a hard stop that requires a quotable approval token (e.g.
`APPROVE GATE N`) in a *new* human message, echoed into the success output as provenance. Treat
absence of a new human turn as decline. Have `ship` delegate to the hardened per-command gate.

---

## High

### JAIRUS-005 · Root `.mcp.json` missing `neon` → Neon projects get no backend MCP server
`severity:high` `area:consistency`
**Problem:** `.jairus/.mcp.json` and `templates/mcp.json` have `neon`; the committed root
`.mcp.json` has only 5 servers. init's "skip if file exists" means a cloned harness keeps the
stale root file, and the trim step then leaves a Neon project with zero backend MCP servers.
**Fix:** Add `neon` to root `.mcp.json`; have init source the trim from `templates/mcp.json`
rather than editing a pre-existing root file in place.

### JAIRUS-006 · No enforced secret-commit block; deny list too narrow
`severity:high` `area:security`
**Problem:** Only a `PostToolUse` `git status` hook exists (runs *after* commit). `Bash(git *)`
is broadly allowed, so `git add .env.local && git commit` is permitted. Deny rules miss `.env`,
`.env.production`, and service-account JSON.
**Fix:** Add a `PreToolUse` hook on `Bash(git commit*|git add*)` that greps staged files for
`.env*`, `*serviceAccount*.json`, and key patterns (`sk_live_`, `whsec_`, `napi_`, PEM) and
blocks with non-zero exit. Widen the deny list. Ensure init writes a covering `.gitignore`.

### JAIRUS-007 · Neon MCP has no read-only guardrail (can delete projects / drop tables)
`severity:high` `area:security`
**Problem:** Supabase MCP runs `--read-only`; Neon MCP has no equivalent and can run destructive
DDL / delete projects, mitigated only by prose.
**Fix:** Enable a read-only/scoped default mode; require explicit opt-in for migration application;
recommend a project/branch-scoped API key; add a hard gate before any Neon write/DDL/delete.

### JAIRUS-008 · Firebase auth contradicts the HTTP-only-cookie mandate; Server Components can't auth
`severity:high` `area:security`
**Problem:** `getSession(request)` reads an `Authorization: Bearer <idToken>` header → token must
live in JS-accessible storage (XSS-exposed), violating the HTTP-only-cookie requirement. The
canonical protected page is a Server Component calling `getSession()` with no request → no working
auth path.
**Fix:** Use Admin-SDK session cookies (`createSessionCookie`/`verifySessionCookie`) stored
HTTP-only; make `getSession()` read the cookie via `cookies()` so it works in Server Components,
Route Handlers, and middleware — matching Supabase/Neon.

### JAIRUS-009 · INTENT.md approval flags are forgeable (no provenance)
`severity:high` `area:gate`
**Problem:** Ordering depends on booleans written by the orchestrator and read back by the next
stage — no signature, timestamp, approver, or gate ref. Setting `design_approved: true` unlocks
develop; `code_review_passed: true` unlocks deploy.
**Fix:** Add provenance sub-fields (`*_approved_by`, `*_approved_at`, `review_score`, `gate_ref`);
downstream commands refuse to proceed if a flag is true but provenance is absent.

### JAIRUS-010 · Safety-critical preconditions are non-executable prose
`severity:high` `area:gate`
**Problem:** Only `board.md` has a real grep precondition; design/develop/review/deploy express
their input contracts as prose tables, so design-before-develop and review-before-deploy depend on
the model choosing to check.
**Fix:** Give each command a concrete grep-against-INTENT.md verification block that must run and
pass before dispatch; fail closed on ambiguity.

### JAIRUS-011 · Reviewer score and blocker_count are self-reported and trusted verbatim
`severity:high` `area:gate`
**Problem:** The ≥8-and-no-BLOCKER gate is evaluated on the reviewer's own top-level `score` and
`blocker_count`; the orchestrator does not re-derive them from the dimension/finding tables.
**Fix:** Have the orchestrator recompute the verdict from returned `dimensions[]`/`findings[]`
(count BLOCKER findings, force score ≤7 if any exist), and reject reports where `blocker_count`
disagrees with the findings or `score ≥ 8` coexists with a BLOCKER.

---

## Medium

### JAIRUS-012 · Stripe webhook idempotency is non-atomic (TOCTOU)
`severity:medium` `area:security` — `skills/stripe/SKILL.md`
check-then-mark lets concurrent retries double-process. Fix: `INSERT event.id … ON CONFLICT DO
NOTHING` before handling; treat unique-violation as already-processed.

### JAIRUS-013 · Firebase broad `allow write` defeats the field-validated `create` rule
`severity:medium` `area:security` — `skills/firebase/SKILL.md`, `rules/security.md`
Rules are OR-combined, so a broad `write` permits create/update without the `ownerUid`/shape
checks. Fix: enumerate read/create/update/delete separately; drop the catch-all `write`.

### JAIRUS-014 · Over-broad permissions in settings.json
`severity:medium` `area:security` — `templates/settings.json`
Unscoped Read/Edit/Write + `Bash(npx *)` (arbitrary code) + `Bash(git *)` (`push --force`); deny
rules trivially bypassable. Fix: scope Read/Edit/Write away from secret files; narrow git/npx.

### JAIRUS-015 · Supabase MCP `--read-only` contradicts apply_migration instructions
`severity:medium` `area:security` — `templates/mcp.json`, `rules/mcp-usage.md`, `skills/supabase/SKILL.md`
The shipped read-only server can't apply migrations, pushing users to unaudited apply paths.
Fix: document the sanctioned apply path (gated write-enabled invocation, or `supabase db push`).

### JAIRUS-016 · Neon API key passed as a CLI argument
`severity:medium` `area:security` — `templates/mcp.json`, `.mcp.json`
`start ${NEON_API_KEY}` in argv is visible via `ps`/`/proc`. Fix: pass via `env` if supported.

### JAIRUS-017 · mcp-usage.md mislabels backend-schema gate as Gate 5 (should be Gate 4)
`severity:medium` `area:consistency` — `rules/mcp-usage.md` (supabase, firebase sections)
Contradicts `pipeline.md`/`help.md` (Gate 4 = schema, Gate 5 = live Stripe). Fix: change to Gate 4.

### JAIRUS-018 · doctor.md allowed-tools omits `mcp__neon__*`
`severity:medium` `area:consistency` — `commands/doctor.md`
Step 4 tests Neon connectivity but can't call the tool. Fix: add `mcp__neon__*` to frontmatter.

### JAIRUS-019 · doctor.md plugin-integrity counts are stale
`severity:medium` `area:consistency` — `commands/doctor.md`
Lists 5 agents (missing `extender`) and 7 skills (missing ai/email/feature-flags). Fix: correct
the expected sets.

### JAIRUS-020 · plugin.json / marketplace.json descriptions omit Neon
`severity:medium` `area:consistency` — `.claude-plugin/*`, `.jairus/.claude-plugin/plugin.json`
User-facing strings still say "Supabase or Firebase". Fix: "Supabase, Firebase, or Neon"; add
`neon` keyword.

### JAIRUS-021 · CLAUDE.md and README describe a two-backend harness
`severity:medium` `area:consistency` — `CLAUDE.md`, `README.md`
CLAUDE.md is authoritative context every session; it omits Neon in the backend table, skills list,
and overview. Fix: add Neon throughout.

### JAIRUS-022 · Fix-loop iteration/decline counters live only in model memory
`severity:medium` `area:gate` — `rules/pipeline.md`, `rules/quality-gate.md`
Not persisted; can drift/reset across a long `/jairus:ship` run. Fix: persist per-feature counters
in CHECKLIST.md/INTENT.md; read/increment/write each round.

### JAIRUS-023 · Designer `[BLOCKS GATE]` / open-questions not grep-enforced
`severity:medium` `area:gate` — `agents/designer.md`, `commands/design.md`
Gate 3 exit says open questions block it, but only `{{` and `AC-[0-9]` are grepped. Fix: add a grep
for unresolved markers that fails the gate automatically.

### JAIRUS-024 · Gate 7/8 + ship batching harden together with JAIRUS-004
`severity:medium` `area:gate` — `commands/deploy.md`, `commands/ship.md`
Self-satisfiable staging checkbox and batched gates amplify the enforcement gap. Fix: require a
quotable human confirmation naming the staging URL before Gate 8; ship delegates to hardened gates.

---

## Low

### JAIRUS-025 · `getSession()` naming invites the unvalidated-JWT mistake (Supabase)
`severity:low` `area:security` — rename to `requireUser()`/`getAuthenticatedUser()`; comment that
it must call `getUser()`, never the SDK's `getSession()`.

### JAIRUS-026 · No rate-limit / CSRF reference implementation
`severity:low` `area:security` — security.md requires them but no skill shows one. Add an
Upstash/@vercel/kv sliding-window example on `/api/auth/*` + billing; show Better Auth
`trustedOrigins`.

### JAIRUS-027 · migrations.yml has no active Neon job
`severity:low` `area:consistency` — Neon migration CI is commented-only; the active job is
Supabase-specific. Fix: ship a real Neon job or generate per-backend at init.

### JAIRUS-028 · Firebase MCP env differs between plugin and template configs
`severity:low` `area:consistency` — `.jairus/.mcp.json` passes `FIREBASE_TOKEN`; template does not.
Fix: align the firebase `env` block.

### JAIRUS-029 · Dangling reference to `/jairus:health`
`severity:low` `area:consistency` — `rules/mcp-usage.md`. No such command. Fix: use `/jairus:doctor`.

### JAIRUS-030 · Reviewer BLOCKER list narrower than quality-gate.md
`severity:low` `area:gate` — `agents/reviewer.md` under-tags vs `quality-gate.md`. Fix: reference
quality-gate.md's BLOCKER catalog as the single source of truth.

---

## Suggested close order for the pipeline

1. **Critical block (001–004)** — do not build real apps until these are fixed; 001 and 002/003
   are data-leak / irreversible-action risks.
2. **High (005–011)** — 005 is a quick correctness fix; 006–008 are security; 009–011 harden gates.
3. **Medium (012–024)** — security hardening + consistency cleanup.
4. **Low (025–030)** — polish.

Note: 004, 022, 024 share a root cause (unenforced approval) — fixing 004 first makes 022/024
smaller. 001 and 007/016 all touch the Neon backend and can be batched.
