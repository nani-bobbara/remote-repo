# CLAUDE.md
<!-- Auto-loaded by Claude Code every conversation. Keep it concise — every line is read every time. -->

# Agentic Micro-SaaS Harness — jairus plugin

## What this repo is

The **harness itself**, not a product. No `package.json`, `src/`, or migrations exist until you run `/jairus:init`. The whole repo is the `.jairus/` plugin plus wiring:

```
CLAUDE.md · README.md · .claude/ · .claude-plugin/
.jairus/
├─ commands/   doctor · init · board · design · develop · review · deploy · ship · extend · help
├─ agents/     planner · designer · developer · reviewer · deployer · extender
├─ skills/     nextjs · stripe · vercel · github · neon · ai · email · feature-flags · theming
├─ rules/      pipeline · quality-gate · security · development · design-workflow · adoption · mcp-usage · state-model · foundation
└─ templates/  INTENT.md · jairus.json · env.example · design.md · mcp.json · feature/ · database/ · ci/ · extensions/ · observability/
```

Two kinds of work:
1. **Build a product** — run `/jairus:*` commands. Claude orchestrates; specialist subagents do the work. All output (`INTENT.md`, `docs/`, `.github/`, app code) goes into the project, never into `.jairus/`.
2. **Edit the harness** — change files under `.jairus/`. Run `/reload-plugins` after edits. Plugin files use `${CLAUDE_PLUGIN_ROOT}` (not relative paths).

## The 10 Commandments

```
I.    /jairus:doctor   [--check|--feature n]  Diagnose machine readiness, fix credentials  ← run first
II.   /jairus:init     [context]              Smart entry: auto-detects new vs existing repo  🚦
III.  /jairus:board    [--refresh]            Create/refresh GitHub Project board             🚦
IV.   /jairus:design   <feature>              Designer → 7 artifacts → review ≥8/10           🚦
V.    /jairus:develop  <feature>              Implement (requires approved design)             🚦
VI.   /jairus:review   [feature]              Code-review ≥8/10 → pre-merge handover          🚦
VII.  /jairus:deploy   [feature]              Vercel preview → staging → production            🚦
VIII. /jairus:ship     [--plan|feature]        Full pipeline loop in dependency order
IX.   /jairus:extend   <extension>            Add: ai | email | feature-flags
X.    /jairus:help     [command]              CLI-style help
```

`/jairus:init` detects context: blank repo → new project interview; code present → adoption audit.
Reviews scored /10 (pass ≥ 8) with autonomous fix-loop. Humans approve 🚦 gates.
Full stage/actor/gate definition: `.jairus/rules/pipeline.md`.

## Foundation-first

`/jairus:init` runs a gated, verified **Foundation phase** (F0–F-VERIFY) that provisions the whole
delivery platform — GitHub repo + Project, monorepo, agent skills, Neon Postgres, two Vercel
projects (portal + admin), Stripe, secrets, CI — and stands up a **deployed portal + admin walking
skeleton with working auth BEFORE any product feature**. Provisioning uses the vendor CLIs
(`gh`, `npx neonctl@latest`, `npx vercel@latest`, `stripe`, `npx create-next-app@latest`) plus the
browser-OAuth MCP servers. Feature stages (`design`/`develop`/`review`/`deploy`) refuse to run
until `jairus.json → project.foundation.status == "green"`. Full definition: `.jairus/rules/foundation.md`.

## State & control plane

Three layers own different things — never duplicate (full rule: `.jairus/rules/state-model.md`):

- **`docs/INTENT.md`** — the write-once **seed** (idea + requirements + backend + initial breakdown). Archival/stale once the board exists; never a live tracker. It does **not** hold progress flags — `design_approved` / `code_review_passed` are retired.
- **GitHub Project** — the **source of truth** for feature/stage status. A gate approval is a **human moving the card** across columns: `Backlog → Design → Design Approved → Develop → Review → Review Passed → Deploy → Done`.
- **`jairus.json`** (project root) — the plugin's **control footprint**: version anchor + `project.foundation.status` + board pointer + resume cursor + cached snapshot. Written by `/jairus:init`, updated on every Foundation step and stage transition. Committed but inert — the app builds and runs WITHOUT it. A dead/compacted session resumes from it (version check → reconcile against board + git/files → report next action).

**Per-persona model selection** (token efficiency): planner + deployer = Haiku (mechanical), developer + extender = Sonnet, designer + reviewer = Opus (highest-judgment — reserve the strongest model for design + review).

## Build / test / lint

These scripts don't exist until `/jairus:init` scaffolds the Next.js app:

```
npm run dev          # local dev server
npm run type-check   # tsc --noEmit — strict, zero errors (no `any`)
npm test             # unit/integration/component; single: npm test -- <pattern>
npm run build        # production build; required before deploy
```

A `PostToolUse` hook runs `npm run type-check` after every Edit/Write (silent no-op until the app exists).

## Enabling the plugin

Plugin is enabled in `.claude/settings.json` (`enabledPlugins`). If the marketplace isn't registered:

```
/plugin marketplace add .
/plugin install jairus@jairus-plugin     # if not auto-enabled
```

## Tech stack

Fixed core + fixed Neon backend, provisioned at `/jairus:init`:

| Layer | Technology | Notes |
|-------|-----------|-------|
| Frontend | Next.js 14+ App Router, TypeScript, TailwindCSS + **shadcn** (tweakcn theme, no hardcoded colors) | fixed |
| API | Next.js route handlers | fixed |
| Payments | Stripe | fixed |
| Hosting | Vercel — **two projects** (portal + admin), deployed independently | fixed |
| Backend | **Neon serverless Postgres** (fixed — no host profiles) — Drizzle ORM + Better Auth + two-layer security over a single `DATABASE_URL`. Skill: `.jairus/skills/neon`. | fixed |

**Monorepo topology** (pnpm workspace + turborepo): shared `packages/{db,auth,core}` (`@app/db`,
`@app/auth`) drive one Drizzle schema + Better Auth for migrations AND both apps; `apps/{portal,admin}`.
Portal = public/read-heavy (Neon replica, open email + Google signup); admin = restricted/write-heavy
(Neon primary, seeded admin + forced first-login reset, no self-signup, `requireAdmin` on every route).

Extensions (additive, never remove): `ai` · `email` · `feature-flags` — added via `/jairus:extend`.
Optional opt-in observability (OTel → Grafana Cloud, off by default) lives in `.jairus/templates/observability/`.

## Connected MCP servers

The project `.mcp.json` is generated at `/jairus:init` from `.jairus/templates/mcp.json` —
there is no plugin-level `.mcp.json`. Rules in `.jairus/rules/mcp-usage.md`. Prefer these
over hand-written platform calls. **Auth:** stripe, github, vercel, and neon are remote HTTP
servers using **browser OAuth** (`claude mcp login <server>`, no tokens). MCP is for in-session
reads/ops; provisioning is done by the vendor CLIs (see Foundation-first above).

| Server | Use it to… |
|--------|-----------|
| **stripe** | Create/inspect products, prices, coupons; read customers, subscriptions, invoices |
| **vercel** | List projects, inspect deployments, read build/runtime logs, get preview URLs |
| **github** | Create repo, open branches/PRs, commit CI workflows, read CI status |
| **neon** | Inspect schema, run/apply SQL + migrations, branch per preview, verify RLS |

## Project Overview

<!-- BOOTSTRAP:PROJECT_OVERVIEW:START -->
<!-- Generated by /jairus:init from INTENT.md. Do not hand-edit; re-run /jairus:init. -->

**Status**: Not yet bootstrapped. Run `/jairus:init` to describe your product.

_Until bootstrapped, this is a foundation-first Next.js + Stripe + Vercel SaaS harness with a
Neon Postgres backend (Drizzle + Better Auth over a single `DATABASE_URL`) in a portal + admin
monorepo. `/jairus:init` provisions and verifies a deployed walking skeleton before any feature._
<!-- BOOTSTRAP:PROJECT_OVERVIEW:END -->

## Non-negotiables

- Never skip a 🚦 approval gate — see `.jairus/rules/pipeline.md`.
- Never write code before design is approved (Gate 3).
- Never commit secrets or `.env.local`.
- TypeScript strict mode, zero `any` — enforced by type-check hook.
- Every user-data table is protected by two-layer security: mandatory app-layer `userId` scoping (Layer 1) + defense-in-depth Postgres RLS with `FORCE` and fail-closed defaults (Layer 2), before data is written.
- Always verify Stripe webhook signatures — never trust unverified webhook payloads.
- Prefer MCP tools for database, payments, hosting, and repo operations.
- Design artifacts come from `.jairus/templates/`; tech knowledge lives in `.jairus/skills/<name>/SKILL.md`.
