# Quality Gate — Scoring, Fix-Loops, and Pass/Fail Rules

This is the authoritative reference for all scored reviews in the pipeline. The same
mechanism runs after Stage 2 (design review) and after Stage 3 (code review).
Gate numbers and escalation routing are defined in
`${CLAUDE_PLUGIN_ROOT}/rules/pipeline.md`.

---

## How the Gate Works

1. The `reviewer` agent scores the producer's output **/10** across the stage's dimensions.
2. The reviewer returns a **structured score table** plus a **findings list**.
3. **Pass (≥ 8/10):** Orchestrator presents score + summary → 🚦 human approves the handover.
   The approval is recorded by moving the board card to the gate column (Design Approved / Review
   Passed) and updating `jairus.json` — never by setting a flag in `INTENT.md`. See
   `${CLAUDE_PLUGIN_ROOT}/rules/state-model.md` and `pipeline.md` for the exact handover.
4. **Fail (< 8/10):** Findings go back to the producer (designer or developer) → producer fixes → reviewer re-scores.

---

## Pass Threshold

**≥ 8/10 is required to pass.** This threshold applies to both design review and code review.

**Hard blocker rule:** Any single finding tagged `[BLOCKER]` caps the overall score at **7/10**,
regardless of how well all other dimensions score. A score of 7 is always a fail.

A `[BLOCKER]` is a finding severe enough that shipping the work as-is would cause one of:
- Data exposure (missing app-layer userId scoping, missing RLS + FORCE, exposed DATABASE_URL/BETTER_AUTH_SECRET)
- Security vulnerability (SQL injection, missing Stripe signature verification, hardcoded secret)
- Broken build (`pnpm build` fails, TypeScript errors, failing tests)
- Broken core functionality (an AC from the PRD is not implemented)
- Regulatory/legal risk (PII logged or stored insecurely)

---

## Fix-Loop Mechanics

The fix → re-review loop runs **autonomously** — the human is not consulted each round.

```
reviewer scores ─▶ < 8 ─▶ findings sent to producer ─▶ producer fixes ─▶ reviewer re-scores
                    ↑_______________(max 3 iterations)__________________|
                   ≥ 8 ─▶ orchestrator presents to human at gate
```

- **Max 3 iterations.** After the 3rd failed review, stop and escalate to the human.
- Every iteration is logged: score trend, what changed, which findings remain.
- The reviewer does not receive memory of prior iterations — it scores the current state fresh.
  The orchestrator tracks iteration count and aggregates findings across rounds.

### Escalation after 3 failures

Present to the human:

```
⛔ ESCALATION — [feature] · [review type]
Score after 3 iterations: [N/10]
Still blocking:
  [findings that appeared in ALL 3 iterations — highest priority]
  [findings that appeared in 2/3 iterations]
  [findings that appeared in 1/3 iterations]
Options:
  A) Give the agent specific direction and continue
  B) Accept the work as-is (explicit override, noted in CHECKLIST.md)
  C) Drop this feature from the current iteration
```

---

## Reviewer Behaviour

- The reviewer is **always read-only** — it never writes, edits, or fixes code or artifacts.
- The reviewer scores what exists, not what was intended.
- The reviewer must provide an **actionable fix suggestion** for every finding (not just a
  description of the problem).
- The reviewer must check the actual live state when relevant (e.g., verify RLS is enabled +
  FORCE via `pg_tables`/`pg_policies` — through the neon MCP).

---

## Score Table Format

The reviewer returns this exact structure:

```
## Review Result — [feature] · [design|code] · Iteration [N]

| Dimension | Score | Finding |
|-----------|-------|---------|
| [Dimension 1] | N/10 | One-line summary or "No issues" |
| [Dimension 2] | N/10 | ... |
| ... | | |

**Overall: N/10** [PASS | FAIL]
[BLOCKER present: yes/no — if yes, list which finding and why it's a BLOCKER]

### Findings

**[BLOCKER|HIGH|MEDIUM|LOW]** `file/path:line` — [description]
Fix: [specific, actionable instruction]

...
```

---

## Design Review Dimensions (7)

Applied after Stage 2 to `docs/features/<feature-name>/`.

Score each dimension: count how many binary checks pass, then scale to 0–10.
**Any check marked [BLOCKER] that fails caps the entire dimension at 0 and the overall at 7.**

### 1 · Completeness
- [ ] All 7 artifact files exist: PRD.md, DESIGN.md, API.md, DATABASE.md, COMPONENTS.md, ADR.md, CHECKLIST.md
- [ ] No `<!-- NOTE:` placeholders remain in any artifact (template guidance was replaced with real content)
- [ ] No empty sections — every heading has substantive content beneath it
- [ ] CHECKLIST.md Phase 1 items are all present and unchecked (they should be unchecked at this stage)
- [ ] [BLOCKER] PRD.md has at least one user story and at least one numbered acceptance criterion

### 2 · Feasibility
- [ ] Every technology decision uses only the locked stack (Next.js 14, TypeScript strict, Tailwind, locked backend, Stripe, Vercel)
- [ ] No new npm packages introduced without a corresponding ADR entry explaining why
- [ ] No contradictions between DATABASE.md and INTENT.md data model overview
- [ ] Every API endpoint in API.md is implementable using Next.js route handlers (no custom server required)
- [ ] [BLOCKER] No dependency on a service, tool, or API not in the locked stack without an approved ADR entry

### 3 · Security & Access Control
- [ ] Every API endpoint in API.md specifies its auth method (authenticated / public / webhook-only)
- [ ] Every user table in DATABASE.md specifies **Layer 1** — a scoped repo function filtering by the session `userId`
- [ ] Every user table in DATABASE.md specifies **Layer 2** — RLS `ENABLE` + `FORCE` with a fail-closed policy keyed on `current_setting('app.user_id', true)`
- [ ] Every admin route in API.md specifies `requireStaff()` and routes cross-user reads through `dbAdmin`/`DATABASE_URL_ADMIN`
- [ ] Stripe webhook endpoint specifies signature verification in API.md (if billing feature)
- [ ] No secrets or credentials referenced in any artifact other than as env var key names
- [ ] [BLOCKER] Any user-data query in DATABASE.md with no `userId` scoping predicate (missing Layer 1) is a BLOCKER; a user table with no RLS + FORCE (missing Layer 2) is a BLOCKER

### 4 · Testability
- [ ] Every acceptance criterion (AC-N) in PRD.md has at least one corresponding test scenario
- [ ] Test scenarios are written in given/when/then form — not vague ("it works") descriptions
- [ ] Happy path, auth-failure, and validation-failure scenarios exist for every API endpoint
- [ ] Every user-facing component in COMPONENTS.md has at least one interaction test scenario
- [ ] [BLOCKER] Any AC that has no test scenario is a BLOCKER — untestable requirements cannot be verified as done

### 5 · Scope fit
- [ ] Every user story maps to something in the feature's `description` from INTENT.md scope contract
- [ ] No API endpoints, components, or data models that appear in the feature's `out_of_scope` list
- [ ] No capabilities that belong to another feature's territory (check `depends_on` features' scope contracts)
- [ ] All must-have capabilities stated in `description` have at least one user story covering them
- [ ] [BLOCKER] Any item explicitly listed in `out_of_scope` that is present in the artifacts is a BLOCKER

### 6 · Design system
- [ ] All color references in COMPONENTS.md use **shadcn theme tokens** (`bg-background`, `text-foreground`, `bg-primary`, `border`, …) from the project theme — no raw hex values (see the `theming` skill)
- [ ] Components are specified as **shadcn components** (not bespoke primitives) where shadcn provides one
- [ ] No arbitrary Tailwind values (`text-[#...]`, `p-[13px]`, `w-[347px]`)
- [ ] Every text/background combination specifies WCAG AA compliance (or notes an explicit exception)
- [ ] Every interactive component has loading, empty, and error states specified
- [ ] [BLOCKER] `docs/design.md` missing entirely — COMPONENTS.md cannot be implemented without design tokens

### 7 · Conformance
- [ ] DATABASE.md uses the Neon template (`templates/database/neon.md`) — Drizzle schema + two-layer security
- [ ] No template sections have been removed or reorganized (reviewers compare headings against templates)
- [ ] All open questions in PRD.md Section 9 have been answered or explicitly deferred with justification
- [ ] Artifact files are at `docs/features/<feature-name>/` — not nested in subdirectories
- [ ] ADR.md has at least one real architectural decision documented (not just the template skeleton)

---

## Code Review Dimensions (5)

Applied after Stage 3 to the diff on the feature branch vs `main`.

Score each dimension: count how many binary checks pass, then scale to 0–10.
**Any check marked [BLOCKER] that fails caps the entire dimension at 0 and the overall at 7.**

### 1 · Correctness
- [ ] Every acceptance criterion (AC-N) from PRD.md is implemented — use `// AC-N` comments to locate each one
- [ ] Every AC-N has a corresponding `// AC-N` comment at the line(s) that satisfy it
- [ ] CHECKLIST.md AC Coverage table is filled in — every AC-N maps to a file:line
- [ ] All error paths return `{ error: string, code: string }` with the correct HTTP status from API.md
- [ ] No silent swallowed errors in catch blocks (must log or return, never empty catch)
- [ ] [BLOCKER] Any AC from PRD.md with no implementation and no `// AC-N` comment anywhere is a BLOCKER

### 2 · Security
- [ ] Every `/api/*` route (except `/api/auth/*` and `/api/webhooks/stripe`) calls `requireUser()` as the first statement
- [ ] All inputs are validated before any database operation (type, shape, range)
- [ ] **Layer 1:** every query against a user table filters by the session `userId` via a scoped repo — no bare user-table queries
- [ ] **Layer 2:** every user table touched has RLS enabled + `FORCE` with a fail-closed policy — verified via `pg_tables` / `pg_policies` (neon MCP)
- [ ] Every admin route calls `requireStaff()` as its first statement; cross-user/system reads go through `dbAdmin`/`DATABASE_URL_ADMIN`, never the `userId`-scoped request client
- [ ] Stripe webhook signature verified with `STRIPE_WEBHOOK_SECRET` (if billing feature); the webhook's un-scoped `dbAdmin` system query is the only allowed Layer 1 exception outside admin routes
- [ ] No secrets, API keys, or tokens in source code — `grep -rn "sk_" src/` returns nothing
- [ ] [BLOCKER] Any unauthenticated route outside `auth/` and `webhooks/` is a BLOCKER
- [ ] [BLOCKER] Any admin route missing `requireStaff()` is a BLOCKER — it exposes all users' data
- [ ] [BLOCKER] Any user-table query with no `userId` scoping predicate (missing Layer 1) is a BLOCKER; any user table without live RLS + FORCE (missing Layer 2) is a BLOCKER

### 3 · Design conformance
- [ ] Every ADR decision from ADR.md is reflected in the code — no silent deviations
- [ ] API endpoints match API.md exactly: path, method, auth, request shape, response shape, error codes
- [ ] Component file locations and props interfaces match COMPONENTS.md
- [ ] Components use **shadcn + theme tokens** throughout — `grep -rn "#[0-9a-fA-F]\{3,6\}" apps/*/src/` returns nothing relevant. A hardcoded hex/color or arbitrary color value in a component is a **quality finding** (not a BLOCKER) — flag it with the fix "replace with the shadcn theme token (see the `theming` skill)"
- [ ] [BLOCKER] Any API endpoint that deviates from the approved contract in API.md is a BLOCKER

### 4 · Test coverage
- [ ] Every utility function and custom hook has a unit test
- [ ] Every API route has integration tests: happy path + unauthenticated (401) + invalid input (400)
- [ ] Every user-facing interactive component has a component test
- [ ] Every AC-N from PRD.md has at least one test that explicitly tests that criterion
- [ ] `pnpm test` passes with zero failures
- [ ] [BLOCKER] Any AC-N with no corresponding test is a BLOCKER

### 5 · Standards
- [ ] `pnpm type-check` passes with zero errors (no `any`, no `as any`, no `@ts-ignore`)
- [ ] `pnpm build` succeeds
- [ ] No `console.log` in `src/` — `grep -rn "console\.log" src/` returns nothing
- [ ] All commits follow conventional commit format: `feat(feature-name): description`
- [ ] JSDoc comment on every exported function
- [ ] Path aliases used (`@/`) — no relative imports crossing component boundaries
- [ ] [BLOCKER] `pnpm type-check` or `pnpm build` failing is a BLOCKER
