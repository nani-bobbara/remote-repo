# Development Rules

This file defines code quality, testing, git workflow, and backend change requirements
for the `developer` agent. Security rules are in `${CLAUDE_PLUGIN_ROOT}/rules/security.md`
and are not repeated here — the developer must read that file before implementing any
backend access control, authentication, or Stripe logic.

---

## Prerequisites

Before writing a single line of code:

1. The feature's board card is in **Design Approved (Gate 3)** or later — read via github MCP
   (the status source of truth, not an `INTENT.md` flag; see `${CLAUDE_PLUGIN_ROOT}/rules/state-model.md`).
2. All `depends_on` features are in the board's **Done** column.
3. Feature branch exists: `feature/<feature-name>` (create via github MCP).

**Never start implementation without an approved design.** If the design is ambiguous,
raise an ⚠️ AMBIGUITY block (see `${CLAUDE_PLUGIN_ROOT}/rules/pipeline.md`).

---

## TypeScript

- **Strict mode is always on.** `tsconfig.json` has `"strict": true` — this is non-negotiable.
- **Zero `any` usage.** Use `unknown` with type guards, or define a proper type.
  A single `any` in the diff is a `[BLOCKER]` in code review.
- **Path aliases** are the workspace package names (e.g., `@app/ui`, `@app/domain`, `@app/adapters`, `@app/auth`). Use them.
- **JSDoc** on all public functions, React components, and exported types/interfaces.
  Minimum: one-line description. Include `@param` and `@returns` for non-obvious signatures.

---

## Code Organization

```
apps/portal/                # (and apps/admin) — no src/ inside apps
  app/
    api/
      <resource>/
        route.ts          # API route handler
      auth/               # Auth endpoints — no session validation required
      webhooks/
        stripe/
          route.ts        # Stripe webhook — signature verification required
    (app)/                # Next.js App Router route groups + page files
      <feature>/
        _components/      # Feature-specific components (route-group local)
    _components/          # App-local shared components
packages/
  ui/src/components       # Shared, reusable UI primitives (@app/ui, design system)
  domain/                 # Entities, ports, data-driven RBAC (@app/domain)
  application/            # Use-cases (@app/application)
  adapters/               # Vendor SDKs, DB, auth impl, Stripe, Resend, ai, flags (@app/adapters)
                          #   startup env validation lives here (and packages/config)
  auth/                   # Guards: requireUser / requirePermission / requireStaff (@app/auth)
```

**Server vs. Client Components:**
- Default to **Server Components**. They have access to the backend, avoid hydration
  cost, and keep secrets server-side.
- Add `"use client"` only when the component requires:
  - `useState` or `useReducer`
  - `useEffect` or lifecycle-dependent hooks
  - Browser APIs (`window`, `localStorage`, event listeners)
  - Third-party client libraries (e.g., a charting library)
- The component specification in COMPONENTS.md states whether each component is
  Server or Client — follow it. If the spec is wrong, raise an ⚠️ AMBIGUITY block.

---

## Error Handling

- **API error shape:** Always `{ error: string, code: string }`. Never return stack
  traces, database error messages, or internal state in API responses.
- **HTTP status codes:** 400 (validation), 401 (unauthenticated), 403 (unauthorized),
  404 (not found), 409 (conflict), 422 (unprocessable), 500 (server error).
- **No `console.log` in production code.** Use structured logging if required, or remove.
  `console.error` is acceptable for unexpected server errors — but never log secrets or PII.
- **Client-side errors:** Display user-friendly messages. Never expose internal error
  details in the UI.

---

## Testing Requirements

Every AC from the PRD must have at least one test. This is the minimum bar — not the target.

| Test type | What it covers | Location |
|-----------|---------------|----------|
| Unit | Utilities, use-cases, domain logic — pure logic | co-located `__tests__/` under `packages/*/src/**` (e.g. `packages/application/src/**/__tests__/`, `packages/adapters/src/**/__tests__/`) |
| Integration | API routes — full request/response cycle | `apps/portal/app/api/**/__tests__/` |
| Component | User-facing components — render and interaction | co-located `__tests__/` next to components (`apps/portal/app/**/__tests__/`, `packages/ui/src/**/__tests__/`) |

**Every API route integration test must include:**
- Happy path (valid input, authenticated user)
- Auth failure (no session or invalid session → 401)
- Validation failure (malformed input → 400 or 422)

**Test command:** `pnpm test`
All tests must pass before creating the PR. A failing test is a `[BLOCKER]` in code review.

---

## Backend Changes — Neon Postgres (Drizzle migrations)

The backend is Neon serverless Postgres (Drizzle ORM + Better Auth). Schema and migrations are
owned by the `packages/adapters` package (`@app/adapters`) and deployed by CI (see
`${CLAUDE_PLUGIN_ROOT}/rules/mcp-usage.md` and `${CLAUDE_PLUGIN_ROOT}/skills/neon/SKILL.md`).

1. **Inspect current schema** before writing any migration — via the `neon` MCP.
2. Edit the schema in `packages/adapters/src/db/schema.ts`, then **generate** the migration:
   `pnpm db:generate` (`drizzle-kit generate`) → review the SQL in `packages/adapters/drizzle/`.
   **Append the RLS statements** (Section below) to the
   generated file so a table never ships without RLS. Migrations are **append-only** — never edit
   an applied one; generate a new migration to correct it.
3. Define RLS on every user table: `ENABLE ROW LEVEL SECURITY` **plus** `FORCE ROW LEVEL SECURITY`
   (FORCE closes the owner-bypass fail-open hole), with a fail-closed policy keyed on
   `user_id = current_setting('app.user_id', true)` (see `${CLAUDE_PLUGIN_ROOT}/rules/security.md`).
4. 🚦 **Gate 4 required** before applying to main. Test on a Neon **branch** first.
5. After Gate 4 approval, apply: `pnpm db:migrate` (`drizzle-kit migrate`, runs against
   `DATABASE_URL_ADMIN`; CI applies it on deploy).
6. **Verify:** run `SELECT tablename, rowsecurity FROM pg_tables;` and `SELECT * FROM pg_policies;`
   and confirm RLS is enabled + FORCE for every new user table — via the `neon` MCP. "Applied"
   without this check is not complete.
7. TypeScript row types are **inferred** from the Drizzle schema
   (`typeof table.$inferSelect`) — never hand-written and never separately generated.

Access user data only through the scoped repository functions in `packages/adapters` that filter by
the session `userId` via `withUser` (Layer 1). A query against a user table with no `userId`
predicate, or a table without RLS + FORCE, is a `[BLOCKER]` in code review. Cross-user and system
reads use the privileged `dbAdmin` client (`DATABASE_URL_ADMIN`) and, on admin routes, must sit
behind `requireStaff()` — a missing `requireStaff()` on an admin route is a critical `[BLOCKER]`.

---

## Git Workflow

- **Branch name:** `feature/<feature-name>` (matching the `name` field in `INTENT.md`)
- **Commit message format:** conventional commits — `feat(<feature>): <description>`
  - `feat`: new functionality
  - `fix`: bug fix
  - `test`: adding or correcting tests
  - `refactor`: code change that neither fixes a bug nor adds a feature
  - `chore`: dependency updates, config changes
- **Commit frequently** — at logical checkpoints, not just at the end.
- **Push regularly** — at minimum after each significant milestone (data layer done, API done, etc.)
- **Create PR via github MCP** when ready for review.
- **PR description must reference** the design docs: link to `docs/features/<feature-name>/PRD.md`
  and note the design review score.

---

## AC Traceability Convention

Every acceptance criterion (AC-N) from PRD.md must be traceable to the code that satisfies it.

**Rule:** Add a `// AC-N` comment on the function, route handler, or component that satisfies
each acceptance criterion. The comment goes on the line of the `export` or `function` declaration —
not inside the implementation body.

```typescript
// AC-3: user can only delete their own items
export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  ...
}

// AC-7, AC-8: items list is paginated and filterable by status
export function ItemList({ page, status }: ItemListProps) {
  ...
}
```

After completing all layers, fill in the **AC Coverage table in CHECKLIST.md** (see template).
The reviewer checks this table to verify coverage without reading every file.

**Why this matters:** Without AC comments, a reviewer must read the entire diff to determine
whether AC-5 was implemented. With them, a grep for `AC-5` gives the answer in one second.
The convention costs one comment per function — the traceability payoff is permanent.

---

## Build Validation

Run all three before creating the PR — all must pass:

```bash
pnpm type-check    # tsc --noEmit — zero errors required
pnpm test              # all tests pass
pnpm build         # production build succeeds
```

A PR that fails any of these three will fail code review immediately (Dimension 5 · Standards).

---

## Scoped CLAUDE.md Files

The developer writes two scoped `CLAUDE.md` files during implementation to provide
per-directory context for future contributors:

- `apps/portal/app/api/CLAUDE.md` — API route conventions: auth pattern used, error shape,
  validation library, common imports.
- `apps/portal/app/_components/CLAUDE.md` — Component conventions: Server vs. Client decision rules,
  design token usage, shared component locations (shared primitives in `packages/ui`).

These are written once per project (during the first feature) and updated if conventions
change. They distil the locked skill knowledge into project-specific guidance.

---

## PR Checklist

Before marking the PR ready for review:

- [ ] All tests pass (`pnpm test`)
- [ ] Zero TypeScript errors (`pnpm type-check`)
- [ ] Production build succeeds (`pnpm build`)
- [ ] No `console.log` in production code
- [ ] No `any` in TypeScript
- [ ] Backend changes applied and verified via MCP
- [ ] Design docs referenced in PR description
- [ ] CHECKLIST.md updated with completed items
- [ ] Conventional commit messages throughout
