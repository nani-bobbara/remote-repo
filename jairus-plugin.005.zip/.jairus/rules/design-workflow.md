# Design Workflow Rules

This file defines what the `designer` agent must produce before any code is written.
The pipeline flow and gate numbers are in `${CLAUDE_PLUGIN_ROOT}/rules/pipeline.md`.
Scoring and fix-loop mechanics are in `${CLAUDE_PLUGIN_ROOT}/rules/quality-gate.md`.

---

## Core Principle

**No code is written before Gate 4 is approved.** This is an absolute rule. The value of
design-first is that it surfaces security, feasibility, and scope problems cheaply —
before a developer has built against a flawed model.

---

## The Seven Required Artifacts

All 7 artifacts must be present and complete in `docs/features/<feature-name>/` before
the design review can pass. "Complete" means no placeholder content, no `TODO`, no `TBD`,
and no empty sections.

### 1. PRD.md — Product Requirements

**Template:** `${CLAUDE_PLUGIN_ROOT}/templates/feature/PRD.md`

Must contain:
- Feature name and one-line description
- User stories in format: "As a [role], I want [action], so that [outcome]"
- Acceptance criteria — specific, testable, one per line (Given/When/Then format preferred)
- Success metrics — how will we know this feature works at scale?
- Dependencies — which other features must be `done` before this one can be built
- Out of scope — explicit list of what this feature does NOT do (prevents scope creep)
- Technical considerations — constraints, performance requirements, known risks

### 2. DESIGN.md — UX and Architecture

**Template:** `${CLAUDE_PLUGIN_ROOT}/templates/feature/DESIGN.md`

Must contain:
- User flows — step-by-step or ASCII diagram showing every path through the feature
- Component hierarchy — which components render which, data flow direction
- State management — where state lives (server vs. client), how it is fetched and mutated
- Error handling strategy — what happens on API errors, network failures, empty states
- Accessibility requirements — keyboard navigation, ARIA roles, screen reader behavior
- Performance considerations — loading states, skeleton UIs, data fetching strategy
- Security design — auth requirements, what data is exposed, what is gated

### 3. API.md — API Contract

**Template:** `${CLAUDE_PLUGIN_ROOT}/templates/feature/API.md`

Must contain:
- All endpoints: method, path, purpose
- Request schema: headers, body fields with types, required vs. optional
- Response schema: success body, error body (`{ error: string, code: string }`)
- Authentication method for each endpoint (session cookie, webhook signature, or public)
- Error codes used and their meaning
- Rate limiting if applicable
- Example request and response for each endpoint

### 4. DATABASE.md — Data Design

**Template:** `${CLAUDE_PLUGIN_ROOT}/templates/database/neon.md` (one backend — Neon
serverless Postgres).

**The designer must inspect the live backend before writing this artifact.** Inspect via the
`neon` MCP. Design against reality, not against an assumed schema.

Must contain: the **Drizzle schema** (tables, columns, types, constraints; every user-owned table
has `id`, `user_id` → Better Auth `user.id` ON DELETE CASCADE, `created_at`, `updated_at`),
indexes (including `(user_id)`), the **two-layer security** model — Layer 1 scoped repository
functions filtering by the session `userId` (MANDATORY), and Layer 2 RLS with `ENABLE` + `FORCE`
and a fail-closed policy keyed on `current_setting('app.user_id', true)` (defense-in-depth) — the
append-only Drizzle migration (generate → review → migrate), a rollback migration, and a note that
TypeScript row types are inferred from the schema (`typeof table.$inferSelect`).

Any table the feature touches — even read-only — must be accounted for.

### 5. COMPONENTS.md — Component Specifications

**Template:** `${CLAUDE_PLUGIN_ROOT}/templates/feature/COMPONENTS.md`

For each new component:
- File location (`packages/ui/src/components` (`@app/ui`) for shared primitives, `apps/portal/app/(app)/<feature>/_components/` for feature-specific)
- Component type: Server Component or Client Component (and why if `"use client"`)
- Purpose — one sentence
- Props interface — TypeScript interface with types and descriptions
- Styling approach — token names from `tailwind.config.ts`, never raw hex or arbitrary values
- Accessibility — ARIA roles, keyboard behavior, focus management
- Reusability notes — is this component general-purpose or feature-specific?

### 6. ADR.md — Architecture Decision Record

**Template:** `${CLAUDE_PLUGIN_ROOT}/templates/feature/ADR.md`

One entry per significant decision. Each entry contains:
- Decision title
- Context — why a decision was needed
- Decision — what was chosen
- Alternatives considered — at least two, briefly described
- Consequences — trade-offs accepted, future constraints

If there are no significant architectural decisions in a feature, write one entry explaining
why (e.g., "This feature follows established patterns with no novel decisions").

### 7. CHECKLIST.md — Progress Tracker

**Template:** `${CLAUDE_PLUGIN_ROOT}/templates/feature/CHECKLIST.md`

Tracks completion of:
- [ ] All 7 design artifacts complete
- [ ] Design review score ≥ 8/10
- [ ] Gate 4 (design handover) approved
- [ ] Backend schema changes applied and verified
- [ ] API routes implemented
- [ ] UI components implemented
- [ ] Stripe integration (if applicable)
- [ ] Unit tests written and passing
- [ ] Integration tests written and passing
- [ ] Component tests written and passing
- [ ] `pnpm type-check` passes
- [ ] `pnpm build` passes
- [ ] Code review score ≥ 8/10
- [ ] Gate 6 (pre-merge) approved
- [ ] Staging deployed and verified
- [ ] Production deployed

---

## Design System Rules

The project's visual source of truth is `docs/design.md` (generated at `/jairus:init`)
and `tailwind.config.ts`. Both DESIGN.md and COMPONENTS.md — and later the code — must
reference **token names**, not raw values.

**Prohibited in design artifacts and code:**
- Raw hex values: `#3B82F6`, `rgb(59, 130, 246)`
- Arbitrary Tailwind values: `text-[#3B82F6]`, `p-[13px]`, `w-[347px]`
- Values not defined in `tailwind.config.ts`

**Required:**
- Token names from `tailwind.config.ts` (e.g., `text-primary`, `bg-surface`, `border-muted`)
- Every text/background pairing meets **WCAG AA** minimum contrast (4.5:1 for normal text,
  3:1 for large text)

The `reviewer` enforces this in the Design-system dimension of the design review.

---

## Open Questions

**Any unresolved open question in a design artifact blocks Gate 4.**

The designer surfaces questions using this format in the relevant artifact:

```
> ❓ OPEN QUESTION: [question]
> Options: A) [option] B) [option]
> Recommend: [option + reason]
```

The orchestrator presents open questions to the human and waits for answers before
scheduling the design review. A design review with open questions present will fail
the Completeness dimension.

---

## Retrofit Mode (for `/jairus:adopt`)

When a feature has `adopt_status: partial` or `done`, the designer operates in retrofit mode:

- **Describe what currently exists** — do not redesign working code.
- **Identify the specific gaps** — missing RLS policy, missing API validation, missing test, etc.
- **Design only the gaps** — the artifact covers additions, not the whole feature.
- Mark the PRD with `retrofit: true` in the frontmatter.
- The DATABASE.md inspection of the live backend is especially important in retrofit mode —
  the designer must confirm what schema/rules are already deployed before proposing changes.

The reviewer scores retrofit artifacts the same way, but Completeness accounts for the
fact that some sections will describe existing work rather than greenfield design.

---

## Stage 2 Exit Criteria (summary)

A feature exits Stage 2 only when all of the following are true:

1. All 7 artifacts present in `docs/features/<feature-name>/`
2. No placeholder content in any artifact
3. All open questions resolved
4. DATABASE.md was written after inspecting the live backend (via the neon MCP)
5. Design review score ≥ 8/10 (after up to 3 fix-loop iterations)
6. 🚦 Gate 4 approved by the human
