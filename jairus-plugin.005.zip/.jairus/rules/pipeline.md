# Pipeline — Stage Contracts, Actors, Gates, and Orchestration

This is the **authoritative contract registry** for the jairus pipeline.
Every command reads its stage contract from here before dispatching an agent.
Every agent reads its contract section to know exactly what inputs to expect and outputs to produce.

**State & resume:** see `${CLAUDE_PLUGIN_ROOT}/rules/state-model.md`. `INTENT.md` is the
write-once seed; the **GitHub Project is the status source of truth**; `jairus.json` is the
control footprint (version + board pointer + resume cursor). Stage status is read from the
board and written by moving cards — never from progress flags in `INTENT.md`.

---

## Overview

```
Stage 0: Bootstrap ─┐
  /jairus:init       │  Stage 0.5: FOUNDATION (F0–F-VERIFY) ──▶ foundation.status = green ──┐
  (F1 interview)     └─▶  connect accounts · provision (repo · monorepo · Neon · 2 Vercel   │
                          · Stripe · CI · auth+seeded admin) · deploy + verify skeleton      │
                          🚦 Gate F1 · 🚦 Gate F2 · 🚦 Gate F11 · 🚦 Gate F-VERIFY            │
                          see rules/foundation.md                                            │
                                                                                            ▼
Stage 1: Board ──Gate 2──▶ ┌── Feature Loop (dep-ordered) ──┐ ──▶ Stage 5: Deploy
  /jairus:board            │  Stage 2: Design ──Gate 3──▶    │      /jairus:deploy
  planner agent            │  Stage 3: Develop ──Gate 4/5──▶ │      ──Gate 7/8──▶ prod
  GitHub Project           │  Stage 4: Review ──Gate 6──▶    │
                           └─────────────────────────────────┘
```

**Foundation runs once, before the feature loop.** `/jairus:init` (New Project Path) orchestrates
the Foundation phase (F0–F-VERIFY, authoritative spec in `${CLAUDE_PLUGIN_ROOT}/rules/foundation.md`):
it stands up the entire delivery platform — repo, monorepo scaffold, Neon, two Vercel projects,
Stripe, CI, and an auth skeleton with a seeded admin — and deploys + verifies a walking skeleton.
Only when **Gate F-VERIFY** passes is `jairus.json → project.foundation.status = "green"`, which
**unlocks the feature pipeline**. Backend (Neon) and topology (monorepo) are fixed.

`/jairus:ship` drives the full backlog in dependency order. Every 🚦 gate pauses for human approval.

**Foundation precondition (Stages 2–5):** `design`, `develop`, `review`, and `deploy` MUST refuse
to run unless `jairus.json → project.foundation.status == "green"`. If it is not green, stop and
tell the user to complete `/jairus:init` (Foundation) first, pointing at the next incomplete
F-step. Foundation gates are named (F1/F2/F11/F-VERIFY) and are **not** renumbered into the 1–8
feature-gate sequence.

---

## Dispatcher Pattern — How Every Command Works

Every pipeline command is a **thin dispatcher** that follows this exact 4-step sequence.
No pipeline logic, fix-loop logic, or gate logic lives anywhere else.

```
STEP 0 — VERIFY MCP CONNECTIVITY (before every Stage 2–5 dispatch)
  Required servers per stage:
    Stage 1 (board)   : github
    Stage 2 (design)  : neon + github
    Stage 3 (develop) : neon + stripe + github
    Stage 4 (review)  : neon + github
    Stage 5 (deploy)  : vercel + github + stripe + neon
  Test each required server with one lightweight read call.
  If any required server fails: stop —
    "MCP server <name> is not connected. Run /jairus:doctor to diagnose before continuing."
  Do not skip this check — a server failure mid-agent is unrecoverable without this gate.

  Backend is Neon serverless Postgres. Test the neon MCP with one lightweight read
  (list projects/tables) before every Stage 2–5 dispatch.

STEP 1 — VERIFY INPUT CONTRACT
  Read this file. Check each item in the stage's INPUT CONTRACT.
  FIRST (Stages 2–5 only): verify jairus.json → project.foundation.status == "green".
    If not green: stop —
      "Foundation is not green. Run /jairus:init to complete the Foundation phase
       (rules/foundation.md); next incomplete step: <F-step>." Do not dispatch.
  If any item fails: stop with the prescribed error. Do not proceed.

STEP 2 — DISPATCH AGENT
  Dispatch the designated agent. Pass exactly the inputs listed in the stage contract.
  Wait for the agent's structured return. Do not write code or artifacts yourself.

STEP 3 — VERIFY OUTPUT CONTRACT
  Check each item in the stage's OUTPUT CONTRACT / EXIT CRITERIA.
  If any item is missing or fails: see the stage's failure handling rules below.

STEP 4 — PRESENT GATE
  Use the canonical Gate Format (defined below).
  On approval: write the handover state and report success.
  On decline: route back per the gate's decline path.
```

The orchestrator thread **never** writes application code, design artifacts, or test files.
It coordinates, verifies contracts, and manages gates. Agents do the work.

---

## CRAFT Dispatch Envelope

Every agent dispatch must be framed as a complete CRAFT envelope. This eliminates ambiguity
at the agent boundary — the agent never has to infer context, role, or standards from scattered reads.

```
CRAFT DISPATCH
──────────────────────────────────────────────────────────────
Context  : [who, what, where — the full situation the agent operates in]
           • Project: <display_name> — <one_liner>
           • Feature: <name> — <description>
           • Backend: Neon serverless Postgres (hexagonal monorepo: packages/{domain,application,adapters,auth,ui,config} + apps/{portal,admin}, cloned from jairus-starter)
           • Scope contract:
               description : <feature.description>
               out_of_scope: <feature.out_of_scope[]>
           • Current state: <what has been done so far this feature>
           • Live backend state: <what MCP returned, if already read>

Role     : [who the agent is and what it is accountable for]
           • You are the <designer | developer | reviewer | deployer | planner>.
           • You own <artifact production | implementation | scoring | deployment>.
           • You are NOT responsible for <gate decisions | INTENT.md writes | dispatching other agents>.

Action   : [exactly what to do — from the stage contract in this file]
           • Produce: <list of required outputs from the output contract>
           • Order: <implementation order or artifact order if prescribed>
           • Blockers: <any condition that stops work and requires signaling back>

Format   : [the exact shape of the return value]
           • Return the output contract JSON defined in your agent file.
           • Do not summarize or truncate findings.
           • Signal gates via return value, not by presenting them directly.

Tone     : [the standards and rules this agent applies throughout]
           • Rules files to apply: <list from stage contract>
           • Pass threshold: ≥ 8/10 (reviewer) | zero errors (type-check) | all pass (tests)
           • Any BLOCKER finding stops the work; signal it in the return.
──────────────────────────────────────────────────────────────
```

### CRAFT quality invariants

**Context completeness:** An agent that receives an incomplete Context will fill gaps with
assumptions — and assumptions are where quality breaks down. The orchestrator must pass:
- The full scope contract (description + out_of_scope) on every design/review dispatch
- The live backend state when dispatching designer or developer (read MCP first if not already done)
- The diff range on every code-review dispatch

**Role clarity:** Each agent's role declaration explicitly states what it does NOT do.
This prevents scope creep: a reviewer that starts writing fixes, or a designer that approves its own work.

**Action from contract:** The Action field is never written ad-hoc — it is copied directly
from the stage's output contract in this file. The orchestrator does not improvise what the agent should do.

**Format as contract:** The output contract JSON is the shared language between orchestrator and agent.
If an agent's return doesn't match the expected shape, the orchestrator rejects it and re-dispatches.

**Tone as guardrails:** Rules files are not suggestions — they are the quality definition.
The reviewer's scoring dimensions come from `quality-gate.md`. The developer's implementation
standards come from `development.md` + `security.md`. Passing the rules = passing the stage.

---

## Canonical Gate Format

Every gate uses this exact structure — no variation:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🚦 GATE [N] — [NAME]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Stage    : [Stage Name]
Feature  : [feature-name or "all features"]
Agent    : [agent that produced this output]

OUTPUT CONTRACT — Exit Criteria
  ✅ / ❌  [criterion 1]
  ✅ / ❌  [criterion 2]
  ...

REVIEW SCORE (where applicable)
  [dimension table — score / finding — from quality-gate.md]
  Overall: N/10 — PASS ≥ 8 | FAIL < 8

ARTIFACTS / CHANGES (what was produced)
  [structured list of files, migrations, Stripe objects, URLs, etc.]

BLOCKING ISSUES (if any ❌ in exit criteria or BLOCKER findings)
  [list — each one prevents gate approval]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[Exact yes/no question — Yes = approve and advance, No = decline]

✅ Approved → [next stage / action]
❌ Changes needed → [what to revise; which command to re-run]
❌ Stop → [what remains blocked]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Gate rules:**
- An ❌ in any exit criterion is a blocking issue — the gate cannot be approved.
- A BLOCKER finding from the reviewer caps the overall score at 7/10 — gate cannot be approved.
- Only an explicit human message ("approved", "yes", "✅") constitutes approval.
- Implicit or inferred approval is never valid.

---

## Fix-Loop Protocol (shared by Stages 2 and 4)

Stages that include a reviewer fix-loop (Design and Review) follow this protocol:

```
iteration = 1

LOOP:
  dispatch reviewer → returns score N/10 + findings

  if score ≥ 8 AND no BLOCKER:
    → proceed to gate presentation

  if score < 8 OR any BLOCKER:
    if iteration < 3:
      iteration += 1
      dispatch producer-agent with findings (designer for Stage 2, developer for Stage 4)
      producer returns updated artifacts/code
      → LOOP

    if iteration == 3 (cap reached):
      → ESCALATE TO HUMAN:
        present all findings grouped by iteration, mark recurring BLOCKERs,
        ask human to resolve before continuing
        → do not re-dispatch; wait for human guidance
```

The fix-loop runs **autonomously** between iterations — no human involvement until the cap.
The human **only sees** the gate (if score ≥ 8) or the escalation (after 3 failures).

---

## Stage Contract Registry

---

### STAGE 0 — Bootstrap (`/jairus:init`)

| | |
|---|---|
| **Command** | `/jairus:init` |
| **Agent(s)** | orchestrator only (new-project path); `planner` for board step |
| **Rules applied** | `rules/pipeline.md` · `rules/adoption.md` (existing-repo path) |

#### Input contract
| Item | Requirement |
|------|------------|
| MCP authorization | github MCP authorized via browser OAuth (`claude mcp login github`) for the Gate 2 repo step — can be skipped. No credentials are required to start the interview. |
| Git repository | Working directory is inside a git repo |
| INTENT.md | Does NOT exist, OR exists with `status: draft` |

#### Output contract
| Artifact | Requirement |
|----------|------------|
| `docs/INTENT.md` | Written with `status: bootstrapped`, all fields populated |
| `docs/design.md` | Created from template |
| `.env.example` | Created for Neon Postgres (DATABASE_URL + DATABASE_URL_ADMIN + BETTER_AUTH_SECRET + BETTER_AUTH_URL + ADMIN_EMAIL/ADMIN_INITIAL_PASSWORD + GOOGLE_CLIENT_ID/SECRET) |
| `.mcp.json` | Copied from the template: stripe + vercel + github + neon |
| `package.json` | Created with required scripts |
| `CLAUDE.md` | BOOTSTRAP block written |

#### Exit criteria (all must pass before Gate 1)
- [ ] Product intent captured (project_name, display_name, one_liner, persona)
- [ ] Backend is Neon serverless Postgres (fixed — no host choice)
- [ ] Feature breakdown forms a valid DAG (no cycles in depends_on)
- [ ] Every user-defined feature has a non-empty `description` and `out_of_scope`
- [ ] `bootstrap-app`, `auth`, and `billing` included in feature list

#### Gate 1 — Intent and breakdown
Presents: project summary, Neon Postgres backend + monorepo layout, dependency-ordered feature tree
Approves: write INTENT.md + workspace scaffold
Declines: revise intent or breakdown
Stops: workspace not written; re-run `/jairus:init` when ready

#### Handover (after Gate 1 approval)
- `INTENT.md` status → `bootstrapped`
- Next: continue the Foundation phase (Stage 0.5) — F2 resource plan onward

---

### STAGE 0.5 — Foundation (`/jairus:init`, New Project Path)

| | |
|---|---|
| **Command** | `/jairus:init` (New Project Path) |
| **Agent(s)** | orchestrator; `planner` for the board step (F3) |
| **Rules applied** | `rules/foundation.md` (authoritative) · `rules/pipeline.md` · `rules/state-model.md` |
| **Spec** | `${CLAUDE_PLUGIN_ROOT}/rules/foundation.md` — steps F0–F-VERIFY (do not duplicate here) |

Foundation stands up the entire delivery platform and a deployed, verified walking skeleton
**before** any product feature. Fixed stack: Neon backend + hexagonal monorepo topology
(`packages/{domain,application,adapters,auth,ui,config}` + `apps/{portal,admin}`, cloned from
jairus-starter). Each step records `{step: done|failed, at, ref}`
in `jairus.json → project.foundation.steps` — resume-safe: skip `done`, retry `failed`, never
re-create existing resources.

#### Named gates (not renumbered into 1–8)
- **Gate F1** — intent + feature breakdown approved
- **Gate F2** — resource plan approved (before any billable provisioning)
- **Gate F11** — first production deploy of the walking skeleton
- **Gate F-VERIFY** — human confirms the skeleton is live + secure

#### Exit criterion
- [ ] Gate F-VERIFY passes → `jairus.json → project.foundation.status = "green"`

**Until foundation is green, Stages 2–5 refuse to run** (enforced in the Dispatcher Pattern STEP 1).

#### Handover (after Gate F-VERIFY)
- `jairus.json`: `project.foundation.status = "green"`; advance `cursor` to first feature/`board`
- Next: `/jairus:board` → `/jairus:design <feature>` or `/jairus:ship`

---

### STAGE 1 — Board (`/jairus:board`)

| | |
|---|---|
| **Command** | `/jairus:board` |
| **Agent** | `planner` |
| **Rules applied** | `rules/pipeline.md` |

#### Input contract
| Item | Requirement |
|------|------------|
| `docs/INTENT.md` | Exists with `status: bootstrapped` or `status: active` |
| GitHub MCP | Connected with `repo` + `project` scope |

#### Output contract
| Artifact | Requirement |
|----------|------------|
| GitHub Project | Created/refreshed; URL confirmed via github MCP |
| Epics (milestones) | One per SDLC phase |
| Feature issues | One per feature, with `depends_on` labels |
| Columns | Backlog · Ready · In Progress · In Review · Done · Blocked |

#### Exit criteria (all must pass before Gate 2)
- [ ] Board plan previewed (read-only pass) — no GitHub objects created yet
- [ ] All features from INTENT.md mapped to issues
- [ ] Dependency labels applied to blocked features
- [ ] Existing issues de-duplicated (not recreated)

#### Gate 2 — Board write
Presents: board name, epics list, feature issue tree, column assignments, reconciliation with existing
Approves: planner creates/refreshes all GitHub objects
Declines: revise INTENT.md feature list and re-run
Stops: board deferred; user can run `/jairus:board` later

#### Handover (after Gate 2 approval)
- GitHub Project URL recorded in success output
- Each feature issue URL available for `/jairus:design` references
- Next: `/jairus:design <first-feature>` or `/jairus:ship`

---

### STAGE 2 — Design (`/jairus:design <feature>`)

| | |
|---|---|
| **Command** | `/jairus:design` |
| **Agent(s)** | `designer` (produces artifacts) → `reviewer` (scores) — fix-loop per protocol above |
| **Rules applied** | `rules/design-workflow.md` · `rules/quality-gate.md` · `rules/security.md` |

#### Input contract
| Item | Requirement |
|------|------------|
| Foundation | `jairus.json → project.foundation.status == "green"` — hard stop if not (run `/jairus:init` Foundation first) |
| `docs/INTENT.md` | Exists, feature entry present, `status ≠ done` |
| Scope contract | Feature `description` non-empty + `out_of_scope` list present — stop if either missing |
| Dependency check | All features in `depends_on` have `status: done` — stop if any are not done |
| `docs/design.md` | Exists (design tokens) — stop if missing, run `/jairus:init` first |
| Existing artifacts | If the board card is already in **Design Approved** (Gate 3 passed) → retrofit mode only |

#### Output contract
| Artifact | Location | Verified |
|----------|----------|---------|
| PRD.md | `docs/features/{feature}/` | file present + no `{{placeholder}}` content |
| DESIGN.md | `docs/features/{feature}/` | file present |
| API.md | `docs/features/{feature}/` | file present |
| DATABASE.md | `docs/features/{feature}/` | file present |
| COMPONENTS.md | `docs/features/{feature}/` | file present |
| ADR.md | `docs/features/{feature}/` | file present |
| CHECKLIST.md | `docs/features/{feature}/` | file present, Phase 1 items populated |

#### Exit criteria (all must pass before Gate 3)
- [ ] All 7 artifacts present with no placeholder content
- [ ] PRD.md has acceptance criteria numbered `AC-1, AC-2, …` (exact prefix)
- [ ] No unresolved open questions (any `?` section blocks the gate)
- [ ] Design review score `≥ 8/10` (via fix-loop protocol)
- [ ] No BLOCKER findings from reviewer
- [ ] Scope contract honored — no out_of_scope items appear in any artifact

#### Gate 3 — Design handover
Presents: feature, score, score trend across iterations, 7-artifact summary table, key decisions, open questions (must be empty)
Approves: move the board card to **Design Approved (Gate 3)**; update `jairus.json`
Declines: trigger one more fix-loop pass (max 2 additional after gate decline)
Stops: card stays in **Design**; not advanced

#### Handover (after Gate 3 approval)
- Board: move the feature card to **Design Approved (Gate 3)** via the github MCP (status SoT)
- `jairus.json`: update `updated_at`, set `cursor` to this feature/`develop`, refresh the feature's `snapshot`
- Next: `/jairus:develop <feature>`

---

### STAGE 3 — Develop (`/jairus:develop <feature>`)

| | |
|---|---|
| **Command** | `/jairus:develop` |
| **Agent** | `developer` (loads: nextjs skill + stripe skill + neon skill) |
| **Rules applied** | `rules/development.md` · `rules/security.md` · `rules/pipeline.md` |

#### Input contract
| Item | Requirement |
|------|------------|
| Foundation | `jairus.json → project.foundation.status == "green"` — hard stop if not |
| Board column | Feature card is in **Design Approved (Gate 3)** or later — read via github MCP; hard stop if still in Design/Backlog |
| Design artifacts | All 7 present in `docs/features/{feature}/` — hard stop if any missing |
| Feature branch | `feature/{feature-name}` exists or will be created |
| Skills loaded | architecture, auth, nextjs, stripe, neon skill all read before any code written |

#### Output contract
| Artifact | Requirement |
|----------|------------|
| Feature branch | Pushed to GitHub |
| Implementation | Backend → API → UI → Stripe → tests (in this order) |
| `CHECKLIST.md` | Phase 2 (Develop) items checked |
| CLAUDE.md stubs | `apps/portal/app/api/CLAUDE.md`, `apps/portal/app/_components/CLAUDE.md` scoped |
| AC traceability | `// AC-N` comments on every exported fn/route/component satisfying an AC |
| AC Coverage table | In CHECKLIST.md — every AC-N mapped to a test |

#### Conditional gates (raised mid-stage by developer before writing)
**Gate 4 — Drizzle migration** (if any migration or security rules change):
- Presents: Drizzle migration SQL from `packages/adapters`, RLS policies, reversibility note
- Approves: developer applies the Drizzle migration (verified via neon MCP; deployed by CI)
- Declines: developer revises schema design; re-presents Gate 4
- Stop: development pauses at schema step

**Gate 5 — Live Stripe objects** (only if feature involves payments AND live mode):
- Presents: products, prices, webhooks to create in live mode; test-mode status; irreversibility warning
- Approves: developer creates via mcp__stripe__* live mode
- Declines: remain in test mode (deferred to deploy)
- Stop: no live Stripe wiring

#### Exit criteria (all must pass before handover)
- [ ] `pnpm type-check` — zero TypeScript errors
- [ ] `pnpm test` — all tests pass, every AC-N covered
- [ ] `pnpm build` — production build succeeds
- [ ] Backend state verified via MCP (after any schema/rules change)
- [ ] Gate 4 completed if schema changed
- [ ] Gate 5 completed or deferred if payments involved

#### Handover (all exit criteria pass)
- Board: move the feature card to **Review** via the github MCP (status SoT)
- `jairus.json`: update `updated_at`, set `cursor` to this feature/`review`, refresh the feature's `snapshot`
- PR opened on GitHub (reviewed by `/jairus:review`)
- Next: `/jairus:review <feature>`

---

### STAGE 4 — Review (`/jairus:review [feature]`)

| | |
|---|---|
| **Command** | `/jairus:review` |
| **Agent(s)** | `reviewer` (scores code) → `developer` (fixes) — fix-loop per protocol above |
| **Rules applied** | `rules/quality-gate.md` · `rules/security.md` · `rules/development.md` |

#### Input contract
| Item | Requirement |
|------|------------|
| Foundation | `jairus.json → project.foundation.status == "green"` — hard stop if not |
| Feature branch | `feature/{feature-name}` with commits ahead of `main` |
| PR | Open on GitHub |
| Design artifacts | All 7 present — reviewer uses them as the acceptance baseline |
| Build state | `type-check` + `test` + `build` must all pass before review begins |
| Board column | Feature card is in **Design Approved (Gate 3)** or later — read via github MCP |

#### Output contract
| Artifact | Requirement |
|----------|------------|
| Reviewer report | Score table + findings + overall N/10 verdict |
| CHECKLIST.md | Phase 3 (Review) items checked |
| PR description | Updated with score, AC checklist, non-blocking findings |

#### Exit criteria (all must pass before Gate 6)
- [ ] `pnpm type-check` passes
- [ ] `pnpm test` passes
- [ ] `pnpm build` passes
- [ ] Code review score `≥ 8/10`
- [ ] No BLOCKER findings (any BLOCKER caps score at 7 — gate blocked)
- [ ] AC Coverage table in CHECKLIST.md is complete (every AC-N mapped to a test)
- [ ] No hardcoded secrets (`grep` check passes)
- [ ] No `any` type leaks (`grep` check passes)

#### Gate 6 — Pre-merge handover
Presents: feature, branch, score, score trend, files changed, key findings resolved, remaining non-blocking findings, build check summary, PR link
Approves: merge PR, move the card to **Review Passed (Gate 6)**, unlock dependents
Declines: fix-loop continues (max 2 more after gate decline)
Stops: card stays in **Review**; PR stays open

#### Handover (after Gate 6 approval)
- Board: move the feature card to **Review Passed (Gate 6)** via the github MCP (status SoT); this is the gate record
- `jairus.json`: update `updated_at`, set `cursor` to this feature/`deploy`, refresh the feature's `snapshot`
- PR merged to main via github MCP
- Dependent features unlocked (their `depends_on` constraint satisfied by the board column)
- Next: `/jairus:deploy` (or next feature in ship loop)

---

### STAGE 5 — Deploy (`/jairus:deploy [feature]`)

| | |
|---|---|
| **Command** | `/jairus:deploy` |
| **Agent** | `deployer` |
| **Rules applied** | `rules/pipeline.md` · `rules/security.md` |

#### Input contract
| Item | Requirement |
|------|------------|
| Foundation | `jairus.json → project.foundation.status == "green"` — hard stop if not |
| Board column | Feature card is in **Review Passed (Gate 6)** — read via github MCP; hard stop if not |
| PR | Open and ready to merge |
| Vercel MCP | Connected (OAuth) — stop if not connected |

#### Output contract
| Artifact | Requirement |
|----------|------------|
| Preflight | type-check + test + build all exit 0 |
| Staging URL | Vercel preview in `READY` state (confirmed via MCP) |
| Production URL | Vercel production in `READY` state (confirmed via MCP) |
| Backend | All migrations/rules applied and MCP-verified post-merge |

#### Exit criteria (Stage 5a — before Gate 7)
- [ ] `pnpm type-check` passes
- [ ] `pnpm test` passes
- [ ] `pnpm build` passes
- [ ] Vercel preview deployment status = `READY`
- [ ] No build errors in Vercel logs

#### Gate 7 — Staging verification
Presents: feature, preview URL (must be READY), build status, backend migration status, Stripe test-mode status
Approves: proceed to Gate 8 and production
Declines: deployer investigates/fixes, re-deploys preview; re-presents Gate 7
Stops: deployment paused on preview branch

#### Exit criteria (Stage 5b — before Gate 8)
- [ ] Gate 7 approved
- [ ] All changes listed (PR, backend changes marked irreversible, live Stripe objects if any)
- [ ] Human has reviewed staging URL

#### Gate 8 — Production deployment
Presents: PR to merge, feature list, staging approval confirmation, backend changes (irreversibility warning), live Stripe objects if applicable
Approves: merge PR → apply backend changes → create live Stripe objects → deploy to production → poll until READY
Declines: PR stays open on staging branch
Stops: no merge, no production changes

#### Handover (after Gate 8 approval)
- Board: move all deployed feature cards to **Done** via the github MCP (status SoT)
- `jairus.json`: update `updated_at`, advance `cursor` to the next queued feature, refresh the deployed features' `snapshot`
- CHECKLIST.md deployment section marked complete (per-feature working mirror, non-authoritative)
- Next: next feature loop or project is live

---

## Orchestration Rules

**One agent at a time.** Dispatch exactly one specialist agent per step. Wait for its structured return before proceeding.

**Dependency order.** Never start a feature whose `depends_on` features are not in the board's **Done** column (read via github MCP — the status SoT, not an INTENT.md flag).

**Gate discipline.** Never advance past a gate without explicit human approval. Never skip a gate.

**Contract violations block.** If an input contract item is missing, stop with the exact error prescribed. Do not attempt to work around it.

**Fix-loop cap.** After 3 fix-loop iterations without reaching ≥ 8/10, escalate to human. Never loop endlessly.

**CLAUDE.md.** Only edit between `<!-- BOOTSTRAP:PROJECT_OVERVIEW:START -->` and `<!-- BOOTSTRAP:PROJECT_OVERVIEW:END -->` markers.

---

## "Created ≠ Done" — Verification Invariant

**"The command succeeded" is not verification. Confirming resulting state via MCP is.**

| Write operation | Required verification |
|----------------|-----------------------|
| Neon (Drizzle) migration applied | `SELECT tablename, rowsecurity FROM pg_tables; SELECT * FROM pg_policies;` — confirm RLS is enabled + FORCE on every user table (via the neon MCP) |
| Vercel deployment pushed | Confirm build status = `READY` via vercel MCP |
| GitHub issue / PR created | Read the created object back via github MCP |
| Stripe product created | Read the product via stripe MCP |

A stage that cannot be MCP-verified is **not complete** — report the gap explicitly.

---

## Ambiguity Protocol

When an agent cannot derive a decision from INTENT.md, design artifacts, rules, or skills:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚠️  AMBIGUITY — [feature] · [agent role]
Need: [one specific question]
Options:
  A) [option] — [consequence]
  B) [option] — [consequence]
Recommend: [letter] — [one-line reason]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

Never make a silent default on anything affecting architecture, security, or the data model.

---

## Unplanned Work Protocol

Work not on the board does not get started. When an agent discovers unplanned work:

1. Draft an issue: title, why found, acceptance criteria, severity.
2. Stop and wait for human to type `CREATE_ISSUE`.
3. On `CREATE_ISSUE`: create via github MCP, place in dependency graph.
4. Normal gated flow begins.

---

## INTENT.md Schema v2.0

`INTENT.md` is the **write-once seed** — the confirmed idea and initial breakdown. It carries
**no live progress state**: feature/stage status lives on the GitHub Project (SoT) and the
resume cursor lives in `jairus.json`. Do not add `design_approved`, `code_review_passed`, or a
live per-feature `status` here — see `${CLAUDE_PLUGIN_ROOT}/rules/state-model.md`.

```yaml
schema_version: "2.0"
project_name: ""           # kebab-case ≤32 chars
display_name: ""
one_liner: ""              # ≤120 chars
status: draft              # seed lifecycle only: draft | bootstrapped (archival after board is created)
backend: neon              # Neon serverless Postgres — the only backend
stack:
  frontend: nextjs-14
  api: nextjs-api-routes
  payments: stripe
  hosting: vercel
extensions: []             # additive: ai | email | feature-flags
features:
  - name: ""
    display_name: ""
    description: ""        # 1-2 sentences — required before /jairus:design
    out_of_scope: []       # explicit exclusions — required before /jairus:design
    type: foundation        # foundation | feature | billing
    plan: all               # free | basic | pro | all
    depends_on: []
```

`backend` is always `neon` (Neon serverless Postgres — no host choice).
`description` and `out_of_scope` empty = `/jairus:design` blocked (no scope anchor = non-deterministic output).
Live feature/stage status (which of Backlog → Design → Design Approved → Develop → Review →
Review Passed → Deploy → Done a feature is in) is read from the **GitHub Project**, never from this file.
