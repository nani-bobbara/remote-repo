# Security Rules

**This is the single source of truth for all security requirements.**
All other rules files reference this one and do not repeat its content.
The `reviewer` enforces all requirements below during code review (Dimension 2: Security).

---

## Environment and Secrets

**Never commit `.env.local`, `.env.*.local`, or any file containing real secrets.**

- Use `NEXT_PUBLIC_*` prefix only for values that are intentionally public (they are
  inlined into the browser bundle). Never put secrets in `NEXT_PUBLIC_*` variables.
- All required environment variables are validated at **startup** — in the adapters/config
  layer (`packages/adapters`, e.g. where the lazy vendor clients are constructed, and
  `packages/config`) using a schema validator (e.g. Zod). Validation runs on server start,
  not lazily when the code path first executes. A missing required variable must crash
  startup with a clear error message.
- Environment variables for production are configured in **Vercel project settings**.
  They are never set in code, committed to `.env`, or passed via CLI arguments.
- **Never log secrets, PII, or payment data** in any log statement, error message,
  or console output.

---

## Authentication (Neon Postgres — Better Auth)

The backend is **Neon serverless Postgres** with **Better Auth** for sessions
(see `${CLAUDE_PLUGIN_ROOT}/skills/neon/SKILL.md`). Auth lives in the shared `@app/auth`
package (`packages/auth`), consumed by both `apps/portal` and `apps/admin`.

- Auth is a **library (Better Auth)** — sign-up, Google OAuth, and sessions, with users stored
  in Postgres in the Better Auth `user` table. Better Auth mounts its handlers at
  `apps/portal/app/api/auth/[...all]/route.ts` (and the equivalent route in `apps/admin`).
- Validate the session on every server component and API route by calling `requireUser()` (which
  wraps `auth.api.getSession()`) as the **first call in every handler** — never trust a
  client-supplied token blindly.
- `BETTER_AUTH_SECRET` signs sessions, `BETTER_AUTH_URL` is the canonical auth origin (each app
  uses its own origin — portal `http://localhost:3001`, admin `http://localhost:3002` in dev), and
  `DATABASE_URL` (pooled) is the DB connection — all are **server-only**. Never expose them to
  the client; no `NEXT_PUBLIC_` prefix.
- User-owned tables reference the Better Auth `user.id` (a text id). There is no `auth.uid()` —
  user scoping comes from the Better Auth session (see below).

---

## Backend Access Control — TWO layers (non-negotiable)

Postgres RLS alone is **not** sufficient: if the app connects as the table-owner role, Postgres
exempts the owner from RLS unless `FORCE` is set (the classic fail-open trap). So the model is
defense-in-depth with **app-layer scoping as the primary guard**. Full detail:
`${CLAUDE_PLUGIN_ROOT}/skills/neon/SKILL.md`.

### Layer 1 — App-layer authorization (MANDATORY)

- Every query for user data is scoped by the session `userId` via the `withUser` helper. Queries
  go through scoped repository functions (`packages/adapters`) that filter by `eq(table.userId, userId)`.
- **A query against a user table with no `userId` predicate is a `[BLOCKER]`.** This is the
  primary guard.
- The one allowed exception is the privileged `dbAdmin` path (see below): the Stripe webhook acts
  as a system actor and updates subscription state with an intentionally un-scoped query, guarded
  by signature verification (see below); admin cross-user reads go through `dbAdmin` behind
  `requireStaff()`.

### Layer 2 — Row Level Security (defense-in-depth)

- Enable RLS in a Drizzle migration on every user table: `ENABLE ROW LEVEL SECURITY` **plus**
  `FORCE ROW LEVEL SECURITY` — `FORCE` closes the owner-bypass fail-open hole.
- Policies are keyed on a session variable, e.g. `user_id = current_setting('app.user_id', true)`.
  The `true` (missing_ok) makes it **fail-closed** — an unset context returns NULL → zero rows
  rather than leaking. Postgres has no `auth.uid()`.
- Set the context per-request inside a transaction (`select set_config('app.user_id', $1, true)`).
- The request-path client (`DATABASE_URL`) connects as a **non-owner** role so `FORCE` is fully
  effective.
- After every migration, verify RLS is on via
  `SELECT tablename, rowsecurity FROM pg_tables; SELECT * FROM pg_policies;` — via the neon MCP.
  "Migration applied" without this verification is not complete.

### Privileged path — `dbAdmin` / `DATABASE_URL_ADMIN`

- System operations (the Stripe webhook) and legitimate admin cross-user reads use a separate
  privileged client, `dbAdmin`, connected over `DATABASE_URL_ADMIN`. This is the only path that
  is not `userId`-scoped.
- **Every admin route MUST call `requireStaff()` as its first statement.** A missing
  `requireStaff()` on an admin route is a critical `[BLOCKER]` — it exposes every user's data.
  `requireStaff()` validates the session AND checks the `admin:access` permission (resolved from
  the `role` table) before any `dbAdmin` access.
- Never reach for `dbAdmin` on a normal user route — cross-user access outside an admin context
  is a `[BLOCKER]`.

### Data-driven RBAC (roles are DATA, not an enum)

- Roles live in a `role` table (`name`, `permissions text[]`) — they are **not** a hardcoded
  enum. The `@app/domain` package defines the shape (`RoleDef`, `PERMISSIONS`) and the pure
  `can(session, permission)` check; permission strings are `resource:action`.
- Guards (in `@app/auth`): `requireUser()` validates the session; `requirePermission('resource:action')`
  enforces a specific permission; `requireStaff()` is the admin-console guard (equivalent to
  `requirePermission('admin:access')`). All permission checks resolve through `can(session, permission)`.
- `power_user` is the seeded, undeletable superadmin role (`['*']` — all permissions); `regular`
  is the default portal role. Adding a permission to a route means naming a `resource:action`
  string — never editing an enum or a hardcoded role list.

---

## API Routes

**Every route under `/api/*` requires authentication** except:
- `/api/auth/*` — handles auth itself; never requires a pre-existing session
- `/api/webhooks/stripe` — uses Stripe signature verification instead of session auth

All other routes must reject requests without a valid session with HTTP 401.

**Input validation:**
- Validate the shape, type, and ranges of all inputs before any database operation.
- Use a schema validator (e.g. Zod) on the request body and query params.
- Sanitize all user-provided strings before use in any query or downstream system.
- Use parameterized queries (Drizzle handles this; never string-concatenate
  user input into a raw SQL fragment).

**Error responses:**
- Always return `{ error: string, code: string }` — never return stack traces, database
  error messages, or internal state in API responses.
- Use appropriate HTTP status codes: 400 (validation), 401 (unauthenticated), 403
  (unauthorized), 404 (not found), 409 (conflict), 422 (unprocessable), 500 (server error).

**CORS:** Whitelist only known origins. Never use `origin: '*'` on authenticated routes.

**Rate limiting:** Apply rate limiting on all public-facing endpoints, especially auth routes
and any endpoint that triggers an external API call.

---

## Stripe Integration

**Webhook signature verification is mandatory and non-negotiable.**

- Verify every incoming webhook with `stripe.webhooks.constructEvent(body, sig, STRIPE_WEBHOOK_SECRET)`.
- Use the raw request body (not parsed JSON) for signature verification.
- A webhook handler that skips signature verification is an automatic `[BLOCKER]` in code review.

**Idempotency:**
- Webhook handlers must be idempotent. Use the Stripe event ID to deduplicate:
  store processed event IDs and skip re-processing.
- This prevents double-charges, double-credits, and state corruption on retries.

**Price and subscription integrity:**
- Never trust client-supplied price IDs or amounts. Always look up the price from
  your own database or the Stripe API.
- Reconcile subscription state from webhook events, not from checkout redirect parameters.
  Redirect params can be tampered with or arrive out of order.

**Live mode gate:**
- Creating products or prices in Stripe live mode requires 🚦 Gate 5 approval.
  See `${CLAUDE_PLUGIN_ROOT}/rules/pipeline.md`.
- Use `sk_test_*` keys during all development. Never use `sk_live_*` keys in code
  committed to the repository.

**Never log card data, full card numbers, CVCs, or PII fields from Stripe response objects.**

---

## Code-Level Security

| Threat | Requirement |
|--------|-------------|
| Hardcoded secrets | Zero tolerance. No API keys, tokens, passwords, or private keys anywhere in the codebase. Use environment variables validated at startup. |
| SQL injection | Use parameterized queries exclusively. Drizzle ORM parameterizes queries — never build raw SQL strings or interpolate unsanitized user input into `sql\`\`` template fragments. |
| XSS | React's default escaping protects rendered content. Do not use `dangerouslySetInnerHTML` with user-supplied content. Sanitize with a trusted library (e.g. DOMPurify) if raw HTML must be rendered. |
| CSRF | Use Next.js built-in CSRF protections. Set `SameSite=Lax` (minimum) on all cookies. Do not accept state-changing requests via GET. |
| Supply chain | Pin production dependencies. Review dependency additions — each new package is an attack surface. |

---

## Deployment Security

**Security headers** are configured in `next.config.ts`:
```
X-Frame-Options: DENY
X-Content-Type-Options: nosniff
Referrer-Policy: strict-origin-when-cross-origin
Content-Security-Policy: [configured per project]
```

**Branch protection:**
- Never force-push to `main`.
- All changes reach `main` via PR, subject to code review (Gate 6) and CI passing.

**Vercel:**
- Environment variables are set in Vercel project settings per environment
  (development, preview, production).
- Never set production secrets in `.env` files committed to the repo.
- Production deployments happen only after Gate 8 approval
  (see `${CLAUDE_PLUGIN_ROOT}/rules/pipeline.md`).
