# MCP Server Usage Rules

This file defines when and how to use each MCP server. All platform servers are
configured in the project-level `.mcp.json`, copied from
`${CLAUDE_PLUGIN_ROOT}/templates/mcp.json` at `/jairus:init`. There is no plugin-level `.mcp.json`.

The backend is **Neon serverless Postgres** (Drizzle + Better Auth). The `neon` MCP
(`mcp__neon__*`) is always available for schema inspection, migrations, and RLS verification.
`stripe`, `github`, and `vercel` are always present as well.

## Authentication model

The platform servers are **remote HTTP MCP** and authenticate via **browser OAuth** on first use —
no tokens or API keys in `.mcp.json` or the shell env:

| Server | Endpoint | Auth | Present when |
|--------|----------|------|--------------|
| stripe | `https://mcp.stripe.com` | browser OAuth | always |
| github | `https://api.githubcopilot.com/mcp/` | browser OAuth | always |
| vercel | `https://mcp.vercel.com` | browser OAuth | always |
| neon | `https://mcp.neon.tech/mcp` | browser OAuth | always |

Authorize each once with `claude mcp login <server>` (run in a terminal; the browser opens).
Tokens are stored in Claude Code's keychain.

Runtime app secrets (e.g. `STRIPE_SECRET_KEY`, `DATABASE_URL`, `DATABASE_URL_ADMIN`, `NEXT_PUBLIC_*`) are separate
from MCP auth and still belong in `.env.local` — they are never used to authenticate MCP.

---

## Golden Rule

**Before writing any shell command or code to perform a platform operation, ask:**
> "Can an MCP tool do this?"

If yes, use the MCP tool. Platform operations include anything touching the database,
Stripe, Vercel deployments, or the GitHub repo. Using MCP tools over shell commands or
hand-written platform calls means the action is authenticated, auditable, and consistent.

---

## Read Before Write, Verify After Write

This invariant applies to every MCP server:

1. **Read current state** before proposing any change (inspect existing schema, rules, resources).
2. **Make the change** only after Gate 5 or the relevant approval.
3. **Verify the new state** by reading it back via MCP — do not assume the write succeeded.

"The tool call returned success" is not verification. Reading the resulting state is.

---

## Project MCP configuration

| File | Scope | Contents |
|------|-------|----------|
| `.mcp.json` | Project-level — copied from the template at `/jairus:init` or `/jairus:adopt` | stripe + vercel + github + neon |

The template `${CLAUDE_PLUGIN_ROOT}/templates/mcp.json` carries all four servers, copied
verbatim to `.mcp.json` at `/jairus:init`.

Check connectivity with `/mcp`. Run `/jairus:doctor` for a full wiring report.

---

## neon

**Purpose:** inspect schema, apply Drizzle migrations, run read-only SQL, verify RLS.
Migrations are owned by `packages/adapters` and authored with Drizzle. See
`${CLAUDE_PLUGIN_ROOT}/skills/neon/SKILL.md`.

**Migrations are always authored with Drizzle** (`pnpm db:generate` / `drizzle-kit generate` →
review SQL in `packages/adapters/drizzle/` → apply). Use the `neon` MCP to inspect, branch, and verify:

| Action | Tooling |
|--------|---------|
| Inspect / branch / verify | `mcp__neon__*` (OAuth): list tables, create a **branch** to test first, verify RLS |
| Apply migration | `pnpm db:migrate` (`drizzle-kit migrate`) against the branch/target `DATABASE_URL_ADMIN` (deployed by CI from `packages/adapters`) |

**Verify RLS after every migration:**
`SELECT tablename, rowsecurity FROM pg_tables; SELECT * FROM pg_policies;` — confirm RLS is
enabled + FORCE on every user table, via the `neon` MCP.

**Rules:**
- Schema changes require Gate 4 approval before being applied to main.
- A migration applied without post-apply RLS verification is incomplete — report the gap.
- **Migrations are append-only** — never edit an applied migration; generate a new one.
- Test migrations on a Neon **branch** first; preview deployments point `DATABASE_URL` at a
  branch so previews never touch production data.
- The `neon` MCP can run destructive SQL — review and approve every action; never point it at
  production data casually.
- Cross-user and system reads use the privileged `dbAdmin` client over `DATABASE_URL_ADMIN`;
  see `${CLAUDE_PLUGIN_ROOT}/rules/security.md`.

---

## stripe

**Purpose:** create/read products, prices, coupons; read customers, subscriptions, invoices.

| When | Tool / action |
|------|--------------|
| During development | Read/create via stripe MCP using test-mode keys (`sk_test_*`) |
| Before creating a product | Check if it already exists to avoid duplicates |
| Creating live-mode objects | Only after 🚦 Gate 5 approval |
| Debugging | Read invoices, subscriptions, and payment intents via stripe MCP |

**Rules:**
- **Test mode only during development.** The `STRIPE_SECRET_KEY` in the shell that runs
  Claude Code must be a test key (`sk_test_*`). Never use a live key in development.
- **Creating live-mode products or prices requires Gate 5 (human approval).**
  The orchestrator presents the proposed objects to the human before creating them.
- Never log Stripe API responses that contain cardholder PII or full card data.
- Use the stripe MCP to create test mode objects — not the Stripe dashboard — so that
  the development environment is reproducible and auditable.

---

## vercel

**Purpose:** list projects, inspect deployment status, get preview URLs, read build and
runtime logs.

| When | Tool / action |
|------|--------------|
| After pushing a branch | Check deployment status and build logs |
| At Gate 7 (staging) | Get preview URL, confirm build status = READY |
| Debugging a failed build | Read build logs via vercel MCP |
| Debugging a runtime error | Read runtime logs via vercel MCP |
| At Gate 8 (production) | Confirm production deployment status = READY |

**Rules:**
- **Do not create deployments via MCP.** Vercel's Git integration triggers deployments
  automatically on push. The MCP is for reading and monitoring, not triggering.
- Preview URLs are obtained via vercel MCP — do not ask the user to copy them from the
  Vercel dashboard.
- Prefer reading logs via vercel MCP over asking the user to paste them.
- Vercel MCP requires OAuth authentication. If the tool is unavailable, run `/mcp` in
  an interactive session to complete the OAuth flow.

---

## github

**Purpose:** create repo, manage branches and PRs, create CI workflows, manage issues and
the Project board.

| When | Tool / action |
|------|--------------|
| Bootstrap | `create_repository` during `/jairus:init` (after Gate 3) |
| Feature start | Create branch `feature/<feature-name>` |
| Stage 4 | Create PR linking to design docs |
| Stage 5 | Merge PR to `main` after Gate 8 |
| Board management | Create/update Project issues, milestones, labels |
| Stage status | Read/write feature stage status — the GitHub Project board is the status source of truth; reading a card's column and moving it between columns (e.g. to Design Approved / Review Passed) is done via this MCP (see `${CLAUDE_PLUGIN_ROOT}/rules/state-model.md`) |
| CI | Commit `.github/workflows/*.yml` from `${CLAUDE_PLUGIN_ROOT}/templates/ci/` |

**Rules:**
- Feature branches must follow the naming convention: `feature/<feature-name>`.
- PR descriptions must link to `docs/features/<feature-name>/` and note the design review score.
- **Never force-push shared branches** (`main` or any branch another person may be using).
- **Never bypass CI** (`--no-verify`, skipping required checks).
- **Workflow scope required:** Writing `.github/workflows/*.yml` requires a GitHub token
  with `workflow` scope (or a GitHub App with Actions:write + Contents:write). A plain
  `repo`-scoped token will be rejected — surface that error, don't retry blindly.
- CI workflows are checks-only. Deployment is handled by Vercel's Git integration, not a
  GitHub Actions deploy step.
- **Board capability ladder:** Projects v2 API via github MCP → `gh` CLI →
  issues + labels + milestones. Use the highest-capability option available.
- **During adopt:** never delete existing issues. Classify, label, and link them instead.
  See `${CLAUDE_PLUGIN_ROOT}/rules/adoption.md`.
