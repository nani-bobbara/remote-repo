# Adoption Rules

These rules apply **only during `/jairus:adopt`**. Once adoption completes and
`INTENT.md` has `status: active`, the normal pipeline rules take over fully:
`${CLAUDE_PLUGIN_ROOT}/rules/pipeline.md`, `quality-gate.md`, `development.md`, `security.md`.

---

## What Adopt Does

`/jairus:adopt` onboards an existing repository into the jairus pipeline by:

0. **Checking for an existing jairus footprint** — if a `jairus.json` is present at the project
   root, read its version anchor and board pointer first: the repo may already be partly under
   jairus. Treat the GitHub Project it points at as the backlog source of truth and reconcile
   against it rather than recreating state (see `${CLAUDE_PLUGIN_ROOT}/rules/state-model.md`).
1. **Auditing** the codebase — stack, backend, features, quality gaps, open issues.
2. **Reverse-engineering intent** — reconstructing the product vision from the code.
3. **Importing GitHub state** — all open issues classified and placed on the board.
4. **Creating or mapping the Project board** — features assigned to columns by status.
5. **Transitioning** — setting up the pipeline so normal `/jairus:*` commands take over.

## What Adopt Does NOT Do

- Does not rewrite working code.
- Does not delete existing GitHub issues, PRs, or branches.
- Does not change the detected backend.
- Does not create design docs for features that already have approved docs.
- Does not make any code changes during the audit phase.
- Does not create live-mode Stripe objects.
- Does not add features not found in the codebase or explicitly requested.

**Read first, propose second, write only after approval.** No project file is modified
until the human approves the intent + breakdown (Gate 1+2 equivalent). No GitHub object
is created until the board plan is approved (Gate 3 equivalent).

---

## Backend Detection

The backend is **Neon serverless Postgres** (Drizzle + Better Auth). Adoption detects that stack:
a Neon backend = Drizzle + Better Auth + a `DATABASE_URL` pointing at `neon.tech`.

**Neon / Drizzle / Better Auth signals:**
- `drizzle-orm` and/or `drizzle-kit` in `package.json`; a `drizzle.config.ts` and/or `drizzle/` directory
- `better-auth` in `package.json`; `src/app/api/auth/[...all]/route.ts` (Better Auth handler) present
- `@neondatabase/serverless` driver in `package.json`; `DATABASE_URL` in any `.env*` file with a host containing `neon.tech`

**Decision rules:**
- Drizzle + Better Auth signals found and `DATABASE_URL` host contains `neon.tech` → lock
  `backend: neon` in `INTENT.md`.
- `DATABASE_URL` present but host is not `neon.tech` → stop with ⚠️ AMBIGUITY block; this harness
  targets Neon, ask the human how to proceed.
- No Neon/Drizzle/Better Auth signals found → stop with ⚠️ AMBIGUITY block, ask the human.

## Stack Detection

| Signal | Detection |
|--------|-----------|
| Next.js | `next.config.*` file present |
| Tailwind | `tailwind.config.*` file present |
| Stripe | `stripe` in `package.json` dependencies |
| Vercel | `vercel.json` or `.vercel/` directory present |

## Extension Detection

| Extension | Signal |
|-----------|--------|
| `ai` | `@anthropic-ai/sdk` or `openai` in `package.json` |
| `email` | `resend` or `nodemailer` in `package.json` |
| `feature-flags` | `growthbook` or `launchdarkly` in `package.json` |

Detected extensions are added to `INTENT.md` `extensions:` list (additive only).

---

## Feature Classification

Every detected feature gets exactly one status. Use the criteria precisely.

### `done`

**All four layers present:**
1. Backend data layer: Drizzle table + Layer 1 scoped repo (userId-filtered) + Layer 2 RLS (ENABLE + FORCE, fail-closed policy)
2. API route(s) in `/api/*`, guarded by authentication
3. UI components with loading, empty, and error states
4. At least one test (unit or integration)

If any layer is missing or incomplete, it is `partial`, not `done`.

### `partial`

At least one layer is present but not all four, **or** a critical `TODO`/`FIXME` exists
in a load-bearing code path. This is the most common adoption case.

### `planned`

Referenced in an issue, comment, or `TODO` but no code exists. Zero implementation layers present.

### `bug`

Actively broken: a failing test, a runtime error surfaced during audit, or a `FIXME` in a
critical path that causes visible user-facing breakage.

---

## Handling Each Classification

### `done` features

Skip design and develop — but not review.

If no code-review PASS (score ≥ 8) is on record in the pipeline history:
- Move the feature card to **Review** on the board.
- Run `/jairus:review` — the reviewer scores the existing code as-is.
- If score ≥ 8: move the card to **Review Passed (Gate 6)** and update `jairus.json`.
- If score < 8: findings go to the developer as **gap-fill work** (same process as `partial`).
  The feature moves to `In progress` until it passes.

This ensures adopted code meets the same quality bar as newly developed code.

### `partial` features

1. **`/jairus:design <feature>`** in retrofit mode:
   - Describe what currently exists — do not redesign it.
   - Identify the specific gaps (missing RLS, missing validation, missing test, etc.).
   - Design only the gaps.
   - Mark the PRD with `retrofit: true` in the frontmatter.
2. **`/jairus:develop <feature>`** — fill gaps only:
   - Read existing code first. Never rewrite working code.
   - Implement only what the retrofit design specifies as missing.
   - Verify live state via MCP after applying any backend changes.
3. **`/jairus:review`** — standard code-review gate on the diff.

### `planned` features

Standard pipeline: design → develop → review. No special handling.

### `bug` features

1. Stop and draft a GitHub issue: title, root cause (if found), impact, acceptance criteria.
2. Wait for the human to type `CREATE_ISSUE`.
3. On `CREATE_ISSUE`: create the issue via github MCP, assign it to the Blocked column.
4. Human prioritizes the bug in the backlog.
5. When prioritized: treated as `partial` (design gaps, develop fix, review).

**Never start fixing bugs silently during the audit phase.**

---

## Backlog Import Rules

Every open GitHub issue in the existing repo is imported during adoption.

| Classification | Board column | Action |
|---------------|-------------|--------|
| Maps to a feature | Same column as the feature's status | Link issue to feature in `INTENT.md` |
| Standalone task | Backlog | Add as a standalone board item |
| Duplicate | Backlog | Note the target issue; add a comment on the duplicate; do not delete |
| Bug (failing) | Blocked | Follow bug handling above |
| Question/discussion | Backlog | Add for triage; do not close |

**Never delete any existing issue.** Only classify, label, link, and assign a column.

---

## INTENT.md Adopt-Specific Fields

The `features:` block gains **audit metadata** during adoption (one-time classification from
the audit — not live progress flags; live feature/stage status lives on the board):

```yaml
features:
  - name: "auth"
    display_name: "Authentication"
    type: feature
    plan: free
    depends_on: []
    adopt_status: done            # done | partial | planned | bug — set once during audit
    design_status: none           # none | exists | retrofit | approved — one-time audit finding
```

`adopt_status` drives **initial** board placement (each feature's starting column). `design_status`
tells the designer whether to produce a full spec, a retrofit artifact, or skip design. Neither is
a live progress flag — once the board is created, the GitHub Project card is the status SoT. Do not
add `design_approved` / `code_review_passed` / a live `status` to `INTENT.md`
(see `${CLAUDE_PLUGIN_ROOT}/rules/state-model.md`).

The top-level `INTENT.md` also gains:

```yaml
adopt_status: detected    # detected | confirmed | complete
```

- `detected`: audit complete, backend and features identified, awaiting human confirmation.
- `confirmed`: human approved the breakdown; writing INTENT.md and board.
- `complete`: board created; normal pipeline takes over.

---

## Transition to Normal Pipeline

Once `adopt_status: complete` and `INTENT.md` `status: active`:

- All adopt-specific fields are preserved in `INTENT.md` but no longer drive behavior.
- Use normal commands: `/jairus:ship`, `/jairus:design <feature>`, `/jairus:develop <feature>`.
- `done` features not yet in **Review Passed (Gate 6)** on the board go directly to `/jairus:review`.
- `partial` and `planned` features start at `/jairus:design`.
- `bug` features follow the issue-first protocol before entering the pipeline.

```bash
/jairus:ship --plan    # preview the dep-ordered execution plan
/jairus:ship           # run the full loop in dependency order
```

Everything from this point — gates, quality scores, MCP verification, artifact structure —
is identical to a greenfield project.
