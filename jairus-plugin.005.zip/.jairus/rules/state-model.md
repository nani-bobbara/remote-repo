# State Model — Control Plane, Source of Truth, and Resume

This rule defines **where pipeline state lives** and **how a session resumes**. Every command
and agent follows it. It supersedes any older instruction that stored progress flags in
`INTENT.md`.

## The three layers (own different things — never duplicate)

| Layer | Owns | Lifecycle | Authoritative for |
|-------|------|-----------|-------------------|
| **`docs/INTENT.md`** | The **seed** — initial idea, vague product requirements, and the confirmed backend + first feature breakdown | Write-once at `/jairus:init`. **Archival/stale after the board is created.** Never a live tracker. | the original intent only |
| **GitHub Project** | The **living backlog** — every feature, its stage, and its status | The whole project lifetime | **feature + stage status (the source of truth)** |
| **`jairus.json`** (project root) | The plugin's **control footprint** — version anchor + board pointer + resume cursor + cached snapshot | Written at init, updated on every stage transition | nothing about status — it is a *cursor + cache*, reconciled from the board |

**Consequences:**
- Do **not** store `design_approved` / `code_review_passed` (or any progress flag) in `INTENT.md`.
  Stage status is a **GitHub Project column/label**. A gate approval is a **human moving the card**
  (or the orchestrator moving it only after an explicit human approval in chat).
- The built app never depends on `jairus.json` — the repo builds and runs without jairus.
- `jairus.json` is committed (small; carries the version stamp + board pointer so it travels
  across machines/teammates) but is inert to the build.

## GitHub Project = source of truth for status

- Stage status is read from the board via the `github` MCP, not from any local file.
- Gate → column mapping (planner establishes these columns):
  `Backlog → Design → Design Approved (Gate 3) → Develop → Review → Review Passed (Gate 6) → Deploy → Done`.
- Moving a card into a gate column is a human action outside the model — that is the real gate.
- Preconditions (`develop` needs design approved, `deploy` needs review passed) are checked by
  querying the card's column, not by grepping `INTENT.md`.

## jairus.json — the control footprint

Schema/skeleton: `${CLAUDE_PLUGIN_ROOT}/templates/jairus.json`. `/jairus:init` writes it to the
project root after Gate 1. It holds:
- `jairus_version` / `schema_version` / `created_with` — the version anchor.
- `project` — name, backend, extensions, repo, and the **board pointer** (URL + number).
- `cursor` — `active_feature` + `active_stage`: the resume hint.
- `snapshot` — last-known board state, cached for fast/offline read (board still wins).

**Write discipline:** every command updates `jairus.json` (`updated_at`, `cursor`, and the
snapshot for the feature it touched) when it finishes a stage. This is what makes resume correct.

## Session start — resume protocol

On the first jairus action in a session (and after a compaction), the orchestrator:

1. **Read `jairus.json`** at the project root. Absent → this repo isn't initialized; run `/jairus:init`.
2. **Version check** (`jairus_version` vs the current plugin version in `${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json`):
   - same → continue.
   - newer plugin, **patch/minor** → apply any `schema_version` migration silently, re-stamp `jairus_version`, note the bump.
   - newer plugin, **major** → **stop and prompt**: summarize what changed; migrate only on explicit approval. Never auto-jump a major.
3. **Reconcile against reality** — do not blindly trust the cursor/snapshot:
   - board reachable → refresh `snapshot` from the GitHub Project (board wins on any disagreement).
   - cross-check cheap ground truth: feature branch exists? the 7 design artifacts present? If the
     cursor says "develop done" but there's no branch, surface the drift instead of resuming wrong.
4. **Report and resume** — state clearly: what's completed, the active feature/stage, what's queued
   (dependency order), and the single next action.

## Graceful degradation

- **No github MCP / no board yet** → read from the `jairus.json` snapshot and say the status is
  last-known (not live); block gate-dependent actions until the board is reachable.
- **jairus.json missing but board exists** → rebuild `jairus.json` from the board + git/files.
- **Both disagree** → the GitHub Project wins; re-stamp `jairus.json` from it.
