---
description: "Add an extension integration to an existing project. Supported extensions: ai (Anthropic/OpenAI via Vercel AI SDK), email (Resend), feature-flags (GrowthBook). Extensions are additive and permanent — once added, they're part of your stack."
argument-hint: "<extension-name>"
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, mcp__stripe__*, mcp__neon__*, mcp__github__*, mcp__vercel__*
---

You are the **orchestrator** running the Extend command from `${CLAUDE_PLUGIN_ROOT}/rules/pipeline.md`.

Extension: **$ARGUMENTS**

## Preconditions

- `docs/INTENT.md` exists with `status: bootstrapped` or `status: active`.
- `$ARGUMENTS` is one of: `ai` | `email` | `feature-flags`.
  If not provided or not in the supported list, stop:
  "Supported extensions: ai · email · feature-flags. Usage: `/jairus:extend <extension-name>`"
- If the extension is already present in `docs/INTENT.md` `extensions:` list:
  Read its current configuration, present it, and ask:
  "Extension `$ARGUMENTS` is already installed. Do you want to reconfigure it or check its status?"
  If the user wants status only: show current env vars and skip to success output.
  If the user wants to reconfigure: proceed with dispatch (re-runs will be idempotent).

---

## Step 1: Validate and load context

Read:
- `docs/INTENT.md` → locked `backend`, existing `extensions:` list, project details
- `${CLAUDE_PLUGIN_ROOT}/skills/$ARGUMENTS/SKILL.md` → extension skill (if it exists)
  If the skill file is missing: warn "Extension skill not found at `${CLAUDE_PLUGIN_ROOT}/skills/$ARGUMENTS/SKILL.md`"
  but continue with general implementation patterns.

Check the project for existing extension signals in `package.json` and source files:
- **ai**: `@anthropic-ai/sdk`, `openai`, `ai` (Vercel AI SDK)
- **email**: `resend`, `@sendgrid/mail`
- **feature-flags**: `@growthbook/growthbook`, `@growthbook/growthbook-react`

If signals detected: "Signals found suggesting `$ARGUMENTS` may already be partially integrated.
Proceeding with `extender` to audit and complete the integration."

---

## Step 2: Present extension overview

Before dispatching, show the user what will be added:

| Extension | What it adds | Key env vars | Provider |
|---|---|---|---|
| `ai` | AI SDK wrapper, chat/completion routes, streaming support | `ANTHROPIC_API_KEY` or `OPENAI_API_KEY` | Anthropic Claude or OpenAI via Vercel AI SDK |
| `email` | Transactional email client, email templates, send utilities | `RESEND_API_KEY` | Resend |
| `feature-flags` | Feature flag client, flag evaluation hooks, dashboard | `GROWTHBOOK_CLIENT_KEY`, `NEXT_PUBLIC_GROWTHBOOK_CLIENT_KEY` | GrowthBook |

Ask: "Proceed with adding the `$ARGUMENTS` extension?"

---

## Step 3: Dispatch extender

> **Dispatch** `extender`
> Pass: docs/INTENT.md, extension=$ARGUMENTS, backend=[from INTENT.md]
> Loads: ${CLAUDE_PLUGIN_ROOT}/skills/$ARGUMENTS/SKILL.md (if exists)
> Returns: integration code written, env vars documented, verification steps
> On failure: report specific error; user can re-run `/jairus:extend $ARGUMENTS` (idempotent)

The extender must (per the hexagonal contract — `${CLAUDE_PLUGIN_ROOT}/skills/architecture/SKILL.md`):
1. Add required packages to the right package (`pnpm --filter @app/adapters add <packages>`; client-only helpers → `pnpm --filter portal add <packages>`)
2. Implement the ALREADY-DEFINED domain port by replacing the stub in `packages/adapters/src/<extension>/index.ts` — the vendor SDK lives ONLY in `@app/adapters`
3. Add app-local client UI only where the extension is client-facing (e.g. `apps/portal/app/api/ai/chat/route.ts` + a `useChat` component; a flag provider/hook)
4. Add environment variable names to the ROOT `.env.example` (key names only — no values)
5. Write a brief setup guide to `docs/extensions/$ARGUMENTS.md`

Extension-specific requirements:
- **ai**: implement `AiPort` in `packages/adapters/src/ai/index.ts` via the Vercel AI SDK (`ai` + `@ai-sdk/anthropic`, model configurable); apps call `ai.generate(...)` / an exported stream helper — never the SDK
- **email**: the Resend `EmailPort` already ships in `packages/adapters/src/email/index.ts`; the extension ADDS React Email templates under `packages/adapters/src/email/templates/` and renders them in `email.send`
- **feature-flags**: implement `FlagsPort` in `packages/adapters/src/flags/index.ts` with the GrowthBook **server** SDK; the **client** provider + `useFlag` hook live in `apps/portal` (React SDK)

---

## Step 4: Update INTENT.md and .env.example

After extender completes:

1. Add extension to `docs/INTENT.md` `extensions:` list (permanent):
   ```yaml
   extensions:
     - $ARGUMENTS
   ```

2. Verify the root `.env.example` has the extension's env var key names.
   If not already present, append them:
   ```
   # $ARGUMENTS extension
   <KEY_NAME>=
   ```

3. Run `pnpm -r type-check` to verify integration compiles:
   - If fails: dispatch extender in fix mode with type error output (max 1 retry)
   - If still fails after retry: report error; note that extension was added to INTENT.md
     but may need manual type fixes

---

## Step 5: Success output

```
✅ Extension added — $ARGUMENTS

Files changed:
  packages/adapters/src/$ARGUMENTS/index.ts — domain port implemented (SDK stays here)
  apps/portal/app/...        — app-local client UI (if applicable)
  packages/adapters/src/email/templates/ — React Email templates (email only)
  docs/extensions/$ARGUMENTS.md — setup guide

New env vars (add to .env.local):
  <KEY_NAME>=<your-key>
  ...

Type-check (pnpm -r): ✅ | ⚠️ see errors above
Boundary: ✅ vendor SDK only in @app/adapters

Setup steps:
  1. Add env vars to .env.local (see above)
  2. [Extension-specific setup — e.g. "Create a GrowthBook account and copy your API key"]
  3. Restart the dev server: pnpm dev
  4. Verify: [extension-specific verification step]

Extension is now part of your permanent stack.
Next: /jairus:design <feature> to use this extension in a feature
```

---

## On Error

| Error | Recovery |
|---|---|
| Extension not in supported list | Stop; show supported list; suggest correct spelling |
| Extension skill file missing | Proceed with general implementation; note limitation in output |
| pnpm add fails | Report error; check network and registry; user resolves manually |
| adapter already implemented (not the stub) | Surface it; do not overwrite; ask whether to reconfigure |
| Type-check fails after 1 retry | Report remaining errors; extension is added to INTENT.md but needs manual type fix |
| Extension already installed, reconfigure requested | Extender is idempotent — re-running updates without breaking existing usage |

---

## Rules
- Extensions are additive only — once added to INTENT.md, they are part of the permanent stack.
- Never add an extension to a project that hasn't been bootstrapped (no INTENT.md).
- Never store API keys or secrets — only key names in `.env.example`.
- Cross-reference `${CLAUDE_PLUGIN_ROOT}/rules/pipeline.md` for how extensions integrate with the feature loop.
