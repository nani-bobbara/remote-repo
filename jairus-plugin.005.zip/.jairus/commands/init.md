---
description: "Smart project entry point. Detects whether the repo is new or existing and runs the right path automatically: new repos go through the intent interview and scaffold; existing repos go through audit, classification, and backlog import. Run once per project."
argument-hint: "[optional context, e.g. 'Next.js + Postgres (Neon), ~60% complete']"
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, mcp__stripe__*, mcp__github__*, mcp__vercel__*, mcp__neon__*
---

You are the **orchestrator** running Stage 0 of the jairus pipeline.
This is the single entry point for all projects — new and existing.

**On start, print a one-line banner with the plugin version** (read dynamically, never hardcode):
```bash
node -p "'Jairus v' + require('${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json').version"
```
→ e.g. `Jairus v2.2.0 — initializing`. Record this version into `jairus.json` (`jairus_version` /
`created_with`) when the file is written.

Optional seed from the user: "$ARGUMENTS"

## Session start — resume check (run before anything else)

Before any mode detection, look for `jairus.json` at the project root:

- **`jairus.json` present** → this repo is already initialized. Run the **resume protocol**
  in `${CLAUDE_PLUGIN_ROOT}/rules/state-model.md` (version check against the current plugin
  version in `${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json` → reconcile the cursor/snapshot
  against the GitHub Project board + git/files → report what's done, the active feature/stage,
  and the single next action). This is a **resume, not a fresh init**: do not re-interview or
  re-scaffold. If `docs/INTENT.md` also has `status: bootstrapped`, confirm the resume summary
  and point the user at the next command. Stop here unless the user explicitly asks to re-init.
- **`jairus.json` absent** → this repo is not yet initialized; continue with mode detection below.

## Preconditions

The intent interview (F1) runs without any credentials. But init now runs the **Foundation
phase** (F0–F-VERIFY per `${CLAUDE_PLUGIN_ROOT}/rules/foundation.md`), which **provisions real
infrastructure** — so accounts and CLIs must be connected at **F0**, before any resource is
created.

> **Init provisions.** Backend is Neon (fixed) and topology is a monorepo (fixed). Foundation
> stands up the repo, Neon project, two Vercel projects, Stripe test objects, CI, an auth
> skeleton with a seeded admin, and a deployed walking skeleton — **before** any product feature.
> The earlier "no database at init" model is superseded: F0 connects gh/neonctl/vercel/stripe
> (CLIs + `claude mcp login`), and Neon is provisioned at F5. Nothing billable is created until
> **Gate F2** (resource-plan approval).

Credentials by Foundation step:
- **F0** — authenticate `gh` · `npx neonctl@latest auth` · `npx vercel@latest login` · `stripe login`, plus `claude mcp login github/vercel/stripe/neon`. Claude cannot complete browser/device OAuth in-session — it prompts and then **verifies** (`gh auth status`, `neonctl me`, `vercel whoami`, `stripe config`).
- **F5/F6/F7** — provisioning uses the connected CLIs + MCP reads.

If the user hasn't run `/jairus:doctor` yet, note it as a reminder but do not block the F1 interview.

---

## Step 0: Detect mode

Before doing anything else, determine which path to take:

```bash
# Check for existing app code
ls package.json src/ app/ 2>/dev/null && echo "existing" || echo "new"
```

| Condition | Mode |
|---|---|
| `jairus.json` present, or `docs/INTENT.md` has `status: bootstrapped` | **Already initialized** — run the resume protocol (state-model.md) and tell the user what to run next |
| `package.json` OR `src/` OR `app/` exists | **Existing repo mode** → proceed to [Existing Repo Path](#existing-repo-path) |
| None of the above | **New project mode** → proceed to [New Project Path](#new-project-path) |

### Stack compatibility check (existing repos only)

Before auditing an existing repo, verify the stack is compatible with the jairus pipeline:

| Signal detected | Jairus-compatible? |
|---|---|
| Next.js (App Router) + TypeScript | ✅ Fully compatible |
| Next.js (Pages Router) + TypeScript | ⚠️ Compatible with migration notes |
| Next.js + JavaScript (no TypeScript) | ⚠️ Requires TypeScript migration first |
| Create React App / Vite / Vue / Nuxt / SvelteKit | ❌ Not compatible |
| No framework detected | ❌ Not compatible |

**If stack is incompatible:** stop and present clearly:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
STACK INCOMPATIBLE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Detected stack : <framework detected>
Jairus requires: Next.js 14+ (App Router) + TypeScript

Options:
  A) Migrate the frontend to Next.js 14+ App Router + TypeScript
     (jairus can scaffold this alongside your existing backend)
  B) Use jairus only for new features built with the supported stack
  C) Stop — do not adopt this repo into the jairus pipeline

Which do you prefer? (A / B / C)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

Do not proceed unless the user picks A or B and explicitly acknowledges the constraint.

---

## Silent workspace prep (idempotent — run before anything else)

These writes are non-destructive. Skip any file that already exists.

- **`.mcp.json`** missing → copy from `${CLAUDE_PLUGIN_ROOT}/templates/mcp.json`
- **`.claude/settings.json`** missing → copy from `${CLAUDE_PLUGIN_ROOT}/templates/settings.json`
- **`.gitignore`** missing → create with standard Next.js + Postgres entries (include
  `.env*.local`, `node_modules/`, `.next/`; do NOT ignore the `drizzle/` migration folder —
  migrations are committed); if present, confirm `.env.local` and `.env.*.local` are listed
  and append if not. **Never add `jairus.json`** — it is committed (version anchor +
  board pointer). Only `.env*` stays ignored.
- **`CLAUDE.md`** missing → note it; the `BOOTSTRAP:PROJECT_OVERVIEW` block is written
  after Gate 1 approval

---

---

# New Project Path — the Foundation orchestrator

*Taken when: no `package.json`, no `src/`, no `app/`*

Read `${CLAUDE_PLUGIN_ROOT}/rules/pipeline.md` AND
`${CLAUDE_PLUGIN_ROOT}/rules/foundation.md` before proceeding. This path no longer just writes a
workspace stub — it **orchestrates the Foundation phase (F0–F-VERIFY)** defined authoritatively in
`foundation.md`: connect accounts → interview → confirm resource plan → provision (repo, monorepo,
Neon, 2 Vercel projects, Stripe, secrets, auth seed, CI) → deploy + verify a walking skeleton →
set `foundation.status = green`, which unlocks the feature pipeline. Do not duplicate the spec —
drive its steps in order, recording each in `jairus.json → project.foundation.steps`.

---

## NP — Foundation orchestration overview

Drive these steps **in order**, per `${CLAUDE_PLUGIN_ROOT}/rules/foundation.md`. Each step records
`{step: done|failed, at, ref}` in `jairus.json → project.foundation.steps`; on re-run skip `done`,
retry `failed`, never re-create an existing resource.

```
F0  Connect accounts       prompt+verify gh · neonctl · vercel · stripe CLIs + mcp logins
F1  Interview 🚦 Gate F1    intent + persona + 3–6 features + monetization + entities → draft INTENT.md
F2  Resource plan 🚦 Gate F2  show EXACTLY what will be created; explicit approval before any spend
F3  GitHub (from template) repo FROM jairus-starter (private) + Project board (planner) + branch protection on main
F4  Install skeleton       pnpm install + type-check + build the cloned monorepo (do NOT regenerate)
F5  Neon                   npx neonctl@latest project + GitHub integration · apply the template's migrations
F6  Vercel                 2 projects (portal, admin) linked · env per project
F7  Stripe                 test-mode products (free/basic/pro) + webhook endpoint
F8  Seed first admin       pnpm db:seed → power_user + regular roles + the bootstrap superadmin
F9  Secrets/vars           pnpm gen:secret BETTER_AUTH_SECRET · gh secret/var · vercel env · local .env.local
F10 CI/CD                  confirm the template's .github/workflows + branch protection require them
F11 Deploy 🚦 Gate F11     deploy portal + admin; migrations applied
F-VERIFY 🚦 Gate           prove skeleton live + secure → set foundation.status = green
```

**Fixed (nothing to pick):** backend = Neon, topology = the hexagonal monorepo **cloned from
`jairus-starter`** (not regenerated). Provision with `@latest` npx CLIs (`npx neonctl@latest`,
`npx vercel@latest`).

---

## F0: Connect accounts (before any provisioning)

Per foundation.md F0. Prompt the user to authenticate each CLI + MCP in a terminal — Claude Code
cannot complete browser/device OAuth in-session, so it **orchestrates and verifies**:

```
gh auth login   ·   npx neonctl@latest auth   ·   npx vercel@latest login   ·   stripe login
+ claude mcp login github   ·   claude mcp login neon   ·   claude mcp login vercel   ·   claude mcp login stripe
```

Verify before proceeding: `gh auth status` · `neonctl me` · `vercel whoami` · `stripe config`,
plus one lightweight read per MCP. Record F0 status in `jairus.json`. If any is not connected,
pause and tell the user exactly which command to run; do not advance to provisioning.

---

## F1 Step 1: Capture intent

Interview the user in ONE batch of questions. If `docs/INTENT.md` already exists with
`status: draft`, read it first, present what's there, and ask what to confirm or change.

Capture all of the following:
- `project_name` (kebab-case, ≤32 chars), `display_name` (human-readable)
- `one_liner` (≤120 chars — what it does for whom)
- Core problem being solved and target user persona
- 3–6 MVP features (name, what it does, which plan tier: free/basic/pro)
- Monetization model (free-tier + paid tiers, or one-time, or usage-based)
- Key data entities (e.g. User, Workspace, Project, Subscription)
- First feature to build after auth

Write a draft `docs/INTENT.md` from `${CLAUDE_PLUGIN_ROOT}/templates/INTENT.md` with
`status: draft`. This is the working copy until Gate 1 approves it.

---

## F1 Step 2: Backend + topology (fixed — no choice)

The backend is **fixed**: Neon serverless Postgres (Drizzle ORM + Better Auth + two-layer
security — see `${CLAUDE_PLUGIN_ROOT}/skills/neon/SKILL.md`). The topology is a **hexagonal
monorepo cloned from `jairus-starter`** — `packages/{domain,application,adapters,auth,ui,config}` +
`apps/{portal,admin}`, consumed as TS source via `@app/*` workspace deps. There is no host choice
to make: Neon gives serverless Postgres with DB branching per preview, and the neon MCP authorizes
via browser OAuth (`mcp__neon__*`). Migrations run via `drizzle-kit` and are already in the template.

Just note this to the user (no question — nothing to pick):

> Backend is Neon Postgres (fixed); topology is monorepo (portal + admin, shared packages).

Record `backend: neon` in `docs/INTENT.md`.

---

## F1 Step 3: Generate MVP feature breakdown

From the captured intent, generate the `features:` list in the INTENT.md v2 schema.

**Before writing the YAML, ask one question per user-defined feature:**

> For **[Feature Display Name]**: in 1–2 sentences, what does it do and why does it matter?
> Also, is anything explicitly out of scope for this feature?

Skip this question for `bootstrap-app`, `auth`, and `billing` — these have fixed scope.
For user-defined features, a blank `description` blocks `/jairus:design` from running.

```yaml
features:
  - name: bootstrap-app
    display_name: "App Scaffold"
    description: "Sets up the Next.js project, Tailwind, environment config, and CI pipeline."
    out_of_scope: []
    type: foundation
    plan: all
    depends_on: []
    status: planned
  - name: auth
    display_name: "Authentication"
    description: "Email/password sign-up and sign-in with session management."
    out_of_scope: ["OAuth providers", "magic link"]
    type: foundation
    plan: all
    depends_on: [bootstrap-app]
    status: planned
  - name: billing
    display_name: "Billing & Subscriptions"
    description: "Stripe subscription checkout, plan management, and webhook handling."
    out_of_scope: ["one-time payments", "invoicing"]
    type: feature
    plan: pro
    depends_on: [auth]
    status: planned
```

Rules:
- Always include `bootstrap-app` and `auth` first (`type: foundation`).
- Always include `billing` for any monetized product.
- User-defined features come between auth and billing unless they depend on billing.
- `depends_on` must form a valid DAG (no cycles).

---

## F1 Step 4: Gate F1 — Confirm intent + backend + breakdown

---
🚦 GATE F1 — INTENT, BACKEND, AND FEATURE BREAKDOWN

**Show the user:**
- Project: `display_name` — `one_liner`
- Backend: Neon Postgres (Drizzle + Better Auth + RLS) · monorepo (portal + admin, shared packages) — fixed
- Feature breakdown (dependency-ordered tree):
  ```
  bootstrap-app
  └─ auth
     ├─ [feature A]
     ├─ [feature B]  depends_on: [feature A]
     └─ billing
  ```
- Total features: N · Gates per feature: design + (backend?) + code-review = min 2

**Ask:**
> Does this capture your intent correctly? Approve the intent + breakdown to move on to the
> resource plan (Gate F2). Nothing is provisioned yet.

**✅ Approved** → write draft `docs/INTENT.md` (status: bootstrapped) + seed `jairus.json`, then proceed to F2
**❌ Changes needed** → revise and re-present
**❌ Stop** → do not write files; re-run `/jairus:init` when ready
---

After Gate F1 approval, write the seed workspace files needed by Foundation (these are cheap,
non-billable, resume-safe):

1. **Write `docs/INTENT.md`** — set `status: bootstrapped`.
2. **Confirm `.mcp.json`** — the four servers are fixed: stripe, github, vercel, neon (all browser OAuth).
3. **Copy `.env.example`** — from `${CLAUDE_PLUGIN_ROOT}/templates/env.example`; keep `DATABASE_URL` + `DATABASE_URL_ADMIN` + `BETTER_AUTH_SECRET` + `BETTER_AUTH_URL` (+ `ADMIN_EMAIL`/`ADMIN_INITIAL_PASSWORD`, `GOOGLE_CLIENT_ID`/`GOOGLE_CLIENT_SECRET`).
4. **Create `docs/design.md`** from `${CLAUDE_PLUGIN_ROOT}/templates/design.md`.
5. **Update `CLAUDE.md`** — replace content between `<!-- BOOTSTRAP:PROJECT_OVERVIEW:START -->` and `<!-- BOOTSTRAP:PROJECT_OVERVIEW:END -->`. Touch nothing outside the markers.
6. **Write `jairus.json`** to the project root from `${CLAUDE_PLUGIN_ROOT}/templates/jairus.json` (control footprint — see `${CLAUDE_PLUGIN_ROOT}/rules/state-model.md`). Fill:
   - `jairus_version` + `created_with` = current plugin version from `${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json`.
   - `created_at` / `updated_at` = now (ISO 8601).
   - `project.name` = `project_name`, `project.backend` = `neon`, `project.topology` = `monorepo`, `project.extensions` = `[]`, `project.repo` = `""` (filled at F3), `project.board` = `{ "url": "", "number": null }` (filled at F3).
   - `project.foundation` = `{ "status": "pending", "steps": { "F0": {"step":"done", ...}, "F1": {"step":"done", ...} } }` — record each F-step's result as it completes.
   - `cursor` = `{ "active_feature": "<first feature after bootstrap-app>", "active_stage": "foundation" }`.
   The app scaffold arrives at F3/F4 by **cloning `jairus-starter`**, not here — do not stub `package.json`/`src/`.

---

## F2: Confirm resource plan 🚦 (Gate F2 — before any spend)

Per foundation.md F2. Show EXACTLY what will be created, on which accounts, before any billable
provisioning:

---
🚦 GATE F2 — RESOURCE PLAN (provisioning approval)

```
GitHub  : repo <owner>/<name> (private) + Project board
Neon    : project <name> (region <r>) + main branch
Vercel  : 2 projects — <name>-portal, <name>-admin
Stripe  : test-mode products + a webhook endpoint
```

**Ask:**
> Approve provisioning exactly these resources? This is the first step that creates real
> (billable) infrastructure on your connected accounts.

**✅ Approved** → run F3–F10 provisioning in order
**❌ Changes needed** → adjust the plan and re-present
**❌ Stop** → nothing provisioned; re-run `/jairus:init` to resume from F2
---

Never auto-create billable resources without Gate F2 approval.

---

## F3–F10: Provision (after Gate F2 approval)

Drive each step per `${CLAUDE_PLUGIN_ROOT}/rules/foundation.md`, recording status in
`jairus.json → project.foundation.steps` after each. Skip `done`, retry `failed`, never re-create
an existing resource (check first: does the repo/project/branch already exist?).

- **F3 GitHub (from template)** — `gh repo create <owner>/<name> --private --template Nani-Bobbara_CUDL/jairus-starter --clone` so the scaffold is **cloned, not regenerated** (fallback: `git clone` jairus-starter → drop `.git` → `git init` + push). Then create the Project board (dispatch `planner`) · enable branch protection on `main`. Record `project.repo` + `project.board.{url,number}` and refresh `snapshot`.
- **F4 Install skeleton** — the clone already has the full hexagonal monorepo (`packages/{domain,application,adapters,auth,ui,config}` + `apps/{portal,admin}`), CI, Drizzle migrations, RBAC, and bundled agent skills. Do **not** run `create-next-app` or hand-wire packages. Run `pnpm install` then `pnpm -r type-check && pnpm turbo build` to prove it's green before provisioning. (Optionally `npx skills update`.)
- **F5 Neon** — `npx neonctl@latest projects create` → pooled `DATABASE_URL` + direct `DATABASE_URL_ADMIN` (pooled host minus `-pooler`); install the Neon GitHub integration; apply the template's existing migrations with `pnpm db:migrate`. Verify via neon MCP.
- **F6 Vercel** — `npx vercel@latest link` two projects (portal, admin) to `apps/portal`/`apps/admin`; set env per project (both → `DATABASE_URL` + `DATABASE_URL_ADMIN` + `BETTER_AUTH_*`; each `BETTER_AUTH_URL` = its own deployed origin); consider deployment protection on admin.
- **F7 Stripe** — `stripe` CLI: create test-mode products for the **free/basic/pro** tiers (capture `STRIPE_PRICE_BASIC`/`STRIPE_PRICE_PRO`) + a webhook endpoint; capture `STRIPE_WEBHOOK_SECRET`.
- **F8 Seed first admin** — the template already ships Better Auth + data-driven RBAC (`role` table, `power_user`/`regular`, `can()`/`requireStaff`). Just `pnpm db:seed` — seeds the `power_user` + `regular` roles and the bootstrap superadmin from `ADMIN_EMAIL`/`ADMIN_INITIAL_PASSWORD`. Portal self-signup → `regular`; admin is invite-only (staff created by `power_user` in the admin Staff screen). Do not hand-build auth.
- **F9 Secrets/vars** — `pnpm gen:secret` → `BETTER_AUTH_SECRET` (random, NOT a URL); `gh secret set`/`gh variable set` (CI: `DATABASE_URL_ADMIN`, `STRIPE_*`, `BETTER_AUTH_SECRET`; var `NEON_PROJECT_ID`); `vercel env add` per project; write per-app `.env.local` (gitignored). Never print or commit secret values.
- **F10 CI/CD** — the cloned template already ships `.github/workflows/`; confirm branch protection requires the validate check and the deploy secrets (`VERCEL_TOKEN`, `VERCEL_ORG_ID`, `VERCEL_PROJECT_ID_PORTAL/ADMIN`) are set.

---

## F11: Deploy walking skeleton 🚦 (Gate F11)

Per foundation.md F11. Deploy portal + admin to Vercel with migrations applied.

---
🚦 GATE F11 — DEPLOY WALKING SKELETON

**Show the user:** both Vercel projects, build status, backend migration status.

**Ask:**
> Approve the first production deploy of the (empty) portal + admin apps?

**✅ Approved** → deploy both; confirm each build status = `READY` via vercel MCP
**❌ Changes needed** → fix build issues and re-present
**❌ Stop** → deploy paused; resume from F11
---

---

## F-VERIFY: Prove it 🚦 (the proof gate → foundation green)

Per foundation.md F-VERIFY. Verify with **evidence, not claims**:

---
🚦 GATE F-VERIFY — WALKING SKELETON PROOF

**Show the user (each ✅/❌):**
- portal URL loads the **landing page**; `/sign-up` creates a `regular` user (email + Google both work)
- admin URL: the seeded `power_user` signs in and reaches the console (Overview / Role Control / Staff)
- **boundaries**: a `regular` account on admin sees "Unknown user"; a staff account on the portal is blocked
- both deploys green; DB migrated (Better Auth tables + `role` table present; `power_user`/`regular` seeded)

**Ask:**
> Do you confirm the walking skeleton is live and secure? Approving sets foundation green and
> unlocks the feature pipeline.

**✅ Approved** → set `jairus.json → project.foundation.status = "green"`, record F11 + F-VERIFY done, advance `cursor` to the first feature/`board`
**❌ Changes needed** → fix the failing check and re-present
**❌ Stop** → foundation stays `pending`; features remain locked
---

---

## Observability (optional — ask once, default off)

Claude Code emits OpenTelemetry natively. Offer to wire it to Grafana Cloud —
this is opt-in and never blocks. Check if it's already on:

```bash
[ -n "${CLAUDE_CODE_ENABLE_TELEMETRY:-}" ] && echo "on" || echo "off"
```

If already on, skip this step. If off, ask once:

> Optional: stream Claude's tool, agent, and command telemetry (token cost,
> MCP call counts, command timing) to Grafana Cloud? This adds no code — it just
> sets OTEL env vars in your shell profile. (yes / skip)

**✅ yes** →
1. Ask for the Grafana Cloud OTLP endpoint and the base64 `instanceID:token` (input hidden).
2. Append the `Observability` block from `${CLAUDE_PLUGIN_ROOT}/templates/env.example`
   to the shell profile with the values filled in (never echo the token back).
3. Copy `${CLAUDE_PLUGIN_ROOT}/templates/observability/grafana-dashboard.json` to
   `docs/observability/grafana-dashboard.json` and tell the user to import it in Grafana.
4. Note: telemetry starts after the next Claude Code restart.

**⏭️ skip** → note it can be enabled anytime via `/jairus:doctor` or the `.env.example` block.

---

## NP Success output (foundation green)

```
✅ Foundation GREEN — <display_name> · backend: Neon Postgres · monorepo (portal + admin) · <N> features approved

Deployed walking skeleton:
  Portal  <portal-vercel-url>       — public landing + email/Google signup (→ regular)
  Admin   <admin-vercel-url>        — invite-only console; seeded power_user

Admin credentials:
  ADMIN_EMAIL from your input; ADMIN_INITIAL_PASSWORD from your env (seeded as power_user).
  Not committed — rotate it after first login.

Provisioned:
  GitHub   repo <owner>/<name> (private, from jairus-starter) + Project board + branch protection
  Neon     project <name> + migrations applied (Better Auth + role tables)
  Vercel   2 projects (portal, admin), both READY
  Stripe   test-mode products (free/basic/pro) + webhook endpoint
  CI       .github/workflows (validate · deploy · migrations · security-audit)
  jairus.json  foundation.status = green  (features unlocked)

Next (features now unlocked):
  /jairus:design <first-feature>   # design the first product feature
  /jairus:ship                     # run the full feature loop in dependency order
```

Features unlock only now that `jairus.json → project.foundation.status == "green"`. Until then,
`design`/`develop`/`review`/`deploy` refuse to run (see `${CLAUDE_PLUGIN_ROOT}/rules/pipeline.md`).

---

---

# Existing Repo Path

*Taken when: `package.json` OR `src/` OR `app/` exists*

Read `${CLAUDE_PLUGIN_ROOT}/rules/adoption.md` before proceeding.

---

## ER Step 1: Read-only audit (no writes in this step)

### A1 — Tech stack detection
Read in parallel:
- `package.json` → framework version, deps, scripts (`dev`, `build`, `test`, `type-check`)
- `tsconfig.json` → is `strict: true`?
- `tailwind.config.*` → present?
- `next.config.*` → App Router vs Pages Router?
- `.env.example` or `.env.local` → key names only, never values
- `vercel.json` → deployment configuration

### A2 — Backend detection

The backend is always Neon Postgres. Detect it and confirm the monorepo topology.

| Signal | Meaning |
|---|---|
| `drizzle.config.*`, `@neondatabase/serverless`/`postgres`/`pg` dep, `better-auth` dep, `DATABASE_URL` env key | Neon Postgres backend confirmed → `backend: neon` |
| No Postgres/Drizzle/Better Auth signal at all | **Stop — this repo has no compatible backend; ask the user to confirm they want a Neon Postgres backend added** |

Attempt a read-only neon MCP call to confirm live backend state. Also note whether the repo is
already a hexagonal monorepo (`packages/{domain,application,adapters,auth,ui,config}` +
`apps/{portal,admin}`, shared `@app/*`) or needs that topology introduced.

### A3 — Extensions detection
Scan `package.json` and imports for:
- **ai**: `@anthropic-ai/sdk`, `openai`, `ai` (Vercel AI SDK)
- **email**: `resend`, `@sendgrid/mail`, `nodemailer`
- **feature-flags**: `@growthbook/growthbook`, `launchdarkly-js-sdk`

### A4 — Feature map
Scan `src/` or `app/` to identify feature areas. Classify each as `done`, `partial`, `planned`, or `bug`
using `${CLAUDE_PLUGIN_ROOT}/rules/adoption.md` (Section: Feature Classification).

Also scan `docs/features/*/` — note which features already have design artifacts.

### A5 — GitHub state import (best-effort, read-only)
Via github MCP:
- Open + closed issues → classify: feature, bug, tech-debt, question
- Open PRs → link to feature area
- Milestones → map to pipeline epics
- Existing GitHub Project → read columns and items

### A6 — Stripe + Vercel state (best-effort, read-only)
- stripe: list products + prices, note webhook endpoints
- vercel: confirm project exists, last deployment status, env key names

---

## ER Step 2: Present audit report (no writes yet)

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ADOPT AUDIT — <repo name>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Stack       Next.js <ver> · TypeScript <strict?> · Tailwind <yes/no>
Backend     Neon Postgres (Drizzle + Better Auth) · monorepo (portal + admin, shared packages)
Payments    Stripe <wired/not wired>
Hosting     Vercel <project name / not wired>
Extensions  <detected list or none>

FEATURES DETECTED
  done     <name> · <name>
  partial  <name> — missing: <what layers>
  planned  <name> · <name>
  bug      <name> — <one-line description>

GITHUB BACKLOG (<N> issues · <N> open PRs)
  #<num>  [feature|bug|tech-debt]  <title>
  ...

STRIPE  <N products> · tiers: <list>
VERCEL  <project> · last deploy: <status>

GAPS / RISKS
  • <e.g. missing RLS, type-check fails, no .env.example, no tests>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Do not advance until the user confirms the audit is accurate.**

---

## ER Step 3: Draft INTENT.md and feature breakdown

Populate `docs/INTENT.md` from `${CLAUDE_PLUGIN_ROOT}/templates/INTENT.md` with all
detected information. Set `status: draft` until Gate 1 approves.

For each feature include `adopt_status` (the seed classification only — **no progress flags**;
stage status lives on the GitHub Project board per `${CLAUDE_PLUGIN_ROOT}/rules/state-model.md`):
```yaml
- name: dashboard
  display_name: "Dashboard"
  type: feature
  plan: free
  depends_on: [auth]
  adopt_status: partial    # done | partial | planned | bug — initial board column only
```

Present the full dependency-ordered breakdown:
```
FEATURE BREAKDOWN (dependency-ordered)
  [done]    bootstrap-app
  [done]    auth          depends_on: bootstrap-app
  [partial] dashboard     depends_on: auth        — missing: API route, RLS policy
  [planned] billing       depends_on: auth
  [bug]     export-csv    depends_on: dashboard   — test failing

GITHUB BACKLOG → BOARD MAPPING
  #12  [bug]     "Export CSV breaks on empty rows"   → export-csv
  #18  [feature] "Add dark mode toggle"               → planned (new feature)
```

---

## ER Step 4: Gate 1 — Confirm intent + backend + breakdown

---
🚦 GATE 1 — INTENT, BACKEND, AND FEATURE BREAKDOWN

**Show the user:**
- Project: `display_name` — `one_liner`
- Backend: Neon Postgres · monorepo (portal + admin, shared packages) (confirmed in A2)
- Complete feature breakdown tree (adopt_status per feature)
- GitHub backlog → board mapping
- Gaps/risks identified

**Ask:**
> Does this accurately capture the project state? Approve to write INTENT.md and scaffold the workspace.

**✅ Approved** → proceed to ER Step 5
**❌ Changes needed** → revise and re-present
**❌ Stop** → do not write any files; re-run `/jairus:init` when ready
---

### After Gate 1 approval — workspace scaffold

1. **Write `docs/INTENT.md`** — set `status: bootstrapped`.
2. **`.env.example`** — generate from template if missing; diff and note missing keys if present (never overwrite). Keep `DATABASE_URL` + `DATABASE_URL_ADMIN` + `BETTER_AUTH_SECRET` + `BETTER_AUTH_URL`.
3. **`.mcp.json`** — the four fixed servers are stripe, github, vercel, neon. No trimming needed.
4. **`docs/design.md`** — create from template if missing; leave untouched if present.
5. **`CLAUDE.md`** — insert project overview between `BOOTSTRAP` markers.
6. **Write `jairus.json`** to the project root from `${CLAUDE_PLUGIN_ROOT}/templates/jairus.json` (see state-model.md). Fill `jairus_version` + `created_with` from `${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json`, `created_at`/`updated_at`, `project.{name,extensions,repo}` from the audit, `project.backend` = `neon`, `project.topology` = `monorepo`, `project.board` left empty until Gate 2, and an initial `cursor` (first not-done feature + `active_stage: board`). Committed; carries no progress flags. Ensure `.gitignore` does not list it.
   - Set `project.foundation.status` from the audit: if the adopted repo already has the full platform (repo + Neon + 2 Vercel projects + auth skeleton + CI, all live), record it `green`; otherwise `pending` with the missing F-steps noted. **Foundation-green is required before any feature stage runs.**
7. **Baseline check** — run `pnpm type-check` and `pnpm test` if scripts exist. Failures are recorded as `bug` items — not blockers.

### Foundation gap check (existing repos)

Feature stages (`design`/`develop`/`review`/`deploy`) refuse to run until
`jairus.json → project.foundation.status == "green"` (see
`${CLAUDE_PLUGIN_ROOT}/rules/pipeline.md` and `rules/foundation.md`). If the adopted repo lacks
part of the platform (no Neon project, only one Vercel app, no seeded admin, no CI), guide the
user to complete the missing **F-steps** from `rules/foundation.md` before features unlock — run
only the not-`done` steps (F0–F-VERIFY are resume-safe; never re-create existing resources).

---

## ER Step 5: Gate 2 — Board plan, then planner dispatch

> **Dispatch** `planner` — mode: plan-only
> Pass: docs/INTENT.md, adopt_status per feature, existing GitHub issues/milestones
> Returns: board structure (epics, issues, column assignments, backlog mapping)

---
🚦 GATE 2 — GITHUB PROJECT BOARD PLAN

**Show the user:**
- Epics (milestones): Init · Design · Develop · Deploy · Extend
- Feature issues to create, with depends_on links and adopt_status labels
- Column assignment per adopt_status: done → Done · partial → In Progress · planned → Backlog · bug → Blocked
- Existing GitHub issues to import and link

**Ask:**
> Create or update the GitHub Project board with this plan?

**✅ Approved** → dispatch planner to create/refresh the board
**❌ Skip** → note board is pending; user can run `/jairus:board` manually later
---

After Gate 2 approval: dispatch planner to execute, then verify via github MCP. Then update `jairus.json` — set `project.board.{url,number}` and refresh `snapshot` from the board (state-model.md write discipline).

---

## ER Step 6: Success output

```
✅ Adopted <display_name>
   Backend : Neon Postgres (Drizzle + Better Auth) · monorepo (portal + admin)
   Features: <N done> done · <N partial> partial · <N planned> planned · <N bug> bugs
   Board   : <GitHub Project URL>
   Backlog : <N> issues imported · <N> PRs linked
   Foundation : <green — features unlocked | pending — complete F-steps: F5, F6, …>

NEXT STEPS
  /jairus:doctor --check      # verify MCP, creds, toolchain
  # If foundation is pending: complete the missing F-steps (rules/foundation.md) first
  /jairus:ship --plan         # preview the dependency-ordered run  (foundation must be green)
  /jairus:ship                # run the feature loop
  /jairus:design <feature>    # or design one feature manually
```

---

---

# On Error

| Error | Recovery |
|---|---|
| Already initialized (`status: bootstrapped`) | Show current state summary and suggest: `/jairus:board`, `/jairus:ship`, or `/jairus:design <feature>` |
| Stack incompatible (CRA, Vite, Vue, etc.) | Present the 3-option menu (A/B/C) — do not proceed without explicit choice |
| No Neon/Postgres backend signal in existing repo | Stop in A2; ask the user to confirm they want a Neon Postgres backend added |
| GitHub MCP unavailable | Skip A5; note backlog import will be incomplete; continue code-only audit |
| TypeScript missing in existing repo | Warn; record as `partial` state; suggest migration path |
| `pnpm type-check` fails at baseline | Record as `bug` items; do not block adoption |
| Planner fails to create board | Present board plan as manual checklist; user can run `/jairus:board` |
| User does not provide enough intent info (new) | Ask follow-ups; do not proceed to breakdown until all required fields captured |
| Gate 1 not approved after 2 revision cycles | Stop; tell user to re-run `/jairus:init` with clearer requirements |

---

## Rules

- **Existing-repo mode is read-first** — never modify application feature code during the audit.
- **Foundation provisions the platform, not product features** — the New Project Path stands up the walking skeleton (scaffold, auth skeleton, deployed empty apps) via F3–F-VERIFY. Product *feature* code is still never written before its design is approved (Gate 3 in `/jairus:develop`).
- **No billable resource before Gate F2** — F0/F1 are free; provisioning (F3+) requires resource-plan approval.
- Never overwrite existing design docs — only create missing ones.
- The audit (ER Step 1) must complete before any write — not even INTENT.md is written until Gate 1.
- Existing GitHub issues are never deleted — only linked and re-labelled.
- Backend is always Neon Postgres (fixed) with a monorepo topology — there is no host profile to infer or choose.
- Never write secret values into committed files — only `.env.example` key names.
- Cross-reference `${CLAUDE_PLUGIN_ROOT}/rules/pipeline.md` for gate definitions.
