---
description: "Design a feature end-to-end. Verifies scope contract, dispatches the designer agent to produce all 7 required artifacts, runs the design-review fix-loop to ≥8/10, then presents Gate 3 for human approval."
argument-hint: "<feature-name>"
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, mcp__stripe__*, mcp__neon__*
---

You are the **orchestrator** running Stage 2 (Design).
Read the Stage 2 contract in `${CLAUDE_PLUGIN_ROOT}/rules/pipeline.md` and the state model in
`${CLAUDE_PLUGIN_ROOT}/rules/state-model.md` before proceeding. Stage status is read from the
GitHub Project board (source of truth), not from INTENT.md flags. On the first jairus action in
a session, run the resume protocol (state-model.md) before Step 1.

Feature: `$ARGUMENTS`

---

## Step 1 — Verify input contract

Check each item in the Stage 2 input contract:

| Check | Block message if failed |
|-------|------------------------|
| `docs/INTENT.md` exists | "Run `/jairus:init` first." |
| Feature `$ARGUMENTS` exists in INTENT.md | "Feature not found. Check spelling or run `/jairus:init` to add it." |
| Feature `description` non-empty | "Feature description is empty. Edit INTENT.md — add `description:` before running design." |
| Feature `out_of_scope` present | "Feature `out_of_scope` is missing. Edit INTENT.md — add the list (can be empty `[]`)." |
| All `depends_on` features are in or past the **Review Passed (Gate 6)** column on the GitHub Project board (via github MCP) | "Feature `<name>` in depends_on hasn't passed review on the board. Complete it first." |
| `docs/design.md` exists | "Design tokens missing. Run `/jairus:init` to create them." |

Extract the **scope contract** from INTENT.md:
```yaml
scope_contract:
  description: <feature.description>
  out_of_scope: <feature.out_of_scope>
```

If the feature card is already in **Design Approved** or past it on the board: enter retrofit mode — designer will document gaps in existing implementation, not start from scratch.

Move the feature card to the **Design** column on the board (via github MCP). Do not write any status flag to INTENT.md — INTENT.md is the write-once seed (state-model.md).

---

## Step 2 — Dispatch designer

Construct the CRAFT envelope before dispatching:

```
CRAFT DISPATCH — designer
──────────────────────────────────────────────────────────────
Context  : Project: <display_name> — <one_liner>
           Feature: $ARGUMENTS — <feature.description>
           Backend: Neon Postgres — Drizzle + Better Auth + two-layer security (hexagonal monorepo: portal + admin, cloned from jairus-starter). Read skills/architecture/SKILL.md (extend recipe) · skills/auth/SKILL.md (RBAC) · skills/neon/SKILL.md.
           Scope contract:
               description : <feature.description>
               out_of_scope: <feature.out_of_scope[]>
           Design tokens: docs/design.md (all components must use token names)
           Live backend state: <read before designing DATABASE.md — via the neon MCP or `drizzle-kit` introspect>
           Mode: design (new) | retrofit (card already in/past Design Approved on the board)

Role     : You are the designer. You own artifact production for this feature.
           You are NOT responsible for scoring your own work, presenting Gate 3,
           or writing application code.

Action   : Produce all 7 artifacts in docs/features/$ARGUMENTS/.
           Number acceptance criteria exactly AC-1, AC-2, AC-3, … (grep-dependent).
           Any item in out_of_scope found in an artifact = remove it and flag as scope violation.
           Read live backend state before writing DATABASE.md (neon MCP or `drizzle-kit` introspect). DATABASE.md uses Drizzle schema + two-layer security (Layer 1 app-layer userId scoping via `withUser` + Layer 2 defense-in-depth RLS FORCE; `dbAdmin`/`DATABASE_URL_ADMIN` for system + admin cross-user).

Format   : Return: artifact paths + AC count + open questions list + scope violations.
           Any open question affecting architecture/security = mark [BLOCKS GATE].

Tone     : Apply rules/design-workflow.md throughout.
           No raw hex values — design token names only.
           DATABASE.md must reflect actual live state, not guesses.
           AC prefix AC-N is non-negotiable — developer and reviewer grep for it.
──────────────────────────────────────────────────────────────
```

> **Dispatch** `designer`
> Pass: CRAFT envelope above, INTENT.md path, feature name, locked backend, docs/design.md path, scope_contract
> Mode: `design` (new) or `retrofit` (if the card was already in/past Design Approved)
> Returns: 7 artifact files in `docs/features/$ARGUMENTS/`

---

## Step 3 — Verify output contract + run fix-loop

Check all Stage 2 exit criteria. Then run the fix-loop per the Fix-Loop Protocol in pipeline.md:

**Verification checks (run before each fix-loop iteration):**
```bash
# All 7 artifacts present?
for f in PRD.md DESIGN.md API.md DATABASE.md COMPONENTS.md ADR.md CHECKLIST.md; do
  [ -f "docs/features/$ARGUMENTS/$f" ] && echo "✅ $f" || echo "❌ $f missing"
done

# No placeholder content?
grep -r "{{" docs/features/$ARGUMENTS/ && echo "⚠️ placeholders found" || echo "✅ no placeholders"

# AC prefix present?
grep -q "AC-[0-9]" docs/features/$ARGUMENTS/PRD.md && echo "✅ AC-N found" || echo "❌ AC-N prefix missing"
```

**Fix-loop (max 3 iterations — see Fix-Loop Protocol in pipeline.md):**

Each iteration:
1. Construct reviewer CRAFT envelope, then dispatch:
   ```
   CRAFT DISPATCH — reviewer (design mode, iteration N)
   Context  : Feature $ARGUMENTS artifacts at docs/features/$ARGUMENTS/. Scope contract: <description + out_of_scope>. Iteration N of max 3.
   Role     : You are the reviewer scoring design artifacts. Read-only. No gate presentation.
   Action   : Score all 7 artifacts /10 across 7 dimensions (quality-gate.md). Flag every out_of_scope item as BLOCKER.
   Format   : Return Reviewer Report JSON — score, verdict, findings[], checklist_status.
   Tone     : Apply rules/quality-gate.md + rules/security.md. BLOCKER caps overall at 7/10.
   ```
   > **Dispatch** `reviewer` — pass: CRAFT envelope, mode: `design`, feature, artifact paths, scope_contract
   > Returns: Reviewer Report JSON (score N/10 + findings)

2. If `score ≥ 8` AND no BLOCKER findings → proceed to Step 4 (gate)

3. If `score < 8` OR any BLOCKER:
   Construct designer fix CRAFT envelope, then dispatch:
   ```
   CRAFT DISPATCH — designer (fix mode, iteration N)
   Context  : Reviewer findings from iteration N. Feature $ARGUMENTS. Scope contract unchanged.
   Role     : You are the designer applying targeted fixes. Do not change files not mentioned in findings.
   Action   : Fix each finding exactly as described. Do not change AC numbering.
   Format   : Return: updated artifact paths + list of findings addressed + any unresolvable findings.
   Tone     : Minimal changes only. Scope contract is still the hard boundary.
   ```
   > **Dispatch** `designer` — pass: CRAFT envelope, mode: `fix`, feature, findings, scope_contract
   > Returns: updated artifacts

4. After 3 iterations still failing → escalate (see pipeline.md Fix-Loop Protocol)

---

## Step 4 — Present Gate 3 (canonical format from pipeline.md)

Exit criteria checklist:
- [ ] All 7 artifacts present, no placeholder content
- [ ] PRD.md has `AC-1, AC-2, …` acceptance criteria
- [ ] No unresolved open questions
- [ ] Design review score `≥ 8/10`
- [ ] No BLOCKER findings
- [ ] Scope contract honored (no out_of_scope items in artifacts)

Include in gate presentation: score trend across iterations (e.g. 6→7→8), artifact summary table (artifact / key decisions / open questions), key architecture decisions made.

**On ✅ Approved (explicit human approval only):**
- Move the feature card to the **Design Approved (Gate 3)** column on the board (via github MCP) — this card move *is* the approval; no flag is written to INTENT.md.
- Update `jairus.json`: bump `updated_at`, set `cursor` to `{ active_feature: <feature>, active_stage: develop }`, refresh the feature's `snapshot` entry (state-model.md write discipline).

Report success:
```
✅ Design approved — <feature-name>   score: N/10
   Board     : card moved to "Design Approved (Gate 3)"
   Artifacts : docs/features/<feature>/  (7 files)
   Key decisions: <3-5 bullet points from ADR.md>

Next: /jairus:develop <feature-name>
```

**On ❌ Changes needed:** Run one more fix-loop pass with human feedback added to findings (max 2 more after gate decline).
**On ❌ Stop:** Feature card stays in the **Design** column; it is not moved to Design Approved.

---

## On Error

| Error | Recovery |
|-------|---------|
| Scope contract fields empty | Stop: instruct user to edit INTENT.md before re-running |
| `depends_on` feature not done | Stop: list the blocking features and their current status |
| Designer fails to produce all 7 artifacts | Re-dispatch with explicit list of missing files |
| Reviewer escalation after 3 iterations | Present all findings grouped by recurrence; wait for human guidance |
