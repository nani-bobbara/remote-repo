---
description: "Implement a feature from its approved design artifacts. Dispatches the developer agent to build backend, API, components, Stripe wiring, and tests. Raises Gate 4 (schema) and Gate 5 (live Stripe) as needed. Requires the feature card in or past Design Approved (Gate 3) on the board."
argument-hint: "<feature-name>"
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, mcp__stripe__*, mcp__neon__*, mcp__github__*
---

You are the **orchestrator** running Stage 3 (Develop).
Read the Stage 3 contract in `${CLAUDE_PLUGIN_ROOT}/rules/pipeline.md` and the state model in
`${CLAUDE_PLUGIN_ROOT}/rules/state-model.md` before proceeding. Stage status is read from the
GitHub Project board (source of truth), not from INTENT.md flags. On the first jairus action in
a session, run the resume protocol (state-model.md) before Step 1.

Feature: `$ARGUMENTS`

---

## Step 1 — Verify input contract

| Check | Block message if failed |
|-------|------------------------|
| `docs/INTENT.md` exists | "Run `/jairus:init` first." |
| Feature `$ARGUMENTS` exists in INTENT.md | "Feature not found in INTENT.md." |
| Feature card is in or past the **Design Approved (Gate 3)** column on the board (via github MCP) | "Design not approved. Run `/jairus:design $ARGUMENTS` first." |
| All 7 design artifacts present | "Missing artifacts: <list>. Run `/jairus:design $ARGUMENTS` to complete design." |
| All `depends_on` features are in or past the **Review Passed (Gate 6)** column on the board (via github MCP) | "Feature `<name>` in depends_on hasn't passed review. Complete it first." |

Check for existing implementation (patch mode guard):
```bash
[ -d "src" ] && git log --oneline feature/$ARGUMENTS 2>/dev/null | head -5
```

If the feature card is already in or past **Review Passed (Gate 6)** on the board: enter **patch mode** — confirm scope with user before writing any code.

Ensure feature branch exists:
```bash
git checkout -b feature/$ARGUMENTS 2>/dev/null || git checkout feature/$ARGUMENTS
```

Move the feature card to the **Develop** column on the board (via github MCP). Do not write any status flag to INTENT.md (state-model.md).

---

## Step 2 — Dispatch developer

Construct the CRAFT envelope before dispatching:

```
CRAFT DISPATCH — developer
──────────────────────────────────────────────────────────────
Context  : Project: <display_name> — <one_liner>
           Feature: $ARGUMENTS — <feature.description>
           Backend: Neon Postgres — Drizzle + Better Auth + two-layer security (hexagonal monorepo: packages/{domain,application,adapters,auth,ui,config} + apps/{portal,admin}, cloned from jairus-starter)
           Scope contract:
               description : <feature.description>
               out_of_scope: <feature.out_of_scope[]>
           Design artifacts: docs/features/$ARGUMENTS/ (all 7 files — read before writing)
           Branch: feature/$ARGUMENTS
           Mode: implement | patch (card already in/past Review Passed on the board)

Role     : You are the developer implementing this feature from approved design artifacts.
           You own the code on branch feature/$ARGUMENTS.
           You are NOT responsible for presenting gates — signal gate4/gate5 via JSON return.
           You do NOT modify design artifacts in docs/features/.

Action   : Implement in strict order: backend → API routes → UI components → Stripe → tests.
           Pre-read the skills before writing the first line of code (architecture + auth first):
             skills/architecture/SKILL.md · skills/auth/SKILL.md · skills/nextjs/SKILL.md · skills/stripe/SKILL.md · skills/neon/SKILL.md
           Before any schema/rules change: return gate_required: gate4 and wait.
           Before any live Stripe object: return gate_required: gate5 and wait.
           Add // AC-N traceability comment on every exported fn/route/component satisfying an AC.
           Write AC Coverage table in CHECKLIST.md Phase 2 section.

Format   : Return implementation report JSON (see Stage 3 output contract in pipeline.md).
           Signal gates as: { "status": "gate_required", "gate_required": "gate4|gate5", ... }
           Return { "status": "complete" } only when type-check + test + build all pass.

Tone     : Apply rules/development.md + rules/security.md throughout.
           TypeScript strict — zero any. Auth check before every data operation.
           Never write to .env.local. Never hardcode secrets.
           Two-layer security — always: Layer 1 (MANDATORY) every user-data query scoped by session userId
           through the `withUser` app-layer path in the Drizzle repos (`@app/adapters`) (never query a user table without a userId predicate);
           Layer 2 (defense-in-depth) Postgres RLS with FORCE + a non-owner role keyed on `current_setting('app.user_id', true)`,
           fail-closed defaults. The `dbAdmin`/`DATABASE_URL_ADMIN` privileged path is reserved for system + admin cross-user access.
           Data-driven RBAC: roles are rows in a `role` table (name, permissions text[]); guards requireUser() / requirePermission('resource:action') / requireStaff() (= admin:access) in @app/auth, resolved via can(session, permission) in @app/domain. power_user = seeded superadmin (['*']); regular = portal default.
           Migrations authored in `packages/adapters/src/db/schema.ts` via `pnpm db:generate` / `pnpm db:migrate` (`drizzle-kit`) against `DATABASE_URL_ADMIN` (SQL in `packages/adapters/drizzle/`); you MAY inspect/branch via the neon MCP first.
           Auth = Better Auth in packages/auth (@app/auth); requireUser() is the first call in every route handler.
──────────────────────────────────────────────────────────────
```

> **Dispatch** `developer`
> Pass: CRAFT envelope above, INTENT.md path, feature name, locked backend, all design artifact paths
> Implementation order: backend → API routes → UI components → Stripe wiring → tests
> Returns: structured implementation report JSON with gate signals embedded

The developer signals gates via return value — the orchestrator presents them in Step 3.

The developer signals when a gate is needed by returning a `gate_required` field:
```json
{ "gate_required": "gate4", "migration_preview": "...", "rls_policies": "..." }
{ "gate_required": "gate5", "live_objects": [...] }
{ "gate_required": null, "status": "complete" }
```

---

## Step 3 — Handle conditional gates

**When developer signals `gate_required: gate4`** — present Gate 4 using canonical format from pipeline.md:

Exit criteria checklist:
- [ ] Drizzle migration SQL diff shown (`drizzle-kit generate` output)
- [ ] RLS policies reviewed (ENABLE + FORCE, non-owner app role) and app-layer userId scoping confirmed
- [ ] Reversibility noted (migrations are append-only — never edit an applied one)

On ✅ Approved → relay approval to developer; developer applies via `drizzle-kit migrate` against `DATABASE_URL_ADMIN` (may inspect/branch via the neon MCP first) and verifies RLS is on (`pg_tables.rowsecurity`, `pg_policies`)
On ❌ Changes needed → relay feedback to developer; developer revises schema; developer re-signals gate4
On ❌ Stop → pause development at schema step; user must re-run `/jairus:develop` to continue

**When developer signals `gate_required: gate5`** — present Gate 5 using canonical format:

Exit criteria checklist:
- [ ] Live-mode products, prices, webhooks listed
- [ ] Test-mode status confirmed (tested before going live)
- [ ] Irreversibility acknowledged (live Stripe objects cannot be easily deleted)

On ✅ Approved → developer creates via mcp__stripe__* live mode
On ❌ Skip → remain test mode only; note deferred to `/jairus:deploy`
On ❌ Stop → no live Stripe wiring this session

---

## Step 4 — Verify output contract

After developer returns `status: complete`, verify all exit criteria:

```bash
pnpm type-check   # must exit 0
pnpm test             # must exit 0
pnpm build        # must exit 0
```

| Exit criterion | Check |
|---------------|-------|
| type-check passes | `pnpm type-check` exit 0 |
| All tests pass | `pnpm test` exit 0 |
| Build succeeds | `pnpm build` exit 0 |
| Backend verified | Developer confirmed state after any schema change (via `drizzle-kit`, or the neon MCP) |
| Gate 4 completed or not needed | Noted in implementation report |
| Gate 5 completed or deferred | Noted in implementation report |

**If any check fails (max 2 retries):**
Construct fix CRAFT envelope:
```
CRAFT DISPATCH — developer (fix mode)
Context  : Exit check failure output: <npm error>. Feature $ARGUMENTS. Branch feature/$ARGUMENTS.
Role     : Fix the failing check only. Do not refactor passing code.
Action   : Minimal fix for the specific error. Re-run checks after each change.
Format   : Return { "status": "complete" } when all checks pass, or { "status": "failed", "error": "..." }.
Tone     : rules/development.md. TypeScript strict. Zero any.
```
> **Dispatch** `developer` — pass: CRAFT envelope, mode: `fix`, failing check output
> Returns: fixed code

Re-run checks. After 2 failed retries: stop and present failure to human with full output.

**On all checks passing:**
Move the feature card to the **Review** column on the board (via github MCP). Update `jairus.json`: bump `updated_at`, set `cursor` to `{ active_feature: <feature>, active_stage: review }`, refresh the feature's `snapshot` entry (state-model.md write discipline).

Report success:
```
✅ Development complete — <feature-name>
   Branch   : feature/<feature-name>
   Tests    : <N> passing
   Type     : ✅ zero errors
   Build    : ✅ success
   Gate 4   : <applied / not needed>
   Gate 5   : <live / test-mode / deferred>

Next: /jairus:review <feature-name>
```

---

## On Error

| Error | Recovery |
|-------|---------|
| Feature card not yet in **Design Approved (Gate 3)** | Hard stop: design must be approved (card moved to Design Approved) before any code is written |
| Missing design artifacts | List which are missing; user must re-run `/jairus:design` |
| type-check / test / build fail after 2 retries | Present failure output to human; stop |
| Backend MCP write fails | Developer reports gap; present to human; gate cannot be marked complete |
