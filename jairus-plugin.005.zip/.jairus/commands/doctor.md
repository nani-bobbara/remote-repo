---
description: "Diagnose and fix machine readiness. Checks toolchain, credentials, MCP connectivity, and plugin integrity. Writes missing credentials to the shell profile. Safe to run anytime — always read-only in --check mode."
argument-hint: "[--check] [--feature <name>]"
allowed-tools: Read, Write, Bash, Glob, Grep, mcp__stripe__*, mcp__github__*, mcp__vercel__*, mcp__neon__*
---

You are running **jairus doctor** — a combined setup wizard and health check.
Run it once per machine before the first project, and any time something seems wrong.

- **No arguments**: diagnose everything; prompt to fix what is broken.
- **`--check`**: diagnose only — no prompts, no writes. Reports current state.
- **`--feature <name>`**: deep-dive on one feature's pipeline state (skip to Step 5).

Report every check with: ✅ ready · ⚠️ warn (works but incomplete) · ❌ missing / failed
For every ⚠️ or ❌, include a one-line **Fix** action.
**Never print secret values** — only whether a variable is set.

## Preconditions

None — always safe to run. Never touches application code, INTENT.md, or pipeline state.

---

## --feature flag (deep-dive mode)

If `$ARGUMENTS` contains `--feature <name>`, skip Steps 1–4 and run only Step 5
with extended detail for that feature. Useful after a failed run or session interruption.

Status is read from the **GitHub Project board** (source of truth, via github MCP), then
cross-checked (reconciled) against the `jairus.json` cursor/snapshot and against git/files.
Report any **drift** (e.g. cursor says "develop done" but no branch exists, or snapshot column
≠ live board column). The board wins; a stale `jairus.json` is drift, not truth (state-model.md).

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
FEATURE STATE — <feature-name>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Board column (SoT)   : <Backlog|Design|Design Approved|Develop|Review|Review Passed|Deploy|Done>
jairus.json cursor   : active_feature=<name> · active_stage=<stage>
jairus.json snapshot : <column> @ <refreshed_at>   (drift vs board? yes/no)
description (seed)    : <text or "MISSING — /jairus:design will be non-deterministic">
out_of_scope (seed)   : <list or "none specified">

Design artifacts     :
  PRD.md             : ✅ present / ❌ missing
  DESIGN.md          : ✅ present / ❌ missing
  API.md             : ✅ present / ❌ missing
  DATABASE.md        : ✅ present / ❌ missing
  COMPONENTS.md      : ✅ present / ❌ missing
  ADR.md             : ✅ present / ❌ missing
  CHECKLIST.md       : ✅ present / ❌ missing

CHECKLIST.md state   :
  Phase 1 (design)   : N/8 items checked
  Phase 2 (develop)  : N/13 items checked
  Phase 3 (review)   : N/8 items checked
  AC Coverage table  : ✅ filled / ⚠️ empty / ❌ missing

Git state            :
  Branch feature/<name> : ✅ exists / ⚠️ not found
  Commits ahead of main : N
  Working tree          : clean / dirty (<N> uncommitted files)

Current stage gap    : <what is blocking forward progress>
Recommended action   : <single most impactful next step>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Step 1: Detect environment

```bash
node --version
npm --version
git --version
```

Detect the shell and profile file:

| Shell | Profile file |
|-------|-------------|
| zsh | `~/.zshrc` |
| bash | `~/.bashrc` or `~/.bash_profile` |
| PowerShell (Windows) | `$PROFILE` (usually `~\Documents\PowerShell\Microsoft.PowerShell_profile.ps1`) |

Read the plugin version dynamically (never hardcode it):
```bash
node -p "require('${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json').version"
```

Print (lead with the Jairus version):
```
ENVIRONMENT
  Jairus    : v<version from plugin.json>
  OS        : <Windows | macOS | Linux>
  Shell     : <zsh | bash | PowerShell>
  Profile   : <path to shell profile>
  Node.js   : <version> ✅ / ❌ (need 18+)
  npm       : <version> ✅ / ❌
  git       : <version> ✅ / ❌
```

If Node.js < 18 or missing: print fix instruction and stop — nothing else will work.

---

## Step 2: Plugin integrity

Confirm `${CLAUDE_PLUGIN_ROOT}` resolves and all files are present:

| Check | Expected |
|---|---|
| `${CLAUDE_PLUGIN_ROOT}/commands/` | 10 command files present (doctor init board design develop review deploy ship extend help) |
| `${CLAUDE_PLUGIN_ROOT}/agents/` | 6 agents: planner, designer, developer, reviewer, deployer, extender |
| `${CLAUDE_PLUGIN_ROOT}/skills/` | 11 skills: architecture, auth, nextjs, stripe, vercel, github, neon, ai, email, feature-flags, theming |
| `${CLAUDE_PLUGIN_ROOT}/rules/` | 8 rules: pipeline, quality-gate, security, development, design-workflow, adoption, mcp-usage, state-model |
| `${CLAUDE_PLUGIN_ROOT}/templates/` | INTENT.md, jairus.json, env.example, design.md, feature/, database/, ci/, observability/ |
| `.mcp.json` at project root | ⚠️ if missing — `/jairus:init` will create it |
| `.claude/settings.json` at project root | ⚠️ if missing — `/jairus:init` will create it |
| `.claude/skills/` at project root (foundation'd project) | ⚠️ if missing the official vendor skills — expected: `neon-postgres` (neondatabase/agent-skills), `stripe-best-practices` (stripe/ai), `vercel` (vercel-labs/agent-skills), `shadcn` (shadcn/ui), + `anthropics/skills` when the `ai` extension is on (installed at Foundation F4b). Fix: `npx skills add …` / `npx skills update` (see `rules/foundation.md`) |

---

## Step 3: Credentials

Check each env var (never print the value):

```bash
[ -n "${VAR_NAME:-}" ] && echo "set" || echo "MISSING"
```

The backend is always Neon Postgres (fixed) — there is no host profile to read.

> **MCP auth vs runtime secrets.** The four OAuth MCP servers (stripe, github, vercel, neon)
> authenticate via browser OAuth on first use — no tokens or API keys live in `.mcp.json` or the
> shell env. The variables below are **runtime app secrets** (needed by the deployed app / CI),
> NOT MCP credentials — MCP auth is handled separately in Step 3b.

**Always required (runtime app secret — server-side Stripe calls):**
- `STRIPE_SECRET_KEY`

**Neon backend — DEVELOP-TIME, not needed to `init`/`board`/`design`:**
- `DATABASE_URL` (use the **pooled** Neon connection string — scoped app access)
- `DATABASE_URL_ADMIN` (privileged conn for migrations + system + admin cross-user ops)
- `BETTER_AUTH_SECRET` (32+ random chars — signs Better Auth sessions; server-only)
- `BETTER_AUTH_URL` (base URL — each app uses its own origin in dev: portal `http://localhost:3001`, admin `http://localhost:3002`; the deployed URL in prod)
- Optional: `ADMIN_EMAIL` / `ADMIN_INITIAL_PASSWORD` (seed admin), `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` (OAuth sign-in)

> These are checked when the pipeline reaches `/jairus:develop`. Their absence is **not** a blocker
> for a fresh `init`/`board`/`design` run — report as ⚠️ "needed at develop", not ❌, pre-develop.

**Stripe (runtime, checked separately):**
- `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`
- `STRIPE_WEBHOOK_SECRET`

**MCP authorization (OAuth — not env vars):** stripe, github, vercel, and neon all authorize via
browser OAuth (see Step 3b). Attempt a lightweight `mcp__<server>__*` call for each; if it fails,
mark ❌ not authorized — run `claude mcp login <server>`.

Also check file presence:
- `.env.local` at project root: ✅ present / ⚠️ missing
- `.env.example` at project root: ✅ present / ⚠️ missing

Print credential summary. If `--check`: stop here after printing summary.

---

## Step 3b: OAuth server pre-authorization (non --check mode only)

**This must happen before the pipeline runs and before Claude Code restarts.**
OAuth tokens are stored by Claude Code's keychain — not in env vars or `.mcp.json`.

All four servers authorize via browser OAuth (no static tokens). Each is authorized once
via `claude mcp login <server>` run in a **new terminal** (browser opens):

| Server | Auth method | How to authorize |
|--------|------------|-----------------|
| `stripe` | OAuth (HTTP MCP) | `claude mcp login stripe`, then approve in browser |
| `github` | OAuth (HTTP MCP) | `claude mcp login github`, then approve in browser |
| `vercel` | OAuth (HTTP MCP) | `claude mcp login vercel`, then approve in browser |
| `neon` | OAuth (HTTP MCP) | `claude mcp login neon`, then approve in browser |

Schema ops run via Drizzle migrations (`drizzle-kit`) against `DATABASE_URL_ADMIN`; the neon
MCP additionally enables schema inspection and DB branching per preview.

For each of the four OAuth servers that is not yet authorized, print this instruction and
pause — do not continue until the user confirms:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MCP OAuth authorization required — <server>
  This server uses Claude Code's built-in OAuth, not a static API token.
  OAuth tokens are stored in Claude Code's keychain — not in env vars.

  ⚡ Open a NEW terminal (outside Claude Code) and run:
       claude mcp login <server>

  Your browser will open. Authorize the connection.
  Once authorized, come back here and type "done".

  Why now? If you skip this, Claude will hit an auth wall mid-pipeline
  (e.g., mid-deploy or mid-migration) with no graceful recovery path.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

After user confirms "done": attempt a lightweight MCP call to verify the token was stored.
If it fails, repeat the instruction once — if it fails again, mark ⚠️ DEFERRED and warn
which stages will be blocked by that server.

---

## Step 4: MCP connectivity

The active server set is read from the project `.mcp.json` (post-init) or, before init
exists, from `${CLAUDE_PLUGIN_ROOT}/templates/mcp.json` — there is no longer a
plugin-level `.mcp.json`.

Attempt one lightweight read on each active MCP server:

| Server | Test call | Failure means |
|---|---|---|
| neon | List projects or run a read-only query | Not authorized (run `claude mcp login neon`) |
| stripe | List products (limit 1) | Not authorized (run `claude mcp login stripe`) |
| vercel | List projects | Not authorized (run `claude mcp login vercel`) |
| github | Get authenticated user | Not authorized (run `claude mcp login github`) |

Report each as ✅ CONNECTED · ⚠️ NOT_CONFIGURED · ❌ UNREACHABLE with a one-line Fix action.

> **Auth failure note:** For all four OAuth servers (stripe, github, vercel, neon), a failed test
> call almost always means the server is not yet authorized — run `claude mcp login <server>` in a
> new terminal (Step 3b).

If any server is ❌ UNREACHABLE: mark overall status BLOCKED and do not proceed past Step 4.
The pipeline cannot run safely if a required MCP server is unavailable.

---

## Step 5: Project state

| Check | How to verify |
|---|---|
| `docs/INTENT.md` present | File exists |
| INTENT.md status | Read `status:` (draft / bootstrapped / active) |
| Backend | Read `backend:` (always `neon`) |
| `docs/design.md` present | File exists |
| Features + approvals | List `docs/features/*/`; grep each CHECKLIST.md |
| Git repo | `git rev-parse --is-inside-work-tree` |
| Working tree | `git status --porcelain` |

If `package.json` exists, check required scripts: `dev`, `build`, `type-check`, `test`.

Also read `jairus.json` at the project root (the control footprint — see
`${CLAUDE_PLUGIN_ROOT}/rules/state-model.md`) and report:

| Check | How to verify |
|---|---|
| `jairus.json` present | File exists (⚠️ if missing but board exists → can be rebuilt from board + git/files) |
| Board pointer | `project.board.url` / `number` set (points at the status SoT) |
| Cursor | `cursor.active_feature` / `active_stage` (resume hint) |

**Version anchor (semver rule from state-model.md):** compare `jairus.json.jairus_version`
against the current plugin version in `${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json`:
- same → ✅ up to date.
- newer plugin, **patch/minor** → ⚠️ a silent `schema_version` migration + re-stamp is due (note it).
- newer plugin, **major** → ❌ migration must be prompted and approved before proceeding — never auto-jump a major.
Report as: `jairus <jairus_version> vs plugin <plugin version> — <up to date | migration due (minor) | migration required (major)>`.

---

## Step 5b: Observability (optional — never blocks)

Claude Code emits OpenTelemetry natively; jairus does not instrument anything itself.
Check whether telemetry is wired to a collector (Grafana Cloud or any OTLP endpoint):

```bash
[ -n "${CLAUDE_CODE_ENABLE_TELEMETRY:-}" ] && [ -n "${OTEL_EXPORTER_OTLP_ENDPOINT:-}" ] && echo "on" || echo "off"
```

Report as:
- ✅ ON — telemetry enabled, exporting to `<endpoint host only, never the token>`
- ⚪ OFF — optional; not configured (this is the default, not a problem)

If OFF and not in `--check` mode, mention once (do not prompt or pause):
> Observability is optional. To stream Claude's tool/agent/command telemetry to
> Grafana Cloud, run `/jairus:init` (it will offer to set it up) or see the
> `Observability` block in `.env.example`. A prebuilt dashboard lives at
> `${CLAUDE_PLUGIN_ROOT}/templates/observability/grafana-dashboard.json`.

Never treat OFF as a failure — it does not affect readiness level.

---

## Step 6: Collect and fix missing credentials (non --check mode)

For each ❌ credential (skipping ✅ ones), prompt the user one at a time:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MISSING: STRIPE_SECRET_KEY
  Where to find it: Stripe Dashboard → Developers → API keys → Secret key
  Use test key (sk_test_*) during development — live key only at Gate 5.

  Paste your Stripe secret key (input hidden):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

Guidance per credential:

| Credential | Where to find it |
|---|---|
| `STRIPE_SECRET_KEY` | Stripe Dashboard → Developers → API keys → Secret key. Runtime app secret for server-side calls. Use `sk_test_*` during dev. |
| `DATABASE_URL` | Your Neon connection string — use the **pooled** one (host contains `-pooler`). Scoped app access. |
| `DATABASE_URL_ADMIN` | Neon privileged connection string — used for migrations + system + admin cross-user ops. |
| `BETTER_AUTH_SECRET` | Generate 32+ random chars (e.g. `openssl rand -base64 32`). Server-only. |
| `BETTER_AUTH_URL` | Dev: per app — portal `http://localhost:3001`, admin `http://localhost:3002`. Prod: the deployed app URL. |

The four OAuth MCP servers (stripe, github, vercel, neon) are **not** collected as env vars —
they authorize via browser OAuth. If any is ❌ not authorized:
```
MCP — OAuth authorization required (<server>)
  This server uses Claude Code's built-in OAuth, not a static token.
  Open a NEW terminal and run:  claude mcp login <server>
  After authorizing, re-run /jairus:doctor to confirm connection.
```

If the user skips a credential: mark ⚠️ skipped — warn which pipeline stage will fail.

**Write collected credentials to shell profile** (append, never overwrite):
These are runtime app secrets only — MCP servers authorize via OAuth, not env vars.

Bash/zsh:
```bash
# jairus runtime secrets — added by /jairus:doctor
export STRIPE_SECRET_KEY="<value>"
export DATABASE_URL="<value>"
export BETTER_AUTH_SECRET="<value>"
# (only the vars that were collected)
```

PowerShell:
```powershell
# jairus runtime secrets — added by /jairus:doctor
$env:STRIPE_SECRET_KEY = "<value>"
$env:DATABASE_URL = "<value>"
$env:BETTER_AUTH_SECRET = "<value>"
```

After writing: confirm the file path and variable names written — never print the values.

---

## Step 7: Summary

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DOCTOR SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Overall  : READY | PARTIAL | BLOCKED

1. Toolchain ✅ | ⚠️ | ❌  [Node <ver>, npm, git]
2. Plugin    ✅ | ⚠️ | ❌  [N/N files present]
3. Creds     ✅ | ⚠️ | ❌  [N/N vars set]
4. MCP       ✅ | ⚠️ | ❌  [N/4 servers connected — stripe, github, vercel, neon]
5. Project   ✅ | ⚠️ | ❌  [status: <value> / not initialized]
6. Telemetry ✅ ON | ⚪ OFF  [optional — Grafana/OTLP export]

Most important next action:
  <single most impactful fix or next step>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

If credentials were written to shell profile:
```
  ⚡ Restart Claude Code so the shell profile is reloaded, then re-run /jairus:doctor --check
```

If all green and no project yet:
```
  Ready. Run /jairus:init to start your project.
```

If all green and project exists:
```
  All systems go. Run /jairus:ship to continue the pipeline.
```

---

## Readiness levels

- **READY**: all ✅, no ❌, at most minor ⚠️
- **PARTIAL**: some ⚠️ that affect functionality but don't block all commands
- **BLOCKED**: one or more ❌ that prevent the pipeline from running

---

## On Error

| Error | Recovery |
|---|---|
| Node.js missing or < 18 | "Install Node.js 18+ from nodejs.org then re-run /jairus:doctor" |
| `${CLAUDE_PLUGIN_ROOT}` does not resolve | "Plugin is not active — run `/plugin install jairus@jairus-plugin`" |
| Shell profile not writable | "Cannot write to <path>. Add credentials manually then re-run `/jairus:doctor --check`." |
| Value looks wrong (e.g. Stripe key doesn't start with `sk_`) | Warn and ask: "This doesn't look like a valid Stripe key. Save anyway? (y/n)" |
| `DATABASE_URL` malformed (not `postgres://…`) | Warn: "This doesn't look like a Postgres connection string. Save anyway? (y/n)" |
| MCP call throws unexpected error | Mark ❌ UNREACHABLE; include the error message in the Fix |

---

## Rules

- Never print a credential value — only confirm variable names written
- `--check` mode is always read-only — no prompts, no writes
- Never start the pipeline — doctor is purely environment preparation and diagnostics
- Never modify application code, INTENT.md, or any `.jairus/` file
