---
description: "Create or refresh the GitHub Project board from INTENT.md. Dispatches the planner agent in plan-then-create mode. Idempotent — safe to re-run to add stories or update column assignments."
argument-hint: "[--refresh]"
allowed-tools: Read, Bash, Glob, Grep, mcp__github__*
---

You are the **orchestrator** running Stage 1 (Board).
Read the Stage 1 contract in `${CLAUDE_PLUGIN_ROOT}/rules/pipeline.md` and the state model in
`${CLAUDE_PLUGIN_ROOT}/rules/state-model.md` before proceeding.

The GitHub Project board this command creates is the **source of truth for feature/stage
status** (state-model.md). The planner establishes the gate→column scheme:

```
Backlog → Design → Design Approved (Gate 3) → Develop → Review → Review Passed (Gate 6) → Deploy → Done
```

Moving a card into a gate column (Design Approved, Review Passed) is the real gate action —
INTENT.md progress flags are retired. After creating/refreshing the board, this command updates
`jairus.json` (board pointer + `snapshot`) per state-model.md write discipline.

---

## Step 1 — Verify input contract

Check each item in the Stage 1 input contract:

```bash
# INTENT.md must exist and not be in draft state
[ -f "docs/INTENT.md" ] && grep -q "status: bootstrapped\|status: active" docs/INTENT.md \
  && echo "ok" || echo "BLOCKED"
```

| Check | Block message if failed |
|-------|------------------------|
| `docs/INTENT.md` exists | "Run `/jairus:init` to bootstrap the project first." |
| `status: bootstrapped` or `status: active` | "INTENT.md is still in draft state. Complete `/jairus:init` first." |
| GitHub MCP connected | "GitHub MCP is not connected. Run `/jairus:doctor` to fix credentials." |

Do not proceed past Step 1 until all checks pass.

---

## Step 2 — Dispatch planner (plan-only mode)

Construct the CRAFT envelope (see CRAFT Dispatch Envelope in pipeline.md) before dispatching:

```
CRAFT DISPATCH — planner (plan mode)
──────────────────────────────────────────────────────────────
Context  : Project: <display_name> — <one_liner> from INTENT.md
           Features: <N> features with dependency graph
           Backend: Neon Postgres (Drizzle + Better Auth) · monorepo (portal + admin, shared packages)
           Existing board: <GitHub Project URL if found, or "none">
           Scope: read-only — no GitHub writes in this pass

Role     : You are the planner. You own GitHub Project structure.
           You are NOT responsible for presenting Gate 2 or writing to INTENT.md.

Action   : Produce a board plan covering every feature in INTENT.md.
           Map each feature to an issue with correct column assignment and dependency labels.
           Reconcile with existing GitHub issues — do not recreate what already exists.

Format   : Return the structured board plan (see Stage 1 output contract in pipeline.md).
           Plan mode only — no GitHub objects created. Return the plan text for gate review.

Tone     : Dependency order must be correct. Labels must match adopt_status.
           Existing issues take priority over new creates (idempotency rule).
──────────────────────────────────────────────────────────────
```

> **Dispatch** `planner`
> Mode: `plan`
> Pass: CRAFT envelope above, `docs/INTENT.md` path, existing GitHub Project URL if known
> Returns: structured board plan (epics, feature issues, column assignments, reconciliation note)
> On agent failure: present the plan manually from the INTENT.md feature list

The planner runs **read-only** in this pass — no GitHub objects are created yet.

---

## Step 3 — Verify output contract

Before presenting the gate, confirm the plan covers every feature in INTENT.md:

| Exit criterion | Check |
|---------------|-------|
| All features mapped to issues | Every `features[].name` appears in the plan |
| Dependency labels applied | Each feature with `depends_on` has `blocked-by` labels |
| Existing issues de-duplicated | Plan notes which issues already exist (not recreated) |

If any criterion fails: ask the planner to revise the plan before presenting the gate.

---

## Step 4 — Present Gate 2 (canonical format from pipeline.md)

Present Gate 2 using the canonical gate format. Exit criteria checklist:
- [ ] Board plan covers all INTENT.md features
- [ ] Dependency labels applied to blocked features
- [ ] Existing GitHub objects reconciled (not duplicated)

**On ✅ Approved:**
Re-dispatch planner in create mode:

> **Dispatch** `planner`
> Mode: `create`
> Pass: `docs/INTENT.md`, approved board plan from Step 2
> Returns: GitHub Project URL (MCP-confirmed), issue count, capability tier used, any partial failures

Verify the Project and all items exist via github MCP before reporting done. Then update
`jairus.json`: set `project.board.{url,number}`, refresh `snapshot.features` from the board,
bump `updated_at`, and set `snapshot.refreshed_at` (state-model.md write discipline). If
`jairus.json` is missing, rebuild it from the board + git/files per state-model.md.

Report success:
```
✅ Board created — <GitHub Project URL>
   Epics     : <N> milestones
   Features  : <N> issues
   Columns   : Backlog · Design · Design Approved (Gate 3) · Develop · Review · Review Passed (Gate 6) · Deploy · Done
   Status SoT: this board (jairus.json board pointer + snapshot updated)

Next: /jairus:design <first-feature>  or  /jairus:ship
```

**On ❌ Changes needed:** Ask user to update INTENT.md feature list and re-run `/jairus:board`.
**On ❌ Stop:** Note that the board is deferred. User can run `/jairus:board` when ready.

---

## On Error

| Error | Recovery |
|-------|---------|
| `docs/INTENT.md` missing | Stop: "Run `/jairus:init` to bootstrap first." |
| `status: draft` | Stop: "Complete `/jairus:init` — status must be `bootstrapped`." |
| GitHub MCP fails on create | Report partial failures; user can re-run `/jairus:board` (idempotent) |
| Planner returns empty plan | Present feature list from INTENT.md manually; present gate manually |
