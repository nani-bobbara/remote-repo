---
description: "Run the full pipeline for all planned features in dependency order: design → develop → review for each, then deploy. Pauses at every 🚦 gate. Pass --plan to preview the sequence without executing."
argument-hint: "[--plan] [feature-name]"
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, mcp__stripe__*, mcp__neon__*, mcp__github__*, mcp__vercel__*
---

You are the **pipeline orchestrator**. Read the Stage Contract Registry in
`${CLAUDE_PLUGIN_ROOT}/rules/pipeline.md` and the state model in
`${CLAUDE_PLUGIN_ROOT}/rules/state-model.md` before proceeding — every stage contract,
gate definition, fix-loop protocol, and dispatcher pattern is defined there.

**On start, run the resume protocol** (state-model.md): read `jairus.json`, version-check
against `${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json`, reconcile the cursor/snapshot
against the live GitHub Project board (board wins) and git/files, then pick up the queue at the
cursor. The GitHub Project board is the source of truth for feature/stage status — INTENT.md
progress flags are retired; INTENT.md is only the seed (feature list + `depends_on` graph).

Target: **$ARGUMENTS** — a single feature name, `--plan` for dry run, or empty for the whole backlog.

## Preconditions

- `docs/INTENT.md` exists with `status: bootstrapped` or `status: active`.
- Backend is Neon Postgres (fixed) and the topology is a monorepo (portal + admin, shared packages).
- Feature breakdown was human-approved at Gate 1 (during `/jairus:init`).
- If INTENT.md is missing or `status: draft`: stop — "Run `/jairus:init` to complete bootstrapping first."
- GitHub Project board should exist (run `/jairus:board` if not) — it is the status source of truth.
  If the board is unreachable, fall back to the `jairus.json` snapshot and say status is last-known
  (not live), and block gate-dependent actions until the board is reachable (state-model.md).

---

## Step 1: Build the execution plan from the board (SoT) + INTENT.md seed

- Read `docs/INTENT.md` for the **seed only**: the feature list and the `depends_on` graph. Build the dependency graph (topological sort). Do **not** read status flags from INTENT.md — they are retired.
- Read **feature/stage status from the GitHub Project board** (via github MCP), using the gate→column scheme in state-model.md (`Backlog → Design → Design Approved (Gate 3) → Develop → Review → Review Passed (Gate 6) → Deploy → Done`). Cache into `jairus.json.snapshot`; the board wins on any disagreement.
- Classify each feature by its board column:
  - **skip**: card in **Done** (already shipped)
  - **in-progress**: card in **Design / Develop / Review / Deploy** (already running — offer to continue or restart)
  - **unlocked**: card in **Backlog** with all `depends_on` in or past **Review Passed (Gate 6)**
  - **blocked**: card in **Backlog** with one or more `depends_on` not yet at Review Passed

---

## Step 2: Handle --plan flag (dry run — no execution)

If `$ARGUMENTS` contains `--plan`:

Print the execution plan without running anything:
```
SHIP PLAN — <display_name>

Dependency-ordered feature sequence:
  1. bootstrap-app     [unlocked]   Gates: design(3) → backend(4) → stripe(5)? → code(6)
  2. auth              [unlocked after 1]   Gates: design(3) → backend(4) → code(6)
  3. <feature A>       [unlocked after 2]   Gates: design(3) → code(6)
  4. <feature B>       [blocked by: feature A]
  5. billing           [unlocked after 2]   Gates: design(3) → backend(4) → stripe(5) → code(6)

Already done: [list or "none"]
In progress: [list with current stage or "none"]

Gates per feature:
  Gate 3  — Design handover (every feature)
  Gate 4  — Backend schema changes (if DATABASE.md has schema changes)
  Gate 5  — Live Stripe objects (billing feature only)
  Gate 6  — Code review pre-merge (every feature)

After all features reviewed:
  Gate 7  — Staging verification
  Gate 8  — Production deployment

Total gates (estimate): N
```

Then stop — do not execute anything.

---

## Step 3: Determine execution scope

If `$ARGUMENTS` names a specific feature:
- Run only that feature through its full cycle (design → develop → review)
- Skip the rest of the backlog
- After completion: "Feature `<name>` complete. Run `/jairus:ship` to continue the backlog."

If `$ARGUMENTS` is empty: run the full backlog in dependency order.

---

## Step 4: Feature loop (dependency-ordered)

For each unlocked feature in dependency order, run its gated micro-cycle:

### 4a — Skip check (board column is the status)
- If the card is in **Done**: print "  ✓ `<feature>` already done — skipping" and continue to next.
- If the card is in **Design / Develop / Review / Deploy**: print current column, ask "Continue from `<stage>` or restart from design?"

### 4b — Design stage
Execute Stage 2 contract from pipeline.md (`/jairus:design` dispatcher pattern):
- Verify Stage 2 input contract — stop if scope_contract.description is empty
- Dispatch `designer` with scope contract → 7 artifacts
- Fix-loop per Fix-Loop Protocol in pipeline.md (max 3 iterations)
- **🚦 Gate 3 — Design handover** (canonical gate format — human must approve)
- On approval: move card to **Design Approved (Gate 3)** on the board; update `jairus.json` cursor/snapshot (no INTENT.md flag)

### 4c — Develop stage
Execute Stage 3 contract from pipeline.md (`/jairus:develop` dispatcher pattern):
- Verify Stage 3 input contract
- Dispatch `developer` (pre-loads nextjs + stripe + neon skills)
- **🚦 Gate 4** — if developer signals `gate_required: gate4` (human must approve)
- **🚦 Gate 5** — if developer signals `gate_required: gate5` (human must approve)
- Verify all exit criteria (type-check + test + build)
- On all passing: move card to **Review** on the board; update `jairus.json` cursor/snapshot

### 4d — Review stage
Execute Stage 4 contract from pipeline.md (`/jairus:review` dispatcher pattern):
- Verify Stage 4 input contract (build must pass before review begins)
- Fix-loop per Fix-Loop Protocol in pipeline.md (max 3 iterations)
- **🚦 Gate 6 — Pre-merge handover** (canonical gate format — human must approve)
- On approval: open PR, move card to **Review Passed (Gate 6)** on the board; update `jairus.json` cursor/snapshot (no INTENT.md flag)

### 4e — Mark review-passed and unlock
- Print: "  ✓ `<feature>` complete (design N/10, code M/10)"
- The card is now in **Review Passed (Gate 6)** (deploy moves it to Deploy → Done later).
- Check if any blocked features are now unlocked (all their `depends_on` are in/past Review Passed on the board)
- If newly unlocked features exist: print "Unlocked: [list]"

### Blocking rules
- If a feature's cycle is blocked at a gate (escalation, failing build, missing dep): STOP.
  Do not skip ahead past a dependency. Print: "Blocked at `<feature>` — `<reason>`. Resolve before continuing."
- If Gate 3, 4, 5, or 6 is denied: stop the loop for that feature; report current state.
  User must re-run `/jairus:ship` or the specific stage command to continue.

---

## Step 5: After all features complete

When every feature card is in or past **Review Passed (Gate 6)** on the board:

```
All features complete. Reviewed features ready for deployment:
  <feature list>

Run /jairus:deploy to ship to staging then production.
```

Note: `ship` does NOT run deploy automatically — `/jairus:deploy` requires explicit user invocation.

---

## Step 6: Status updates between features

Between each feature, print a one-line status + next action:
```
  ✓ auth (design 9/10, code 8/10) — next: <feature A>
  → Starting: <feature A>
```

Never advance past a failed gate or a score < 8 without either a passing re-review or
explicit human approval at the gate.

---

## On Error

| Error | Recovery |
|---|---|
| INTENT.md missing | Stop; "Run `/jairus:init` first" |
| Feature in unknown status | Ask user: "Feature `<name>` has status `<value>` — continue, restart, or skip?" |
| Design fix-loop exhausted (3 iterations, still < 8) | Stop loop; escalate to human; re-run `/jairus:design <feature>` after addressing findings |
| Build/test fails during develop | Stop at that feature; user fixes and re-runs `/jairus:ship` (resumes from reviewing status) |
| Code review fix-loop exhausted | Stop loop; escalate to human; re-run `/jairus:review` after addressing findings |
| Gate denied by user | Stop; note which gate was denied; user re-runs the appropriate command when ready |
| Dependency cycle detected | Stop; report the cycle; user must fix `depends_on` in INTENT.md |

---

## Rules
- Never skip a 🚦 gate.
- Never start develop before design is approved.
- Never open a PR before code review passes.
- `ship` never runs deploy — that requires explicit `/jairus:deploy`.
- Cross-reference `${CLAUDE_PLUGIN_ROOT}/rules/pipeline.md` for the full gate + actor definitions.
