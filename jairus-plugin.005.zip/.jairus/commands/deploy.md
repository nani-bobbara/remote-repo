---
description: "Deploy a reviewed feature to staging then production. Dispatches the deployer agent for preflight and preview, presents Gate 7 (staging verification) then Gate 8 (production approval). Requires the feature card in or past Review Passed (Gate 6) on the board."
argument-hint: "[feature-name]"
allowed-tools: Read, Bash, Glob, Grep, mcp__stripe__*, mcp__neon__*, mcp__github__*, mcp__vercel__*
---

You are the **orchestrator** running Stage 5 (Deploy).
Read the Stage 5 contract in `${CLAUDE_PLUGIN_ROOT}/rules/pipeline.md` and the state model in
`${CLAUDE_PLUGIN_ROOT}/rules/state-model.md` before proceeding. Stage status is read from the
GitHub Project board (source of truth), not from INTENT.md flags. On the first jairus action in
a session, run the resume protocol (state-model.md) before Step 1.

Feature: `$ARGUMENTS` (or deploy all reviewed-but-undeployed features if omitted)

---

## Step 1 — Verify input contract

| Check | Block message if failed |
|-------|------------------------|
| Feature card in or past the **Review Passed (Gate 6)** column on the board (via github MCP) | "Code review not passed. Run `/jairus:review <feature>` first." |
| PR open on GitHub | "No open PR found for this feature." |
| Vercel MCP connected | "Vercel MCP not connected. Run `/jairus:doctor` — Vercel requires OAuth via `/mcp`." |

**Backend env + migrations (Neon):** set `DATABASE_URL` (the **pooled** connection string),
`DATABASE_URL_ADMIN` (privileged conn for migrations + system/admin cross-user ops),
`BETTER_AUTH_SECRET`, and `BETTER_AUTH_URL` as Vercel env vars per environment
(`BETTER_AUTH_URL` = the deployed URL in production). Apply the migration with
`drizzle-kit migrate` against the target `DATABASE_URL_ADMIN`, then verify RLS is on
(`pg_tables.rowsecurity`, `pg_policies`).

Point **preview** deployments at a Neon **branch** so previews never touch production data;
production uses the main branch. You MAY inspect/apply via the neon MCP.

---

## Step 2 — Dispatch deployer (preflight + preview)

Construct the CRAFT envelope before dispatching:

```
CRAFT DISPATCH — deployer (preview phase)
──────────────────────────────────────────────────────────────
Context  : Project: <display_name> — <one_liner>
           Feature: $ARGUMENTS — <feature.description>
           Backend: Neon Postgres — Drizzle + Better Auth (monorepo: portal + admin, shared packages)
           PR: #<number> on branch feature/$ARGUMENTS
           Gate 4 status: <applied | not needed> (from Stage 3 handover)
           Gate 5 status: <live | test-mode | deferred> (from Stage 3 handover)
           Board: card in/past "Review Passed (Gate 6)" ✅ (status SoT — state-model.md)

Role     : You are the deployer. You own the deployment pipeline for this feature.
           You do NOT present gates — signal readiness to the orchestrator via return JSON.
           You do NOT merge the PR until the orchestrator relays Gate 8 approval.

Action   : Phase preview:
             1. Run preflight (type-check + test + build) — stop if any fail.
             2. Push branch, open/update PR, trigger Vercel preview build.
             3. Poll Vercel until status = READY (max 5 min).
             4. Read build logs and runtime errors.
           Return phase preview output contract JSON.

Format   : Return { "phase": "preview", "preflight": {...}, "preview_url": "...", "vercel_status": "READY", ... }
           Do not proceed to production — wait for orchestrator to re-dispatch with phase=production.

Tone     : Apply rules/security.md — no secrets in logs or commit messages.
           Verification invariant: "READY" must be confirmed via MCP, not assumed from push success.
──────────────────────────────────────────────────────────────
```

> **Dispatch** `deployer`
> Pass: CRAFT envelope above, INTENT.md path, feature name, locked backend, PR number
> Phase: `preview` — preflight + Vercel preview only
> Returns: phase preview output contract JSON

If preflight fails: stop — "Preflight failed: <output>. Fix before deploying."

---

## Step 3 — Verify output contract (Stage 5a)

| Exit criterion | Check |
|---------------|-------|
| Preflight passed | All three checks exit 0 |
| Preview URL available | Vercel returns a preview URL |
| Preview in READY state | Vercel build status = `READY` (MCP-confirmed) |
| No build errors in logs | Vercel log scan shows no ERROR lines |

If preview is not READY: re-dispatch deployer to investigate logs and fix; re-present when READY.

---

## Step 4 — Present gates sequentially

### Gate 7 — Staging verification (canonical format from pipeline.md)

Exit criteria checklist:
- [ ] Vercel preview deployment status = `READY`
- [ ] No build errors in Vercel logs
- [ ] Backend migration status confirmed
- [ ] Stripe test-mode status confirmed

Show the preview URL prominently. Human must visit it before approving.

**On ✅ Approved:** proceed to Gate 8.
**On ❌ Issues found:** re-dispatch deployer to investigate/fix; re-present Gate 7 after new preview is READY.
**On ❌ Stop:** deployment paused on preview branch; PR remains open.

---

### Gate 8 — Production deployment (canonical format from pipeline.md)

Exit criteria checklist:
- [ ] Gate 7 approved
- [ ] All changes listed (PR, backend changes with irreversibility warning, live Stripe objects if any)
- [ ] Human has reviewed staging URL

**On ✅ Approved:**
Move the feature card to the **Deploy** column on the board (via github MCP), then re-dispatch deployer for production sequence with updated CRAFT envelope:

```
CRAFT DISPATCH — deployer (production phase)
──────────────────────────────────────────────────────────────
Context  : Gate 7 approved — staging verified at <preview_url>.
           Gate 8 approved — human confirmed production deployment.
           Backend changes: <Gate 4 details or "not needed">.
           Stripe live objects: <Gate 5 details or "test-mode only">.
           PR #<number> ready to merge.

Role     : Execute the irreversible production sequence in strict order.
           You own this sequence end-to-end. Signal any failure immediately.

Action   : 1. Apply backend changes via `drizzle-kit migrate` against production `DATABASE_URL_ADMIN` (or the neon MCP). Gate 4 must have been approved.
           2. Create live Stripe objects if Gate 5 approved.
           3. Merge PR (squash) via github MCP.
           4. Poll Vercel production until READY (max 8 min).
           5. Scan runtime logs for 2 minutes. Update CHECKLIST.md.

Format   : Return { "phase": "production", "production_url": "...", "vercel_status": "READY", ... }
           Any step failure = stop and return error immediately — do not skip ahead.

Tone     : Verification invariant applies: every MCP write must be read back to confirm.
           Order is non-negotiable — backend before merge, merge before polling prod.
──────────────────────────────────────────────────────────────
```

> **Dispatch** `deployer`
> Pass: CRAFT envelope above, phase: `production`

Verify production URL is READY via Vercel MCP before reporting done.

Update state:
- CHECKLIST.md: deployment section marked complete
- Move the feature card to the **Done** column on the board (via github MCP) — the board is the status source of truth (state-model.md).
- Update `jairus.json`: bump `updated_at`, advance `cursor` to the next unlocked feature (or clear `active_stage` if the backlog is complete), refresh the feature's `snapshot` entry (state-model.md write discipline).
- INTENT.md stays the write-once seed — do not write status flags to it.

Report success:
```
✅ Deployed to production — <feature-name>
   Staging  : <preview URL>  ✅
   Production: <production URL>  ✅
   Backend  : <migrations applied / rules deployed / no changes>
   Stripe   : <live objects created / test-mode / no payments>

🎉 Feature is live.
```

**On ❌ Stop:** PR stays open on staging branch. No production changes made.

---

## On Error

| Error | Recovery |
|-------|---------|
| Preflight fails | Stop: "Fix build failures. Run `/jairus:develop <feature>` to fix." |
| Vercel not connected | Stop: "Run `/jairus:doctor` — Vercel requires OAuth via `/mcp`." |
| Preview never reaches READY | Deployer reads build logs and surfaces error; present to human |
| Production merge fails | Report github MCP error; manual merge may be needed |
| Backend MCP write fails post-Gate-8 | Report gap; production may be partially deployed; human must intervene |
