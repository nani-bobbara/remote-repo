---
description: "Show help for the jairus pipeline. Pass a command name for detailed help on that command, or run without arguments for the full reference."
argument-hint: "[command-name]"
allowed-tools: Read
---

You are printing **jairus help**. Output ONLY the reference below (adapt lightly to state).
Keep it scannable — no long prose. Do not run the pipeline; this is help only.

**Header:** first Read `${CLAUDE_PLUGIN_ROOT}/.claude-plugin/plugin.json` and lead the output with
the version banner `Jairus v<version>` (read it — never hardcode the number).

## Preconditions

None — always safe to run.

---

## Step 1: Check for specific command

If `$ARGUMENTS` names a specific command (`doctor` | `init` | `board` | `design` | `develop` |
`review` | `deploy` | `ship` | `extend` | `help`):

Read `${CLAUDE_PLUGIN_ROOT}/commands/$ARGUMENTS.md` and print:
- **Usage**: `/jairus:$ARGUMENTS <args>` (from `argument-hint` frontmatter)
- **What it does**: 2-3 lines from description + first paragraph of body
- **Preconditions**: the Preconditions section summary
- **Agent dispatched**: list any agent dispatches in the command
- **Gates triggered**: list the gate numbers and names
- **Next command**: what to run after this one

Then stop — do not print the full reference.

---

## Step 2: Print full reference (when no argument given)

If `$ARGUMENTS` is empty, print the full reference:

```
jairus — agentic micro-SaaS harness
Intent → Design → Develop → Review → Deploy, with human approval gates (🚦).
Built on: Next.js 14+ · TypeScript · TailwindCSS · Stripe · Vercel + Neon Postgres (monorepo: portal + admin, shared packages)

USAGE
  /jairus:<command> [args]

THE 10 COMMANDMENTS
  I.    doctor   [--check|--feature <n>]  Diagnose and fix machine readiness  ← run first
  II.   init     [optional context]       Smart entry point: detects new vs existing repo  🚦
  III.  board    [--refresh]              Create/refresh GitHub Project from breakdown      🚦
  IV.   design   <feature>               Designer → 7 artifacts → review ≥8/10            🚦
  V.    develop  <feature>               Implement (requires approved design)              🚦*
  VI.   review   [feature]               Code-review ≥8/10 → pre-merge handover           🚦
  VII.  deploy   [feature]               Vercel preview → staging verify → production      🚦
  VIII. ship     [--plan|<feature>]       Feature loop in dep order; --plan = dry run
  IX.   extend   <extension>             Add extension: ai | email | feature-flags
  X.    help     [command]               This help; pass a command name for details

  * develop raises Gate 4 (backend changes) and Gate 5 (live Stripe) as needed

ENTRY POINT
  /jairus:init   — detects context, then runs the FOUNDATION phase (new repo):
    new repo     → connect accounts → intent interview → resource plan → provision
                   (repo · monorepo portal+admin · Neon · 2 Vercel · Stripe · CI ·
                    auth skeleton + seeded admin) → deploy + verify walking skeleton
    existing repo → read-only audit → classify features → import backlog
                   (foundation-green required before features; complete missing F-steps)

TYPICAL FLOW — new project
  1. /jairus:doctor              # once per machine — check toolchain, collect
                                 # credentials, write to shell profile; restart when prompted
  2. /jairus:init                # runs the FOUNDATION phase (F0–F-VERIFY):
                                 #   F0 connect gh/neonctl/vercel/stripe + mcp logins
                                 #   🚦 Gate F1: approve intent + breakdown
                                 #   🚦 Gate F2: approve the resource plan (before any spend)
                                 #   F3–F10 provision monorepo (portal + admin) + infra + CI
                                 #   🚦 Gate F11: deploy the walking skeleton
                                 #   🚦 Gate F-VERIFY: prove it live+secure → foundation GREEN
  3. /jairus:board               # 🚦 Gate 2: approve → create/refresh GitHub Project
  4. /jairus:ship                # feature loop in dependency order (features unlock only
                                 # after foundation is verified green); --plan to preview first

TYPICAL FLOW — existing repo
  1. /jairus:doctor              # once per machine (skip if already done)
  2. /jairus:init                # auto-detects existing repo → audit mode
                                 # 🚦 Gate 1: approve intent + breakdown
                                 # foundation must be green before features — complete any
                                 # missing F-steps (rules/foundation.md) if the platform is partial
  3. /jairus:ship --plan         # preview dep-ordered run: partial → planned → bugs
  4. /jairus:ship                # run the feature loop

FOUNDATION (runs once, in /jairus:init, before any feature)
  Connect accounts → provision platform → deploy + verify a walking skeleton.
  Stack is fixed: monorepo (portal + admin apps) on Neon + Vercel + Stripe + GitHub.
  Named gates: F1 (intent) · F2 (resource plan) · F11 (deploy skeleton) · F-VERIFY (proof).
  Features unlock only after foundation is verified GREEN (jairus.json foundation.status).

APPROVAL GATES (never skipped)
  Gate F1 foundation intent + breakdown     (init)
  Gate F2 foundation resource plan          (init — before provisioning)
  Gate F11 / F-VERIFY foundation skeleton   (init — deploy + prove)
  Gate 2  GitHub Project board write        (init or board)
  Gate 3  design handover                   (design — per feature)
  Gate 4  backend schema changes            (develop — if schema changes)
  Gate 5  live Stripe objects               (develop — if payments feature)
  Gate 6  code review pre-merge             (review — per feature)
  Gate 7  staging verification              (deploy)
  Gate 8  production deployment             (deploy)

REVIEWS
  Scored /10. Pass threshold: ≥8.
  Fail → producer agent fixes → re-review (autonomous, capped at 3 iterations, then escalate).
  Humans approve gate handovers — not each fix-loop iteration.

STATE MODEL (3 layers — see .jairus/rules/state-model.md)
  docs/INTENT.md   write-once seed: idea + requirements + backend + breakdown (no progress flags)
  GitHub Project   source of truth for feature/stage status; a gate = human moving the card
                   Backlog → Design → Design Approved → Develop → Review → Review Passed → Deploy → Done
  jairus.json      control footprint at project root: version anchor + board pointer + resume
                   cursor + snapshot. Committed but inert — the app builds without it.
  Resume: a dead/compacted session reads jairus.json → version-checks (patch/minor auto,
          major prompts) → reconciles vs board + git/files (board wins) → reports next action.

PLUGIN SHAPE
  10 commands · 6 agents · 11 skills · 8 rules
  Skills: architecture · auth · nextjs · stripe · vercel · github · neon · ai · email · feature-flags · theming
  (foundation'd projects also install official vendor skills into .claude/skills/:
   neon-postgres · stripe · github · vercel · shadcn)
  Per-persona models: planner/deployer = Haiku · developer/extender = Sonnet · designer/reviewer = Opus

FIXED TECH STACK
  Frontend  Next.js 14+ (App Router) + TypeScript strict + TailwindCSS
  API       Next.js API routes
  Payments  Stripe (test mode first, live at Gate 5)
  Hosting   Vercel (preview per PR, production on main merge)
  Backend   Neon Postgres (monorepo: portal + admin, shared packages) — Drizzle ORM +
            Better Auth + two-layer security (Layer 1 withUser app-layer userId scoping +
            Layer 2 defense-in-depth RLS FORCE). DATABASE_URL for scoped access; DATABASE_URL_ADMIN
            (dbAdmin) for system + admin cross-user. Neon MCP gives preview branching per deploy.

ADDITIVE EXTENSIONS
  ai             Vercel AI SDK + Anthropic Claude or OpenAI
  email          Resend (transactional email)
  feature-flags  GrowthBook

  Add with: /jairus:extend <extension-name>

PREREQUISITES
  Node 18+ · Claude Code (with jairus plugin enabled)
  Accounts: Stripe · Vercel · GitHub · Neon (Postgres host)
  MCP auth: stripe/github/vercel/neon authorize via browser OAuth (claude mcp login <server>).
    Runtime app secrets go in .env.local — never MCP auth.

NON-NEGOTIABLES
  • Never skip a 🚦 gate
  • Never start code before design is approved (Gate 3)
  • Never commit secrets or .env.local
  • TypeScript strict, zero any — enforced by type-check hook
  • Two-layer security (mandatory app-layer userId scoping + defense-in-depth RLS) — always

WHERE TO LEARN MORE
  Pipeline definition  .jairus/rules/pipeline.md
  Quality gate rules   .jairus/rules/quality-gate.md
  State model + resume .jairus/rules/state-model.md
  MCP usage guide      .jairus/rules/mcp-usage.md
  Security rules       .jairus/rules/security.md

  Run /jairus:help <command> for any command's detailed usage.
  Run /jairus:doctor --check to verify your setup is ready to use.
```

---

## On Error

| Error | Recovery |
|---|---|
| Specific command file not found | "Command `$ARGUMENTS` not found. Valid commands: doctor init board design develop review deploy ship extend help" |
| INTENT.md not found (called from empty state context) | Show the full reference; note at top: "Project not initialized. Run `/jairus:init` to start." |
