---
description: "Code-review the current feature branch against main. Verifies build state, dispatches the reviewer agent, runs the fix-loop to ≥8/10, then presents Gate 6 for pre-merge approval."
argument-hint: "[feature-name]"
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, mcp__neon__*, mcp__github__*
---

You are the **orchestrator** running Stage 4 (Review).
Read the Stage 4 contract in `${CLAUDE_PLUGIN_ROOT}/rules/pipeline.md` and the state model in
`${CLAUDE_PLUGIN_ROOT}/rules/state-model.md` before proceeding. Stage status is read from the
GitHub Project board (source of truth), not from INTENT.md flags. On the first jairus action in
a session, run the resume protocol (state-model.md) before Step 1.

Feature: `$ARGUMENTS` (or infer from current branch if omitted)

---

## Step 1 — Verify input contract

Determine the feature name:
```bash
# If $ARGUMENTS empty, infer from current branch
git branch --show-current | sed 's|feature/||'
```

| Check | Block message if failed |
|-------|------------------------|
| Develop done: feature card in the **Review** column on the board, or the feature branch (`feature/<name>`) exists | "No feature branch / card not in Review. Run `/jairus:develop <feature>` first." |
| PR is open on GitHub | "No open PR for this branch. The developer must push the branch first." |
| Feature card in or past the **Design Approved (Gate 3)** column on the board (via github MCP) | "Design not approved. Run `/jairus:design <feature>` first." |
| All 7 design artifacts present | "Design artifacts missing. Run `/jairus:design <feature>`." |
| Build state clean (see below) | "Build must pass before review begins." |

**Build state pre-check (hard stop if any fail):**
```bash
pnpm type-check   # must exit 0
pnpm test             # must exit 0
pnpm build        # must exit 0
```

If any fail: stop immediately — "Fix build failures before running review. Run `/jairus:develop <feature>` to fix."

---

## Step 2 — Dispatch reviewer

Prepare diff range:
```bash
git diff main...feature/<feature-name> --stat
```

Construct the CRAFT envelope before dispatching:

```
CRAFT DISPATCH — reviewer (code mode)
──────────────────────────────────────────────────────────────
Context  : Project: <display_name> — <one_liner>
           Feature: <feature-name> — <feature.description>
           Backend: Neon Postgres — Drizzle + Better Auth + two-layer security (monorepo: portal + admin, shared packages)
           Scope contract:
               description : <feature.description>
               out_of_scope: <feature.out_of_scope[]>
           Diff range: main..feature/<feature-name> (<N> files, <N> additions, <N> deletions)
           Design artifacts: docs/features/<feature>/ (these are the acceptance baseline)
           Build state: type-check ✅ · tests ✅ · build ✅ (pre-verified in Step 1)

Role     : You are the reviewer scoring the code diff against the approved design.
           Read-only — you do not write code or present Gate 6.
           You do NOT fix findings yourself — signal them for the developer to fix.

Action   : Score the diff /10 across 5 dimensions (quality-gate.md code mode).
           Run all static checks (hardcoded secrets, any types, console.log, missing auth).
           Verify the two-layer security model: Layer 1 (MANDATORY) — every user-data query is scoped by session userId through the Drizzle repos; a query against a user table with NO userId predicate is a BLOCKER. Layer 2 — RLS matches DATABASE.md (ENABLE + FORCE, non-owner app role; verify via the neon MCP with `pg_policies`, or `drizzle-kit`/SQL). The `dbAdmin`/`DATABASE_URL_ADMIN` privileged path is reserved for system + admin cross-user access.
           Check AC Coverage: every AC-N from PRD.md must have // AC-N in source + a test.
           Post inline PR comments for each BLOCKER and HIGH finding.

Format   : Return Reviewer Report JSON (see Stage 4 output contract in pipeline.md).
           Include: score, verdict, blocker_count, dimensions[], findings[], ac_coverage.
           Do not summarize or truncate findings — the orchestrator needs the full list.

Tone     : Apply rules/quality-gate.md + rules/security.md + rules/development.md.
           BLOCKER caps overall score at 7/10 — gate cannot open with any BLOCKER.
           UNVERIFIED security findings are treated as HIGH, not informational.
──────────────────────────────────────────────────────────────
```

> **Dispatch** `reviewer`
> Pass: CRAFT envelope above, mode: `code`, diff range, design artifact paths, INTENT.md path
> Returns: Reviewer Report JSON (score N/10 + findings + verdict)

---

## Step 3 — Verify output contract + run fix-loop

**Fix-loop (max 3 iterations — see Fix-Loop Protocol in pipeline.md):**

Each iteration:
1. Reviewer returns Reviewer Report JSON

2. If `score ≥ 8` AND no BLOCKER findings → proceed to Step 4 (gate)

3. If `score < 8` OR any BLOCKER:
   Construct developer fix CRAFT envelope:
   ```
   CRAFT DISPATCH — developer (fix mode, iteration N)
   Context  : Reviewer findings iteration N. Feature <name>. Branch feature/<name>. Scope contract unchanged.
   Role     : Apply targeted fixes from the findings list. Do not refactor passing code.
   Action   : Fix each BLOCKER and HIGH finding exactly as described. Re-run checks after.
   Format   : Return { "status": "complete", "checks": {...} } when all pass.
   Tone     : rules/development.md + rules/security.md. Minimal change surface.
   ```
   > **Dispatch** `developer` — pass: CRAFT envelope, mode: `fix`, findings list, feature name
   > Returns: updated code on branch

   Re-run build checks after developer returns:
   ```bash
   pnpm type-check && pnpm test && pnpm build
   ```
   If checks fail: include failure output in next reviewer CRAFT envelope Context field.

   Construct next-iteration reviewer CRAFT envelope with updated Context (include previous findings + iteration count), then re-dispatch.

4. After 3 iterations still failing → escalate per Fix-Loop Protocol in pipeline.md

---

## Step 4 — Present Gate 6 (canonical format from pipeline.md)

Exit criteria checklist:
- [ ] `pnpm type-check` passes
- [ ] `pnpm test` passes
- [ ] `pnpm build` passes
- [ ] Code review score `≥ 8/10`
- [ ] No BLOCKER findings
- [ ] AC Coverage table complete (every AC-N mapped to a test in CHECKLIST.md)
- [ ] No hardcoded secrets (grep check passed)
- [ ] No `any` type leaks (grep check passed)

Include in gate presentation: score trend across iterations, files changed (count + key paths), key findings resolved, remaining non-blocking findings, PR link.

**On ✅ Approved (explicit human approval only):**
- Open or update PR via github MCP with: score, AC checklist, resolved findings, non-blocking findings
- Move the feature card to the **Review Passed (Gate 6)** column on the board (via github MCP) — this card move *is* the approval; no flag is written to INTENT.md. Dependent features whose `depends_on` are now all in/past Review Passed become unlocked.
- Update `jairus.json`: bump `updated_at`, set `cursor` to `{ active_feature: <feature>, active_stage: deploy }`, refresh the feature's `snapshot` entry (state-model.md write discipline).

Report success:
```
✅ Code review passed — <feature-name>   score: N/10
   PR       : <GitHub PR URL>
   Files    : <N> changed
   Tests    : <N> passing, all ACs covered
   Board    : card moved to "Review Passed (Gate 6)", <N> dependents unlocked

Next: /jairus:deploy <feature-name>
```

**On ❌ Changes needed:** One more fix-loop pass with human feedback added to findings (max 2 more).
**On ❌ Stop:** Feature card stays in the **Review** column; PR stays open.

---

## On Error

| Error | Recovery |
|-------|---------|
| Build fails before review | Hard stop: "Fix build failures first. Run `/jairus:develop <feature>` to fix." |
| Reviewer escalation after 3 iterations | Present all findings grouped by recurrence; wait for human guidance |
| PR creation fails | Report github MCP error; user can open PR manually |
| AC Coverage table missing from CHECKLIST.md | Block gate: developer must add it before review can pass |
