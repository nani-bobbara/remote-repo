<!--
  INTENT.md — the write-once SEED: the confirmed initial idea, vague requirements,
  chosen backend, and the initial feature breakdown. It is NOT a live tracker.
  Live feature/stage status lives on the GitHub Project (the source of truth);
  jairus.json is the plugin's control footprint (version + board pointer + resume cursor).
  This file is archival after the board is created. See .jairus/rules/state-model.md.
  /jairus:init fills in this template and writes it to the project root.
  Replace every <!-- NOTE: ... --> placeholder with your content.
-->

---
schema_version: "2.0"                # do not change — pipeline reads this

project_name: ""                     # <!-- NOTE: kebab-case; becomes the repo name + package name -->
display_name: ""                     # <!-- NOTE: human-facing product name shown in the UI -->
one_liner: ""                        # <!-- NOTE: ≤120 chars. What it does and for whom. -->
status: draft                        # seed lifecycle only: draft | bootstrapped — /jairus:init sets to bootstrapped. Archival after the board exists. NOT live progress.

backend: neon                        # Neon serverless Postgres (Drizzle + Better Auth) — the only backend, fixed
topology: monorepo                   # fixed — packages/{db,auth,core} + apps/{portal,admin}; DB/auth live in shared packages

stack:
  frontend: nextjs-14                # fixed — do not change
  api: nextjs-api-routes             # fixed — do not change
  payments: stripe                   # fixed — do not change
  hosting: vercel                    # fixed — do not change

extensions: []                       # <!-- NOTE: additive integrations layered on top. Options: ai | email | feature-flags -->
                                     #   Add them with /jairus:extend <name> after init. Never remove once added.

features:
  # <!-- NOTE: Dependency-ordered. foundation type goes first; billing last.
  #      The feature loop (/jairus:ship) processes a feature only after everything
  #      in its depends_on list is done. Keep it tight — this is the MVP scope. -->

  - name: ""                         # <!-- NOTE: kebab-case identifier, used as branch + doc folder name -->
    display_name: ""                 # <!-- NOTE: human-readable feature name -->
    description: ""                  # <!-- NOTE: 1–2 sentences. What it does and why it matters. This is the designer's scope contract. -->
    out_of_scope: []                 # <!-- NOTE: explicit list of things this feature does NOT include. Prevents scope creep. -->
    type: foundation                 # foundation | feature | billing
    plan: all                        # free | pro | all
    depends_on: []                   # <!-- NOTE: list of feature name strings this depends on -->
    # <!-- NOTE: no status/approval flags here. Live feature+stage status lives on the
    #      GitHub Project (source of truth); the resume cursor lives in jairus.json. -->

  # <!-- NOTE: repeat the block above for each MVP feature. Typical order:
  #   1. bootstrap-app (foundation, free, depends_on: [])
  #      description: "Scaffold the Next.js app with Tailwind, global layout, and error boundaries."
  #   2. auth (foundation, free, depends_on: [bootstrap-app])
  #      description: "Email/password sign-up and sign-in with session management."
  #   3. <your core feature> (feature, free|pro, depends_on: [auth])
  #   4. billing (foundation, pro, depends_on: [auth])
  #      description: "Stripe-powered subscription checkout, portal, and webhook sync."
  # -->
---

# Product Intent

<!-- NOTE: This document is the human-readable companion to the frontmatter above.
     Fill in every section. The pipeline agents read both. -->

## 1. What

<!-- NOTE: What does this product do? 2–3 sentences. Be concrete: who uses it,
     what they do with it, what outcome they get. -->

## 2. Who

<!-- NOTE: Target users. Describe 1–2 primary personas: role, context, pain.
     Example: "Indie hackers who ship weekly and forget what changed between releases." -->

## 3. Core Value

<!-- NOTE: The ONE thing that makes this worth building. What problem does it solve
     uniquely well? What would users lose if this product disappeared?
     One focused paragraph — resist listing everything. -->

## 4. Key Features

<!-- NOTE: Prose description of each feature in the frontmatter. One bullet per feature.
     Format: Feature name — what it does, why it matters to the user. -->

- 

## 5. Out of Scope (v1)

<!-- NOTE: What is this explicitly NOT doing in v1? Being clear here prevents scope creep.
     List at least 3 things. -->

- 

## 6. Monetization

<!-- NOTE: How does this make money? Map to the billing feature in frontmatter. -->

- **Model**: <!-- subscription | usage-based | one-time | freemium -->
- **Tiers**: <!-- e.g. Free (core features), Pro $19/mo (advanced features), Team $49/mo -->
- **Stripe products**: <!-- list product names, or "propose during billing feature design" -->
- **Trial**: <!-- free trial period, or "none" -->

## 7. Data Model Overview

<!-- NOTE: Name the key entities and describe their relationships in prose — not schema.
     The designer will design the actual schema. This is just "what nouns exist."
     Example: "Users own Projects. Projects contain Entries. Entries have Tags." -->

## 8. Non-Negotiables

<!-- NOTE: Security, compliance, performance, or tooling constraints.
     Examples: GDPR compliance required, must support SSO, max 200ms API response,
     no vendor X allowed. If none, write "Standard security practices apply." -->

- 

## 9. Success Metrics

<!-- NOTE: How do you know v1 succeeded? Name 2–4 measurable outcomes.
     Examples: 100 signups in first 30 days, <2s page load on mobile, NPS ≥40. -->

- 
