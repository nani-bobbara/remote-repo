# Design Tokens — {{display_name}}

<!-- NOTE: /jairus:init creates this at docs/design.md. Fill in the Tailwind classes
     for your brand. All components reference these TOKEN NAMES via tailwind.config.ts.
     Never use raw hex values or arbitrary Tailwind values like text-[#3b82f6] or p-[13px].
     The reviewer enforces this at the design-review gate. -->

> **Single source of visual truth.** Components use token names (mapped in `tailwind.config.ts`),
> never raw hex or arbitrary values. The `reviewer` enforces this at the design-review gate.

---

## Color Tokens

<!-- NOTE: Fill in Tailwind color classes (e.g. "bg-white", "bg-zinc-950").
     No hex values. Every light/dark pairing must meet WCAG AA (≥4.5:1 for text, ≥3:1 for UI). -->

| Token | Light (Tailwind class) | Dark (Tailwind class) | Use |
|-------|------------------------|----------------------|-----|
| `bg` | bg-white | bg-zinc-950 | App background |
| `surface` | bg-zinc-50 | bg-zinc-900 | Cards, panels, inputs |
| `border` | border-zinc-200 | border-zinc-800 | Dividers, input borders |
| `text` | text-zinc-900 | text-zinc-50 | Primary text |
| `text-muted` | text-zinc-500 | text-zinc-400 | Secondary / helper text |
| `primary` | bg-indigo-600 | bg-indigo-500 | Primary actions, links |
| `primary-fg` | text-white | text-white | Text on primary background |
| `success` | text-green-700 | text-green-400 | Confirmations, success states |
| `warning` | text-amber-700 | text-amber-400 | Warnings, caution states |
| `danger` | text-red-600 | text-red-400 | Errors, destructive actions |

<!-- NOTE: Replace the Tailwind classes above with your brand palette.
     Test WCAG contrast before approving. Tool: https://webaim.org/resources/contrastchecker/ -->

---

## Typography Scale

<!-- NOTE: All type uses Tailwind size classes. One font family defined in tailwind.config.ts.
     The reviewer rejects raw font-size values. -->

| Token | Tailwind class | Usage |
|-------|---------------|-------|
| `heading-xl` | text-4xl font-bold tracking-tight | Page titles (H1) |
| `heading-lg` | text-2xl font-semibold tracking-tight | Section titles (H2) |
| `heading-md` | text-xl font-semibold | Card titles, modal titles (H3) |
| `heading-sm` | text-base font-semibold | Sub-section labels (H4) |
| `body-lg` | text-base leading-relaxed | Long-form prose |
| `body-md` | text-sm leading-normal | Standard UI copy |
| `body-sm` | text-xs leading-normal | Fine print, footnotes |
| `label` | text-xs font-medium uppercase tracking-wide | Form labels, table headers |
| `caption` | text-xs text-muted | Timestamps, metadata |

<!-- NOTE: Font family is set once in tailwind.config.ts under theme.fontFamily.
     Use a single variable font (e.g. Inter, Geist) to cover all weights. -->

---

## Spacing

Spacing uses **Tailwind's 4px grid only** — `p-1` (4px), `p-2` (8px), `p-3` (12px),
`p-4` (16px), `p-6` (24px), `p-8` (32px), `p-12` (48px), `p-16` (64px).

No arbitrary values like `p-[13px]` or `mt-[7px]`.

---

## Border Radius Tokens

| Token | Tailwind class | Use |
|-------|---------------|-----|
| `radius-sm` | rounded | Buttons, badges, small elements |
| `radius-md` | rounded-lg | Cards, inputs, modals |
| `radius-lg` | rounded-2xl | Large panels, feature cards |
| `radius-full` | rounded-full | Avatars, pill badges |

---

## Shadow Tokens

| Token | Tailwind class | Use |
|-------|---------------|-----|
| `shadow-sm` | shadow-sm | Subtle depth on surface elements |
| `shadow-md` | shadow-md | Cards, dropdowns |
| `shadow-lg` | shadow-xl | Modals, popovers |

---

## Reviewer Rules (enforced at design-review gate)

1. Colors referenced by **token name only** (via Tailwind theme extension) — never raw hex or `text-[#…]`.
2. Spacing, radius, and type size from the scale above — no `[13px]`-style arbitrary values.
3. Every text/background pairing meets **WCAG AA** (≥4.5:1 for text, ≥3:1 for interactive UI).
4. **Dark mode** is required for every surface — all tokens have a paired dark-mode class.
5. Tokens live in `tailwind.config.ts` under `theme.extend`; this file documents intent only.
