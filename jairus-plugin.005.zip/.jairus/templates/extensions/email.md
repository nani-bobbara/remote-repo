---
feature: ""        # kebab-case feature name this email integration is part of
extension: email
---

# Email Integration: {{Feature Display Name}}

<!-- NOTE: /jairus:extend email fills in this template and writes it to
     docs/features/{{feature}}/EMAIL_INTEGRATION.md.
     All emails are sent via Resend using React Email templates.
     Complete all sections before the developer implements the email routes. -->

---

## 1. Email Triggers

<!-- NOTE: One row per email this feature sends.
     "Transactional" = triggered by a user action (always sent).
     "Marketing" = promotional or informational (requires opt-in + unsubscribe). -->

| Trigger Event | Template Name | Recipient | Subject | Type |
|--------------|--------------|-----------|---------|------|
| <!-- e.g. user signs up --> | <!-- WelcomeEmail --> | user | <!-- Welcome to {{app_name}}! --> | transactional |
| <!-- e.g. payment succeeds --> | <!-- ReceiptEmail --> | user | <!-- Your receipt from {{app_name}} --> | transactional |
| <!-- e.g. weekly digest --> | <!-- DigestEmail --> | subscribed users | <!-- Your weekly summary --> | marketing |

## 2. Templates

<!-- NOTE: Each template is a React Email component in packages/adapters/src/email/templates/.
     Use Tailwind classes via the @react-email/tailwind component. -->

| Template | File | Data required |
|---------|------|--------------|
| <!-- WelcomeEmail --> | `packages/adapters/src/email/templates/WelcomeEmail.tsx` | <!-- { name: string, loginUrl: string } --> |
| <!-- add more --> | | |

**Sending function location**: `packages/adapters/src/email/index.ts` — the EmailPort adapter (`@app/adapters`), exporting `sendEmail(template, to, data)`. The Resend SDK is imported ONLY here, behind the domain EmailPort — never in an app.

## 3. From Address Configuration

<!-- NOTE: The from address must be a verified domain in Resend.
     Never send from a free email provider (gmail.com, yahoo.com). -->

| Setting | Value |
|---------|-------|
| **From address** | <!-- noreply@yourdomain.com --> |
| **From name** | <!-- {{app_name}} --> |
| **Reply-to** | <!-- support@yourdomain.com or null --> |
| **Resend domain verified** | <!-- yes / pending --> |

## 4. Unsubscribe and Compliance

<!-- NOTE: Marketing emails MUST include an unsubscribe link.
     Transactional emails (receipts, security alerts) are exempt but should have a
     "manage notifications" link. GDPR/CAN-SPAM applies. -->

| Email type | Unsubscribe required | Implementation |
|-----------|---------------------|---------------|
| Transactional | No — but include "manage notifications" link | Link to `/settings/notifications` |
| Marketing | Yes — one-click unsubscribe | Resend unsubscribe header + link to `/unsubscribe?token=…` |

**Preference storage**: <!-- describe where user email preferences are stored (DB table/field) -->

## 5. Test Plan

<!-- NOTE: Test emails locally using Resend's test domain before going live. -->

- **Local testing**: Set `RESEND_API_KEY=re_test_...` (Resend test key — emails are captured, not delivered)
- **Preview**: Use `email-preview` script (`npx react-email dev`) to render templates in browser
- **E2E test**: Send to a Resend test address and verify in the Resend dashboard
- **Checklist**:
  - [ ] Template renders correctly in Gmail, Apple Mail, Outlook
  - [ ] Plain-text fallback present
  - [ ] Unsubscribe link works (marketing emails)
  - [ ] From address verified in Resend

---

## Approval

- [ ] Email triggers and templates reviewed
- [ ] From address verified
- [ ] Unsubscribe / compliance requirements met
- [ ] Test plan reviewed
- **Date approved**: <!-- YYYY-MM-DD -->
