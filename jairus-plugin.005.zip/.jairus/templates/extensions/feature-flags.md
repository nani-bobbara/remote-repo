---
feature: ""        # kebab-case feature name these flags belong to
extension: feature-flags
---

# Feature Flags: {{Feature Display Name}}

<!-- NOTE: /jairus:extend feature-flags fills in this template and writes it to
     docs/features/{{feature}}/FEATURE_FLAGS.md.
     Feature flags allow gradual rollout and instant kill-switch without a deploy.
     Keep the number of active flags small — each one is tech debt until cleaned up. -->

---

## 1. Flags

<!-- NOTE: One row per flag. Flag keys are kebab-case, prefixed with the feature name.
     Default value is what unenrolled users see (usually the safe/old behavior). -->

| Flag Key | Description | Default | Type |
|----------|-------------|---------|------|
| `{{feature}}-enabled` | <!-- Master switch for the entire feature --> | `false` | boolean |
| `{{feature}}-new-ui` | <!-- Show redesigned UI vs legacy --> | `false` | boolean |
| <!-- add more --> | | | |

## 2. Targeting Rules

<!-- NOTE: Describe who sees the flag as `true`. Be specific about the rollout strategy. -->

| Flag Key | Rollout Strategy | Target Criteria |
|----------|----------------|----------------|
| `{{feature}}-enabled` | <!-- Percentage rollout --> | <!-- Start at 5%, increase to 100% over 2 weeks --> |
| `{{feature}}-new-ui` | <!-- Specific users --> | <!-- Internal team first, then beta users by user attribute --> |

## 3. Implementation

<!-- NOTE: Where and how each flag is evaluated. Server-side evaluation is preferred
     (faster, no layout shift). Use client-side only for UI-specific toggles. -->

| Flag Key | Evaluated in | File | Notes |
|----------|-------------|------|-------|
| `{{feature}}-enabled` | Server (middleware or server component) | `apps/portal/app/(app)/{{feature}}/page.tsx` | Gate the entire route |
| `{{feature}}-new-ui` | Client Component | `apps/portal/app/(app)/{{feature}}/_components/{{Feature}}View.tsx` | Swap UI variant |

**SDK usage pattern (GrowthBook)**:

```typescript
// Server-side — GrowthBook SDK lives ONLY in the adapters package, behind the FlagsPort
import { getServerGrowthBook } from '@app/adapters/flags';  // packages/adapters/src/flags/index.ts
const gb = await getServerGrowthBook(userId);
if (!gb.isOn('{{feature}}-enabled')) return notFound();

// Client-side — the React-only helper/provider lives in the app (apps/portal/app/_components/)
import { useFeatureIsOn } from '@growthbook/growthbook-react';
const showNewUI = useFeatureIsOn('{{feature}}-new-ui');
```

## 4. Cleanup Plan

<!-- NOTE: Flags are temporary by design. Define when each becomes permanent.
     A flag without a cleanup date is indefinite tech debt. -->

| Flag Key | Permanent after | Cleanup action |
|----------|----------------|---------------|
| `{{feature}}-enabled` | <!-- 100% rollout confirmed + 1 week soak --> | Remove flag + `isOn` check; feature is always on |
| `{{feature}}-new-ui` | <!-- Old UI removed --> | Remove flag + old UI component |

<!-- NOTE: Add a GitHub issue or ADR entry for each flag's cleanup. -->

---

## Approval

- [ ] Flags and targeting rules reviewed
- [ ] Implementation approach reviewed
- [ ] Cleanup plan has dates and owners
- **Date approved**: <!-- YYYY-MM-DD -->
