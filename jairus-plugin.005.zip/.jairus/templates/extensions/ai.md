---
feature: ""               # kebab-case feature name this AI integration is part of
extension: ai
model-provider: anthropic # anthropic | openai
---

# AI Integration: {{Feature Display Name}}

<!-- NOTE: /jairus:extend ai fills in this template and writes it to
     docs/features/{{feature}}/AI_INTEGRATION.md.
     Complete all sections before the developer implements the AI route. -->

---

## 1. AI Feature Description

<!-- NOTE: What AI capability does this feature use? Be specific about the task:
     text generation, classification, extraction, summarization, Q&A, etc.
     Who triggers it, and what do they see as output? -->

## 2. Model Configuration

<!-- NOTE: Pin the model ID. Do not use "latest" aliases in production — they change silently. -->

| Setting | Value |
|---------|-------|
| **Model ID** | <!-- e.g. claude-sonnet-4-5 / gpt-4o-mini --> |
| **Temperature** | <!-- 0.0–1.0; use 0 for deterministic extraction, ~0.7 for creative --> |
| **Max output tokens** | <!-- e.g. 1024 --> |
| **Streaming** | <!-- yes / no --> |

**System prompt**:

```
<!-- NOTE: Write the full system prompt here. Keep it focused on the task.
     Never include user-controlled content in the system prompt. -->
```

## 3. API Route

<!-- NOTE: This is the streaming (or non-streaming) Next.js route handler for the AI call.
     All AI calls go server-side — never expose API keys to the client.
     The route lives in the app (apps/portal/app/api/{{feature}}/ai/route.ts), but the
     provider SDK (Anthropic/OpenAI via the Vercel AI SDK) is imported ONLY in
     packages/adapters/src/ai/index.ts, behind the domain AiPort (@app/adapters) — never in an app.
     Client-only React helpers (e.g. ai/react useChat) may live in the app's _components/. -->

| Field | Value |
|-------|-------|
| **Route** | `POST /api/{{feature}}/ai` (handler in `apps/portal/app/api/{{feature}}/ai/route.ts`) |
| **Auth** | Required — session checked before calling AI provider |
| **Streaming** | yes — `text/event-stream` response |
| **Input schema** | <!-- TypeScript interface or Zod schema --> |
| **Output format** | <!-- streaming text / JSON object --> |

## 4. Rate Limiting Plan

| Setting | Value |
|---------|-------|
| **Per-user limit** | <!-- e.g. 20 requests / hour --> |
| **Window** | <!-- e.g. 1 hour rolling --> |
| **Enforcement** | <!-- e.g. Upstash Redis counter keyed on user ID --> |
| **Quota exceeded response** | 429 with `Retry-After` header |

## 5. Cost Estimate

<!-- NOTE: Use current pricing from the provider's pricing page. Model prices change — review quarterly. -->

| Metric | Value |
|--------|-------|
| **Avg input tokens / request** | <!-- estimate --> |
| **Avg output tokens / request** | <!-- estimate --> |
| **Cost per 1,000 users / month** | <!-- calculation at the rate limit above --> |
| **Monthly cap (hard limit)** | <!-- budget ceiling; alert at 80% --> |

## 6. Error Handling

<!-- NOTE: AI calls can fail silently or return unexpected output. Plan the fallback. -->

| Scenario | What the user sees | Recovery |
|---------|-------------------|----------|
| Provider API unavailable (5xx) | Inline error message: "AI is temporarily unavailable. Try again in a moment." | Retry button |
| Rate limit exceeded (429) | "You've reached your AI request limit. Resets in X minutes." | Show countdown |
| Response timeout | "This is taking longer than expected. Try a shorter input." | Cancel + retry |
| Streaming interrupted mid-response | Partial output shown + "Response was cut short" note | Retry option |

---

## Approval

- [ ] Model and prompt approved
- [ ] Rate limiting plan reviewed
- [ ] Cost estimate reviewed and budget set
- [ ] Error handling reviewed
- **Date approved**: <!-- YYYY-MM-DD -->
