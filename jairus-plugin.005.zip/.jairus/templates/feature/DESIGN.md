---
feature: ""        # kebab-case feature name from INTENT.md
version: "1.0"
status: draft      # draft | approved
---

# Technical Design: {{Feature Display Name}}

<!-- NOTE: Complete this after PRD is approved (Gate 3 requires both).
     The developer will not start without an approved DESIGN.
     Reference: src/ structure lives under Next.js App Router conventions. -->

## 1. Architecture Overview

<!-- NOTE: How does this feature fit into the overall Next.js app? Which App Router
     segments are involved (layouts, pages, route handlers)? What data sources does it touch?
     2–4 sentences, then a concise list of files/routes being created or modified. -->

**New routes / files:**
- `app/(app)/{{feature}}/page.tsx` — <!-- what renders here -->
- `app/api/{{feature}}/route.ts` — <!-- what this handler does -->

## 2. User Flows

<!-- NOTE: Show the key paths a user takes through this feature.
     Use Mermaid flowcharts or ASCII. Show at least the happy path and the auth-error path. -->

### Flow 1: Happy path — {{primary user action}}

```mermaid
flowchart TD
    A([User lands on page]) --> B{Authenticated?}
    B -- No --> C[Redirect to /login]
    B -- Yes --> D[Load data via Server Component]
    D --> E[Render UI]
    E --> F([User completes action])
    F --> G[POST /api/{{feature}}]
    G --> H[Update DB]
    H --> I[Revalidate cache]
    I --> J([Show success state])
```

### Flow 2: Error path — {{error scenario}}

```mermaid
flowchart TD
    A([User submits form]) --> B[POST /api/{{feature}}]
    B --> C{Validation}
    C -- Fails --> D[Return 422 with field errors]
    D --> E([Show inline errors, focus first field])
    C -- Passes --> F[DB write]
    F --> G{Success?}
    G -- No --> H([Show toast: generic error, retry CTA])
    G -- Yes --> I([Optimistic update + success toast])
```

## 3. Component Hierarchy

<!-- NOTE: Show the JSX tree. Mark each component: [S] = Server, [C] = Client.
     Default to Server; use Client only when you need interactivity or browser APIs. -->

```
<{{Feature}}Page> [S]          ← app/(app)/{{feature}}/page.tsx
  <{{Feature}}Header> [S]      ← displays title + actions
  <{{Feature}}List> [S]        ← fetches data, renders list
    <{{Feature}}Card> [S]      ← individual item display
  <{{Feature}}Form> [C]        ← controlled form with client state
    <Input> [C]                ← shared ui/Input.tsx
    <Button> [C]               ← shared ui/Button.tsx
  <EmptyState> [S]             ← shown when list is empty
```

<!-- NOTE: Keep the tree shallow. Avoid "component islands" unless re-use is clear. -->

## 4. State Management

<!-- NOTE: Where does state live? Server state fetched once per request (Server Components)
     does not need client state management. Only add useState/useReducer/context when
     the user interaction requires it. -->

| State | Location | How it flows |
|-------|----------|--------------|
| <!-- e.g. List of items --> | <!-- Server Component (fetch in page.tsx) --> | <!-- fetched at request time, revalidated on mutation --> |
| <!-- e.g. Form inputs --> | <!-- Client Component useState --> | <!-- local until submit --> |
| <!-- e.g. Toast notifications --> | <!-- Client Context (ToastProvider) --> | <!-- triggered from form submit handler --> |

## 5. Error Handling

<!-- NOTE: For each user story, describe the error states: what can fail, what the user
     sees, and how they can recover. Never show raw error messages to users. -->

| Error scenario | What the user sees | Recovery |
|---------------|-------------------|----------|
| Network/server error on load | Skeleton → error boundary fallback with retry button | Click retry |
| Validation error on submit | Inline field error below the input | Fix input |
| Unauthorized (session expired) | Redirect to /login with `redirectTo` param | Re-authenticate |
| Not found (resource deleted) | 404 page with "Go back" link | Navigate back |

## 6. Accessibility (a11y)

<!-- NOTE: Required — the reviewer checks this. Axe-core runs in the quality gates CI. -->

- **Keyboard navigation**: <!-- describe tab order, enter/space to activate, escape to dismiss -->
- **ARIA roles**: <!-- list landmark roles, dialog aria-labelledby, etc. -->
- **Focus management**: <!-- where focus goes after modal opens/closes, after form submit -->
- **Screen reader**: <!-- dynamic announcements (aria-live), descriptive labels -->
- **Color contrast**: All tokens from `docs/design.md` — verified WCAG AA

## 7. Performance

<!-- NOTE: Loading states, caching, pagination. Default to Server Components which
     stream automatically. Add explicit strategies only where needed. -->

- **Loading**: <!-- Suspense boundary with skeleton UI, or streaming via loading.tsx -->
- **Caching**: <!-- Next.js cache tags, revalidatePath/revalidateTag after mutations -->
- **Pagination**: <!-- cursor-based / offset, or "not needed — item count is bounded" -->
- **Images**: <!-- next/image with explicit width/height, or "no images" -->

## 8. Security

<!-- NOTE: Reference .jairus/rules/security.md for the full checklist. Call out
     feature-specific auth, authorization, and input validation decisions here. -->

- **Authentication**: All routes require active session (middleware or server component check)
- **Authorization**: <!-- "Users can only access their own data — enforced via RLS/Security Rules" -->
- **Input validation**: <!-- "Zod schema validated in route handler before DB write" -->
- **Sensitive data**: <!-- "No PII returned in list endpoints" / describe masking if needed -->

---

## Approval

- [ ] Architecture approved — flows and component hierarchy make sense
- [ ] Security reviewed — auth/authz + validation strategy is sound
- [ ] Accessibility reviewed — a11y plan is sufficient
- **Date approved**: <!-- YYYY-MM-DD -->
