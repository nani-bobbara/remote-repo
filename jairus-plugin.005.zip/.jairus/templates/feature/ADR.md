# Architecture Decision Record: {{Feature Display Name}}

<!-- NOTE: Add one ADR entry per significant architectural decision made during design.
     Decisions that warrant an ADR: data model approach, auth strategy, third-party service
     choice, major component pattern, caching strategy, API design tradeoff.
     Trivial decisions (which icon library, exact color value) do NOT need an ADR.
     Keep each entry short — context + decision + consequences. -->

---

## ADR-001: {{Decision title}}

- **Date**: <!-- YYYY-MM-DD -->
- **Status**: Proposed | Accepted | Superseded | Deprecated

### Context

<!-- NOTE: What situation made this decision necessary? What forces or constraints
     are at play? Be specific — name the actual tradeoffs. -->

### Decision

<!-- NOTE: What was decided, and why? Be concrete. "We will use X because Y."
     Not "We considered X." -->

### Alternatives Considered

| Alternative | Why Rejected |
|------------|-------------|
| <!-- Option B --> | <!-- reason --> |
| <!-- Option C --> | <!-- reason --> |

### Consequences

**Positive:**
- <!-- benefit 1 -->

**Negative / risks:**
- <!-- tradeoff or risk -->

---

## ADR-002: {{Decision title}}

- **Date**: <!-- YYYY-MM-DD -->
- **Status**: Proposed | Accepted | Superseded | Deprecated

### Context

### Decision

### Alternatives Considered

| Alternative | Why Rejected |
|------------|-------------|
| | |

### Consequences

**Positive:**
- 

**Negative / risks:**
- 

<!-- NOTE: Duplicate the ADR block above for each additional decision.
     Number them sequentially: ADR-001, ADR-002, ADR-003, … -->
