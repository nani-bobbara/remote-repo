---
feature: ""        # kebab-case feature name from INTENT.md
version: "1.0"
status: draft      # draft | approved
---

# API Design: {{Feature Display Name}}

<!-- NOTE: All API routes are Next.js App Router route handlers (app/api/…/route.ts).
     Every endpoint requires authentication unless explicitly marked public.
     Validate all input with Zod before touching the database. -->

## 1. Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/api/{{feature}}` | required | <!-- list items for the current user --> |
| POST | `/api/{{feature}}` | required | <!-- create a new item --> |
| GET | `/api/{{feature}}/[id]` | required | <!-- get a single item by ID --> |
| PATCH | `/api/{{feature}}/[id]` | required | <!-- update an item --> |
| DELETE | `/api/{{feature}}/[id]` | required | <!-- delete an item --> |

<!-- NOTE: Remove rows that don't apply. Add rows for nested resources if needed.
     Keep paths RESTful. No verbs in paths (/api/items/create → POST /api/items). -->

---

## 2. Endpoint Detail

### GET `/api/{{feature}}`

**Description**: Return a paginated list of items owned by the authenticated user.

**Request**

| Parameter | In | Type | Required | Description |
|-----------|-----|------|----------|-------------|
| `Authorization` | header | `Bearer <token>` | yes | Session token |
| `limit` | query | `number` | no | Items per page (default: 20, max: 100) |
| `cursor` | query | `string` | no | Pagination cursor from previous response |

**Success Response (200)**

```typescript
interface GetItemsResponse {
  data: {
    id: string;
    // <!-- add your fields here -->
    createdAt: string; // ISO 8601
  }[];
  nextCursor: string | null;
}
```

**Error Responses**

| Status | Code | When |
|--------|------|------|
| 401 | `UNAUTHORIZED` | No valid session |
| 500 | `INTERNAL_ERROR` | Unexpected server error |

**Rate limit**: 60 requests / minute per user

---

### POST `/api/{{feature}}`

**Description**: Create a new item for the authenticated user.

**Request**

| Parameter | In | Type | Required | Description |
|-----------|-----|------|----------|-------------|
| `Authorization` | header | `Bearer <token>` | yes | Session token |
| `Content-Type` | header | `application/json` | yes | |

**Request Body**

```typescript
interface CreateItemRequest {
  // <!-- add your fields here -->
  name: string; // 1–100 chars
}
```

**Zod schema** (used in route handler):

```typescript
const createItemSchema = z.object({
  name: z.string().min(1).max(100),
  // add fields
});
```

**Success Response (201)**

```typescript
interface CreateItemResponse {
  data: {
    id: string;
    // <!-- created item fields -->
    createdAt: string;
  };
}
```

**Error Responses**

| Status | Code | When |
|--------|------|------|
| 401 | `UNAUTHORIZED` | No valid session |
| 422 | `VALIDATION_ERROR` | Body fails Zod schema — returns `{ errors: ZodIssue[] }` |
| 500 | `INTERNAL_ERROR` | Unexpected server error |

**Rate limit**: 30 requests / minute per user

---

## 3. Error Codes Reference

| Code | HTTP Status | When to use |
|------|------------|-------------|
| `UNAUTHORIZED` | 401 | Request has no valid session token |
| `FORBIDDEN` | 403 | Session is valid but user lacks permission for this resource |
| `NOT_FOUND` | 404 | Resource does not exist, or belongs to another user |
| `VALIDATION_ERROR` | 422 | Request body or query params fail schema validation |
| `CONFLICT` | 409 | Resource already exists (e.g. duplicate unique field) |
| `INTERNAL_ERROR` | 500 | Unexpected server error — log but do not expose details |

<!-- NOTE: Never return a 200 with an error in the body. Use appropriate HTTP status codes. -->

## 4. Authentication

- **Method**: Session token via cookie (Better Auth session cookie)
- **Validation**: Read the session in the route handler via Better Auth before any DB access
- **Pattern** (Better Auth):
  ```typescript
  import { requireUser } from '@app/auth';   // requireStaff() for admin-app routes (data-driven RBAC: can(session, 'admin:access'))
  const session = await requireUser();        // Better Auth session cookie
  if (!session) return NextResponse.json({ code: 'UNAUTHORIZED' }, { status: 401 });
  ```

## 5. Input Validation

<!-- NOTE: Zod schemas are the contract. Define them in a shared lib/validations/{{feature}}.ts
     so route handlers and client-side forms can import the same schema. -->

| Endpoint | Schema location | Key rules |
|----------|----------------|-----------|
| POST `/api/{{feature}}` | `lib/validations/{{feature}}.ts` | <!-- e.g. name: min 1, max 100; no HTML --> |
| PATCH `/api/{{feature}}/[id]` | `lib/validations/{{feature}}.ts` | <!-- e.g. all fields optional, at least one required --> |

---

## Approval

- [ ] API design approved — endpoints are correct and consistent
- [ ] Security reviewed — all endpoints authenticate + authorize correctly
- [ ] Developer reviewed — implementation is clear from this spec
- **Date approved**: <!-- YYYY-MM-DD -->
