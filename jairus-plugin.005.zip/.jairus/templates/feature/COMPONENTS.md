---
feature: ""        # kebab-case feature name from INTENT.md
version: "1.0"
status: draft      # draft | approved
---

# Component Design: {{Feature Display Name}}

<!-- NOTE: Design every component before the developer writes a single line of JSX.
     Use the component hierarchy from DESIGN.md as the source of truth for what to design here.
     Server Components are the default — add [C] Client only when you need interactivity. -->

---

## Components

### {{Feature}}Page `[S]` — Server Component

**File**: `apps/portal/app/(app)/{{feature}}/page.tsx`

**Type**: Server Component — fetches data at request time, no client-side state needed.

**Purpose**: Root page for the feature. Composes the header and list/form.

**Props**:
```typescript
// Next.js page — no explicit props interface; receives searchParams as a prop
interface PageProps {
  searchParams: { cursor?: string };
}
```

**Styling**: Uses `bg` and `surface` tokens. Layout: `max-w-3xl mx-auto px-4 py-8`.

**Accessibility**: Sets `<h1>` for the page title. Uses semantic `<main>` landmark.

**Reusability**: Page-specific — not promoted to `packages/ui` (`@app/ui`).

---

### {{Feature}}Form `[C]` — Client Component

**File**: `apps/portal/app/(app)/{{feature}}/_components/{{Feature}}Form.tsx`

**Type**: Client Component — manages controlled inputs, calls API on submit, shows errors.

**Purpose**: Handles creation / editing of a {{feature}} item.

**Props**:
```typescript
interface {{Feature}}FormProps {
  onSuccess?: (id: string) => void;   // called after successful submit
  initialValues?: Partial<{{Feature}}FormValues>; // for edit mode
}
```

**State**: `useState` for form values, submission status, and field-level errors.

**Styling**:
- Form wrapper: `space-y-4`
- Labels: `label` token (`text-xs font-medium uppercase tracking-wide`)
- Inputs: `surface` background, `border` token border, `radius-md`
- Submit button: `primary` token background, `primary-fg` text, `radius-sm`

**Accessibility**:
- Each input has an associated `<label htmlFor>` — no placeholder-only labels
- Error messages linked via `aria-describedby`
- On submit failure: focus moves to first errored field
- Submit button shows `aria-busy="true"` while loading

**Reusability**: Feature-specific — not promoted to `packages/ui` (`@app/ui`).

---

<!-- NOTE: Add one section per component from the DESIGN.md component hierarchy.
     Use the same [S] / [C] notation. Be specific about props, tokens, and a11y. -->

---

## Shared UI Additions

<!-- NOTE: New primitives being added to packages/ui/src/components (@app/ui) for use across features.
     If this feature introduces no new shared components, write "None." -->

| Component | File | Purpose |
|-----------|------|---------|
| <!-- e.g. EmptyState --> | <!-- packages/ui/src/components/EmptyState.tsx --> | <!-- Generic empty state with icon, title, CTA --> |

---

## Design Token Usage

<!-- NOTE: List the tokens from docs/design.md used in this feature's components. -->

| Token | Where used |
|-------|-----------|
| `bg` | Page background |
| `surface` | Cards, form fields |
| `border` | Input borders, dividers |
| `text` | Primary labels and content |
| `text-muted` | Helper text, timestamps |
| `primary` | Submit button, links |
| `primary-fg` | Text on primary button |
| `danger` | Validation error messages |

---

## Approval

- [ ] Component design approved — all components from DESIGN.md hierarchy are specified
- [ ] Accessibility reviewed — every interactive component has a11y requirements
- [ ] Tokens reviewed — no raw hex or arbitrary values
- **Date approved**: <!-- YYYY-MM-DD -->
