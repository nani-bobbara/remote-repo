# Feature Progress Checklist: {{Feature Display Name}}

<!-- NOTE: A per-feature WORKING checklist the developer uses to track progress. It is a
     convenience mirror, NOT a source of truth: authoritative feature/stage status lives on
     the GitHub Project card (see .jairus/rules/state-model.md). When this list and the board
     card disagree, the board wins. Gates marked 🚦 require human approval before proceeding —
     the real gate record is the board card moving to the gate column, not a checkbox here.
     Never skip a gate — see .jairus/rules/pipeline.md. -->

---

## Phase 1 — Design (🚦 Gate 3 required before any code)

- [ ] PRD complete — all sections filled, no placeholders
- [ ] DESIGN complete — user flows, component hierarchy, state, error handling
- [ ] API complete — all endpoints specified with request/response schemas
- [ ] DATABASE complete — schema, RLS/Security Rules, migration + rollback SQL
- [ ] COMPONENTS complete — all components from hierarchy designed with tokens + a11y
- [ ] ADR complete — all significant architectural decisions documented
- [ ] Design review passed (≥ 8/10) — reviewer agent returned PASS
- [ ] **🚦 Gate 3: Human approved design artifacts** — date: <!-- YYYY-MM-DD -->

---

## Phase 2 — Develop

- [ ] Feature branch created: `feature/{{feature-name}}`
- [ ] Backend schema implemented (migration applied and verified via backend MCP)
- [ ] RLS policies / Security Rules implemented and verified via backend MCP
- [ ] API route handlers implemented — all endpoints from API.md
- [ ] UI components implemented — all components from COMPONENTS.md
- [ ] Stripe integration implemented (if billing feature — test mode only)
- [ ] Unit tests passing — pure functions and utilities
- [ ] Integration tests passing — all API routes (happy path + unauthorized + validation error)
- [ ] Component tests passing — key interactions tested
- [ ] `pnpm type-check` — zero errors (strict mode, no `any`)
- [ ] `pnpm test` — all tests passing
- [ ] `pnpm build` — production build succeeds
- [ ] **🚦 Gate 4: Human approved backend changes** (if DB schema changed) — date: <!-- YYYY-MM-DD -->
- [ ] **🚦 Gate 5: Human approved live Stripe objects** (if Stripe products/prices created) — date: <!-- YYYY-MM-DD -->

### AC Coverage

<!-- Developer fills this in after all layers are complete.
     Every AC-N from PRD.md must appear here with the file:line of its // AC-N comment.
     The reviewer checks this table — missing rows are [BLOCKER] findings. -->

| AC | Implemented at | Test at |
|----|---------------|---------|
| AC-1 | <!-- e.g. src/app/api/items/route.ts:34 --> | <!-- e.g. src/app/api/items/route.test.ts:12 --> |
| AC-2 | | |
| <!-- add one row per AC from PRD.md --> | | |

---

## Phase 3 — Review and Deploy

- [ ] Code review passed (≥ 8/10) — reviewer agent returned PASS
- [ ] **🚦 Gate 6: Human approved code review** — date: <!-- YYYY-MM-DD -->
- [ ] PR opened (github MCP) — design docs linked in PR description
- [ ] CI passing — all checks green (lint, type-check, test, build, secret-scan)
- [ ] **🚦 Gate 7: Human verified staging** — Vercel preview URL tested — date: <!-- YYYY-MM-DD -->
- [ ] **🚦 Gate 8: Human approved production deploy** — date: <!-- YYYY-MM-DD -->
- [ ] Merged to main
- [ ] Production deployment confirmed via Vercel MCP — URL: <!-- https://... -->
