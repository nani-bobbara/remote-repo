# Observability (optional)

Claude Code emits OpenTelemetry natively. Jairus adds **no instrumentation of its own** —
it points that telemetry at Grafana Cloud and ships a prebuilt dashboard.

## What you capture (per session, automatically)

- **Tokens** — input / output / cacheRead / cacheCreation, by model
- **Cost** — USD, by model
- **Tools & MCP** — every call by name, duration, success/fail, permission decision
- **API** — request latency (p50/p95), errors (rate limits, overloads)
- **Code** — edits by language, lines changed, commits, PRs

## Grafana Cloud is the push endpoint (no collector to host)

Grafana Cloud managed exposes a native **OTLP gateway** — Claude Code pushes OTLP/HTTP
directly to it. You do not deploy or run anything.

1. **Grafana Cloud** → your stack → *Connections → OTLP* → copy the endpoint URL and
   generate an API token. Base64-encode `instanceID:token` for the auth header.

2. **Set env vars in your shell profile** (not `.env.local` — Claude Code reads the shell).
   Copy the full `Observability` block from `.env.example` and fill in the endpoint + header.

3. **Import the dashboard** — Grafana → *Dashboards → New → Import* → upload
   `grafana-dashboard.json` → pick your Prometheus/Mimir data source.

Restart Claude Code so the vars load. Telemetry is off until all vars are set.

## Team distribution

- **Sharing the plugin**: the marketplace is a `git` source — teammates get it by enabling
  `jairus@jairus-plugin` in their `~/.claude/settings.json`. A private repo requires each
  teammate to be authenticated to GitHub.
- **Sharing telemetry**: for a small team, each dev puts the Grafana token in their own
  shell profile (direct push). This is fine up to a handful of devs. Past that — or if you
  need central PII scrubbing / a single token — put a Grafana Alloy (or OTEL Collector)
  in front and point every dev at *its* URL instead. Don't build that until you need it.

## Security

- **Never set `OTEL_LOG_USER_PROMPTS`.** Prompts contain your source code. Leaving it unset
  keeps prompt bodies out of telemetry (event metadata still flows). This is a hard rule.
- The Grafana token is a write credential — treat it like any other secret; never commit it.

## Known limits & roadmap

- **Metric names** follow Claude Code's schema (`claude_code.*`). If Anthropic renames a
  metric, update the `expr` fields in `grafana-dashboard.json`. If a panel shows "No data",
  check the live metric name in Grafana's explorer first.
- **Per-phase / per-feature attribution is NOT in native telemetry.** Native signals tag by
  `session_id`, model, and tool — they do not know jairus is in "design" vs "develop". Getting
  *"design cost $0.40, develop cost $3.10 for feature `billing`"* requires a **v2 phase-enrichment
  hook**: a `PostToolUse`/`Stop` hook that reads the current pipeline stage from `INTENT.md` and
  stamps `jairus.phase` + `jairus.feature` on each emitted event. Shipped separately once the
  config-only dashboards are proven.
