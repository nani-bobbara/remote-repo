---
name: email
description: >
  Transactional email extension skill — Resend for email delivery, React Email for
  type-safe HTML templates (welcome, notifications, password reset, billing alerts).
  Load when INTENT.md extensions includes "email" OR when implementing any feature that
  sends email. Always loaded alongside the nextjs skill.
---

# Email Extension (Resend + React Email)

Active when `INTENT.md` has `"email"` in extensions.

## When This Skill Is Loaded

When any feature needs to send transactional email: welcome/onboarding, email
verification, password reset, subscription confirmation, billing alerts, or
activity notifications.

---

## Where the code lives (hexagonal)

The jairus-starter is a **pnpm + turbo hexagonal monorepo**. The layer rule is strict:

- `@app/domain` — entities and **ports** (interfaces). The `EmailPort` already lives here.
- `@app/application` — use-cases. They depend on ports, never on vendors.
- `@app/adapters` — **the only package allowed to import vendor SDKs** (`resend`,
  `@react-email/components`, `@react-email/render`) plus DB and auth clients.
- `@app/auth`, `@app/ui`, `@app/config` — guards, shared UI, and config/brand.
- Apps: `apps/portal` (`:3001`) and `apps/admin` (`:3002`). There is **no `src/lib/*` tree.**

**The base email adapter already ships.** A working Resend adapter lives at
`packages/adapters/src/email/index.ts` and exports:

```typescript
// Already present — do NOT recreate the client.
export const email: EmailPort = { /* lazy Resend client from env */ }
```

`EmailPort` is defined in `@app/domain`:

```typescript
interface EmailPort {
  send(to: string, template: string, data: Record<string, unknown>): Promise<void>
}
```

So this extension is **additive**: it does not create a new Resend client. It **enriches
the existing adapter** with type-safe React Email templates and wires `email.send` to
render them. Every `resend` / `@react-email/*` import stays inside `packages/adapters/`.
Consumers (app server code, use-cases, the Stripe webhook) only ever call
`email.send(to, template, data)` from `@app/adapters` — they never import Resend or a
template component.

---

## Setup

Add the vendor SDKs to the adapter package only:

```bash
pnpm --filter @app/adapters add resend @react-email/components @react-email/render
```

Required env vars — these already exist in the **root** `.env.example`; confirm, do not
duplicate:

```
RESEND_API_KEY=re_...             # from Resend dashboard — server-side only
EMAIL_FROM=noreply@yourapp.com    # must be a verified domain in Resend
```

Template display names (app title, support address) are read from `@app/config/brand`
inside the templates — do not hardcode them.

**Domain verification:**
- In development, use `onboarding@resend.dev` as the `from` address (Resend's sandbox
  domain — no verification needed, but deliverable only to your own email).
- In production, add and verify your domain in the Resend dashboard first. Email
  sent from an unverified domain will be rejected.

---

## Key Patterns

### React Email templates (adapter-only, server-only)

Templates live at `packages/adapters/src/email/templates/*.tsx`. Each is a server-only
React Email component. Styling is **neutral** — no hardcoded brand colors; names come
from `@app/config/brand`.

```tsx
// packages/adapters/src/email/templates/welcome.tsx
import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Preview,
  Section,
  Text,
} from '@react-email/components'
import { brand } from '@app/config/brand'

export interface WelcomeEmailProps {
  userName: string
  loginUrl: string
}

/**
 * Welcome email sent after a user successfully creates an account.
 */
export function WelcomeEmail({ userName, loginUrl }: WelcomeEmailProps) {
  return (
    <Html>
      <Head />
      <Preview>Welcome to {brand.appName} — let's get you started</Preview>
      <Body style={{ backgroundColor: '#f9fafb', fontFamily: 'sans-serif' }}>
        <Container style={{ maxWidth: '600px', margin: '0 auto', padding: '24px' }}>
          <Heading style={{ fontSize: '24px', fontWeight: '600' }}>
            Welcome to {brand.appName}, {userName}!
          </Heading>
          <Text style={{ lineHeight: '1.6' }}>
            Thanks for signing up. Your account is ready — click the button below
            to get started.
          </Text>
          <Section style={{ textAlign: 'center', margin: '32px 0' }}>
            <Button
              href={loginUrl}
              style={{
                padding: '12px 24px',
                borderRadius: '6px',
                fontWeight: '600',
                textDecoration: 'none',
                border: '1px solid currentColor',
              }}
            >
              Go to Dashboard
            </Button>
          </Section>
          <Hr />
          <Text style={{ fontSize: '12px', opacity: 0.6 }}>
            If you didn't create this account, you can safely ignore this email.
          </Text>
        </Container>
      </Body>
    </Html>
  )
}
```

```tsx
// packages/adapters/src/email/templates/subscription-confirmed.tsx
import { Body, Button, Container, Head, Heading, Html, Preview, Text } from '@react-email/components'
import { brand } from '@app/config/brand'

export interface SubscriptionConfirmedProps {
  userName: string
  planName: string
  billingUrl: string
}

/**
 * Sent from the Stripe webhook after customer.subscription.created.
 */
export function SubscriptionConfirmedEmail({
  userName,
  planName,
  billingUrl,
}: SubscriptionConfirmedProps) {
  return (
    <Html>
      <Head />
      <Preview>You're now on the {planName} plan</Preview>
      <Body style={{ backgroundColor: '#f9fafb', fontFamily: 'sans-serif' }}>
        <Container style={{ maxWidth: '600px', margin: '0 auto', padding: '24px' }}>
          <Heading style={{ fontSize: '24px', fontWeight: '600' }}>
            Subscription confirmed
          </Heading>
          <Text>
            Hi {userName}, you're now subscribed to the <strong>{planName}</strong> plan
            on {brand.appName}. Your billing will start today.
          </Text>
          <Button
            href={billingUrl}
            style={{ padding: '12px 24px', borderRadius: '6px', border: '1px solid currentColor' }}
          >
            Manage Billing
          </Button>
        </Container>
      </Body>
    </Html>
  )
}
```

### Extending `email.send` in the adapter

Enrich the existing adapter so `template` selects a React Email component and `data`
are its props. Render to HTML with `@react-email/render` and hand it to Resend. The
`EmailPort` signature is unchanged; all vendor imports stay here.

```typescript
// packages/adapters/src/email/index.ts (enriched — keep the existing lazy Resend client)
import { Resend } from 'resend'
import { render } from '@react-email/render'
import type { ReactElement } from 'react'
import type { EmailPort } from '@app/domain'
import { WelcomeEmail } from './templates/welcome'
import { SubscriptionConfirmedEmail } from './templates/subscription-confirmed'

let _resend: Resend | null = null
function client(): Resend {
  if (!_resend) _resend = new Resend(process.env.RESEND_API_KEY!)
  return _resend
}

// template name -> (component, subject) resolver. `data` are the component props.
const templates: Record<
  string,
  { subject: (d: Record<string, unknown>) => string; render: (d: Record<string, unknown>) => ReactElement }
> = {
  welcome: {
    subject: () => 'Welcome!',
    render: (d) => WelcomeEmail(d as never),
  },
  'subscription-confirmed': {
    subject: () => 'Your subscription is confirmed',
    render: (d) => SubscriptionConfirmedEmail(d as never),
  },
}

export const email: EmailPort = {
  async send(to, template, data) {
    const entry = templates[template]
    if (!entry) throw new Error(`Unknown email template: ${template}`)

    const from =
      process.env.NODE_ENV === 'production'
        ? process.env.EMAIL_FROM!
        : 'onboarding@resend.dev' // sandbox fallback for dev

    const html = await render(entry.render(data))

    const { error } = await client().emails.send({
      from,
      to,
      subject: entry.subject(data),
      html,
    })

    if (error) throw new Error(`Email send failed (${template}): ${error.message}`)
  },
}
```

### Sending from an app server route

App code depends only on the port — import `email` from `@app/adapters`, never Resend
or a template component.

```typescript
// Inside an authenticated server route/action in apps/portal or apps/admin:
import { email } from '@app/adapters'

// After creating the user account:
await email.send(newUser.email, 'welcome', {
  userName: newUser.displayName,
  loginUrl: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard`,
})
```

### Sending from the Stripe webhook handler

Subscription confirmation emails belong in the webhook handler, not the checkout
success redirect. The webhook lives in the portal app and also calls the shared port.

```typescript
// apps/portal/app/api/stripe/webhook/route.ts
import { email } from '@app/adapters'
// ...after handling the subscription upsert:

if (event.type === 'customer.subscription.created') {
  const sub = event.data.object as Stripe.Subscription
  const user = await getUserByStripeCustomerId(sub.customer as string)

  if (user) {
    await email.send(user.email, 'subscription-confirmed', {
      userName: user.displayName,
      planName: 'Pro',
      billingUrl: `${process.env.NEXT_PUBLIC_APP_URL}/billing`,
    })
  }
}
```

### Preview templates during development

React Email includes a local dev server for previewing templates. Point it at the
adapter's template directory:

```bash
pnpm --filter @app/adapters exec email dev --dir packages/adapters/src/email/templates --port 3001
# Opens http://localhost:3001 — previews all templates with live reload
```

---

## Verify

```bash
pnpm -r type-check
pnpm --filter @app/adapters test
```

---

## Gotchas

**Verify your domain in Resend before go-live.**
Using an unverified domain in production will result in silent rejection. Test with
`onboarding@resend.dev` during development, switch to your verified domain (`EMAIL_FROM`)
in the Preview and Production env vars.

**Don't send email synchronously in a user-facing request if it might be slow.**
`email.send()` is a network call that adds latency. For non-critical emails
(notifications, digests), consider a background job or calling from a webhook.
For critical emails (account creation confirmation), sending inline is acceptable.

**Templates are server-rendered — they stay inside the adapter.**
Never import a template component (or `resend` / `@react-email/*`) in an app, in
`@app/ui`, or a `"use client"` file. All rendering happens inside
`packages/adapters/src/email/` and consumers only call `email.send(...)`.

**Resend rate limits on the free tier: 100 emails/day.**
This is sufficient for development but will block production if you don't upgrade.
Monitor usage in the Resend dashboard before launch.

**Do not log email content — it may contain PII.**
Log only the recipient email (or a masked version), template name, and send status.
Never log the full rendered HTML body.

**`RESEND_API_KEY` must never have a `NEXT_PUBLIC_` prefix.**
It gives full access to your Resend account including reading sent emails, creating
API keys, and configuring domains. Keep it server-side only, read only inside the adapter.

---

## MCP Usage

This skill does not have a dedicated MCP server. Resend is called from the
`@app/adapters` email adapter via the `resend` package. Apps and use-cases go through
`email.send(...)`.

---

## Integration With Other Skills

- **nextjs** — `email.send` is called from app server routes/actions and webhook
  handlers (server-side), imported from `@app/adapters`. Never call it from client
  components. It follows the same error convention: catch, log, return 500 with
  `INTERNAL_ERROR`.
- **stripe** — subscription confirmation, payment failure alerts, and cancellation
  emails are sent from the webhook handler at
  `apps/portal/app/api/stripe/webhook/route.ts`, which calls `email.send(...)` from
  `@app/adapters`. Always send from the webhook, not from the Checkout redirect.
- **neon** — look up the user via the Drizzle `user` table / scoped repo (also in
  `@app/adapters`) to get their email and display name before sending. The auth-session
  email may differ from the user-facing display name in the profile.
- **feature-flags** — gate email types during rollout, e.g.
  `if (evaluateFlag('send-weekly-digest', userId)) { await email.send(...) }`.
- **theming** — template display names and any brand text come from `@app/config/brand`;
  keep template styling neutral (no hardcoded hex brand colors).
