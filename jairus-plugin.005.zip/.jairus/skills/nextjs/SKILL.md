---
name: nextjs
description: >
  Next.js 14+ App Router + TypeScript strict + Tailwind + shadcn/ui — the always-on core
  frontend skill for the jairus monorepo (apps/portal + apps/admin). Load for EVERY feature:
  the two-app model, server/client component split, API route auth contract, error shape,
  input validation, shadcn + theme-token conventions, and testing patterns.
  Required by designer, developer, and reviewer on every task.
---

# Next.js (App Router) + TypeScript + Tailwind + shadcn (monorepo · two apps)

Always-on skill — loaded for every feature. The frontend is **two Next.js apps** in one
monorepo, both importing the shared backend packages and both styled with **shadcn/ui**
components over a single theme.

## When This Skill Is Loaded

Always. This covers the fixed core stack: Next.js 14+ App Router, TypeScript strict, Tailwind
+ **shadcn/ui**, in the **monorepo two-app** topology. Load it when building or reviewing any
frontend component, page, layout, API route, hook, or utility in either app.

---

## The two apps

```
apps/
  portal/   ← end-user product. `/` is a PUBLIC landing page. (auth)/login + (auth)/signup
             (email + Google). Protected routes call requireUser(). Read-heavy.
  admin/    ← internal console. `/` redirects to /login (NO public landing, NO signup).
             /login is email+password only (seeded admin, forced first-reset).
             Protected routes call requireStaff(). Write / cross-user.
packages/
  domain/      → @app/domain       entities, value-objects, PORTS + data-driven RBAC (see the neon skill)
  application/ → @app/application   use-cases orchestrating ports
  adapters/    → @app/adapters      Drizzle client, schema (src/db/), scoped repos (see the neon skill)
  auth/        → @app/auth          request-scoped session + guards: requireUser() (portal) · requireStaff() (admin)
```

Both apps import `@app/adapters` / `@app/auth` / `@app/domain` — they never define their own DB
client or auth. Backend detail (schema, security, migrations) lives in the **neon** skill.

| | portal | admin |
|---|---|---|
| `/` | public landing page | redirect → `/login` |
| signup | `(auth)/signup` — email + Google | **none** (self-signup disabled) |
| login | `(auth)/login` | `/login` — email + password only |
| guard | `requireUser()` | `requireStaff()` |

---

## Setup

Both apps are **cloned from the `jairus-starter` template** by Foundation (App Router, TS, Tailwind
already configured — Foundation clones, it does not regenerate) and wired to the workspace packages
— no extra install for the core stack. shadcn components are added per app on demand (see below).

```bash
# Per app (tsconfig.json): "strict": true (never disable) · alias "@/*": ["./*"]
# Workspace packages resolve as @app/adapters, @app/auth, @app/domain, @app/application.
# Shared UI primitives resolve as @app/ui (packages/ui/src).

# Add shadcn components into an app (run inside apps/portal or apps/admin):
pnpm dlx shadcn@latest add button input card dialog
# Component mechanics (variants, composition, forms) → the official `shadcn` skill
# in .claude/skills/. Theme tokens → the jairus `theming` skill.
```

Required env vars (public — safe for client, set per app):
```
NEXT_PUBLIC_APP_URL=<each app's own origin>   # portal → http://localhost:3001 · admin → http://localhost:3002
NEXT_PUBLIC_APP_NAME=YourApp
```

---

## Key Patterns

### Server vs Client Components

Server components are the default — no directive needed. They run on the server, have
direct access to env vars and backend clients, and never ship JS to the browser.

```typescript
// apps/portal/app/(dashboard)/dashboard/page.tsx — server component (default)
import { requireUser } from '@app/auth'
import { redirect } from 'next/navigation'
import { DashboardStats } from './_components/DashboardStats'

export default async function DashboardPage() {
  const session = await requireUser()   // admin pages call requireStaff() instead
  if (!session) redirect('/login')

  // Fetch data directly — this runs on the server
  const stats = await fetchStats(session.userId)

  return <DashboardStats stats={stats} />
}
```

Add `"use client"` ONLY when the component needs:
- `useState`, `useEffect`, `useRef`, `useCallback`, or any React hook with state/effects
- Browser APIs (`window`, `document`, `localStorage`, `navigator`)
- DOM event handlers attached inline (`onClick`, `onChange`, etc.)
- Third-party libraries that rely on the above

```typescript
// apps/portal/app/(dashboard)/dashboard/_components/StatsChart.tsx
'use client'  // ← only because recharts needs the DOM

import { LineChart, Line, XAxis, YAxis } from 'recharts'

interface StatsChartProps {
  data: { date: string; value: number }[]
}

/**
 * Renders an interactive line chart for dashboard stats.
 * Marked as client component because recharts requires browser APIs.
 */
export function StatsChart({ data }: StatsChartProps) {
  return (
    <LineChart width={600} height={300} data={data}>
      <XAxis dataKey="date" />
      <YAxis />
      <Line type="monotone" dataKey="value" stroke="var(--color-primary)" />
    </LineChart>
  )
}
```

### API Routes

Every API route follows this exact structure. Deviation from this contract breaks the
frontend error handling and test suite.

```typescript
// apps/portal/app/api/{resource}/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { requireUser } from '@app/auth'   // admin routes import requireStaff
import { z } from 'zod'

// Input schema — define before the handler
const CreateItemSchema = z.object({
  name: z.string().min(1).max(100),
  description: z.string().max(500).optional(),
})

/**
 * GET /api/items — list all items for the authenticated user.
 */
export async function GET(request: NextRequest) {
  const session = await requireUser()
  if (!session) {
    return NextResponse.json(
      { error: 'Authentication required', code: 'UNAUTHORIZED' },
      { status: 401 }
    )
  }

  try {
    const items = await fetchItemsForUser(session.userId)
    return NextResponse.json({ items })
  } catch (error) {
    console.error('[GET /api/items]', error)
    return NextResponse.json(
      { error: 'Internal server error', code: 'INTERNAL_ERROR' },
      { status: 500 }
    )
  }
}

/**
 * POST /api/items — create a new item.
 */
export async function POST(request: NextRequest) {
  const session = await requireUser()
  if (!session) {
    return NextResponse.json(
      { error: 'Authentication required', code: 'UNAUTHORIZED' },
      { status: 401 }
    )
  }

  let body: unknown
  try {
    body = await request.json()
  } catch {
    return NextResponse.json(
      { error: 'Invalid JSON body', code: 'INVALID_REQUEST' },
      { status: 400 }
    )
  }

  const parsed = CreateItemSchema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0].message, code: 'INVALID_REQUEST' },
      { status: 400 }
    )
  }

  try {
    const item = await createItem({ userId: session.userId, ...parsed.data })
    return NextResponse.json({ item }, { status: 201 })
  } catch (error) {
    console.error('[POST /api/items]', error)
    return NextResponse.json(
      { error: 'Internal server error', code: 'INTERNAL_ERROR' },
      { status: 500 }
    )
  }
}
```

**Standard error codes and HTTP status mapping — never deviate:**

| Code               | Status | When to use                                      |
|--------------------|--------|--------------------------------------------------|
| `INVALID_REQUEST`  | 400    | Malformed JSON, failed schema validation         |
| `UNAUTHORIZED`     | 401    | No session / expired token                       |
| `FORBIDDEN`        | 403    | Authenticated but not allowed on this resource   |
| `NOT_FOUND`        | 404    | Resource does not exist (or user can't see it)   |
| `CONFLICT`         | 409    | Duplicate unique value, state conflict           |
| `INTERNAL_ERROR`   | 500    | Unexpected backend / DB error                    |

### TypeScript Conventions

```typescript
// Use interfaces for public APIs and component props
interface UserProfile {
  id: string
  email: string
  displayName: string
  createdAt: Date
}

// Use types for unions, intersections, utility derivations
type UserRole = 'owner' | 'member' | 'viewer'
type UserWithRole = UserProfile & { role: UserRole }

// unknown + type guard instead of any
function isApiError(value: unknown): value is { error: string; code: string } {
  return (
    typeof value === 'object' &&
    value !== null &&
    'error' in value &&
    'code' in value
  )
}

// JSDoc on every exported function and component
/**
 * Fetches the current user's subscription tier from the DB.
 * Returns null if the user has no active subscription.
 */
export async function getUserSubscriptionTier(userId: string): Promise<string | null> {
  // ...
}
```

### UI = shadcn + theme tokens

The UI is built from **shadcn/ui** components (`npx shadcn@latest add ...`), styled with the
project's **shadcn theme tokens** (CSS variables). Each app imports its own
`apps/portal/app/globals.css` / `apps/admin/app/globals.css`, and the shared design tokens live
in `packages/ui/src/styles.css` (established once at Foundation). Both apps share the theme;
admin may carry a distinct accent. Never hardcode a
color or hex in a component — use the semantic token classes (`bg-background`, `text-foreground`,
`bg-primary`, `border`, `bg-muted`, `text-muted-foreground`, …).

- **Component mechanics** (variants, `cn()`, composition, `<Form>` + react-hook-form) → the
  official **`shadcn` skill** in `.claude/skills/`.
- **The theme + token discipline** → the jairus **`theming` skill**.

```tsx
// ✅ Correct — shadcn Button + theme tokens
import { Button } from '@app/ui'
<Button>Save changes</Button>
// or, styling directly with tokens:
<button className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-md px-4 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
  Save changes
</button>

// ❌ Wrong — hardcoded color / arbitrary values bypass the theme (a review finding)
<button className="bg-[#6366f1] text-white rounded-[6px] px-[16px] py-[8px] text-[14px]">
  Save changes
</button>
```

All interactive elements must meet WCAG AA contrast (4.5:1 for normal text, 3:1 for
large text). Use `focus-visible:ring-2` for keyboard focus, not `focus:outline-none`.
A hardcoded hex/color in a component is a **quality finding** in code review — see
`rules/quality-gate.md`.

### Component File Structure (per app)

Each app owns its own `app/` (App Router at the package root — no `src/` directory); the DB
client, schema, and auth helpers live in the shared packages (`@app/adapters`, `@app/auth`) —
never re-declared inside an app. Reusable UI primitives live in `packages/ui` (`@app/ui`).

```
apps/portal/
  app/
    page.tsx              ← PUBLIC landing page
    globals.css           ← app stylesheet (imports shared tokens from @app/ui)
    (auth)/
      login/page.tsx
      signup/page.tsx     ← email + Google (portal only)
    (app)/
      layout.tsx          ← authenticated layout wrapper
      _components/         ← route-group-scoped components
      dashboard/
        page.tsx           ← calls requireUser() (admin: requireStaff())
        _components/        ← page-scoped components
          DashboardStats.tsx
          StatsChart.tsx    ← "use client" because of chart lib
    _components/           ← app-local shared components
    api/
      auth/[...]/route.ts ← Better Auth handler — excluded from auth guard
      items/route.ts
      items/[id]/route.ts
  lib/
    utils.ts              ← cn() and app helpers (auth/db come from @app/*)
  types/index.ts          ← app-local types

apps/admin/               ← same shape, but: `/` redirects to /login, NO signup route,
                            protected pages/routes call requireStaff()

packages/ui/src/
  components/             ← shared shadcn primitives (button, input, card, ...) → @app/ui
  styles.css             ← shared design tokens (CSS variables)
```

Shared backend (imported by both apps):
```
packages/auth/src        → @app/auth        requireUser() (portal) · requireStaff() (admin)
packages/adapters/src/db → @app/adapters    Drizzle client + schema (types via $inferSelect) + scoped repos
packages/domain/src      → @app/domain      entities, ports, data-driven RBAC (can(), PERMISSIONS)
```

---

## Gotchas

**`getServerSideProps` / `getStaticProps` do not exist in App Router.**
These are Pages Router APIs. Use `async` server components or `generateStaticParams`
for static generation.

**`layout.tsx` runs on every navigation — never fetch user-specific data there.**
Put per-page data fetching in the page component, not the layout. Layout is for
persistent chrome (nav, sidebar) that doesn't change per-route.

**`"use client"` on a parent turns ALL its children into client components.**
Keep the client boundary as low as possible. Extract only the interactive bit into
a client component; keep the wrapper and siblings as server components.

**`NEXT_PUBLIC_*` env vars are compiled into the client bundle.**
Never put secrets, service-role keys, or API keys in `NEXT_PUBLIC_*` vars. These
are visible to anyone who inspects the page source or network tab.

**Never expose DB error messages to the client.**
Log `error` server-side, return `{ error: 'Internal server error', code: 'INTERNAL_ERROR' }`.
DB errors can contain table names, column names, and query fragments.

**Input validation must happen before any DB call.**
Use zod `safeParse`. Return 400 before touching the database if the input is invalid.

---

## Testing

Integration tests for every API route. Component tests for every UI component.
Unit tests for lib/ and hooks.

```typescript
// apps/portal/__tests__/items/api.test.ts
import { GET, POST } from '@/app/api/items/route'
import { NextRequest } from 'next/server'

// Mock the shared auth package
jest.mock('@app/auth', () => ({
  requireUser: jest.fn(),
}))

describe('GET /api/items', () => {
  it('returns 401 when not authenticated', async () => {
    const { requireUser } = require('@app/auth')
    requireUser.mockResolvedValue(null)

    const response = await GET(new NextRequest('http://localhost/api/items'))
    expect(response.status).toBe(401)
    const body = await response.json()
    expect(body.code).toBe('UNAUTHORIZED')
  })

  it('returns items for authenticated user', async () => {
    const { requireUser } = require('@app/auth')
    requireUser.mockResolvedValue({ userId: 'user-123' })
    // mock fetchItemsForUser...

    const response = await GET(new NextRequest('http://localhost/api/items'))
    expect(response.status).toBe(200)
    const body = await response.json()
    expect(Array.isArray(body.items)).toBe(true)
  })
})
```

File patterns:
- `__tests__/{feature}/api.test.ts` — API route integration tests
- `__tests__/{feature}/{Component}.test.tsx` — component tests
- `__tests__/lib/{utility}.test.ts` — utility unit tests

---

## MCP Usage

This skill does not have a dedicated MCP server. Use the **github** MCP for repo
operations and the **neon** MCP (or Drizzle) for data operations.

---

## Integration With Other Skills

- **neon** — the Drizzle client (`@app/adapters`) is imported into API routes. The auth
  session helper (`@app/auth`) wraps Better Auth's `requireUser()` (portal) /
  `requireStaff()` (admin, = `requirePermission('admin:access')`). Never import the Drizzle client in client components.
- **shadcn** (official skill) + **theming** — every component is a shadcn component
  styled with theme tokens; no hardcoded colors. shadcn covers component mechanics,
  `theming` owns the shared theme + token discipline for both apps.
- **stripe** — the Stripe webhook route (`apps/portal/app/api/stripe/webhook/route.ts`)
  is exempt from the auth guard. All other billing routes require auth.
- **ai** — AI streaming routes return `result.toDataStreamResponse()` instead of
  `NextResponse.json()`. The `useChat` hook in client components connects to them.
- **email** — `sendEmail` is called from API routes (server-side only), never from
  client components or pages.
- **feature-flags** — server-side flag evaluation happens in server components or API
  routes; client-side hooks are in `"use client"` components only.
