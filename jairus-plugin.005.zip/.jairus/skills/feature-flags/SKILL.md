---
name: feature-flags
description: >
  Feature flags extension skill — GrowthBook (default, open-source) for UX gating,
  A/B testing, and gradual rollouts. Covers GrowthBook provider setup, client-side
  useFeatureFlag hook, server-side evaluation for SSR, and flag-gated component patterns.
  Load when INTENT.md extensions includes "feature-flags" OR when implementing gradual
  rollouts, A/B tests, or conditional feature access. Always loaded alongside nextjs.
---

# Feature Flags Extension (GrowthBook)

Active when `INTENT.md` has `"feature-flags"` in extensions. Default provider: **GrowthBook**.

## When This Skill Is Loaded

When any feature needs gradual rollout gating, A/B testing, per-plan feature access
(beyond what Stripe subscription status alone provides), or kill switches for new
functionality.

---

## Where the code lives (hexagonal)

The jairus-starter is a **pnpm + turbo hexagonal monorepo**. Feature flags are split
strictly by runtime — the server SDK and the client SDK never mix:

| Concern | Package / App | What goes here |
| --- | --- | --- |
| **Domain port** | `@app/domain` | `FlagsPort { isEnabled(key, userId?): Promise<boolean> }` — already defined |
| **Server adapter** | `packages/adapters/src/flags/index.ts` | Real `FlagsPort` impl using the **server** SDK `@growthbook/growthbook`. This is the file onboarding replaces (it ships as a fail-closed stub) |
| **Server-side gating** | use-cases (`@app/application`), SSR server components, route handlers | Call `flags.isEnabled(key, userId)` through the port import from `@app/adapters` |
| **Client provider + hooks** | `apps/portal/app/_components/…` | `"use client"` provider wrapping `@growthbook/growthbook-react` + `useFlag` / `useFlagValue`. **App-local — never in `@app/adapters`** |

Hard rules:

- The **server SDK** (`@growthbook/growthbook`) is imported **only** inside
  `packages/adapters/src/flags/index.ts`. Never import it in an app.
- The **client SDK** (`@growthbook/growthbook-react`) is a browser concern that lives
  **only** in the app (`apps/portal`). Never put React client hooks in `@app/adapters`.
- There is no `src/` tree at the repo root — adapters live under `packages/adapters/src`,
  app code under `apps/<app>/app`.

---

## Setup

Install each SDK into the package that actually uses it:

```bash
# Server SDK — used ONLY inside the adapter
pnpm --filter @app/adapters add @growthbook/growthbook

# Client SDK — used ONLY inside the portal app
pnpm --filter portal add @growthbook/growthbook-react
```

Required env vars (root `.env.example`):
```
# Server-side only — read inside packages/adapters/src/flags/index.ts. Never NEXT_PUBLIC_.
GROWTHBOOK_CLIENT_KEY=sdk-abc123...
GROWTHBOOK_API_HOST=https://cdn.growthbook.io      # or self-hosted URL

# Client-side — NEXT_PUBLIC_ prefix is correct here; client key is safe to expose
NEXT_PUBLIC_GROWTHBOOK_CLIENT_KEY=sdk-abc123...
```

The GrowthBook **client key** (SDK key) is safe to expose in the browser. It is
read-only and used to fetch feature flag values from the CDN. The admin API key
(used in the GrowthBook dashboard) must never be exposed.

---

## Server: implement `FlagsPort` in the adapter

`@app/domain` already declares the port and `packages/adapters/src/flags/index.ts`
ships as a fail-closed stub:

```typescript
// packages/adapters/src/flags/index.ts  (the stub you are replacing)
import type { FlagsPort } from '@app/domain'
export const flags: FlagsPort = { async isEnabled() { return false } }
```

Onboarding = replace that stub with a real GrowthBook **server** implementation behind
the port. Lazy-init from `process.env`, and fail closed (return `false`) when unconfigured:

```typescript
// packages/adapters/src/flags/index.ts
import { GrowthBook } from '@growthbook/growthbook'
import type { FlagsPort } from '@app/domain'

/**
 * Server-side GrowthBook client, lazily created once per process.
 * Returns null when GROWTHBOOK_CLIENT_KEY is unset so the port fails closed.
 */
let clientPromise: Promise<GrowthBook | null> | null = null

function getClient(): Promise<GrowthBook | null> {
  if (clientPromise) return clientPromise

  clientPromise = (async () => {
    const clientKey = process.env.GROWTHBOOK_CLIENT_KEY
    if (!clientKey) return null // unconfigured → fail closed

    const gb = new GrowthBook({
      apiHost: process.env.GROWTHBOOK_API_HOST ?? 'https://cdn.growthbook.io',
      clientKey,
    })

    // Must await before evaluating — otherwise every flag reads false.
    await gb.init({ timeout: 2000 })
    return gb
  })()

  return clientPromise
}

/**
 * Real FlagsPort implementation backed by the GrowthBook server SDK.
 * Consumed by use-cases, SSR server components, and route handlers via
 * `import { flags } from '@app/adapters'`.
 */
export const flags: FlagsPort = {
  async isEnabled(key: string, userId?: string): Promise<boolean> {
    const gb = await getClient()
    if (!gb) return false // fail closed when unconfigured

    // Per-call attributes so the same process can evaluate for any user.
    gb.setAttributes({ id: userId ?? 'anonymous' })
    return gb.isOn(key)
  },
}
```

### Server-side gate (use-case / server component)

Any server-side code calls the port — it never touches the GrowthBook SDK directly:

```typescript
// packages/application/src/dashboard/get-dashboard-view.ts
import { flags } from '@app/adapters'

export async function getDashboardView(userId: string) {
  const showNewAnalytics = await flags.isEnabled('new-analytics-dashboard', userId)
  return { showNewAnalytics }
}
```

```tsx
// apps/portal/app/dashboard/page.tsx  (server component — no "use client")
import { flags } from '@app/adapters'
import { requireUser } from '@app/auth'

export default async function DashboardPage() {
  const session = await requireUser()   // throws UnauthorizedError if not signed in

  const showNewAnalytics = await flags.isEnabled('new-analytics-dashboard', session.userId)

  return showNewAnalytics ? <NewAnalyticsDashboard /> : <LegacyAnalyticsDashboard />
}
```

---

## Client: provider + hooks in the app

The browser SDK lives in `apps/portal`. Wrap the app in the GrowthBook provider and
expose thin `useFlag` / `useFlagValue` hooks.

### Provider

```tsx
// apps/portal/app/_components/feature-flags-provider.tsx
'use client'
import { GrowthBook, GrowthBookProvider } from '@growthbook/growthbook-react'
import { useEffect, useState } from 'react'

interface FeatureFlagsProviderProps {
  userId?: string
  attributes?: Record<string, unknown>
  children: React.ReactNode
}

/**
 * Wraps children with the GrowthBook context. Mounted in apps/portal/app/layout.tsx.
 * Uses the NEXT_PUBLIC_ client key — this runs in the browser.
 */
export function FeatureFlagsProvider({ userId, attributes, children }: FeatureFlagsProviderProps) {
  const [gb] = useState(() => new GrowthBook({
    apiHost: 'https://cdn.growthbook.io',
    clientKey: process.env.NEXT_PUBLIC_GROWTHBOOK_CLIENT_KEY!,
    enableDevMode: process.env.NODE_ENV !== 'production',
    trackingCallback: (experiment, result) => {
      // Optional: send experiment exposure to your analytics
      console.debug('[GrowthBook]', experiment.key, result.variationId)
    },
  }))

  useEffect(() => {
    // Set user attributes for targeting rules
    gb.setAttributes({ id: userId ?? 'anonymous', ...attributes })
  }, [gb, userId, attributes])

  useEffect(() => {
    // Load features from the GrowthBook CDN
    gb.init({ streaming: true })
  }, [gb])

  return <GrowthBookProvider growthbook={gb}>{children}</GrowthBookProvider>
}
```

```tsx
// apps/portal/app/layout.tsx
import { FeatureFlagsProvider } from './_components/feature-flags-provider'

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <FeatureFlagsProvider>{children}</FeatureFlagsProvider>
      </body>
    </html>
  )
}
```

### Client hooks

```typescript
// apps/portal/app/_components/use-flag.ts
'use client'
import { useFeatureIsOn, useFeatureValue } from '@growthbook/growthbook-react'

/**
 * Returns true if the feature flag is on for the current user.
 * Returns false while features are loading (safe default for gating).
 */
export function useFlag(key: string): boolean {
  return useFeatureIsOn(key)
}

/**
 * Returns the feature flag value, or defaultValue if the flag is off or not found.
 * Use for A/B test variants, configuration values, or multi-variate flags.
 */
export function useFlagValue<T>(key: string, defaultValue: T): T {
  return useFeatureValue(key, defaultValue)
}
```

### Client-side gate

```tsx
// apps/portal/app/_components/checkout-button.tsx
'use client'
import { useFlag } from './use-flag'

/**
 * Renders the new checkout flow if the flag is enabled,
 * falls back to the legacy button otherwise.
 */
export function CheckoutButton() {
  const useNewCheckout = useFlag('new-checkout-flow')
  return useNewCheckout ? <NewCheckoutFlow /> : <LegacyCheckoutButton />
}
```

### A/B test variant (client)

```tsx
// apps/portal/app/_components/hero-section.tsx
'use client'
import { useFlagValue } from './use-flag'

export function HeroSection() {
  // 'control' | 'variant-a' | 'variant-b'
  const variant = useFlagValue<string>('hero-copy-test', 'control')

  const copy = {
    control:     { headline: 'Build faster', cta: 'Get started' },
    'variant-a': { headline: 'Ship in days', cta: 'Try for free' },
    'variant-b': { headline: 'Launch your SaaS today', cta: 'Start building' },
  }[variant] ?? { headline: 'Build faster', cta: 'Get started' }

  return (
    <section>
      <h1 className="text-4xl font-bold">{copy.headline}</h1>
      <a href="/register" className="btn-primary">{copy.cta}</a>
    </section>
  )
}
```

---

## Verify

```bash
pnpm -r type-check
pnpm --filter @app/adapters test
```

---

## Gotchas

**Server SDK stays in the adapter; client SDK stays in the app.**
`@growthbook/growthbook` is imported only in `packages/adapters/src/flags/index.ts`.
`@growthbook/growthbook-react` is imported only under `apps/portal/app`. Crossing this
line (React hooks in an adapter, or the server SDK in an app) breaks the hexagon and
will leak server config into the browser bundle.

**Server evaluation goes through the port — never `new GrowthBook()` in app code.**
Use-cases, server components, and route handlers call `flags.isEnabled(key, userId)`
imported from `@app/adapters`. This keeps the app depending on `FlagsPort`, not on a
vendor SDK.

**Fail closed when unconfigured.**
The adapter returns `false` if `GROWTHBOOK_CLIENT_KEY` is unset. This is deliberate —
an unconfigured environment hides new (flag-gated) features rather than exposing them.

**`await gb.init()` is required before evaluating.**
Skipping it means the GrowthBook instance has no features loaded, and `isOn()` always
returns `false`. This is a silent failure — no error, just wrong results. The adapter's
lazy `getClient()` awaits `init()` exactly once per process.

**The client key (SDK key) is safe to expose — the admin API key is not.**
`NEXT_PUBLIC_GROWTHBOOK_CLIENT_KEY` (client) and `GROWTHBOOK_CLIENT_KEY` (server) are
read-only access to feature definitions. The GrowthBook admin API key (used to
create/modify flags via the API) must stay out of both.

**Feature flags are UX gating — NOT a security control.**
Never use a feature flag as the sole access control for sensitive data or operations.
Auth (`@app/auth` guards) + RLS handle security. Flags handle UX experience. A user who
inspects their request or disables JS can bypass client-side flags.

**`useFeatureIsOn` returns `false` while features are loading — design for this.**
On first render before features resolve, all flags evaluate to false, so new features
are hidden on first paint. This is the correct safe default. Design rollouts where the
fallback (flag=off) is the existing behavior.

**A/B test exposure should be tracked only once per user per experiment.**
Use the `trackingCallback` in the client provider init to send exposure events to your
analytics tool. Calling it on every render would inflate your event counts.

---

## MCP Usage

This skill does not have a dedicated MCP server. GrowthBook flag definitions are
managed in the GrowthBook dashboard (or self-hosted instance). The SDKs fetch flag
values at runtime from the GrowthBook CDN.

---

## Integration With Other Skills

- **nextjs** — client hooks (`useFlag`, `useFlagValue`) live in `"use client"`
  components under `apps/portal/app/_components`. Server-side gating calls the
  `FlagsPort` via `import { flags } from '@app/adapters'` in server components and
  route handlers. The provider wraps `apps/portal/app/layout.tsx`.
- **ai** — gate AI features behind a flag during rollout. Client:
  `const aiEnabled = useFlag('ai-assistant-enabled')`. Server:
  `if (await flags.isEnabled('ai-assistant-enabled', userId)) { ... }`.
- **email** — gate new email types behind a flag during rollout:
  `if (await flags.isEnabled('send-welcome-series', userId)) { ... }`. Useful for
  A/B testing email copy or onboarding sequences.
- **stripe** — feature flags complement subscription gating but do not replace it.
  Check subscription tier for paid feature access; use flags for gradual rollout of
  new paid features to existing subscribers.
