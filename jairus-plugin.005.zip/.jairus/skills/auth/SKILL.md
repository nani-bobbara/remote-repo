---
name: auth
description: >
  Better Auth + DATA-DRIVEN RBAC skill for the jairus monorepo (cloned from jairus-starter).
  Load for ANY work touching sessions, login/signup, route guards, roles, permissions, staff
  management, or the portal↔admin boundary. Covers the `role` catalog table, the pure `can()`
  check, the guards `requireUser` / `requirePermission` / `requireStaff`, the `power_user`
  superadmin, how to add a feature-specific permission, and the two-app access rules. Required by
  designer, developer, and reviewer on any feature with protected routes or new permissions.
  Use this whenever you are about to write `requireStaff`/`requirePermission`, add a permission
  string, gate an admin route, or reason about who can see what — even if the user didn't say "auth".
---

# Auth + Data-Driven RBAC (Better Auth · monorepo · two apps)

The template already ships a complete, working auth + RBAC system. **Feature work extends it —
it does not rebuild it.** Roles are **data**, not a hardcoded enum: each app grows its own roles
and permissions through the admin app as features evolve. Get the model right and the guards
write themselves.

## The model in one screen

- **Session** (`@app/domain` port) carries the resolved permissions, not just the role name:
  ```ts
  interface Session { userId: string; email: string; role: string; permissions: string[] }
  ```
- **Roles are rows** in the `role` catalog table (`@app/adapters` schema), not an enum:
  ```ts
  interface RoleDef { name: string; label: string; description: string | null; permissions: string[]; isSystem: boolean }
  ```
  `permissions` are `'resource:action'` strings; `'*'` (`ALL_PERMISSIONS`) means full control.
- **`power_user`** (`POWER_USER`) is the seeded, **undeletable** superadmin — permissions `['*']`,
  `isSystem: true`. It always passes every check. It is the only role created by `pnpm db:seed`
  alongside **`regular`** (`DEFAULT_PLATFORM_ROLE`) — the portal signup default.
- **`can()` is pure** (in `@app/domain`, zero deps — unit-test it directly):
  ```ts
  can(subject: { permissions: string[] }, permission: string): boolean
  // true if permissions includes '*' OR the exact permission
  ```

## The guards (in `@app/auth`) — the ONLY way to protect a route

`@app/auth` resolves the session from Next.js request headers, looks up the role's permissions in
the catalog, and exposes three guards. Import these — never re-implement session parsing.

```ts
import { requireUser, requirePermission, requireStaff } from '@app/auth'
import { PERMISSIONS } from '@app/domain'

await requireUser()                              // any authenticated user, else UnauthorizedError
await requirePermission(PERMISSIONS.STAFF_WRITE) // that permission, else ForbiddenError
await requireStaff()                             // = requirePermission('admin:access')
```

- `getSession()` is wrapped in React `cache()` — layout + page share one round-trip. Call it
  freely; it does not re-hit the DB per call within a request.
- `requireStaff()` is the **admin-app gate**: it requires the `admin:access` permission. Any staff
  role that grants `admin:access` passes; `power_user` always passes.
- These throw typed domain errors (`UnauthorizedError` / `ForbiddenError`). The app's error
  boundary / route handler maps them to 401/403 (and the admin app renders "Unknown user" for a
  non-staff visitor).

**BLOCKER rule (reviewer enforces):** every admin route/server action MUST call `requireStaff()`
(or a stricter `requirePermission`) as its **first statement**, before any data access. A missing
guard on an admin route exposes every user's data — it is a critical `[BLOCKER]`, never a nit.

## The base permission vocabulary

The template ships (`PERMISSIONS` in `@app/domain`):

| Permission | Meaning |
|---|---|
| `admin:access` | may enter the admin app at all (= `requireStaff`) |
| `roles:read` / `roles:write` | view / manage the role catalog (Role Control screen) |
| `staff:read` / `staff:write` | view / manage staff users (Staff screen) |

`PERMISSION_CATALOG = Object.values(PERMISSIONS)` drives the admin Role Control checkboxes.

## Adding a feature-specific permission (the extend recipe)

Do NOT invent a new role enum or a bespoke guard. Add a permission string and gate with it:

1. Add the constant to `PERMISSIONS` in `@app/domain/src/entities/index.ts`
   (e.g. `REPORTS_EXPORT: 'reports:export'`). It auto-joins `PERMISSION_CATALOG`, so it appears as
   a checkbox on the admin Role Control screen — a `power_user` can grant it to any staff role.
2. Gate the route/action: `await requirePermission(PERMISSIONS.REPORTS_EXPORT)`.
3. That's it — no migration, no role table change. `power_user` already has it (via `'*'`); other
   roles get it when an admin ticks the box. Roles evolve as **data**, at runtime.

## Staff management (privileged path — admin app only)

Staff are created by a `power_user` in the admin **Staff** screen (portal self-signup is open and
always lands on `regular`). Staff mutations use the **privileged** `dbAdminPort` (bypasses RLS)
behind a `staff:write` guard — never the request-scoped client:

```ts
"use server"
import { requirePermission, auth } from '@app/auth'
import { PERMISSIONS } from '@app/domain'
import { dbAdminPort } from '@app/adapters/db'

export async function setUserRole(userId: string, role: string) {
  await requirePermission(PERMISSIONS.STAFF_WRITE)   // guard FIRST
  await dbAdminPort.users.setRole(userId, role)
}
```

## The two-app boundary (enforced at each app's `(app)` layout)

| | Portal (`:3001`) | Admin (`:3002`) |
|---|---|---|
| Signup | open (email + Google) → `regular` | invite-only (no self-signup) |
| Gate | non-staff only — **staff are blocked** | `requireStaff()` — others see "Unknown user" |

A staff account visiting the portal is blocked ("Admin account"); a `regular` account visiting the
admin app is denied ("Unknown user"). This mutual exclusion is deliberate — keep it when extending.

## Env + wiring (already provisioned by Foundation)

- `BETTER_AUTH_SECRET` — a **random** secret (`pnpm gen:secret`), NOT a URL, NOT a Neon Auth endpoint.
- `BETTER_AUTH_URL` — **each app's own origin** (portal `:3001`, admin `:3002`).
- Better Auth handler mounts at `app/api/auth/[...all]/route.ts` via `authHandler` from `@app/auth`.
- The role is surfaced on the session via Better Auth `additionalFields` (`input:false`) — resolved
  to permissions in `getSession()` through `dbPort.roles.getByName(role)`.

## Where things live (do not relocate)

- `@app/domain` — `RoleDef`, `can()`, `PERMISSIONS`, `POWER_USER`, `Session`/`AuthPort` port. Pure.
- `@app/adapters/auth` — the Better Auth instance (`drizzleAdapter` + schema). `@app/adapters/db` — `roles` repo, `users.setRole`.
- `@app/auth` — request-scoped `getSession` + the three guards (lives outside adapters because it needs Next headers).
- `pnpm db:seed` — seeds `power_user` + `regular` and the first superadmin from `ADMIN_EMAIL`/`ADMIN_INITIAL_PASSWORD`.

## Integration

- **architecture** — auth is the reference example of the ports-and-adapters seam (`AuthPort`/`DbPort` in domain, implemented in adapters, guarded in `@app/auth`). Follow the same shape for new domain features.
- **neon** — permission checks decide the data path: user-owned reads go through `withUser` (Layer 1 + RLS Layer 2); staff/cross-user reads go through `dbAdminPort` behind a guard.
- **nextjs** — guards run in server components / server actions / route handlers only; never trust the client.
