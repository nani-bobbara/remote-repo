---
name: vercel
description: >
  Vercel hosting and deployment skill — Git-integrated deployment model (preview per PR,
  production on main merge), environment variables, reading deployment status and logs
  via MCP, and troubleshooting build/runtime failures. Load when deploying, verifying a
  deployment, or debugging a build or runtime error. MCP server: vercel (OAuth).
---

# Vercel (Hosting + Deployments)

Always-on skill (fixed core stack). MCP server: **vercel** — a remote HTTP server
(`https://mcp.vercel.com`) that authenticates via **browser OAuth** on first use.
Authorize once with `claude mcp login vercel` (or `/mcp` in an interactive session).

## When This Skill Is Loaded

When deploying a feature to staging or production, reading deployment status, diagnosing
a build failure, or surfacing runtime errors after a deploy.

---

## Setup

No additional npm packages needed — Vercel is configured via project settings in the
Vercel dashboard, not in code.

Required env vars (set in Vercel project settings, NOT committed to the repo):
```
# Set per scope: Development | Preview | Production
NEXT_PUBLIC_APP_URL=https://yourapp.com      # Production scope
NEXT_PUBLIC_APP_NAME=YourApp

# Backend secrets — set server-side only (no NEXT_PUBLIC_ prefix)
STRIPE_SECRET_KEY=sk_live_...                # Production scope only
STRIPE_WEBHOOK_SECRET=whsec_...
# DATABASE_URL — Neon connection string; Preview points at a per-PR Neon branch
```

---

## Key Patterns

### Deployment model — Git integration, not a deploy API

Vercel's Git integration is the CD pipeline. Do NOT add deployment steps to GitHub
Actions CI or call Vercel's deploy API manually.

```
Feature branch pushed   →  Vercel creates a Preview deployment automatically
PR opened               →  Vercel posts preview URL as a PR comment
PR merged to main       →  Vercel creates a Production deployment automatically
```

This means:
- CI (GitHub Actions) stays checks-only: lint → type-check → test → build
- Never add `vercel deploy` to a workflow file
- Production deploys happen on main merge — the 🚦 Gate 5 approval is merging the PR

### Reading deployment state via MCP

After pushing a feature branch, use the MCP to find the preview URL and verify it
reached READY status before presenting it to the user.

```
Step 1: list_projects         → find the project ID
Step 2: list_deployments      → filter by branch name, find the most recent
Step 3: get_deployment        → check status field
Step 4: (if READY) web_fetch_vercel_url → smoke-test the preview URL
Step 5: (if ERROR) get_deployment_build_logs → surface the failure
```

**Deployment status values:**
- `BUILDING` — in progress, wait and re-check
- `READY` — deployed successfully, URL is live
- `ERROR` — build failed, check build logs
- `CANCELED` — a newer commit superseded this one (not an error)

Never present a `BUILDING` or `ERROR` deployment as "ready for review."

### Diagnosing a build failure

```
1. get_deployment_build_logs (serverId = deployment.id)
   → Look for: TypeScript errors, missing env vars, import errors, out-of-memory
2. If build succeeded but runtime is failing:
   get_runtime_logs (serverId = deployment.id)
   → Look for: 5xx responses, unhandled promise rejections, missing env vars at runtime
```

Common build failures and fixes:

| Error in build logs                          | Fix                                              |
|----------------------------------------------|--------------------------------------------------|
| `Type error: ...`                             | Run `pnpm type-check` locally, fix TS errors  |
| `Module not found: Can't resolve '@/...'`     | Check tsconfig paths and import spelling         |
| `Error: NEXT_PUBLIC_* is not defined`         | Add env var to the Preview/Production scope      |
| `Killed` / out-of-memory                      | Check for infinite loops or huge bundle deps     |

Common runtime errors and fixes:

| Error in runtime logs                        | Fix                                              |
|----------------------------------------------|--------------------------------------------------|
| `STRIPE_SECRET_KEY is not defined`           | Add env var to Production scope in Vercel        |
| `500` on `/api/*`                            | Read runtime logs, check for DB connection issue |
| `401` on all routes                          | Session/cookie misconfiguration for preview URL  |

### Environment variable scopes

Vercel has three scopes — set vars in the right scope:

| Scope         | When it's used                                    |
|---------------|---------------------------------------------------|
| Development   | `vercel dev` (local) — rarely used in this stack |
| Preview       | Every PR preview deployment                       |
| Production    | Production deployment (main branch)               |

`NEXT_PUBLIC_*` vars must be set for every scope where they're used (usually all three).
Backend secrets (DB keys, Stripe live key) should be Production scope only — Preview
scope uses test/staging credentials.

### Preview URL pattern for staging verification

After the deployer agent pushes a branch and waits for READY status:

```typescript
// Pseudocode for the deployer agent's verification step
const deployments = await mcp.listDeployments({ project: projectId, branch: 'feature/checkout' })
const latest = deployments[0]

if (latest.status === 'ERROR') {
  const logs = await mcp.getDeploymentBuildLogs({ serverId: latest.id })
  throw new Error(`Build failed:\n${logs}`)
}

// Poll for READY (max ~5 min)
while (latest.status === 'BUILDING') {
  await sleep(15_000)
  const updated = await mcp.getDeployment({ id: latest.id })
  if (updated.status === 'READY') break
  if (updated.status === 'ERROR') throw new Error('Build failed after polling')
}

const previewUrl = latest.url   // e.g. myapp-git-feature-checkout-team.vercel.app
```

---

## Gotchas

**Vercel MCP requires OAuth — authorize it before the pipeline runs.**
Run `claude mcp login vercel` in a terminal (or `/mcp` in an interactive session) to
authorize the Vercel MCP server. In non-interactive (subagent) contexts, the OAuth flow
cannot run — the deployer agent requires the MCP to be pre-authorized.

**Build logs and runtime logs are separate — check both.**
A deployment can show READY in the dashboard but have runtime errors (e.g. a missing
env var that only manifests when the route is hit). Check runtime logs after verifying
the build succeeded.

**Production deploys are automatic on main merge — don't race the confirmation.**
After merging, the production deploy starts immediately. The 🚦 gate is the merge
decision, not a manual deploy trigger. Let the deploy complete before announcing
the release.

**`NEXT_PUBLIC_APP_URL` must match the actual deployment URL.**
In production it must be the custom domain (`https://yourapp.com`), not the Vercel
auto-generated URL (`myapp.vercel.app`). Stripe webhook URLs, email links, and OAuth
callbacks depend on this being correct.

**Never commit `.vercel/` to the repo.**
It contains local project link state. Add it to `.gitignore`.

---

## MCP Usage

All deployment operations go through the Vercel MCP. Do not use `vercel` CLI in
CI or in subagent scripts — the MCP is the sanctioned interface.

Key tools:
- `list_projects` — find the project ID
- `list_deployments` — filter by branch to find the latest preview
- `get_deployment` — check status (BUILDING / READY / ERROR)
- `get_deployment_build_logs` — diagnose build failures
- `get_runtime_logs` — diagnose runtime errors post-deploy
- `get_project` — read env var names (not values — Vercel never returns secret values)

---

## Integration With Other Skills

- **github** — CI workflow (`ci.yml`) runs checks-only. Never add deploy steps to CI.
  The PR merge to main is the production gate, which triggers Vercel automatically.
- **nextjs** — TypeScript errors in source code show up in Vercel build logs. Run
  `pnpm type-check` locally before pushing to catch them before CI/Vercel.
- **stripe** — In Preview deployments, use Stripe test keys. Production scope uses
  live keys. The Stripe webhook endpoint URL must be registered in the Stripe
  dashboard for both Preview and Production environments.
- **neon** — Preview deployments point `DATABASE_URL` at a per-PR Neon branch (via the
  Neon GitHub integration / create-branch-action); Production uses the Neon main branch.
  The two apps (portal + admin) deploy as separate Vercel projects, each with its own
  `DATABASE_URL` set per scope.
