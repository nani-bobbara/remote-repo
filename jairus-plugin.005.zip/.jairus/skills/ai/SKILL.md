---
name: ai
description: >
  AI / LLM extension skill — Vercel AI SDK with Anthropic Claude (default) or OpenAI,
  streaming chat API routes, client-side useChat hook, tool use, rate limiting, and error
  handling. Load when INTENT.md extensions includes "ai" OR when implementing any feature
  that calls an LLM, streams text, or uses tool use / structured generation. Always
  loaded alongside the nextjs skill.
---

# AI / LLM Extension (Vercel AI SDK + Anthropic Claude)

Active when `INTENT.md` has `"ai"` in extensions. Default model provider: **Anthropic Claude**.

> When this extension is enabled, install the **official Anthropic agent skill** into the project's
> `.claude/skills/` for authoritative Claude-API detail (models, params, tool use, streaming):
> `npx skills add anthropics/skills --skill <claude-api-skill>` (resolve the exact skill name via
> `npx skills find anthropic`). This skill stays the opinionated Vercel-AI-SDK integration layer.

## When This Skill Is Loaded

When any feature involves generating, summarizing, classifying, or transforming text via
an LLM; streaming responses to the UI; or structured tool use / function calling.

---

## Where the code lives (hexagonal)

This is a **pnpm + turbo hexagonal monorepo** cloned from `jairus-starter`. The AI
integration is a **domain port with a vendor adapter** — the layer rule is absolute:

| Layer | Package | AI responsibility |
|-------|---------|-------------------|
| Domain | `@app/domain` | Owns the port: `AiPort { generate(prompt: string): Promise<string> }`. Zero deps. |
| Application | `@app/application` | Use-cases call the `ai` singleton; never import the SDK. |
| Adapters | `@app/adapters` | **The ONLY place the vendor SDK (`ai`, `@ai-sdk/anthropic`) may be imported.** Implements `AiPort` behind the port; may export extra helpers (e.g. `aiStream`). |
| Apps | `apps/portal` (:3001), `apps/admin` (:3002) | Route handlers call `requireUser()` from `@app/auth`, validate input, and call the exported adapter functions. Client components may use `ai/react` (a client helper). |

**The hard rule:** `ai` and `@ai-sdk/anthropic` may be imported **only inside
`packages/adapters/`**. Never in an app, never in `@app/ui`, never in any `src/lib/*`
tree (there is no `src/` — this is a monorepo). Consumers import the `ai` singleton
from `@app/adapters` and call `ai.generate(...)`; they never touch the SDK.

**Onboarding = replace the stub.** A stub adapter already exists at
`packages/adapters/src/ai/index.ts`:

```typescript
// packages/adapters/src/ai/index.ts (STUB — as cloned)
import type { AiPort } from '@app/domain'

export const ai: AiPort = {
  async generate() {
    throw new Error('ai adapter not enabled')
  },
}
```

Enabling the AI extension means **replacing that stub with a real implementation
behind the same port** — the contract seen by the rest of the app never changes.

---

## Setup

```bash
# For Anthropic Claude (default) — SDK belongs to the adapters package ONLY
pnpm --filter @app/adapters add ai @ai-sdk/anthropic

# For OpenAI (alternative — only if INTENT.md specifies openai)
pnpm --filter @app/adapters add ai @ai-sdk/openai

# Client-only React binding for useChat — installed into the app that renders chat
pnpm --filter portal add ai
```

Required env vars go in the **root `.env.example`** (server-side only — no
`NEXT_PUBLIC_` prefix):
```
ANTHROPIC_API_KEY=sk-ant-api03-...    # Anthropic — never expose to browser
# OR
OPENAI_API_KEY=sk-...                  # OpenAI — never expose to browser
```

The adapter reads `process.env.ANTHROPIC_API_KEY` with **lazy client construction**
so the build is safe even without a key present.

---

## Key Patterns

### The adapter: implement `AiPort` + export a stream helper (SDK lives HERE only)

```typescript
// packages/adapters/src/ai/index.ts
// The ONLY module allowed to import the vendor AI SDK.
import { createAnthropic } from '@ai-sdk/anthropic'
import { streamText, generateText, type CoreMessage } from 'ai'
import type { AiPort } from '@app/domain'

// Lazy client construction — build-safe without a key at import time.
function client() {
  const apiKey = process.env.ANTHROPIC_API_KEY
  if (!apiKey) throw new Error('ANTHROPIC_API_KEY is not set')
  return createAnthropic({ apiKey })
}

/**
 * The domain port implementation. This is the singleton the rest of the app
 * imports as `ai` — consumers only ever see `generate(prompt)`.
 */
export const ai: AiPort = {
  async generate(prompt: string): Promise<string> {
    const { text } = await generateText({
      model: client()('claude-haiku-4-5-20251001'), // cheap for simple tasks
      prompt,
      maxTokens: 512,
    })
    return text
  },
}

/**
 * Extra adapter helper for STREAMING chat. Still lives inside the adapter so the
 * SDK never leaks out. App routes call this and return the result directly.
 * Returns a Response with the Vercel AI SDK `data:` stream format.
 */
export function aiStream(messages: CoreMessage[]): Response {
  // Truncate to last N messages to control costs.
  const recentMessages = messages.slice(-20)

  const result = streamText({
    model: client()('claude-sonnet-4-5'),
    system: 'You are a helpful assistant.',
    messages: recentMessages,
    maxTokens: 2048,
  })

  // ⚠️ Return toDataStreamResponse() — NOT NextResponse.json()
  return result.toDataStreamResponse()
}
```

### Streaming chat API route (app calls the adapter — no SDK import)

```typescript
// apps/portal/app/api/ai/chat/route.ts
import { NextRequest } from 'next/server'
import { requireUser } from '@app/auth'
import { aiStream } from '@app/adapters'
import { checkRateLimit } from '@app/adapters' // or wherever the rate limiter is exported

export async function POST(request: NextRequest) {
  // Auth is required — AI calls are expensive.
  const user = await requireUser(request)
  if (!user) {
    return new Response(
      JSON.stringify({ error: 'Authentication required', code: 'UNAUTHORIZED' }),
      { status: 401, headers: { 'Content-Type': 'application/json' } }
    )
  }

  // Per-user rate limiting — prevents runaway costs.
  const allowed = await checkRateLimit(user.id)
  if (!allowed) {
    return new Response(
      JSON.stringify({ error: 'Rate limit exceeded. Please try again later.', code: 'RATE_LIMITED' }),
      { status: 429, headers: { 'Content-Type': 'application/json' } }
    )
  }

  const { messages } = await request.json()

  try {
    // The adapter owns the SDK; the route just validates + delegates.
    return aiStream(messages)
  } catch (error) {
    console.error('[POST /api/ai/chat]', error)
    // Never expose the raw error — it can contain model names, token counts, etc.
    return new Response(
      JSON.stringify({ error: 'AI service unavailable', code: 'AI_ERROR' }),
      { status: 503, headers: { 'Content-Type': 'application/json' } }
    )
  }
}
```

### Client-side chat component (`ai/react` is a client helper — allowed in the app)

```typescript
// apps/portal/app/(features)/ai-chat/ChatInterface.tsx
'use client'
import { useChat } from 'ai/react'

/**
 * Streaming chat UI connected to /api/ai/chat.
 * useChat is a client-only binding — it is NOT the vendor server SDK, so it is
 * allowed here in the app. It only speaks HTTP to the route above.
 */
export function ChatInterface() {
  const { messages, input, handleInputChange, handleSubmit, isLoading, error } = useChat({
    api: '/api/ai/chat',
    onError: (err) => {
      // useChat surfaces errors from the API route
      console.error('Chat error:', err.message)
    },
  })

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto space-y-4 p-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={message.role === 'user' ? 'text-right' : 'text-left'}
          >
            <span className="inline-block rounded-lg px-4 py-2 max-w-prose bg-muted">
              {message.content}
            </span>
          </div>
        ))}
        {isLoading && (
          <div className="text-muted-foreground text-sm">Thinking…</div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="border-t p-4 flex gap-2">
        <input
          value={input}
          onChange={handleInputChange}
          placeholder="Ask something…"
          disabled={isLoading}
          className="flex-1 rounded-md border px-3 py-2 text-sm"
          aria-label="Chat message input"
        />
        <button
          type="submit"
          disabled={isLoading || !input.trim()}
          className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground disabled:opacity-50"
        >
          Send
        </button>
      </form>
    </div>
  )
}
```

### Non-streaming: single completion (use-case calls the port)

The vendor call already lives in the adapter's `ai.generate` (above). Application
use-cases and server code consume it through the port — they never import the SDK:

```typescript
// packages/application/src/summarize-note.ts
import { ai } from '@app/adapters'

/**
 * A use-case that summarizes text. It depends only on the AiPort surface
 * (`ai.generate`) — swapping providers means editing the adapter, not this file.
 */
export async function summarizeNote(body: string): Promise<string> {
  return ai.generate(`Summarize the following note in one sentence:\n\n${body}`)
}
```

### Tool use (structured AI operations — SDK stays in the adapter)

Tool use requires the SDK, so it lives in the adapter as another exported helper.
Pass server-side dependencies (like a scoped repo or the userId) in as arguments so
the adapter stays free of app/DB imports:

```typescript
// packages/adapters/src/ai/agent.ts
import { streamText, tool } from 'ai'
import { z } from 'zod'
import { createAnthropic } from '@ai-sdk/anthropic'

function client() {
  const apiKey = process.env.ANTHROPIC_API_KEY
  if (!apiKey) throw new Error('ANTHROPIC_API_KEY is not set')
  return createAnthropic({ apiKey })
}

/**
 * Agentic tool-use stream. The caller injects a scoped search function so the
 * adapter never imports the app's DB directly.
 */
export function aiAgentStream(
  messages: Parameters<typeof streamText>[0]['messages'],
  deps: { searchItems: (query: string) => Promise<unknown[]> },
): Response {
  const result = streamText({
    model: client()('claude-sonnet-4-5'),
    messages,
    tools: {
      searchItems: tool({
        description: "Search the user's items by keyword",
        parameters: z.object({
          query: z.string().describe('Search query'),
        }),
        execute: async ({ query }) => {
          // Runs on the server — delegated to the injected, already-scoped fn.
          const items = await deps.searchItems(query)
          return { items }
        },
      }),
    },
    maxSteps: 5, // allow up to 5 tool call rounds
  })

  return result.toDataStreamResponse()
}
```

```typescript
// apps/portal/app/api/ai/agent/route.ts
import { NextRequest } from 'next/server'
import { requireUser } from '@app/auth'
import { aiAgentStream } from '@app/adapters'
import { searchUserItems } from '@app/adapters' // scoped repo helper from the DB adapter

export async function POST(request: NextRequest) {
  const user = await requireUser(request)
  if (!user) {
    return new Response(JSON.stringify({ error: 'Unauthorized', code: 'UNAUTHORIZED' }), { status: 401 })
  }

  const { messages } = await request.json()

  // Inject a search fn already scoped to the authenticated user.
  return aiAgentStream(messages, {
    searchItems: (query) => searchUserItems(user.id, query),
  })
}
```

### Rate limiting per user (an adapter concern — export it from adapters)

```typescript
// packages/adapters/src/ai/rate-limit.ts
// Simple in-memory rate limiter for AI calls — swap for Redis in production.

const REQUESTS_PER_HOUR = 50

// In production: use Upstash Redis or similar persistent store.
const callCounts = new Map<string, { count: number; resetAt: number }>()

/**
 * Returns true if the user is within their AI rate limit.
 */
export function checkRateLimit(userId: string): boolean {
  const now = Date.now()
  const state = callCounts.get(userId)

  if (!state || state.resetAt < now) {
    callCounts.set(userId, { count: 1, resetAt: now + 3_600_000 })
    return true
  }

  if (state.count >= REQUESTS_PER_HOUR) return false

  state.count += 1
  return true
}
```

### Model selection guide

| Use case                                   | Model                                    | Notes                        |
|--------------------------------------------|------------------------------------------|------------------------------|
| Chat, summarization, most tasks            | `claude-sonnet-4-5`                      | Best cost/quality balance    |
| Simple classification, short extraction   | `claude-haiku-4-5-20251001`              | Fastest, cheapest            |
| Complex reasoning, multi-step agents      | `claude-opus-4-8`                        | Most capable, most expensive |
| OpenAI alternative                        | `openai('gpt-4o')` via `@ai-sdk/openai` | Only if INTENT.md specifies  |

All model strings are referenced **inside the adapter** (`packages/adapters/src/ai/`).
Changing a model never touches an app or a use-case.

---

## Verify

```bash
# Type-check the whole workspace
pnpm -r type-check

# Run the adapter's tests (the port implementation lives here)
pnpm --filter @app/adapters test
```

---

## Gotchas

**The vendor SDK may ONLY be imported inside `packages/adapters/`.**
`ai` (`streamText`/`generateText`/`tool`) and `@ai-sdk/anthropic` must never appear
in an app, in `@app/ui`, or in a use-case. Apps and use-cases import the `ai`
singleton (or an exported helper like `aiStream`) from `@app/adapters`. Note the one
exception: `ai/react` (`useChat`) is a **client-only binding**, not the server SDK,
and is allowed in app client components.

**API keys must NEVER be exposed client-side.**
`NEXT_PUBLIC_ANTHROPIC_API_KEY` or `NEXT_PUBLIC_OPENAI_API_KEY` would ship the key
to every browser. Keep them server-side only (no `NEXT_PUBLIC_` prefix), in the
root `.env.example`, and read them with lazy client construction in the adapter.

**Streaming responses MUST use `result.toDataStreamResponse()`.**
Returning `NextResponse.json(result)` on a streamed result will fail — the stream
is not JSON-serializable. `toDataStreamResponse()` sets the correct
`Content-Type: text/event-stream` header and pipes the stream. Do this inside the
adapter helper and return it straight through the route.

**Always truncate the conversation history before sending.**
A long conversation grows unboundedly. Slice to the last 15–20 messages (done inside
the adapter helper). Monitor token usage in production; set `maxTokens` on every call.

**Rate-limit AI routes per user — they are expensive.**
A user hammering the chat endpoint can run up hundreds of dollars in API costs.
In-memory rate limiting works for a single server instance; use a persistent store
(Upstash Redis) in production behind Vercel Edge functions.

**Never pass the raw `error` from the AI SDK to the client.**
It can contain model names, token counts, API key fragments in debug info. Return
`{ error: 'AI service unavailable', code: 'AI_ERROR' }`.

**`useChat` requires the API route to return the Vercel AI SDK stream format.**
The hook expects the `data:` SSE format from `toDataStreamResponse()`. Returning
a raw streaming response will break `useChat` message parsing.

---

## MCP Usage

This skill does not have a dedicated MCP server. The Anthropic / OpenAI APIs are
called directly from inside the `@app/adapters` package via the Vercel AI SDK.

---

## Integration With Other Skills

- **nextjs** — AI API routes live at `apps/portal/app/api/ai/` (and `apps/admin/...`
  if admin needs them). They follow the same auth pattern (`requireUser()` from
  `@app/auth` first), error shape (`{ error, code }`), and test pattern (integration
  tests for 401, rate limit, happy path). Streaming routes return the adapter's
  `toDataStreamResponse()` result instead of `NextResponse.json()`. The route never
  imports the vendor SDK — it calls the `@app/adapters` helper.
- **neon** — AI tools (in tool-use patterns) query the user's data via the Drizzle
  scoped repos exported from `@app/adapters`. Inject the already-scoped query fn into
  the adapter's tool-use helper; scope every query to the authenticated `userId`.
- **feature-flags** — use a feature flag to gate AI feature access during rollout:
  `useFeatureFlag('ai-chat-enabled')`. This lets you enable AI features for a subset
  of users before full launch.
