---
name: theming
description: >
  Establish and enforce ONE shadcn theme (CSS-variable design tokens) across both apps
  (portal + admin) using a tweakcn preset. Load at Foundation when setting up the theme, and
  whenever a component's colors/spacing are chosen or reviewed. Opinionated: all UI uses shadcn
  theme tokens — no hardcoded colors/hex. Defers component mechanics to the official `shadcn` skill.
---

# Theming (one shadcn theme · tweakcn tokens · both apps)

The project has **one theme**, established once at Foundation and shared by `apps/portal` and
`apps/admin`. It is a set of **shadcn design tokens** (CSS variables in `globals.css`), not a
component library — components come from **shadcn** (see the official `shadcn` skill); this skill
owns the *tokens* and the *no-hardcoded-colors* rule.

> **tweakcn is a source of tokens, not a dependency.** [tweakcn](https://tweakcn.com) is a
> community theme editor for shadcn (Apache-2.0). We consume its exported **CSS variables as
> data** — pasted into `globals.css`. Nothing from tweakcn is installed or imported at runtime.

## The two ways to get the theme (pick one at Foundation)

1. **Curated default** — apply a sensible tweakcn preset (neutral base + one brand accent). Fast,
   safe, WCAG-checked. This is the lean default; recommend it unless the user wants to design one.
2. **Bring your own** — the user designs at tweakcn.com, exports the CSS variables, and jairus
   pastes them into `globals.css`. Use this when there's an existing brand.

Either way the output is the same shape: `:root { --background … --primary … }` +
`.dark { … }` blocks of HSL/oKLCH tokens, plus the matching `@theme`/`tailwind.config` wiring
that shadcn's `init` already generates.

## Where it lives

```
packages/ui/src/styles.css        ← the shared token block (:root + .dark) — the single source of truth
apps/portal/app/globals.css       ← imports the shared tokens
apps/admin/app/globals.css        ← imports the SAME base tokens; admin MAY override --primary / --accent
                                     for a distinct console accent (keep --background/foreground shared)
```

Both apps run `npx shadcn@latest init` once (sets up `globals.css`, `cn()`, `components.json`),
then the chosen token block replaces the default `:root`/`.dark` variables. Keep the two apps'
token blocks in sync except for the deliberate admin accent.

## The one rule: tokens only, never hardcoded color

Every component uses **semantic token classes**, never a hex or arbitrary color:

| Use | Not |
|---|---|
| `bg-background` `text-foreground` | `bg-white` `text-[#111]` |
| `bg-primary` `text-primary-foreground` | `bg-[#6366f1]` |
| `bg-muted` `text-muted-foreground` | `text-gray-500` |
| `border` `bg-card` `bg-destructive` | `border-[#e5e7eb]` |

Non-color utilities (spacing, radius via `rounded-lg` → `--radius`, typography) follow the same
discipline — no arbitrary `p-[13px]`, `text-[15px]`. A hardcoded hex/color in a component is a
**quality finding** in code review (`rules/quality-gate.md`), not a blocker.

## Integration

- **shadcn** (official skill in `.claude/skills/`) — component mechanics; this skill only sets
  the tokens those components read.
- **nextjs** — the "UI = shadcn + theme tokens" section points here for the token discipline.
- **design workflow** — the theme IS the design-token step: `docs/design.md` records the chosen
  preset + token names, and `rules/design-workflow.md` / `templates/design.md` reference these
  tokens (never raw values). The reviewer enforces token-only styling in the Design-system and
  Standards dimensions.
