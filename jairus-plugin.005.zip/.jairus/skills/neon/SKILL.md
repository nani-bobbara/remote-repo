---
name: neon
description: >
  Neon Postgres backend skill for the jairus monorepo — Drizzle ORM + Better Auth + Row Level
  Security over a single Neon DATABASE_URL, shared by the portal and admin apps. Load for any DB,
  auth, migration, or schema work. Covers the monorepo adapters/auth/domain/application packages, Neon branching for
  previews (neonctl + Neon GitHub integration), the two-layer security model, and CI-deployed
  migrations. Required by designer, developer, reviewer, and deployer. For deep Neon platform
  detail, defer to the official `neon-postgres` agent skill installed at foundation.
---

# Neon Backend (monorepo · Drizzle + Better Auth + RLS)

The backend is **Neon serverless Postgres**, accessed as standard Postgres via one `DATABASE_URL`
and **shared by both apps** (portal + admin) through the monorepo's `packages/adapters`. Drizzle is the
ORM + migration tool; Better Auth is the auth library; security is two-layer (app-scoping + RLS).

> **Platform detail lives in the official skill.** Neon-specific mechanics (connection methods,
> autoscaling, read replicas, `neonctl`, the SDK/REST API) come from the vendor-maintained
> **`neon-postgres`** skill installed into `.claude/skills/` at foundation. This skill is the
> jairus *opinionated* layer: the monorepo layout, the security model, and how migrations deploy.

## Where the DB lives in the monorepo

```
packages/
  domain/      ← @app/domain      — entities, value-objects, PORTS + data-driven RBAC (RoleDef, can(), PERMISSIONS)
  application/ ← @app/application  — use-cases orchestrating ports
  adapters/    ← @app/adapters     — Drizzle schema (src/db/schema.ts) + client (src/db/index.ts) + repos + migrations (drizzle/)
  auth/        ← @app/auth         — request-scoped session + guards: portal (email+Google) · admin (staff, no signup, seed)
apps/
  portal/ ← imports @app/adapters, @app/auth   (read-heavy → Neon read replica, scoped role)
  admin/  ← imports @app/adapters, @app/auth   (write-heavy → Neon primary, privileged role)
```

**One schema, one migration history** (owned by `packages/adapters`), consumed by both apps. Neither app
migrates on its own. Each app supplies its own `DATABASE_URL` (portal → replica, admin → primary).

## Setup

These deps already ship in the template (Foundation clones `jairus-starter`); if you need to add
one, target `packages/adapters`:

```bash
pnpm --filter @app/adapters add drizzle-orm postgres better-auth
pnpm --filter @app/adapters add -D drizzle-kit
```

Env (the only binding is the Neon `DATABASE_URL`):
```
DATABASE_URL=postgres://user:pass@ep-xxx-pooler.<region>.aws.neon.tech/db?sslmode=require  # POOLED
DATABASE_URL_ADMIN=postgres://owner:pass@ep-xxx.<region>.aws.neon.tech/db                   # primary/owner: migrations + system ops
BETTER_AUTH_SECRET=<32+ random chars>   # signs sessions — server-only
BETTER_AUTH_URL=<per app's own origin>  # portal → http://localhost:3001 · admin → http://localhost:3002
```

Neon branching (previews): CI creates a Neon **branch** per PR via the Neon GitHub integration +
`create-branch-action`; the preview deployment points `DATABASE_URL` at that branch (see the CI
workflow). Locally, `npx neonctl@latest branches create` for an isolated dev branch.

## Drizzle — schema, client, migrations (in `packages/adapters`)

```typescript
// packages/adapters/drizzle.config.ts
import { defineConfig } from 'drizzle-kit'
export default defineConfig({
  schema: './src/db/schema.ts', out: './drizzle', dialect: 'postgresql',
  dbCredentials: { url: process.env.DATABASE_URL! },
})
```

```typescript
// packages/adapters/src/db/index.ts — the shared client both apps import
import { drizzle } from 'drizzle-orm/postgres-js'
import postgres from 'postgres'
import * as schema from './schema'
export const db = drizzle(postgres(process.env.DATABASE_URL!, { prepare: false }), { schema })
```

```typescript
// packages/adapters/src/db/schema.ts — the single source of truth (drives migrations AND both apps' types)
import { pgTable, uuid, text, timestamp } from 'drizzle-orm/pg-core'
import { user } from './auth-schema'   // emitted by Better Auth (user/session/account/verification)

export const items = pgTable('items', {
  id:        uuid('id').defaultRandom().primaryKey(),
  userId:    text('user_id').notNull().references(() => user.id, { onDelete: 'cascade' }),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull().$onUpdate(() => new Date()),
})
export type Item = typeof items.$inferSelect
```

**Migrations deploy via CI, never from a laptop:** run `pnpm db:generate` locally (filters
`@app/adapters`, commit the SQL — raw `npx drizzle-kit generate` writes to
`packages/adapters/drizzle/`); CI applies `pnpm db:migrate` (`drizzle-kit migrate`) on merge to main
against `DATABASE_URL_ADMIN`; per-PR previews migrate against the Neon branch. Seed via `pnpm db:seed`.
Append-only. 🚦 Gate 4 approves schema before merge.

## Auth — Better Auth + data-driven RBAC (in `packages/auth`)

`packages/auth` exports two configured instances (both over the shared Neon DB):

- **portal auth** — `emailAndPassword` + Google (`socialProviders.google`); **open signup**;
  new users get the seeded `regular` role (portal default).
- **admin auth** — `admin` plugin; **self-signup disabled**; a **seeded admin** account with
  `mustResetPassword` (forced reset on first login). New admins added only by an existing admin.

**Roles are DATA, not a hardcoded enum.** A `role` table (`name`, `permissions text[]`) drives access.
`power_user` is the seeded, undeletable superadmin (`permissions ['*']`); `regular` is the portal
default. `PERMISSIONS` are `'resource:action'` strings; `can(session, permission)` resolves the
session's role from the `role` table (a `*` entry grants everything).

```typescript
// packages/auth/src/session.ts
export async function requireUser()       { /* Better Auth getSession → { userId, email } | null */ }
export async function requirePermission(p) { /* requireUser + can(session, p), else 403 */ }
export async function requireStaff()      { /* = requirePermission('admin:access'): requireUser + can(session, 'admin:access'), resolved from the role table; else 403 / "Unknown user" */ }
```

Admin seeding runs at foundation: create `ADMIN_EMAIL` with a generated/`ADMIN_INITIAL_PASSWORD`
(never committed) and `mustResetPassword: true`, granted the `power_user` role. Admin signup routes
are absent by design.

## Security — TWO layers (composable via withUser)

Every user-data query runs through `withUser()` (Layer 1 filter + sets `app.user_id` for Layer-2
RLS). System/admin cross-user work uses the privileged `dbAdmin` path.

```typescript
// packages/adapters/src/db/ — scoped repos (repos live alongside the db index)
import { sql } from 'drizzle-orm'; import { db } from './index'
export function withUser<T>(userId: string, cb: (tx: typeof db) => Promise<T>): Promise<T> {
  return db.transaction(async (tx) => {
    await tx.execute(sql`select set_config('app.user_id', ${userId}, true)`)
    return cb(tx as unknown as typeof db)
  })
}
```

**Layer 1 (MANDATORY):** scoped repos filter by `userId` inside `withUser`. A user-table query
with no `userId` predicate, or one bypassing `withUser`, is a **BLOCKER**.
**Layer 2 (defense-in-depth):** RLS `ENABLE` + `FORCE` + policy `USING (user_id =
current_setting('app.user_id', true))` — fail-closed (NULL when unset → zero rows).
**System/admin path (`dbAdmin`, `DATABASE_URL_ADMIN`):** the privileged connection for the Stripe
webhook, migrations, and the **admin app's cross-user reads** — bypasses RLS, so it MUST be gated:
admin routes require `requireStaff()`; the webhook requires signature verification. A missing
`requireStaff()` on an admin route is a **critical BLOCKER** (it exposes every user's data).

## API route — auth + scoped query

```typescript
// apps/portal/app/api/items/route.ts
import { requireUser } from '@app/auth'; import { listItems } from '@app/adapters'
export async function GET() {
  const s = await requireUser()
  if (!s) return Response.json({ error: 'Authentication required', code: 'UNAUTHORIZED' }, { status: 401 })
  return Response.json({ items: await listItems(s.userId) })
}
// apps/admin routes call requireStaff() and read cross-user via dbAdmin — never withUser.
```

## Gotchas

- **App-scoping is the guarantee; RLS composes via `withUser`.** Never bypass `withUser` for user data.
- **Admin = privileged cross-user path.** Every admin route MUST `requireStaff()`; never expose the admin app publicly (separate deploy / private network).
- **Pooled `DATABASE_URL` + `prepare:false`** on serverless; migrations/admin use `DATABASE_URL_ADMIN` (primary/owner).
- **Never expose `DATABASE_URL*` / `BETTER_AUTH_SECRET`** to the client (no `NEXT_PUBLIC_`).
- **Migrations are append-only**, owned by `packages/adapters`, deployed by CI.

## Integration

- **nextjs / shadcn** — apps import `@app/adapters`/`@app/auth`; UI uses shadcn components + the theme tokens.
- **stripe** — webhook uses `dbAdmin` (system, un-scoped), signature-verified.
- **github / vercel** — CI runs `pnpm db:migrate` (`drizzle-kit migrate`); Neon GitHub integration provisions branch creds; each app deploys separately with its own `DATABASE_URL` and its own `BETTER_AUTH_URL` origin (portal :3001, admin :3002).
- **official `neon-postgres` skill** — the authoritative reference for Neon platform mechanics; this skill defers to it.
