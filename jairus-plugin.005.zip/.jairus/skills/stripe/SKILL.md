---
name: stripe
description: >
  Stripe payments skill — products/prices, Checkout, subscription lifecycle, webhook
  handler with signature verification, idempotency, test vs live mode. Load whenever
  a feature involves billing, payments, subscription management, or the Stripe webhook.
  Always loaded alongside the nextjs skill. MCP server: stripe.
---

# Stripe (Payments + Billing)

Always-on skill (fixed core stack). MCP server: **stripe**.

## When This Skill Is Loaded

For any feature that involves billing, subscriptions, upgrading/downgrading plans,
payment method management, invoices, or the Stripe webhook handler.

---

## Where the code lives (hexagonal)

This is a pnpm + turbo **hexagonal** monorepo. Billing follows the ports-and-adapters
contract — the app never touches the Stripe server SDK directly.

- **`@app/domain`** — defines the port. `BillingPort` already exists:
  ```typescript
  // packages/domain/src/ports/billing.ts (already present)
  export interface BillingPort {
    createCheckout(userId: string, tier: 'basic' | 'pro'): Promise<{ url: string }>
    parseWebhook(payload: string, signature: string): Promise<{ type: string; data: unknown }>
  }
  ```
- **`@app/adapters`** — the ONLY place the `stripe` server SDK may be imported. A working
  adapter already exists at `packages/adapters/src/billing/index.ts` exporting
  `export const billing: BillingPort = {...}`. It lazily constructs the Stripe client from
  `process.env.STRIPE_SECRET_KEY`, resolves prices from `STRIPE_PRICE_BASIC` /
  `STRIPE_PRICE_PRO`, and builds redirect URLs from `BETTER_AUTH_URL`.
- **`@app/auth`** — guards. Server code calls `requireUser()` before starting checkout.
- **Apps** — `apps/portal` (`:3001`, **owns billing**) and `apps/admin` (`:3002`).
  Apps use `apps/portal/app/...` — there is **NO `src/` directory anywhere** (no
  `apps/portal/src/app`, no `src/lib`).

**The hard rule:** the `stripe` server SDK may **only** be imported inside
`packages/adapters/`. Consumers import `billing` from `@app/adapters` and call
`billing.createCheckout(...)` / `billing.parseWebhook(...)`. They never `import Stripe from 'stripe'`.

**The one exception:** the client-side `@stripe/stripe-js` (publishable-key browser redirect
helper) is a browser package, not the server SDK — it may live in the app
(`pnpm --filter portal add @stripe/stripe-js`). It never sees `STRIPE_SECRET_KEY`.

---

## Setup

The Stripe server SDK is already a dependency of `@app/adapters`. If you need to (re)add it:

```bash
pnpm --filter @app/adapters add stripe        # server SDK — adapters package ONLY
```

If a feature uses the client-side redirect helper (publishable key, browser):

```bash
pnpm --filter portal add @stripe/stripe-js     # browser helper — app is allowed
```

Required env vars (root `.env.example` — already present):
```
STRIPE_SECRET_KEY=sk_test_...              # test key in dev/staging, sk_live_... in prod
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...            # from Stripe dashboard or `stripe listen`
STRIPE_PRICE_BASIC=price_...               # basic tier price id
STRIPE_PRICE_PRO=price_...                 # pro tier price id
```

Plan tiers are `free` / `basic` / `pro`. `free` has no Stripe price; paid tiers map to
`STRIPE_PRICE_BASIC` and `STRIPE_PRICE_PRO`.

**Test vs live mode:**
- `sk_test_*` and `pk_test_*` in development and staging — always.
- `sk_live_*` and `pk_live_*` in production — creating or modifying live-mode objects
  is a 🚦 Gate 5 human approval step. Never create live products/prices in code without
  explicit approval.

---

## Key Patterns

### The adapter (server Stripe — the only place the SDK lives)

All server Stripe usage — checkout session creation, webhook signature verification +
event parsing, subscription lifecycle, customer create — lives behind `BillingPort` in
`packages/adapters/src/billing/index.ts`. You **extend this adapter**; you do not create a
`src/lib/stripe/client.ts`.

```typescript
// packages/adapters/src/billing/index.ts (already present — extend it here)
import Stripe from 'stripe'
import type { BillingPort } from '@app/domain'

// Lazy singleton — avoids creating multiple instances in Next.js dev (hot reload)
let _stripe: Stripe | null = null
function stripe(): Stripe {
  if (!_stripe) {
    _stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
      apiVersion: '2024-12-18.acacia',
      typescript: true,
    })
  }
  return _stripe
}

const PRICE_BY_TIER = {
  basic: () => process.env.STRIPE_PRICE_BASIC!,
  pro: () => process.env.STRIPE_PRICE_PRO!,
} as const

export const billing: BillingPort = {
  async createCheckout(userId, tier) {
    const priceId = PRICE_BY_TIER[tier]()
    const baseUrl = process.env.BETTER_AUTH_URL! // portal origin (:3001 in dev)

    const customerId = await getOrCreateCustomer(userId)

    const checkout = await stripe().checkout.sessions.create({
      customer: customerId,
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${baseUrl}/billing/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${baseUrl}/billing`,
      subscription_data: { metadata: { userId } },
    })

    if (!checkout.url) throw new Error('Stripe did not return a checkout URL')
    return { url: checkout.url }
  },

  async parseWebhook(payload, signature) {
    // Signature verification lives HERE — never in the route, never skipped
    const event = stripe().webhooks.constructEvent(
      payload,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    )
    return { type: event.type, data: event.data.object }
  },
}

/**
 * Create or retrieve a Stripe customer for a user.
 * Always check the DB first to avoid creating duplicate customers.
 */
async function getOrCreateCustomer(userId: string): Promise<string> {
  const existing = await lookupStripeCustomerId(userId) // via dbAdminPort
  if (existing) return existing

  const customer = await stripe().customers.create({ metadata: { userId } })
  await saveStripeCustomerId(userId, customer.id) // via dbAdminPort
  return customer.id
}
```

Note: `Stripe.*` types (`Stripe.Subscription`, `Stripe.Event`) only appear inside
`packages/adapters/`. The port surface (`{ type, data }`) is SDK-agnostic so consumers
never depend on the Stripe SDK.

### Webhook route (portal owns billing)

The webhook has **no user session** — Stripe calls it, not the user. It reads the raw body
and signature, hands them to `billing.parseWebhook(...)` from `@app/adapters` (which verifies
the signature), then writes subscription state through the privileged `dbAdminPort` from
`@app/adapters/db` (the system path — bypasses RLS because it runs as system, not as a user).

```typescript
// apps/portal/app/api/stripe/webhook/route.ts  (NO src/ — portal owns billing)
import { headers } from 'next/headers'
import { NextResponse } from 'next/server'
import { billing } from '@app/adapters'
import { dbAdminPort } from '@app/adapters/db'

// This route is EXEMPT from the normal auth guard (Stripe calls it, not the user).
// It is authenticated by the Stripe signature instead.
export async function POST(request: Request) {
  const body = await request.text() // raw body — required for signature verification
  const signature = headers().get('stripe-signature')

  if (!signature) {
    return NextResponse.json(
      { error: 'Missing stripe-signature header', code: 'INVALID_REQUEST' },
      { status: 400 }
    )
  }

  let event: { type: string; data: unknown }
  try {
    // Signature verification happens inside the adapter
    event = await billing.parseWebhook(body, signature)
  } catch (err) {
    console.error('[stripe/webhook] Signature verification failed:', err)
    return NextResponse.json(
      { error: 'Invalid webhook signature', code: 'INVALID_SIGNATURE' },
      { status: 400 }
    )
  }

  // Idempotency: skip events already processed (system path)
  const eventId = (event.data as { id?: string })?.id ?? ''
  if (await dbAdminPort.wasWebhookProcessed(eventId)) {
    return NextResponse.json({ received: true })
  }

  try {
    switch (event.type) {
      case 'customer.subscription.created':
      case 'customer.subscription.updated':
        await dbAdminPort.upsertSubscription(event.data)
        break

      case 'customer.subscription.deleted':
        await dbAdminPort.markSubscriptionCanceled(event.data)
        break

      case 'invoice.payment_failed':
        await dbAdminPort.markPaymentFailed(event.data)
        break

      default:
        // Log unhandled events for future implementation — not an error
        console.log(`[stripe/webhook] Unhandled event type: ${event.type}`)
    }

    await dbAdminPort.markWebhookProcessed(eventId)
  } catch (err) {
    console.error(`[stripe/webhook] Handler error for ${event.type}:`, err)
    // Return 500 so Stripe retries — handlers must be idempotent
    return NextResponse.json(
      { error: 'Handler failed', code: 'INTERNAL_ERROR' },
      { status: 500 }
    )
  }

  return NextResponse.json({ received: true })
}
```

### Checkout (server action / route — guarded by @app/auth)

A checkout entry point in `apps/portal/app/...` calls `requireUser()` from `@app/auth`, then
`billing.createCheckout(userId, tier)`. The app never imports the Stripe SDK and never
constructs a session itself.

```typescript
// apps/portal/app/api/billing/checkout/route.ts  (NO src/)
import { NextRequest, NextResponse } from 'next/server'
import { requireUser } from '@app/auth'
import { billing } from '@app/adapters'

const VALID_TIERS = ['basic', 'pro'] as const
type Tier = (typeof VALID_TIERS)[number]

export async function POST(request: NextRequest) {
  // requireUser throws / returns 401 if there is no valid session
  const user = await requireUser()

  const { tier } = (await request.json()) as { tier?: string }

  // ⚠️ Never trust a client-supplied priceId — the client picks a TIER, the adapter
  // resolves the real price id from env server-side.
  if (!tier || !VALID_TIERS.includes(tier as Tier)) {
    return NextResponse.json({ error: 'Invalid tier', code: 'INVALID_REQUEST' }, { status: 400 })
  }

  const { url } = await billing.createCheckout(user.id, tier as Tier)
  return NextResponse.json({ url })
}
```

Equivalent server action form:

```typescript
// apps/portal/app/billing/actions.ts
'use server'
import { requireUser } from '@app/auth'
import { billing } from '@app/adapters'

export async function startCheckout(tier: 'basic' | 'pro') {
  const user = await requireUser()
  const { url } = await billing.createCheckout(user.id, tier)
  return url
}
```

### Subscription state management

Always reconcile subscription state from webhook events, not from client redirects. The
client redirect (Stripe Checkout success URL) can be tampered with or missed. The webhook
route above writes state via `dbAdminPort` — that is the source of truth.

### Products and prices

Model billing tiers as Stripe Products with Prices. Use the Stripe MCP to inspect existing
products before creating new ones.

```
Products:
  - "Free"  product  (metadata: { tier: 'free' })   — no Stripe price
  - "Basic" product  (metadata: { tier: 'basic' })  → STRIPE_PRICE_BASIC
  - "Pro"   product  (metadata: { tier: 'pro' })     → STRIPE_PRICE_PRO

Prices (on the Basic and Pro products):
  - recurring, interval: month (add annual prices as needed)
```

Creating products in test mode during development is fine. Creating live-mode products
requires the 🚦 production approval gate.

---

## Verifying

```bash
pnpm -r type-check                    # typecheck every package + app
pnpm --filter @app/adapters test      # unit-test the billing adapter
```

---

## Gotchas

**The `stripe` server SDK may only be imported inside `packages/adapters/`.**
If you find yourself writing `import Stripe from 'stripe'` in an app or in another package,
stop — extend `packages/adapters/src/billing/index.ts` and call it through `billing` from
`@app/adapters`. The only app-side Stripe import allowed is `@stripe/stripe-js` (browser).

**Never trust client-supplied price IDs or amounts.**
The client selects a **tier** (`basic` / `pro`); the adapter resolves the real price id from
`STRIPE_PRICE_BASIC` / `STRIPE_PRICE_PRO`. A raw client-supplied `priceId` never reaches Stripe.

**Webhook handlers MUST be idempotent.**
Stripe retries on any non-2xx response. If your handler runs twice for the same event, it
must produce the same result. Use the event id as an idempotency key and record processed
events via `dbAdminPort`.

**Reconcile state from webhooks, not from redirect query params.**
The Checkout success redirect URL is user-controlled — a user can craft a fake
`?session_id=...` URL. Always treat the webhook as the source of truth for subscription state.

**The webhook has no session — use `dbAdminPort`, not the user-scoped DB.**
There is no `requireUser()` in the webhook route. Writes go through the privileged
`dbAdminPort` from `@app/adapters/db`, authenticated by the Stripe signature.

**Do not log full Stripe event payloads.**
They can contain PII (email addresses, names) and partial payment data. Log only the event
id, event type, and relevant metadata.

**`stripe-signature` header is critical — never skip it.**
Verification lives in `billing.parseWebhook(...)`. Skipping it means any HTTP client can
trigger your billing state changes. Treat it like an auth check.

**Local webhook testing requires the Stripe CLI.**
```bash
stripe listen --forward-to localhost:3001/api/stripe/webhook
```
The dashboard's "Send test webhook" does not reach `localhost`. Port `3001` is the portal.

---

## MCP Usage

The **stripe** MCP is a remote HTTP server (`https://mcp.stripe.com`) that authenticates via
**browser OAuth** on first use — no API key in `.mcp.json` or env. Authorize once with
`claude mcp login stripe`. This is separate from `STRIPE_SECRET_KEY`, which the **adapter**
still needs in the environment for server-side Stripe calls (webhooks, Checkout).

Use the **stripe** MCP to:
- `create_product` / `list_products` — set up and inspect pricing tiers
- `create_price` / `list_prices` — create monthly/annual prices
- `get_customer` / `list_customers` — debug customer state
- `get_subscription` / `list_subscriptions` — inspect subscription lifecycle
- `list_invoices` — debug payment failures

Always inspect existing state via MCP before creating new Stripe objects — avoid creating
duplicates in test mode.

Creating **live-mode** products, prices, or coupons via MCP requires Gate 5 approval.

---

## Integration With Other Skills

- **nextjs** — the webhook route at `apps/portal/app/api/stripe/webhook/route.ts` is excluded
  from the auth guard (authenticated by Stripe signature instead). All other billing routes
  (`/api/billing/*`, portal-owned) call `requireUser()` from `@app/auth`. Errors follow the
  standard `{ error, code }` shape.
- **neon** — store `stripeCustomerId` and subscription state on the Drizzle schema in the
  adapters package (`@app/adapters`, `packages/adapters/src/db/schema.ts`). The webhook writes
  it via the `dbAdminPort` (system, un-scoped) path — signature-verified, bypassing RLS since
  it runs as system, not as a user.
- **email** — send subscription confirmation emails from the webhook handler after
  `customer.subscription.created`, not from the success redirect.
