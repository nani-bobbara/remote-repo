---
name: architecture
description: >
  The Jairus hexagonal architecture skill — how the jairus-starter template is structured and the
  BEST PRACTICES for extending it with a new domain feature without breaking the ports-and-adapters
  discipline. Load at the START of every feature design/build: it defines what the TEMPLATE owns
  (core implementations + basic vendor integrations) vs what a FEATURE adds, the dependency
  direction between packages, the "add a feature end-to-end" recipe (domain → application →
  adapters → app), and the boundaries a reviewer will enforce. Required by designer, developer, and
  reviewer on every task. Consult this before deciding which package a file belongs in, or whenever
  you're tempted to import a vendor SDK or the Drizzle client directly into an app — that's the
  signal you need this skill.
---

# Jairus Architecture — hexagonal monorepo, and how to extend it

The template (`jairus-starter`, cloned at Foundation) is a **ports-and-adapters (hexagonal)**
pnpm + turbo monorepo. The whole point: **the template owns the core + basic integrations once,
and every project extends it the same way** — so feature work is predictable, testable, and cheap
in tokens. Learn the seams; add features along them.

## Template-owns vs feature-adds (the contract)

| The TEMPLATE (core) owns — do not rebuild | A FEATURE adds |
|---|---|
| Monorepo wiring, two apps, shared packages, CI | New domain entities/ports, use-cases, tables |
| Auth + data-driven RBAC (see the **auth** skill) | New permission strings + guarded routes |
| DB client, two-layer security (`withUser` + RLS), migrations plumbing | New user-owned tables + scoped repos + RLS policy |
| Billing (Stripe checkout + webhook), email (Resend), ai/flags stubs | Feature-specific use-cases that call those ports |
| shadcn/tweakcn UI kit + theme tokens, brand config | New screens composed from `@app/ui` |

**Basic integrations ship wired but minimal** (a checkout call, a send() stub). A feature deepens
them through the existing ports — it does not fork them or add a parallel client.

## The packages + the ONE dependency rule

```
packages/
  domain/       @app/domain       entities · value-objects · errors · PORTS · RBAC (can(), PERMISSIONS). ZERO deps.
  application/  @app/application   use-cases: pure orchestration over ports (makeX(db) factories).
  adapters/     @app/adapters      implements the ports: Drizzle/Neon (db), Better Auth (auth), Stripe (billing), Resend (email), ai/flags.
  auth/         @app/auth          request-scoped session + guards (needs Next headers, so outside adapters).
  ui/           @app/ui            shadcn components + tweakcn tokens.
  config/       @app/config        shared tsconfig + brand.
apps/
  portal/  (:3001)  customer app        admin/  (:3002)  operator console
```

**Dependencies point INWARD only:**
`apps → application → domain` and `apps → adapters → domain`. **Nothing depends on the apps;
nothing outward-of-domain is imported by domain.** The domain knows no vendor, no framework.

**Smell tests (a reviewer BLOCKS these):**
- A vendor SDK (`stripe`, `resend`, `drizzle-orm`, `better-auth`) imported anywhere but `@app/adapters` → wrong layer.
- The Drizzle client imported into an app or a client component → must go through a port/use-case.
- A `role === 'admin'` literal or a new role enum → RBAC is data; use `requirePermission` (see **auth**).
- Business logic living in a React component or a route handler → belongs in a use-case in `@app/application`.

## Packages are consumed as TypeScript source

Apps import `@app/*` directly (via workspace `exports` + `transpilePackages`) — no build step
between packages. Edit `packages/adapters/src/...` and the apps see it immediately. This is why the
schema/types have a single source of truth and both apps stay in lockstep.

## The extend recipe — add a domain feature end-to-end

Work **inside-out** (domain first), one seam at a time. Example: a "projects" feature.

1. **Domain** (`@app/domain`) — add the entity + the port (the interface, not the impl):
   ```ts
   // entities: interface Project { id: string; userId: string; name: string; createdAt: Date }
   // ports:    interface ProjectRepo { listForUser(userId): Promise<Project[]>; create(...): Promise<Project> }
   // extend DbPort with `projects: ProjectRepo`
   ```
   Keep it pure — no imports outside `@app/domain`. Unit-test any logic (like `can()`) here.

2. **Adapters** (`@app/adapters`) — the table + the scoped repo:
   - Add the table to `src/db/schema.ts` with a `userId` column (every user-owned table has one).
   - `pnpm db:generate` → review SQL in `packages/adapters/drizzle/` → **append the RLS policy**
     (fail-closed `FORCE` on `app.user_id`) → `pnpm db:migrate`.
   - Implement `ProjectRepo` so reads/writes run inside `withUser` (Layer 1 scoping). See the **neon** skill.

3. **Application** (`@app/application`) — the use-case, as a factory over the port:
   ```ts
   export function makeListProjects(db: DbPort) {
     return (userId: string) => db.withUser(userId, (repos) => repos.projects.listForUser(userId))
   }
   ```
   No vendor imports; the use-case only knows the port. This is where feature logic lives.

4. **App** (`apps/portal` or `apps/admin`) — the thin edge:
   - Server component / server action / route handler: **guard first** (`requireUser()` or
     `requirePermission(...)` — see **auth**), then call the use-case, then render with `@app/ui`.
   - Cross-user/admin reads use `dbAdminPort` behind `requireStaff()`; user-owned reads use the
     scoped path. Never import the Drizzle client here.

5. **Permission (if the feature is gated)** — add a string to `PERMISSIONS` in `@app/domain` and
   guard with `requirePermission` (see the **auth** skill). No new role enum, ever.

Result: the vendor stays swappable (replace the adapter, keep the port), the logic stays testable
(inject a fake `DbPort` into the use-case), and the app stays thin.

## Two-layer data security is non-negotiable

Every user-owned read/write goes through **`DbPort.withUser(userId, …)`** (Layer 1 — scoped repos
filter by `userId`) AND the table carries Postgres **RLS `FORCE`** fail-closed on `app.user_id`
(Layer 2). System/cross-user writes (e.g. the Stripe webhook, staff management) use the privileged
`dbAdminPort` path, always behind a guard. A user-owned table without an RLS policy is a `[BLOCKER]`.

## Where to draw the line (scope discipline)

- Reuse a shipped port before adding one. Deepen `billing`/`email` through their existing ports;
  don't add a second Stripe/Resend client.
- Put shared UI in `@app/ui`, not copied per app. Put brand/config in `@app/config`.
- If a change touches the core (auth model, DB security, monorepo wiring) rather than adding a
  feature along a seam, that's a **template-version** change, not feature work — flag it, don't
  fork it inside a project.

## Integration (other skills)

- **auth** — the RBAC model + guards; the canonical port/adapter example. Read it for any gated route.
- **neon** — schema, migrations, `withUser`, RLS mechanics for step 2.
- **nextjs** — the two-app model, server/client split, route/error/validation conventions for step 4.
- **stripe / email / theming / vercel / github** — the "basic integrations" the template ships; extend through their ports.
