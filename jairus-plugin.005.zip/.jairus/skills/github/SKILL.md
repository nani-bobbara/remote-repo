---
name: github
description: >
  GitHub repository, CI/CD, and project board skill — branch workflow, PR conventions,
  GitHub Actions (checks-only), GitHub Project board setup (epics → features → stories),
  and MCP usage for all repo operations. Load for any task involving the repo, PRs, CI
  workflows, or the project board. MCP server: github.
---

# GitHub (Repo + CI/CD + Project Board)

Always-on skill (fixed core stack). MCP server: **github**.

CI workflow templates: `${CLAUDE_PLUGIN_ROOT}/templates/ci/ci.yml`,
`${CLAUDE_PLUGIN_ROOT}/templates/ci/quality-gates.yml`,
`${CLAUDE_PLUGIN_ROOT}/templates/ci/migrations.yml` (Drizzle migrations).

## When This Skill Is Loaded

For any task involving: creating or updating branches, opening PRs, writing CI workflows,
reading CI status, managing issues and milestones, or building/refreshing the project board.

---

## Setup

No npm packages needed. The **github** MCP is a remote HTTP server
(`https://api.githubcopilot.com/mcp/`) that authenticates via **browser OAuth** on first
use — no Personal Access Token in `.mcp.json` or env. Authorize once with
`claude mcp login github`; the granted OAuth scopes cover repo, workflow, and project
operations.

A `GITHUB_PERSONAL_ACCESS_TOKEN` is **optional** and only needed for CI (GitHub Actions)
if a workflow calls the GitHub API directly. When a PAT is used in CI, it must carry the
scopes matching the operation:
```
repo       — branch, PR, issue, and file operations
workflow   — writing .github/workflows/*.yml files
project    — GitHub Projects v2 (board operations)
```

---

## Key Patterns

### Branch naming

```
feature/{feature-name}   ← kebab-case, matches the feature name in INTENT.md
```

Examples: `feature/user-auth`, `feature/subscription-billing`, `feature/ai-assistant`

Never commit directly to `main`. All work goes through a feature branch → PR flow.

### PR conventions

**Title format:** `feat({feature-name}): {brief description}`

Examples:
- `feat(user-auth): add email/password login and session management`
- `feat(subscription-billing): Stripe Checkout and subscription webhook handler`

**PR body must include:**
1. Link to the design docs: `docs/features/{feature-name}/`
2. CHECKLIST.md completion status from the feature's design artifact
3. Test coverage summary (what was tested, what was mocked)
4. Any manual verification steps for the reviewer

```markdown
## Summary
Implements email/password auth with Better Auth. Adds `/api/auth/login`,
`/api/auth/register`, and `/api/auth/logout` routes. Middleware protects all
`/dashboard` routes.

## Design docs
[docs/features/user-auth/](../docs/features/user-auth/)

## Checklist
- [x] API routes: login, register, logout
- [x] Middleware: session check on /dashboard/*
- [x] RLS policies: users table
- [x] Integration tests: 401, validation, happy path
- [ ] E2E tests (deferred to QA sprint)

## Test coverage
Unit: lib/auth/session.ts (100%)
Integration: /api/auth/* (happy path + 401 + validation)
Component: LoginForm, RegisterForm
```

Always open PRs against `main`.

### CI workflow structure

**`ci.yml` (from template — checks only, no deploy):**
```yaml
name: CI

on:
  push:
    branches: ['**']
  pull_request:
    branches: [main]

jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v4
        with: { version: 9 }
      - uses: actions/setup-node@v4
        with: { node-version: '20', cache: 'pnpm' }
      - run: pnpm install --frozen-lockfile
      - run: pnpm turbo lint

  type-check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v4
        with: { version: 9 }
      - uses: actions/setup-node@v4
        with: { node-version: '20', cache: 'pnpm' }
      - run: pnpm install --frozen-lockfile
      - run: pnpm turbo type-check

  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v4
        with: { version: 9 }
      - uses: actions/setup-node@v4
        with: { node-version: '20', cache: 'pnpm' }
      - run: pnpm install --frozen-lockfile
      - run: pnpm turbo test

  build:
    runs-on: ubuntu-latest
    needs: [lint, type-check, test]
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v4
        with: { version: 9 }
      - uses: actions/setup-node@v4
        with: { node-version: '20', cache: 'pnpm' }
      - run: pnpm install --frozen-lockfile
      - run: pnpm turbo build
```

**Never add deployment steps to CI.** Vercel's Git integration handles all deployments.

**`migrations.yml` (Drizzle — triggers on migration file changes):**
```yaml
name: Migrations

on:
  push:
    paths:
      - 'packages/adapters/drizzle/**'
    branches: [main]

jobs:
  migrate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v4
        with: { version: 9 }
      - uses: actions/setup-node@v4
        with: { node-version: '20', cache: 'pnpm' }
      - run: pnpm install --frozen-lockfile
      - run: pnpm db:migrate   # root script → drizzle-kit migrate for @app/adapters
        env:
          DATABASE_URL_ADMIN: ${{ secrets.DATABASE_URL_ADMIN }}   # Neon primary/owner
```

Migrations are owned by `packages/adapters`: `drizzle-kit migrate` runs on merge to main against
`DATABASE_URL_ADMIN` (Neon). The Neon GitHub integration provisions per-PR branch creds for
preview migrations.

**`quality-gates.yml` (secret scan + a11y + perf):**
```yaml
name: Quality Gates

on:
  pull_request:
    branches: [main]

jobs:
  secret-scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: gitleaks/gitleaks-action@v2

  accessibility:
    runs-on: ubuntu-latest
    if: env.PREVIEW_URL != ''
    steps:
      - uses: actions/checkout@v4
      - name: axe accessibility check
        uses: dequelabs/axe-core-npm@v1
        with: { urls: '${{ env.PREVIEW_URL }}' }
```

### GitHub Project board (used by `/jairus:board`)

The board is built by the `planner` agent from the approved INTENT.md MVP breakdown.
It is idempotent — match by title + labels on re-runs, never duplicate.

**Mapping: design artifact → board:**

| Design artifact     | Board object              | Labels                                          |
|---------------------|---------------------------|------------------------------------------------|
| SDLC phase          | **Milestone**             | `epic:{phase}` (Init/Design/Develop/Deploy/Extend) |
| MVP feature         | **Issue** (Feature card)  | `feature:{name}`, `type:feature`, `plan:free\|pro` |
| Story / sub-task    | **Issue** (Story)         | `feature:{name}`, `type:story`                  |
| Tech task           | **Issue** (Tech task)     | `feature:{name}`, `type:tech-task`              |

**Project columns (Status field — single select):**
`Backlog` | `Ready` | `In Progress` | `In Review` | `Done` | `Blocked`

**Capability ladder (Projects v2 is GraphQL — verify MCP support first):**

1. **Projects v2 via github MCP** — create project, add Status field with six options,
   create issues, add as items, set Status. Preferred.
2. **`gh` CLI GraphQL** — `gh project create`, `gh project item-add`, `gh issue create`
   — use if the MCP can't mutate Projects v2.
3. **Issues + labels + milestones only** — always works. Print a note for the user to
   manually add issues to a Project and set columns.

Never create board objects until the 🚦 `/jairus:board` approval gate is confirmed.

---

## Gotchas

**`workflow` scope is required to write `.github/workflows/*.yml`.**
A token with only `repo` scope will fail silently or with an opaque 422 error when
committing workflow files. Check the token scopes first; surface the missing scope
to the user.

**Never force-push to `main` or to shared feature branches.**
Force-pushing rewrites history and breaks anyone else's local copy. If you need to
fix the last commit, open a new commit.

**Never delete issues — update their labels and column instead.**
Issues are referenced from PRs, design docs, and the project board. Deleting them
breaks those references. Close or label them `type:wont-fix` if they're no longer
active.

**CI is checks-only — Vercel handles deployment.**
Never add `vercel deploy`, `npm run build && scp`, or any deploy commands to a
GitHub Actions workflow. The build job in CI is a verification build only.

**Branch protection rules must be set after CI workflows exist.**
Add `ci / build` and `quality-gates / secret-scan` as required status checks in
branch protection settings. This is a manual step in GitHub settings after the
workflows are committed.

---

## MCP Usage

All repo operations go through the **github** MCP:

- `create_repository` — initial repo setup
- `create_branch` — create `feature/{name}` branch from main
- `create_pull_request` — open PR with title/body conventions above
- `get_pull_request` / `list_pull_requests` — read PR status and CI checks
- `create_issue` — create feature/story/tech-task issues
- `add_labels` / `create_label` — apply label taxonomy
- `create_milestone` — create SDLC phase milestones (epics)
- `get_workflow_run` — check CI status after push
- `rerun_workflow_run` — retry a flaky CI run

---

## Integration With Other Skills

- **vercel** — CI does NOT deploy. Vercel's Git integration handles that. CI and
  Vercel run in parallel after each push; they are independent.
- **neon** — `migrations.yml` runs the Drizzle path (`drizzle-kit migrate`, owned by
  `packages/adapters`) against `DATABASE_URL_ADMIN` on migration changes on main; the Neon GitHub
  integration provisions branch creds for previews.
- **nextjs** — the `lint`, `type-check`, and `test` jobs correspond directly to
  `pnpm lint`, `pnpm type-check`, and `pnpm test` from the nextjs skill.
- **stripe** — add `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, and
  `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` as GitHub Actions secrets for the build job.
