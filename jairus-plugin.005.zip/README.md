# jairus — Agentic Micro-SaaS Harness `v4.0.0`

A Claude Code plugin that turns a product **intent** into a shipped micro-SaaS. It is a
**foundation-first factory**: `/jairus:init` provisions and verifies a **deployed portal + admin
walking skeleton** before any product feature, then each feature runs a gated
**design → develop → review → deploy** pipeline driven by specialist subagents, vendor CLIs, and
browser-OAuth MCP platform operations.

**Core stack (fixed):** Next.js 14+ · TypeScript · TailwindCSS + shadcn (tweakcn theme) · Stripe · Vercel  
**Backend (fixed):** **Neon** serverless Postgres — Drizzle ORM + Better Auth + two-layer security over a single `DATABASE_URL`, shared across a `packages/{db,auth,core}` + `apps/{portal,admin}` monorepo  
**Extensions (additive):** `ai` · `email` · `feature-flags` — added via `/jairus:extend`  
**Works for:** greenfield projects and existing repos — `/jairus:init` auto-detects which

> ⚠️ **Private / team use.** Not yet published to a public marketplace.  
> **Once you bootstrap a project, replace this file with your product's README.**

---

## Why Jairus?

The name fuses two references that mirror exactly what this plugin does.

**Jarvis** — Tony Stark's AI in Iron Man. Not a passive assistant but an intelligent
coordinator that understands intent the moment it's spoken, knows which system to call,
dispatches the right specialist, and never asks "what should I do next?" It doesn't
wait for step-by-step instructions — it carries the mission forward autonomously,
reporting back only when a human decision is needed.

**Jairus** — a figure from an ancient story who had a vision, a deadline, and no idea
how to execute it alone. He didn't try to do everything himself. He went, described
what he needed with complete clarity, found the one who could do it, and then —
crucially — he *waited at every gate*, trusting the process rather than rushing past
the checkpoints. People around him said it was too late, too complex, it couldn't be
done. He pressed on anyway. What seemed impossible was brought to life, stage by stage.

That story is this plugin.

You have a product idea — a spark, an intent, a problem worth solving. You describe it
once, clearly, and Jairus takes it from there. A designer is called in to turn the idea
into complete, reviewed artifacts before a single line of code is written. A developer
implements it layer by layer — backend, API, components, payments, tests — in a fixed
order that eliminates guesswork. A reviewer scores the output against binary checklists,
not opinions. A deployer ships it to staging, then production, only after you've looked
it in the eye and said yes.

At every gate, Jairus stops and waits for *you*. Not because it can't continue — but
because some decisions belong to the human who owns the vision. The specialist agents
do the work. You hold the meaning.

The name wasn't chosen randomly. It carries the weight of what this plugin attempts:
to take something that doesn't exist yet — your product — and bring it to life through
the right people, in the right order, without skipping a single step.

Every time you run `/jairus:ship`, you're Jairus. You showed up, you described the need,
and you trusted the process. The plugin does the rest.

---

## Architecture

`jairus` runs inside Claude Code and operates its platforms through vendor CLIs (provisioning)
and MCP servers (in-session ops) to build and ship your SaaS. stripe, github, vercel, and neon
authorize once via browser OAuth. The main Claude thread is the **orchestrator** — it never writes
application code. It dispatches specialist agents and enforces gates.

```mermaid
flowchart TB
  subgraph CLAUDE["Claude Code runtime"]
    direction TB
    ORC(["Orchestrator\nmain thread"]):::orch
    subgraph PLUGIN[".jairus/ plugin"]
      direction LR
      CMD("commands/\n10 × .md"):::cmd
      AGT("agents/\n6 × .md"):::agent
      SKL("skills/\n9 × SKILL.md"):::skill
      RUL("rules/\n9 × .md"):::rule
      TPL("templates/\nfiles"):::tmpl
    end
    subgraph MCP["MCP servers — platform operations"]
      direction LR
      MDB("neon\nPostgres"):::backend
      MST("stripe"):::amber
      MVR("vercel"):::neutral
      MGH("github"):::blue
    end
  end
  subgraph PROJECT["Your project (generated output)"]
    direction LR
    INT("docs/INTENT.md"):::proj
    DSG("docs/features/\n7 artifacts per feature"):::proj
    SRC("apps/{portal,admin} +\npackages/{db,auth,core}"):::proj
  end
  USER(["You"]):::orch
  USER -->|"/jairus:command"| ORC
  ORC -->|"loads"| CMD
  ORC -->|"dispatches"| AGT
  AGT -->|"loads on demand"| SKL
  AGT -->|"always-on policy"| RUL
  AGT -->|"fills in"| TPL
  AGT -->|"calls tools"| MCP
  TPL & AGT -->|"writes to"| PROJECT
  classDef orch fill:#EDE9F7,stroke:#8A7FB8,color:#3F3A5A;
  classDef cmd fill:#DBE9F7,stroke:#5A87C0,color:#1E3A5F;
  classDef agent fill:#F7ECD2,stroke:#C99A3E,color:#6B4E1A;
  classDef skill fill:#DDF0E4,stroke:#5FA97C,color:#245A3A;
  classDef rule fill:#F7DED8,stroke:#C56A54,color:#7A2E1E;
  classDef tmpl fill:#E8E8E5,stroke:#9A9A90,color:#444444;
  classDef backend fill:#DDF0E4,stroke:#5FA97C,color:#245A3A;
  classDef amber fill:#F7ECD2,stroke:#C99A3E,color:#6B4E1A;
  classDef neutral fill:#E8E8E5,stroke:#9A9A90,color:#444444;
  classDef blue fill:#DBE9F7,stroke:#5A87C0,color:#1E3A5F;
  classDef proj fill:#F5F5F5,stroke:#AAAAAA,color:#333333;
```

---

## Orchestration architecture

Full 9-layer view — from your `/jairus:command` down through orchestrator, commands, pipeline engine, agents, MCP servers, platforms, and project output. Gates loop back to you for approval; everything between gates runs autonomously.

![Jairus orchestration architecture](docs/architecture.svg)

---

## The pipeline

Foundation (provision + verify a deployed portal + admin walking skeleton) → intent → approved MVP
breakdown → GitHub Project → each feature runs a quality-gated **design → develop → review**
micro-cycle in dependency order. Feature stages stay locked until Foundation is green. Reviews are
scored /10; a score `< 8` sends work back (autonomous fix-loop, max 3 iterations); you approve at
every 🚦 gate.

```mermaid
flowchart TD
  subgraph STAGE0["Foundation — /jairus:init"]
    INIT(["New or existing repo\n/jairus:init\nauto-detects mode"]):::cmd
    G1["🚦 F1\nIntent + breakdown"]:::gate
    GF2["🚦 F2\nResource plan"]:::gate
    GF["🚦 F11 · F-VERIFY\nDeploy + prove skeleton"]:::gate
    INIT --> G1 --> GF2 --> GF
  end
  subgraph STAGE1["Stage 1 — Board"]
    BOARD(["/jairus:board\nplanner agent"]):::cmd
    G2["🚦 Gate 2\nBoard plan"]:::gate
    BOARD --> G2
  end
  GF -->|"✅ foundation green"| STAGE1
  subgraph LOOP["Per feature · dependency order"]
    direction TB
    DES["designer agent\n7 artifacts"]:::agent
    DR{"design review\n/10"}:::gate2
    DES --> DR
    DR -->|"< 8 · fix"| DES
    DR -->|"≥ 8"| G3["🚦 Gate 3\nDesign approval"]:::gate
    DEV["developer agent\nbackend → API → UI → Stripe → tests"]:::agent
    G45["🚦 Gate 4/5\nBackend schema · Live Stripe"]:::gate
    REV["reviewer agent\ncode diff /10"]:::agent
    CR{"code review\n/10"}:::gate2
    DEV --> G45 --> REV --> CR
    CR -->|"< 8 · fix"| DEV
    CR -->|"≥ 8"| G6["🚦 Gate 6\nPre-merge"]:::gate
  end
  G2 -->|"✅"| DES
  G3 -->|"✅"| DEV
  subgraph STAGE5["Stage 5 — Deploy"]
    DEPL(["/jairus:deploy\ndeployer agent"]):::cmd
    G7["🚦 Gate 7\nStaging"]:::gate
    G8["🚦 Gate 8\nProduction"]:::gate
    DEPL --> G7 -->|"✅"| G8
  end
  G6 -->|"✅"| STAGE5
  G8 -->|"✅"| DONE(["🎉 Production"]):::done
  classDef cmd fill:#EDE9F7,stroke:#8A7FB8,color:#3F3A5A;
  classDef gate fill:#F0D9CE,stroke:#C56A54,color:#7A2E1E,font-weight:bold;
  classDef gate2 fill:#FFF8E6,stroke:#C99A3E,color:#6B4E1A;
  classDef agent fill:#F7ECD2,stroke:#C99A3E,color:#6B4E1A;
  classDef done fill:#DDF0E4,stroke:#5FA97C,color:#245A3A,font-weight:bold;
```

**Two ways to drive the pipeline:**
- `/jairus:ship` — drives the **whole backlog** autonomously in dependency order (pauses at gates)
- **Manual** — `/jairus:design <feature>` → `/jairus:develop <feature>` → `/jairus:review` per feature

---

## State model & session resume

Pipeline state lives in **three layers**, each owning something different — they never duplicate. Full definition: `.jairus/rules/state-model.md`.

| Layer | Owns | Authoritative for |
|-------|------|-------------------|
| **`docs/INTENT.md`** | The write-once **seed** — idea, requirements, initial feature breakdown | The original intent only (archival once the board exists) |
| **GitHub Project** | The living backlog — every feature, its stage, its status | **Feature + stage status (source of truth)** |
| **`jairus.json`** (project root) | The plugin's **control footprint** — version anchor + `project.foundation.status` + board pointer + resume cursor + cached snapshot | Foundation completion + a cursor + cache, reconciled from the board |

- **Gate = card move.** A gate approval is a human moving a card across board columns: `Backlog → Design → Design Approved → Develop → Review → Review Passed → Deploy → Done`. There are no `design_approved` / `code_review_passed` flags in `INTENT.md` — status is a board column.
- **Session resume.** A dead or compacted session reads `jairus.json`, checks the version (patch/minor auto-migrate; major prompts), reconciles the cursor/snapshot against the live board + git/files (the board wins on any disagreement), then reports the single next action.
- **The repo builds without jairus.** `jairus.json` is committed but inert — it is guidance for the plugin only. The generated Next.js app builds and runs without it.

---

## How it works — two entry paths

Everything starts with `/jairus:init`. Claude reads your repo state and chooses the right path automatically.

### Path A — New idea, blank repo

You describe your product in plain language (or just run `/jairus:init` and Claude asks):

```
/jairus:init "I want to build a SaaS for managing freelance invoices"
```

Claude runs the **Foundation phase** (`.jairus/rules/foundation.md`): an **intent interview** —
users, key features, monetization — writes `docs/INTENT.md`, then provisions the whole platform
(GitHub repo + Project, monorepo, Neon, two Vercel projects, Stripe, secrets, CI) and deploys a
verified portal + admin walking skeleton. The Foundation gates:

> **🚦 F1** — You read the intent + feature breakdown. Approve, correct, or add features.  
> Nothing is created until you say yes.

> **🚦 F2** — Claude shows exactly what it will provision, on which accounts (GitHub repo,
> Neon project, two Vercel projects, Stripe test objects). You approve before any billable resource.

> **🚦 F11 / F-VERIFY** — Claude deploys portal + admin, then proves the skeleton is live and secure
> (portal signup works, seeded admin logs in and is forced to reset, admin has no self-signup,
> `requireAdmin` blocks non-admins). Only then is `foundation.status = green` and features unlock.

### Path B — Existing repo

```
/jairus:init
```

Claude detects `package.json` / `src/` / `app/` and switches to **audit mode**:

1. **Stack check** — Next.js App Router + TypeScript = compatible and continues.  
   Incompatible stack (CRA, Vite, Vue) → Claude presents 3 options: migrate, wrap, or abort.
2. **Read-only audit** — maps what exists (`done`), what's partial, what's missing.
3. **Feature classification** — imports existing GitHub issues into the backlog.

Then the same Foundation gates (F1 / F2) — you approve the breakdown and resource plan before anything is provisioned.

### Human-in-the-loop contract

The rule is simple: **autonomous between gates, human only at gates.**

| What runs autonomously | What requires your approval |
|------------------------|------------------------------|
| Design fix-loop (up to 3 iterations) | 🚦 Gate 3 — design handover per feature |
| Code fix-loop (up to 3 iterations) | 🚦 Gate 4 — backend schema changes |
| Preflight checks (type-check, test, build) | 🚦 Gate 5 — live Stripe objects |
| Vercel preview deployment polling | 🚦 Gate 6 — code review pre-merge |
| Runtime log scanning | 🚦 Gate 7 — staging verification |
| | 🚦 Gate 8 — final production deployment |

If either fix-loop exhausts 3 iterations without reaching ≥ 8/10, Claude escalates to you with all findings — it never loops indefinitely.

---

## Getting started

### Step 1 — Install the plugin (once per machine)

Plugin installation is handled by Claude Code — jairus does not manage this.

```
/plugin marketplace add C:\path\to\jairus-plugin
/plugin install jairus@jairus-plugin
```

Claude Code handles updates automatically via `autoUpdate: true`. To uninstall:
`/plugin uninstall jairus@jairus-plugin`.

### Step 2 — Run doctor (once per machine)

`/jairus:doctor` is the combined setup wizard and health check. It detects your shell,
checks which credentials are missing, prompts for each value, and writes them to
your shell profile — so you never set env vars manually.

```
/jairus:doctor
```

The doctor walks through:
- Toolchain check (Node.js 18+, npm, git)
- Plugin integrity
- CLI auth: `gh`, `npx neonctl@latest`, `npx vercel@latest`, `stripe` signed in (Foundation provisions with these)
- MCP authorization: stripe, github, vercel, and neon sign in via browser OAuth (`claude mcp login <server>`)
- Runtime app secrets (Stripe keys, `DATABASE_URL`, `BETTER_AUTH_*`) written to `.env.local`
  — separate from MCP auth
- Writes any shell-level vars to `~/.zshrc`, `~/.bashrc`, or PowerShell profile

When it finishes: **restart Claude Code** so any shell profile changes reload. Run
`/jairus:doctor --check` at any time to verify current state without making changes.

> **How MCP auth works.** There is no plugin-level `.mcp.json`. The project `.mcp.json`
> is generated at `/jairus:init` from `templates/mcp.json`. stripe, github, vercel, and neon are
> remote HTTP servers that authorize via **browser OAuth** — no tokens stored in any file; you
> approve once and Claude Code holds the session. MCP handles in-session reads/ops; Foundation
> **provisions** with the vendor CLIs (`gh`, `neonctl`, `vercel`, `stripe`).
>
> **Runtime app secrets are separate from MCP auth.** Your app's own secrets live in
> `.env.local` (never committed): `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`,
> `NEXT_PUBLIC_*` keys, plus the Neon binding — `DATABASE_URL` (+ `DATABASE_URL_ADMIN`) +
> `BETTER_AUTH_SECRET` + `BETTER_AUTH_URL`.

### Step 3 — Start your project

```bash
# New project
mkdir my-saas && cd my-saas && git init
# open in Claude Code, then:
/jairus:init            # auto-detects new repo → intent interview → breakdown
/jairus:board           # create GitHub Project
/jairus:ship            # design → develop → review for every feature → deploy

# Existing repo
cd your-existing-repo
# open in Claude Code, then:
/jairus:init            # auto-detects existing code → audit → classify → import backlog
/jairus:ship --plan     # preview dependency-ordered run
/jairus:ship
```

### Step 4 — Add extensions (any time after init)

```bash
/jairus:extend ai             # Vercel AI SDK + Anthropic streaming
/jairus:extend email          # Resend + React Email templates
/jairus:extend feature-flags  # GrowthBook
```

Extensions are additive and permanent — once added to `INTENT.md`, never removed.

---

## The 10 Commandments

| # | Command | Purpose | Gate |
|---|---|---|---|
| I | `/jairus:doctor [--check\|--feature n]` | Diagnose and fix machine readiness; collect credentials | — |
| II | `/jairus:init [context]` | Smart entry point — detects new vs existing repo automatically | 🚦 1, 2 |
| III | `/jairus:board [--refresh]` | Create/refresh GitHub Project from approved breakdown | 🚦 2 |
| IV | `/jairus:design <feature>` | Designer → 7 artifacts → design-review ≥8 → handover | 🚦 3 |
| V | `/jairus:develop <feature>` | Developer → backend + API + components + tests | 🚦 4, 5 |
| VI | `/jairus:review [feature]` | Code-review ≥8 on diff → pre-merge handover | 🚦 6 |
| VII | `/jairus:deploy [feature]` | Deployer → Vercel preview → production | 🚦 7, 8 |
| VIII | `/jairus:ship [--plan\|feature]` | Full feature loop in dependency order; `--plan` for dry-run | 🚦×n |
| IX | `/jairus:extend <name>` | Add extension: `ai` \| `email` \| `feature-flags` | — |
| X | `/jairus:help [command]` | CLI-style help; pass a command name for details | — |

---

## The 8 approval gates

Every gate requires explicit human approval. None can be skipped.

| Gate | Raised by | Confirms |
|------|-----------|----------|
| 1 | `init` (Foundation F1) | Intent + MVP breakdown |
| 2 | `init` (Foundation F2) | Resource plan before any billable resource is provisioned |
| 3 | `design` | All 7 design artifacts approved before any code written |
| 4 | `develop` | Backend schema changes before migrations / rules deployed |
| 5 | `develop` | Live Stripe objects before production products/prices created |
| 6 | `review` | Code review ≥8/10 before merge |
| 7 | `deploy` | Human verifies staging at Vercel preview URL |
| 8 | `deploy` | Final production deployment approval |

Foundation adds two more gates before features unlock: **F11** (approve first production deploy of the walking skeleton) and **F-VERIFY** (confirm the deployed skeleton is live and secure → `foundation.status = green`). See `.jairus/rules/foundation.md`.

---

## Quality gate — the fix-loop engine

Reviews are scored /10 across binary pass/fail checklists. Any `[BLOCKER]` finding
caps the overall at 7 regardless of other scores. The fix-loop runs a max of 3
iterations before escalating to you.

```mermaid
flowchart TD
  START["Reviewer scores /10\nper dimension\n[BLOCKER] [HIGH] [MEDIUM] [LOW]"]:::review
  B{"Any [BLOCKER]?"}:::decision
  B -->|"Yes"| CAP["Capped at 7/10"]:::rule
  B -->|"No"| AVG["Average dimension scores"]:::rule
  CAP & AVG --> CHECK{"≥ 8/10?"}:::decision
  CHECK -->|"Yes — PASS"| GATE["🚦 Gate N\nHuman approval"]:::gate
  CHECK -->|"No — FAIL"| IC{"Iteration < 3?"}:::decision
  IC -->|"Yes"| FIX["Fixer agent\naddresses findings"]:::dispatch
  FIX --> START
  IC -->|"No"| ESC["Escalate to human\nall findings from 3 iterations"]:::error
  classDef review fill:#DBE9F7,stroke:#5A87C0,color:#1E3A5F;
  classDef decision fill:#FFF8E6,stroke:#C99A3E,color:#6B4E1A;
  classDef rule fill:#F7DED8,stroke:#C56A54,color:#7A2E1E;
  classDef gate fill:#F0D9CE,stroke:#C56A54,color:#7A2E1E,font-weight:bold;
  classDef dispatch fill:#EDE9F7,stroke:#8A7FB8,color:#3F3A5A;
  classDef error fill:#F7DED8,stroke:#C56A54,color:#7A2E1E;
```

---

## MCP integration — Read → Write → Verify

Every agent that writes to a platform must verify the result via MCP before reporting done.
"Created" ≠ done.

| Agent | MCP servers used | Pattern |
|-------|-----------------|---------|
| `designer` | neon, stripe | Read live schema before designing |
| `developer` | neon, stripe, github | Read → apply migration → verify RLS |
| `reviewer` | neon, github | Verify two-layer security (app scoping + RLS) is live |
| `deployer` | vercel, github, neon | Read deployment state, confirm READY |
| `planner` | github | Create Project, issues, columns |

There is **no plugin-level `.mcp.json`**. A single project-level file is generated at
init:

```
.mcp.json (project root) ← generated at /jairus:init from templates/mcp.json.
                            stripe · github · vercel · neon — all remote HTTP
                            servers using browser OAuth.
```

---

## Agents

Each persona runs on a model matched to its work — mechanical stages on Haiku, implementation on Sonnet, and the highest-judgment stages (design + review) on Opus, keeping the strongest model where it matters most.

| Agent | Stage | Model | Read-only? | Tools |
|-------|-------|-------|-----------|-------|
| `planner` | Board | Haiku | No | Read, Bash, Glob, Grep, mcp__github__* |
| `designer` | Design | Opus | No | Read, Write, Edit, Glob, Grep, WebFetch, mcp__neon__*, mcp__stripe__* |
| `developer` | Develop | Sonnet | No | Read, Write, Edit, Bash, Glob, Grep, mcp__neon__*, mcp__stripe__*, mcp__github__* |
| `reviewer` | Design & Review | Opus | **Yes** | Read, Bash, Glob, Grep, mcp__github__*, mcp__neon__* |
| `deployer` | Deploy | Haiku | No | Read, Bash, Glob, Grep, mcp__vercel__*, mcp__github__*, mcp__neon__*, mcp__stripe__* |
| `extender` | Extend | Sonnet | No | Read, Write, Edit, Bash, Glob, Grep, mcp__neon__*, mcp__github__* |

---

## Skills

Skills are loaded on demand — not always in context. Each agent pulls exactly what it needs.

| Skill | Active when | Loaded by |
|-------|-------------|-----------|
| `nextjs` | Always | designer, developer |
| `stripe` | Always | designer, developer |
| `vercel` | Always | deployer |
| `github` | Always | planner, deployer |
| `neon` | Always | designer, developer, reviewer, deployer |
| `theming` | UI work (shadcn + tweakcn theme) | designer, developer |
| `ai` | `extensions` includes `ai` | extender, developer |
| `email` | `extensions` includes `email` | extender, developer |
| `feature-flags` | `extensions` includes `feature-flags` | extender, developer |

jairus ships **9** skills. Foundation also installs the official **vendor agent skills**
(`neon-postgres`, `stripe`, `github`, `vercel`, `shadcn`) into the product's `.claude/skills/`
(team-shared, auto-loaded); jairus's own skills are the opinionated layer that defers to them.

---

## Extending the harness

All plugin files live under `.jairus/`. Run `/reload-plugins` after any edit.

### Add a skill

1. Create `.jairus/skills/{name}/SKILL.md` with YAML frontmatter (`name`, `description`)
2. Body sections: **When Loaded · Setup · Key Patterns · Gotchas · MCP Usage · Integration**
3. The `description` field is the trigger — make it specific and "pushy" so the agent loads it reliably
4. Wire it into the relevant agent's Steps section: `Load skill: ${CLAUDE_PLUGIN_ROOT}/skills/{name}/SKILL.md`
5. `/reload-plugins`

### Add an agent

1. Create `.jairus/agents/{name}.md` with frontmatter (`name`, `description`, `tools`)
2. Keep `tools` as restrictive as possible — reviewer must never have `Write` or `Edit`
3. Body sections: **Contract · Responsibilities (Does / Does NOT) · Steps · MCP Usage · Return Format**
4. Add the canonical dispatch call to the relevant command file
5. `/reload-plugins`

### Add a command

1. Create `.jairus/commands/{name}.md` with frontmatter (`description`, `argument-hint`, `allowed-tools`)
2. Body sections: **Preconditions · Steps · Gates (canonical format) · On Error**
3. Update `help.md` and `CLAUDE.md` with the new command
4. `/reload-plugins`

### Add an extension

1. Add skill → `skills/{name}/SKILL.md`
2. Add template → `templates/extensions/{name}.md`
3. Add section to `agents/extender.md` (packages, files, env vars)
4. Add name to valid args in `commands/extend.md`
5. Add env vars to `templates/env.example`
6. `/reload-plugins`

### Edit rules files

- `security.md` is the single authority on security — never repeat it elsewhere, only reference it
- `pipeline.md` owns gates and stages — if you add a gate, update pipeline.md AND all commands that raise it
- `quality-gate.md` owns scoring — if you add a dimension, update quality-gate.md AND `reviewer` agent
- After edits: `grep -r "the thing you changed" .jairus/commands/ .jairus/agents/` to find affected files

---

## Invariants — never break these

These are hardcoded behavioral rules. Changing any is a breaking change requiring a major version bump.

1. **Backend is immutable.** The backend is always Neon serverless Postgres in the portal + admin monorepo — no host profiles, no vendor swap.
2. **Foundation before features.** No feature stage runs until `jairus.json → project.foundation.status == "green"` (a deployed, verified portal + admin walking skeleton).
3. **Extensions are additive only.** `INTENT.md extensions:` is append-only — never remove.
4. **No code before design approval.** Gate 3 must be approved before `develop` can run.
5. **Gates, none skippable.** Every pipeline flow must pass through every applicable gate.
6. **Fix-loop cap at 3.** After 3 failures the orchestrator escalates to the human — never loops indefinitely.
7. **"Created ≠ Done."** Every agent that writes to a platform must verify via MCP before reporting success.
8. **Reviewer is read-only.** `reviewer` tools must never include `Write` or `Edit`.
9. **Orchestrator never writes app code.** Commands dispatch agents and enforce gates — they do not write to `apps/` or `packages/`.
10. **`${CLAUDE_PLUGIN_ROOT}` for all cross-references.** Never use relative paths in plugin files.
11. **Single source of truth per domain.** `security.md`, `pipeline.md`, `quality-gate.md`, `foundation.md` each own their domain — other files reference them, never repeat them.

---

## Requirements

- **Node.js 18+** and **Claude Code 1.0.0+**
- **Accounts to connect at init (Foundation F0):** GitHub, Neon, Vercel, and Stripe (test mode is
  fine to start) — authenticated via their CLIs (`gh`, `npx neonctl@latest`, `npx vercel@latest`,
  `stripe`) plus browser-OAuth MCP
- **MCP auth:** stripe, github, vercel, and neon authorize via **browser OAuth**
  (`claude mcp login <server>`) — no tokens in any file
- **Runtime app secrets** (Stripe keys, `DATABASE_URL`, `BETTER_AUTH_*`) go in `.env.local`
  — never MCP auth, never committed

---

## Repo structure

```
jairus-plugin/
├─ CLAUDE.md                  # project memory — auto-loaded every conversation
├─ README.md                  # this file
├─ CHANGELOG.md               # version history
├─ .claude/
│   ├─ settings.json          # plugin enabled, permissions, deny list
│   └─ settings.local.json    # local MCP server selection (not committed)
├─ .claude-plugin/
│   └─ marketplace.json       # local plugin marketplace registration
└─ .jairus/                   # the plugin (no plugin-level .mcp.json)
    ├─ .claude-plugin/
    │   └─ plugin.json        # plugin manifest (name, version, author)
    ├─ hooks/hooks.json       # PostToolUse: type-check after Edit/Write; git status after commit
    ├─ commands/              # doctor · init · board · design · develop · review
    │                         # deploy · ship · extend · help
    ├─ agents/                # planner · designer · developer · reviewer · deployer · extender
    ├─ skills/                # nextjs · stripe · vercel · github · neon · theming
    │                         # ai · email · feature-flags (extensions)
    ├─ rules/                 # pipeline · quality-gate · security · development · design-workflow
    │                         # adoption · mcp-usage · state-model · foundation
    └─ templates/             # INTENT.md · jairus.json · env.example · design.md · mcp.json
                              # settings.json · feature/ · database/ · ci/ · extensions/ · observability/
```

---

## Non-negotiables

- Never skip a 🚦 approval gate — see `.jairus/rules/pipeline.md`
- Never write code before design is approved (Gate 3)
- Never commit secrets or `.env.local`
- TypeScript strict — zero `any`, zero type errors (enforced by PostToolUse hook)
- Every user-data table is protected by two-layer security — mandatory app-layer `userId` scoping (Layer 1) + defense-in-depth Postgres RLS with `FORCE`, fail-closed (Layer 2) — before data is written
- Stripe webhook signature verification always — no exceptions
- Prefer MCP tools for platform ops (provisioning via vendor CLIs) — not hand-written API calls
- "Created" ≠ done — agents verify live state via MCP before reporting success

---

## Changelog

See [CHANGELOG.md](CHANGELOG.md).
