# Changelog

All notable changes to the jairus plugin are documented here.
Versioning follows [Semantic Versioning](https://semver.org/).

---

## [4.0.0] — 2026-08-02

**Foundation-first factory, Neon monorepo, portal + admin.** A major re-architecture: jairus now
stands up and *verifies* the entire delivery platform (a deployed walking skeleton) before any
product feature, on a fixed Neon + monorepo stack with separate customer and back-office apps.

### Changed (breaking)

- **Backend is now Neon-only** (dropped the 3.0.0 provider-agnostic host profiles). The `postgres`
  skill became the **`neon`** skill — Neon serverless Postgres + Drizzle + Better Auth + two-layer
  security, specialized for Neon (branching, GitHub integration) and monorepo-aware.
- **Monorepo topology** — `packages/{db,auth,core}` + `apps/{portal,admin}`. One shared Drizzle
  schema + Better Auth (`@app/db`/`@app/auth`) drives migrations *and* both apps. Portal (public,
  read-heavy, replica) and admin (restricted, write-heavy, primary) deploy independently.
- **Two-app auth model** — portal: `/` landing, email + Google, open signup. Admin: `/` login,
  **seeded admin** with forced first-login reset, **self-signup disabled**, `requireAdmin()` on
  every admin route (a missing check is a critical BLOCKER — admin reads are cross-user via the
  privileged `dbAdmin` path).

### Added

- **Foundation phase** (`rules/foundation.md`) — a gated, verified Stage 0.5 that `/jairus:init`
  orchestrates: F0 connect accounts (gh/neonctl/vercel/stripe CLIs + MCP) → F1 intent 🚦 →
  F2 resource-plan 🚦 (before any spend) → F3–F10 provision (GitHub repo+board+branch-protection,
  monorepo scaffold, agent-skills install, Neon, 2 Vercel projects, Stripe, secrets, auth seed, CI)
  → F11 deploy skeleton 🚦 → **F-VERIFY** 🚦 (portal signup + admin login proven live). Feature
  stages refuse to run until `jairus.json → project.foundation.status == "green"`. Resume-safe.
- **Official vendor agent skills** (F4b) — foundation installs `neon-postgres`, `stripe`, `github`,
  `vercel`, `shadcn` into the product's `.claude/skills/` (authoritative platform detail, kept
  current); jairus's own skills stay the opinionated layer that defers to them.
- **`theming` skill** — one shadcn theme via a tweakcn preset (design tokens as data); no
  hardcoded colors (a reviewer finding). 9 jairus skills total.
- **CLI provisioning** — `gh`/`neonctl@latest`/`vercel@latest`/`stripe` + `create-next-app@latest`
  do what MCP can't (create projects, set secrets, link deploys); MCP for in-session ops.

### Removed

- Provider-agnostic host profiles (supabase/generic), the `supabase` MCP server, and the
  `postgres` skill name. Neon is the fixed backend.

---

## [3.0.0] — 2026-07-26

**Breaking backend-model change.** Replaces the three named backends with a single
**provider-agnostic PostgreSQL** backend to eliminate vendor lock-in. The app now depends only
on standard Postgres — you own the schema, auth, and security, and can move hosts freely.

### Removed

- **Firebase backend** — proprietary Firestore + Firebase Auth + Security Rules was the vendor
  lock-in outlier (and the only non-OAuth stdio MCP). Skill, template, env, and all references deleted.
- **`supabase` and `neon` as *distinct backends*** — folded into the one Postgres backend as
  host *profiles* (see below). Their standalone skills/templates are gone.

### Changed

- **One backend: provider-agnostic PostgreSQL** (`skills/postgres/SKILL.md`). Stack:
  **Drizzle ORM** (schema, migrations, inferred types) + **Better Auth** (sessions) +
  **two-layer security** — Layer 1 mandatory app-layer authorization (every user-data query
  scoped by session `userId`; a bare query is a BLOCKER), Layer 2 defense-in-depth Postgres RLS
  with `FORCE` + fail-closed policies (fixes the owner-bypass fail-open trap, JAIRUS-001).
- **Host is a profile, not a backend.** `/jairus:init` picks `neon` | `supabase` | `generic` —
  a convenience layer (MCP availability, preview branching) only. The app is portable Postgres
  regardless; swap hosts with a `DATABASE_URL` change. Recorded as `profile` in `jairus.json`.
- **Auth standardized on Better Auth** across all profiles — Supabase is used *as a Postgres
  host*, not its integrated Auth, to keep apps portable.
- **Migrations standardized on Drizzle** (`drizzle-kit`) as the universal path; the neon/supabase
  MCP is optional for inspect/branch.
- **MCP:** stripe/github/vercel always (browser OAuth); backend MCP is profile-dependent
  (`neon`/`supabase` OAuth, `generic` none). `mcp__firebase__*` removed.
- **`.env.example`** collapsed to one Postgres block: `DATABASE_URL` + `BETTER_AUTH_SECRET` +
  `BETTER_AUTH_URL` (+ optional `SUPABASE_PROJECT_REF` on the supabase profile).
- Propagated across all commands, agents (firebase tool scope removed), and rules; `security.md`,
  `quality-gate.md`, `development.md`, `mcp-usage.md`, `adoption.md` now describe the single model.
- Docs (CLAUDE.md, README, help, architecture diagram) and counts updated: **8 skills**
  (nextjs, stripe, vercel, github, postgres, ai, email, feature-flags), 6 agents, 8 rules.

### Migration note

Projects created on ≤2.2.0 with Supabase-Auth or Firebase are not auto-migrated — 3.0.0 targets
new projects on the portable Postgres model. Existing Neon (Better Auth) projects are closest and
map to the `neon`/`generic` profile.

---

## [2.2.0] — 2026-07-26

Control-plane and state-model overhaul, plus per-persona model selection for token efficiency.
Introduces `jairus.json` and makes the GitHub Project the source of truth for pipeline status.

### Added

- **`jairus.json` control footprint** (project root) — the plugin's version anchor + board
  pointer + resume cursor + cached snapshot. Written by `/jairus:init`, updated on every stage
  transition. Guidance for the plugin only; the app builds and runs without it. New
  `templates/jairus.json` skeleton.
- **`rules/state-model.md`** — the authoritative state model: INTENT.md = write-once seed ·
  GitHub Project = status source of truth · `jairus.json` = control footprint. Defines the
  session-start **resume protocol** (version check → reconcile against board + git/files →
  report next action) and the semver upgrade rule (patch/minor auto-migrate; major prompts).
- **Per-persona model selection** — each agent now declares a `model:` matched to task
  complexity: planner + deployer → Haiku (mechanical/procedural), developer + extender →
  Sonnet, designer + reviewer → Opus (highest-judgment stages). Cuts token cost by reserving
  the strongest model for design and review.

### Changed

- **GitHub Project is now the source of truth for feature/stage status.** Retired the
  `design_approved` / `code_review_passed` flags from `INTENT.md`. Stage status is a board
  column; a gate approval is a card move (a human action outside the model). Gate→column
  scheme owned by the planner: Backlog → Design → Design Approved → Develop → Review →
  Review Passed → Deploy → Done.
- **INTENT.md is now a write-once seed** — the confirmed idea, requirements, backend, and
  initial breakdown; archival once the board exists. `templates/feature/CHECKLIST.md`
  reframed as a non-authoritative working mirror of the board card.
- All commands read stage status from the board (via github MCP) and update `jairus.json`
  on stage transitions; `/jairus:init` writes `jairus.json`; `/jairus:doctor` checks the
  version anchor and reconciles cursor/snapshot against the board; `/jairus:ship` drives
  the loop from the board + cursor.
- Tightened agent tool scopes to the right phase (reviewer stays read-only, deployer
  deploy-scoped) and corrected the doctor plugin-integrity counts (6 agents, 10 skills,
  8 rules — JAIRUS-019).

### Notes

- Session resilience: a dead/compacted session resumes from `jairus.json` + the board
  instead of re-deriving state from chat.
- `jairus.json` is committed (small; carries version + board pointer) but inert to the build.

---

## [2.1.0] — 2026-07-26

Third backend, optional observability, and a browser-OAuth MCP model. No breaking
changes to the pipeline contract; the backend set and MCP auth both changed.

### Added

- **Neon backend** — serverless PostgreSQL + Neon Managed Better Auth + Row Level Security
  as a third `backend:` option alongside Supabase and Firebase. New `skills/neon/SKILL.md`,
  `templates/database/neon.md`, `.env.example` block, and 4-way selection at `/jairus:init`.
  MCP server: `neon`. Access control via Postgres RLS scoped per request (`withUser()` +
  `app.user_id`); data access via the `@neondatabase/serverless` driver; DB branch per preview.
- **Optional observability** — opt-in OpenTelemetry export of Claude Code's native token,
  tool/MCP, and command telemetry to Grafana Cloud. `templates/observability/` ships a
  prebuilt dashboard + setup guide; `/jairus:doctor` detects it; `/jairus:init` offers to
  enable it. Off by default, no extra MCP server.
- **`docs/reviews/2026-07-20-architecture-review.md`** — deep gate/security/consistency
  review (30 findings) plus `scripts/create-review-issues.sh` to log them as GitHub issues.

### Changed

- **MCP authentication → browser OAuth.** Five servers are now remote HTTP and authenticate
  via browser OAuth (no tokens in config/env): `stripe` (mcp.stripe.com), `github`
  (PAT header dropped), `vercel`, `supabase` (mcp.supabase.com, `read_only` + `project_ref`
  query params), `neon` (mcp.neon.tech). Firebase remains a local stdio server
  (`firebase-tools mcp`) — it has no hosted OAuth endpoint.
- **Single MCP config source.** Removed the plugin-level `.jairus/.mcp.json`; `templates/mcp.json`
  is the one fixed server set, instantiated per-project on the fly by `/jairus:init`.
- **`.env.example`** now separates runtime app secrets from MCP auth; dropped
  `SUPABASE_ACCESS_TOKEN`, `NEON_API_KEY`, and the required GitHub PAT (all OAuth now).
- **`/jairus:doctor`** — OAuth pre-authorization step covers all five OAuth servers
  (`claude mcp login <server>`); MCP-connectivity server set sourced from the project
  `.mcp.json` (post-init) or `templates/mcp.json` (pre-init).
- Regenerated `docs/architecture.svg` — persona-driven, three-backend, current gates.
- Updated `CLAUDE.md`, `README.md`, and `/jairus:help` to the three-backend + OAuth model.

### Removed

- **PocketBase backend** — added experimentally then removed. It required a self-hosted
  process (incompatible with Vercel) and had no MCP server, so it never fit the
  managed/serverless, MCP-native model. Skill, template, docker-compose, and all references
  deleted.

### Fixed

- Removed the stale root `.mcp.json` and the plugin-level copy that could leave a Neon
  project with no backend MCP server (review finding JAIRUS-005).
- Added `mcp__neon__*` to `/jairus:init` and `/jairus:doctor` allowed-tools (JAIRUS-018).

---

## [2.0.0] — 2026-07-13

Production-quality rewrite. Every component in the harness was rewritten from scratch
with tighter contracts, no content duplication across rules, and three new extension skills.

### Added

- **`/jairus:extend <name>`** command — add an additive integration (`ai`, `email`, or
  `feature-flags`) to an existing project. Updates `INTENT.md extensions:`, installs packages,
  creates `src/lib/{ext}/` utilities, updates `.env.example`. Permanent — extensions are never removed.
- **`extender` agent** — implements extension integrations (packages, utilities, env vars,
  documentation) and verifies the result via type-check.
- **`skills/ai/SKILL.md`** — Vercel AI SDK + Anthropic Claude (default) or OpenAI. Covers
  streaming chat routes, `useChat` hook, tool use, per-user rate limiting, model selection table.
- **`skills/email/SKILL.md`** — Resend + React Email. Covers client wrapper, templates, API route
  sending pattern, Stripe webhook sending pattern, dev preview.
- **`skills/feature-flags/SKILL.md`** — GrowthBook (default) or LaunchDarkly. Covers provider
  setup, `useFlag` hook, server-side evaluation, A/B variants, cleanup plan guidance.
- **`templates/extensions/`** — three new documentation templates: `ai.md`, `email.md`,
  `feature-flags.md`. Written by the `extender` agent alongside the code changes.
- **`DEVELOPER_GUIDE.md`** — contributor guide covering how to add skills, agents, commands,
  the plugin architecture, and how to test changes.
- **`INTENT.md v2 schema`** — added `schema_version`, `display_name`, per-feature `design_approved`,
  `code_review_passed`, `extensions[]` (additive-only list).
- **Second PostToolUse hook** in `hooks.json` — runs `git status --short` after every `git commit`
  so the developer immediately sees what changed.
- **`minClaudeCodeVersion: "1.0.0"`** in `plugin.json`.

### Changed

**Commands (all 11 rewritten):**
- Every command now has: `## Preconditions` (guard clauses), `## Step N: Name` structure, canonical
  gate format (`🚦 GATE N — NAME` with Show/Ask/✅/❌ branches), canonical agent dispatch format,
  canonical fix-loop format, `## On Error` section with recovery paths.
- All commands are re-entrant — safe to run again if interrupted.
- `init.md`, `adopt.md` — Step 0 workspace prep is now an explicit idempotent phase.
- `ship.md` — `--plan` flag prints dependency order + gate sequence without executing.
- `review.md` — now validates build/test pass before dispatching reviewer.

**Agents (all 6 rewritten):**
- Every agent now has: `## Contract` (inputs/outputs/failure modes), `## Responsibilities` (does / does NOT),
  `## Steps`, `## MCP Usage` (specific tool names and query patterns), `## Verification Protocol`,
  `## Return Format` (structured so the orchestrator can parse it).
- `reviewer.md` — tools list is now read-only (no Write/Edit). Hard blocker rule explicit: any
  `[BLOCKER]` finding caps overall at 7/10 regardless of other scores.
- `developer.md` — 6 explicit exit criteria (type-check + test + build + backend verified + Gate 4
  raised + Gate 5 raised if applicable). Never starts without reading ALL design artifacts first.
- `deployer.md` — never merges to main without Gate 8. Verifies production deployment is READY via
  Vercel MCP before reporting success.

**Rules (all 7 rewritten — no duplication):**
- `security.md` is now the **single source of truth** for all security requirements. Other rules
  cross-reference it instead of repeating content.
- `pipeline.md` — canonical gate format defined here. "Created ≠ Done" invariant with a table
  mapping each write operation to its required MCP verification. Ambiguity protocol formalized.
- `quality-gate.md` — hard blocker rule with concrete BLOCKER examples. Escalation block format
  for 3-iteration failures. Detailed "what the reviewer checks" for all 12 dimensions.
- `design-workflow.md` — open questions format. Gate 3 is blocked if any open question exists.
- `development.md` — scoped `CLAUDE.md` convention documented. Per-backend migration workflow explicit.
- `mcp-usage.md` — per-server operation tables. Two-file MCP architecture explained.
- `adoption.md` — explicit backend detection signal tables. Precise `done` classification criteria
  (all 4 layers required). `adopt_status` lifecycle defined.

**Skills (all 6 core skills rewritten with runnable code examples):**
- `nextjs/SKILL.md` — complete API route template with auth+validation+error handling, Server/Client
  decision rules, error code table, test patterns, 7 gotchas.
- `stripe/SKILL.md` — complete webhook handler with signature verification + idempotency, subscription
  state sync pattern, Checkout session creation, test vs live mode guidance.
- `supabase/SKILL.md` — full schema template with `updated_at` trigger, 4-policy RLS pattern,
  post-migration verification query, `@supabase/ssr` client, type generation.
- `firebase/SKILL.md` — deny-by-default Security Rules template with field validation, composite
  index example, Admin SDK singleton, `FieldValue.serverTimestamp()` pattern.
- `github/SKILL.md` — PR conventions, full CI workflow content, capability ladder for Projects v2.
- `vercel/SKILL.md` — Git-integrated deployment model, MCP deployment polling workflow,
  build/runtime log diagnosis table.

**Templates (all updated to production quality):**
- `INTENT.md` — v2 schema with all new fields, `<!-- NOTE: -->` guidance throughout all 9 sections.
- `feature/PRD.md` — YAML frontmatter, user-stories table with AC IDs, open-questions table.
- `feature/DESIGN.md` — Mermaid flow skeletons, `[S]`/`[C]` component markers, error-handling table.
- `feature/API.md` — full GET+POST per-endpoint detail with TypeScript interfaces, Zod notation.
- `feature/CHECKLIST.md` — all 8 gates named explicitly in the three-phase checklist.
- `database/supabase.md` — complete migration SQL with trigger + RLS + rollback.
- `database/firebase.md` — deny-by-default Security Rules block, `firestore.indexes.json` block.
- `ci/ci.yml`, `ci/quality-gates.yml` — updated for Firebase env vars, `needs:` dependency.

**Infrastructure:**
- `plugin.json` — version `1.1.1 → 2.0.0`, `author` flattened to string, `minClaudeCodeVersion` added.
- `.claude/settings.json` — `Read(**)`/`Edit(**)`/`Write(**)` glob forms, `mcp__firebase__*` added,
  `Bash(curl * | bash)` and `Bash(curl * | sh)` added to deny list.
- `marketplace.json` — `displayName`, `version`, `autoUpdate` added.

### Fixed

- `.jairus/.mcp.json` — removed incorrect `Authorization: Bearer ${VERCEL_TOKEN}` header from Vercel
  HTTP server. Vercel MCP uses Claude Code OAuth, not a static bearer token.
- `agents/deployer.md` — fixed Supabase migration verification query (removed nonexistent `name`/
  `executed_at` columns; `version` is the only standard column in `supabase_migrations.schema_migrations`).
- `agents/deployer.md` — replaced nonexistent `mcp__firebase__get_firestore_rules` tool reference with
  `mcp__firebase__get_config` + a note to check `mcp-usage.md` for the current tool name.
- `README.md` — `extender` agent description corrected from "documents" to accurately describe it as
  a code-writing agent that installs packages and creates utility files.

---

## [1.1.1] — 2026-07-13

Initial iteration release. Combines the adopt path and plugin self-containment
changes into a single version while the plugin is in private testing.

### Added
- **`/jairus:adopt`** command — adopt an existing repo into the jairus pipeline without
  starting from scratch. Audits the codebase, reverse-engineers intent, classifies
  existing work as `done / partial / todo / bug`, imports GitHub issues/PRs/backlog,
  creates or maps a GitHub Project, and hands off to the normal feature loop.
- **`rules/adoption.md`** — feature classification criteria, partial feature retrofit
  design, done feature review-only path, backlog import rules, backend lock detection,
  `adopt_status` / `design_status` fields in `INTENT.md`.
- **`.jairus/.mcp.json`** — plugin-level MCP config (all 5 servers). Active whenever
  jairus is installed. `init`/`adopt` write a trimmed copy to the project root.
- **`.jairus/hooks/hooks.json`** — PostToolUse hook (`Edit|Write` → `npm run type-check`)
  moved from `.claude/settings.json` into the plugin so it ships with installation.
- **`.jairus/templates/mcp.json`** — project-level `.mcp.json` template written by
  `init`/`adopt`, unchosen backend removed.
- **`.jairus/templates/settings.json`** — `.claude/settings.json` template written by
  `init`/`adopt` if missing.
- **Workspace prep phase** (`init` Step 0, `adopt` Phase 0) — silently writes missing
  project wiring before any product questions or audit. Non-destructive.

### Changed
- `plugin.json` — version `1.0.0 → 1.1.1`.
- `marketplace.json` — owner and description updated.
- Root `README.md` — user-level install getting-started; both greenfield and adopt paths.

---

## [1.0.0] — 2026-07-01

### Initial release

- **Pipeline:** intent → board → feature loop (design → develop → review) → deploy,
  with human approval gates at every handover.
- **Commands:** `init`, `board`, `design`, `develop`, `review`, `deploy`, `ship`, `health`, `help`.
- **Agents:** `planner`, `designer`, `developer`, `reviewer`, `deployer`.
- **Skills:** `nextjs`, `stripe`, `vercel`, `github`, `supabase`, `firebase`.
- **Rules:** `pipeline`, `quality-gate`, `design-workflow`, `development`, `security`, `mcp-usage`.
- **Templates:** `INTENT.md`, `env.example`, `design.md`, `feature/`, `database/`, `ci/`.
- **MCP servers:** stripe, vercel, github (fixed) + supabase or firebase (locked at init).
- **Quality gate:** scored /10, pass ≥8, autonomous fix-loop capped at 3 iterations.
