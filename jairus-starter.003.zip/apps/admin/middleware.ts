import { NextResponse, type NextRequest } from "next/server"
import { hasSessionCookie } from "@app/auth/edge"

// Outer bounce for signed-out requests, so a route added outside the `(app)`
// group is closed by default. Cookie presence only — `(app)/layout.tsx` resolves
// the real session and checks `admin:access`. Never decide authorisation here.
export function middleware(request: NextRequest) {
  if (hasSessionCookie(request)) return NextResponse.next()

  const url = request.nextUrl.clone()
  url.pathname = "/sign-in"
  url.search = ""
  return NextResponse.redirect(url)
}

export const config = {
  // Password recovery is reached by definition while signed out, so those
  // routes are exempt alongside sign-in. The root route is exempt too: it
  // renders its own redirect and the "Unknown user" denial for non-staff.
  matcher: [
    "/((?!sign-in|forgot-password|reset-password|api/auth|_next/static|_next/image|favicon.ico|manifest.webmanifest|$).*)",
  ],
}
