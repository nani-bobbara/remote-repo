import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  transpilePackages: ["@app/ui", "@app/auth", "@app/adapters", "@app/domain", "@app/config"],
};

export default nextConfig;
