import { redirect } from "next/navigation"
import { getSession } from "@app/auth"
import { can, PERMISSIONS } from "@app/domain"
import { AdminShell } from "./_components/admin-shell"

export const dynamic = "force-dynamic"

// Staff gate for the whole admin console. Non-staff are sent to the root (which
// shows the generic "Unknown user" denial).
export default async function AppLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const session = await getSession()
  if (!session || !can(session, PERMISSIONS.ADMIN_ACCESS)) redirect("/")

  return (
    <AdminShell email={session.email} role={session.role} access={{ permissions: session.permissions, fullAccess: session.fullAccess }}>
      {children}
    </AdminShell>
  )
}
