import { getSession } from "@app/auth"
import { can, PERMISSIONS } from "@app/domain"
import { dbAdminPort } from "@app/adapters/db"
import { LayoutDashboard } from "lucide-react"
import { Card, CardHeader, CardTitle, CardDescription, ContentPane, PageShell, WorkspaceLayout } from "@app/ui"
import { RefreshButton } from "../_components/refresh-button"

export const dynamic = "force-dynamic"

export default async function OverviewPage() {
  const session = await getSession()
  const [users, roles] = await Promise.all([
    dbAdminPort.users.list(),
    dbAdminPort.roles.list(),
  ])
  // Staff = anyone whose role can enter the admin app. Testing against a role
  // NAME was only correct while exactly one non-staff role existed; with three
  // roles it counted portal users as staff.
  const staffRoles = new Set(
    roles.filter((r) => can(r, PERMISSIONS.ADMIN_ACCESS)).map((r) => r.name),
  )
  const staffCount = users.filter((u) => staffRoles.has(u.role)).length

  return (
    <PageShell>
      <WorkspaceLayout
        cardIcon={<LayoutDashboard />}
        cardTitle="Overview Engine"
        cardSubtitle={`Signed in as ${session?.email} (${session?.role.replace("_", " ")}).`}
        cardActions={<RefreshButton />}
      >
        <ContentPane>
          <div className="grid gap-4 sm:grid-cols-3">
            <Card>
              <CardHeader>
                <CardDescription>Users</CardDescription>
                <CardTitle>{users.length}</CardTitle>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader>
                <CardDescription>Staff</CardDescription>
                <CardTitle>{staffCount}</CardTitle>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader>
                <CardDescription>Roles</CardDescription>
                <CardTitle>{roles.length}</CardTitle>
              </CardHeader>
            </Card>
          </div>
        </ContentPane>
      </WorkspaceLayout>
    </PageShell>
  )
}
