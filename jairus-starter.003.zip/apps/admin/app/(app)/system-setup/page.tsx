import { Database, LockKeyhole, ShieldCheck } from "lucide-react"
import { getSession } from "@app/auth"
import { can, PERMISSIONS } from "@app/domain"
import { brand } from "@app/config/brand"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, ContentPane, PageShell, WorkspaceLayout } from "@app/ui"
import { BrandingConfigs } from "./_components/branding-configs"

export const dynamic = "force-dynamic"

export default async function SystemSetupPage() {
  const session = await getSession()
  if (!session || !can(session, PERMISSIONS.ADMIN_ACCESS)) {
    return <p className="text-muted-foreground text-sm">You don&apos;t have access to system setup.</p>
  }

  return (
    <PageShell>
      <WorkspaceLayout
        cardIcon={<Database />}
        cardTitle="System Setup Engine"
        cardSubtitle="Core platform status, protected configuration, and environment controls."
      >
        <ContentPane>
          <div className="space-y-4">
          <div className="grid gap-4 lg:grid-cols-2">
            <Card className="border-destructive/30 bg-destructive/5">
              <CardHeader>
                <CardTitle className="text-destructive flex items-center gap-2">
                  <LockKeyhole className="size-4" /> Protected operations
                </CardTitle>
                <CardDescription>
                  Destructive database operations are intentionally unavailable until a dedicated authorized system port is defined.
                </CardDescription>
              </CardHeader>
              <CardContent className="text-muted-foreground text-sm leading-6">
                Authentication profiles, role definitions, and user-scoped data remain protected by the existing adapters and server-side authorization boundary.
              </CardContent>
            </Card>
            <Card className="border-primary/30 bg-primary/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Database className="text-primary size-4" /> Core services
                </CardTitle>
                <CardDescription>Foundational services currently provided by Jairus.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex items-center gap-2"><ShieldCheck className="text-primary size-4" /> Better Auth session and staff access</div>
                <div className="flex items-center gap-2"><ShieldCheck className="text-primary size-4" /> Data-driven roles and permissions</div>
                <div className="flex items-center gap-2"><ShieldCheck className="text-primary size-4" /> Drizzle database adapter with protected system path</div>
              </CardContent>
            </Card>
          </div>

          {/* Full width below the status cards — the palette grid, form and
              emitted config need the room. */}
          <BrandingConfigs
            current={{
              name: brand.name,
              tagline: brand.tagline,
              description: brand.description,
              palette: brand.palette,
            }}
          />
          </div>
        </ContentPane>
      </WorkspaceLayout>
    </PageShell>
  )
}
