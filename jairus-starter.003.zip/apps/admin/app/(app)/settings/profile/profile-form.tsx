"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { authClient } from "@app/auth/client"
import { ChangePasswordForm, Input, Label, Separator, toast, useRegisterWorkspaceActions } from "@app/ui"
import { updateProfileName } from "./actions"

/** Profile details with a display/edit toggle; Edit/Save/Cancel live in the header. */
export function ProfileForm({
  name,
  email,
  role,
  hasPassword,
}: {
  name: string
  email: string
  role: string
  hasPassword: boolean
}) {
  const router = useRouter()
  const [mode, setMode] = useState<"display" | "edit">("display")
  const [value, setValue] = useState(name)
  const [pending, start] = useTransition()

  const readOnly = mode === "display"
  const dirty = value.trim() !== name

  function save() {
    start(async () => {
      const res = await updateProfileName(value)
      if (res.error) {
        toast.error(res.error)
        return
      }
      toast.success("Profile updated")
      setMode("display")
      router.refresh()
    })
  }

  useRegisterWorkspaceActions(
    mode === "edit"
      ? {
          mode: "edit",
          onSave: save,
          onCancel: () => {
            setValue(name)
            setMode("display")
          },
          saveDisabled: !dirty || !value.trim(),
          savePending: pending,
          saveLabel: "Save profile",
        }
      : { mode: "display", onEdit: () => setMode("edit"), editLabel: "Edit profile" }
  )

  return (
    <div className="grid max-w-xl gap-5 p-6">
      <div className="grid gap-2">
        <Label htmlFor="pf-name">Display name</Label>
        <Input id="pf-name" value={value} onChange={(e) => setValue(e.target.value)} disabled={readOnly} />
      </div>
      <div className="grid gap-2">
        <Label htmlFor="pf-email">Email</Label>
        <Input id="pf-email" value={email} readOnly disabled />
      </div>
      <div className="grid gap-2">
        <Label htmlFor="pf-role">Role</Label>
        <Input id="pf-role" value={role.replace("_", " ")} readOnly disabled className="capitalize" />
      </div>

      <Separator className="my-2" />

      {/* Outside the display/edit toggle: a password change is its own
          confirmed action, not something saved alongside a display name. */}
      <div className="grid gap-3">
        <div>
          <h3 className="text-base font-semibold">Password</h3>
          <p className="text-muted-foreground text-sm">
            Changing it signs out your other sessions.
          </p>
        </div>
        <ChangePasswordForm hasPassword={hasPassword} changePassword={authClient.changePassword} />
      </div>
    </div>
  )
}
