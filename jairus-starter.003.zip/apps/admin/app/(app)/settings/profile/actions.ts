"use server"

import { getSession } from "@app/auth"
import { dbPort } from "@app/adapters/db"

/** Update the signed-in user's own display name. */
export async function updateProfileName(name: string): Promise<{ error?: string }> {
  const session = await getSession()
  if (!session) return { error: "Not authenticated." }
  const trimmed = name.trim()
  if (!trimmed) return { error: "Name can't be empty." }
  await dbPort.withUser(session.userId, (repos) => repos.users.setName(session.userId, trimmed))
  return {}
}
