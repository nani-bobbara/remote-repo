"use client"

import { useState } from "react"
import { usePathname } from "next/navigation"
import { ChevronDown, ChevronRight } from "lucide-react"
import { ListRow, cn } from "@app/ui"
import { resolveActive, visibleGroups, type NavAccess } from "./nav-resolve"

// Desktop grouped sidebar nav (md+). Items are hidden unless the session grants them.
// The expanded group is derived from the route, so the sidebar and the chevron
// ribbon always agree about which group you are in.
export function Sidebar({
  access,
  collapsed = false,
}: {
  access: NavAccess
  collapsed?: boolean
}) {
  const pathname = usePathname()
  const groups = visibleGroups(access)
  const active = resolveActive(pathname, access)

  // Expanding a group by hand is a browsing gesture, not a selection. Navigating
  // clears it so the sidebar snaps back into agreement with the ribbon.
  const [override, setOverride] = useState<string | null>(null)
  // Reset the manual override during render when the route changes (React's
  // "adjust state on prop change" pattern) — avoids a setState-in-effect.
  const [seenPath, setSeenPath] = useState(pathname)
  if (pathname !== seenPath) {
    setSeenPath(pathname)
    setOverride(null)
  }
  const openGroup = override ?? active?.group.id ?? groups[0]?.id ?? ""

  return (
    <nav className={cn("flex flex-col gap-5 pb-6 pt-4", collapsed ? "px-2" : "px-3")}>
      {groups.map((group) => {
        const GroupIcon = group.icon
        const isOpen = openGroup === group.id
        return (
          <div key={group.id} className="flex flex-col gap-1">
            <button
              type="button"
              onClick={() => setOverride(isOpen ? "" : group.id)}
              className={cn(
                "text-muted-foreground flex w-full items-center rounded-md py-2 text-left text-[11px] font-semibold tracking-[0.14em] uppercase transition-colors hover:bg-accent hover:text-accent-foreground",
                collapsed ? "justify-center px-2" : "gap-2 px-3"
              )}
              aria-label={collapsed ? group.label : undefined}
              title={collapsed ? group.label : undefined}
            >
              <GroupIcon className="size-4 shrink-0" />
              {!collapsed ? <span className="flex-1">{group.label}</span> : null}
              {!collapsed ? (isOpen ? <ChevronDown className="size-3.5" /> : <ChevronRight className="size-3.5" />) : null}
            </button>
            {/* Collapsed sidebar shows group icons only — children are hidden,
                not shrunk. (The left workspace panel behaves differently: it
                keeps its rows and renders them icon-only.) */}
            {!collapsed && isOpen
              ? group.items.map(({ href, label, icon: Icon }) => (
                  <ListRow
                    key={href}
                    href={href}
                    label={label}
                    icon={<Icon />}
                    active={pathname === href || pathname.startsWith(href + "/")}
                  />
                ))
              : null}
          </div>
        )
      })}
    </nav>
  )
}
