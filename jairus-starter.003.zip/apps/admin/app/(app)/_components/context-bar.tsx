"use client"

import { usePathname } from "next/navigation"
import { ChevronRibbon } from "@app/ui"
import { resolveActive, type NavAccess } from "./nav-resolve"
import { LogoutButton } from "./logout-button"

/**
 * Workflow ribbon. Shows the group owning the currently selected sidebar item,
 * and that group's sub-items as steps — resolved from the same nav config the
 * sidebar reads, so the two can never disagree.
 */
export function ContextBar({ access }: { access: NavAccess }) {
  const pathname = usePathname()
  const active = resolveActive(pathname, access)
  if (!active) return null

  return (
    <ChevronRibbon
      eyebrow={active.group.label}
      eyebrowIcon={active.group.icon}
      steps={active.items.map(({ href, label, icon }) => ({ href, label, icon }))}
      activeIndex={active.activeIndex}
      trailing={<LogoutButton />}
    />
  )
}
