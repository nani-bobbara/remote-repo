"use client"

import { useRouter } from "next/navigation"
import { LogOut } from "lucide-react"
import { signOut } from "@app/auth/client"
import { Button } from "@app/ui"

/** Global sign-out action — lives in the header ribbon, next to the theme toggle. */
export function LogoutButton() {
  const router = useRouter()
  return (
    <Button
      type="button"
      variant="outline"
      size="icon"
      aria-label="Logout"
      title="Logout"
      onClick={async () => {
        await signOut()
        router.push("/sign-in")
        router.refresh()
      }}
    >
      <LogOut className="size-4" />
    </Button>
  )
}
