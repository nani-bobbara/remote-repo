// Single source of truth for "where am I in the nav": the sidebar, ribbon,
// bottom tabs and mobile drawer all resolve through these, so they cannot
// disagree.
import { can } from "@app/domain"
import { navGroups, type NavGroup, type NavItem } from "./nav-items"

export type ActiveNav = {
  group: NavGroup
  items: NavItem[]
  activeIndex: number
}

/** An object rather than a bare `string[]`: a full-access role carries an empty
 *  permission list, so filtering on the list alone would hide every item from
 *  it. Requiring both makes omitting the flag a type error. */
export type NavAccess = { permissions: string[]; fullAccess: boolean }

/** Groups the session may see, items permission-filtered. A group declaring no
 *  items is kept (placeholder section); one emptied by filtering is dropped. */
export function visibleGroups(access: NavAccess, groups: NavGroup[] = navGroups): NavGroup[] {
  const grants = (item: NavItem) => !item.permission || can(access, item.permission)

  return groups
    .filter((group) => group.items.length === 0 || group.items.some(grants))
    .map((group) => ({ ...group, items: group.items.filter(grants) }))
}

/** Which group and item own `pathname`, or null when none does. Longest href
 *  wins, so `/reports/archive` beats `/reports` regardless of config order. */
export function resolveActive(
  pathname: string,
  access: NavAccess,
  groups: NavGroup[] = navGroups,
): ActiveNav | null {
  let best: ActiveNav | null = null
  let bestLength = -1

  for (const group of visibleGroups(access, groups)) {
    for (const [index, item] of group.items.entries()) {
      const matches = pathname === item.href || pathname.startsWith(`${item.href}/`)
      if (!matches || item.href.length <= bestLength) continue
      bestLength = item.href.length
      best = { group, items: group.items, activeIndex: index }
    }
  }

  return best
}
