"use client"

import { useTransition } from "react"
import { useRouter } from "next/navigation"
import { RefreshCw } from "lucide-react"
import { Button, cn } from "@app/ui"

/** Header action: re-fetches the current server-rendered page (force-dynamic pages). */
export function RefreshButton() {
  const router = useRouter()
  const [pending, start] = useTransition()
  return (
    <Button
      type="button"
      variant="outline"
      size="icon"
      aria-label="Refresh"
      title="Refresh"
      disabled={pending}
      onClick={() => start(() => router.refresh())}
    >
      <RefreshCw className={cn("size-4", pending && "animate-spin")} />
    </Button>
  )
}
