"use client"

import Link from "next/link"
import { useState } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Rocket } from "lucide-react"
import { brand } from "@app/config/brand"
import { Button } from "@app/ui"
import { Sidebar } from "./sidebar"
import { BottomTabs } from "./bottom-tabs"
import { MobileDrawer } from "./mobile-drawer"
import { ContextBar } from "./context-bar"
import type { NavAccess } from "./nav-resolve"

export function AdminShell({
  email,
  role,
  access,
  children,
}: {
  email: string
  role: string
  access: NavAccess
  children: React.ReactNode
}) {
  const [collapsed, setCollapsed] = useState(false)

  return (
    <div className="bg-muted/20 flex min-h-dvh md:h-dvh md:overflow-hidden md:pt-[5px]">
      {/* Desktop: grouped sidebar + pinned user footer */}
      <aside className={`bg-background relative hidden shrink-0 flex-col border-r transition-[width] duration-200 md:flex ${collapsed ? "w-20" : "w-60"}`}>
        <div className="flex h-14 items-center px-4">
          <Link href="/overview" className="flex min-w-0 items-center gap-2 text-base font-semibold tracking-tight">
            <Rocket className="text-primary size-6 shrink-0" aria-hidden="true" />
            {!collapsed ? <span className="truncate">{brand.name}</span> : null}
          </Link>
        </div>
        <Button
          type="button"
          variant="outline"
          size="icon"
          className="bg-background absolute -right-[18px] top-[46px] z-10 rounded-full"
          onClick={() => setCollapsed((value) => !value)}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {collapsed ? <ChevronRight /> : <ChevronLeft />}
        </Button>
        <div className="flex-1 overflow-y-auto">
          <Sidebar access={access} collapsed={collapsed} />
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col md:min-h-0">
        <header className="bg-muted/20 sticky top-0 z-30 flex h-14 items-center gap-2 px-4 md:hidden sm:px-6" style={{ paddingTop: "env(safe-area-inset-top)" }}>
          <MobileDrawer access={access} email={email} role={role} />
          <Link href="/overview" className="flex items-center gap-2 text-base font-semibold tracking-tight md:hidden">
            <Rocket className="text-primary size-5" aria-hidden="true" />
            <span>{brand.name}</span>
          </Link>
        </header>
        <main className="flex flex-1 flex-col p-4 pb-24 sm:p-6 md:min-h-0 md:overflow-hidden md:pb-0 md:pt-0">
          <div className="mb-4 w-full shrink-0">
            <ContextBar access={access} />
          </div>
          {children}
        </main>
      </div>

      {/* Mobile: plain bottom key-menu */}
      <BottomTabs access={access} />
    </div>
  )
}
