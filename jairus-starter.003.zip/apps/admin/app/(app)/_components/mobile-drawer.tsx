"use client"

import { useState } from "react"
import { usePathname, useRouter } from "next/navigation"
import { LogOut, Menu } from "lucide-react"
import { signOut } from "@app/auth/client"
import { Button, Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@app/ui"
import { Sidebar } from "./sidebar"
import type { NavAccess } from "./nav-resolve"

// Mobile hamburger → full grouped nav + account. Closes on navigation.
export function MobileDrawer({
  access,
  email,
  role,
}: {
  access: NavAccess
  email: string
  role: string
}) {
  const [open, setOpen] = useState(false)
  const pathname = usePathname()
  const router = useRouter()
  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden" aria-label="Open menu">
          <Menu className="size-5" />
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-72 p-0">
        <SheetHeader className="border-b">
          <SheetTitle>Menu</SheetTitle>
        </SheetHeader>
        <div key={pathname} className="flex flex-1 flex-col overflow-y-auto">
          <div className="flex-1" onClick={() => setOpen(false)}>
            <Sidebar access={access} />
          </div>
          <div className="border-t p-3">
            <div className="mb-2 px-1">
              <p className="text-foreground truncate text-sm font-medium">{email}</p>
              <p className="text-muted-foreground truncate text-xs capitalize">{role.replace("_", " ")}</p>
            </div>
            <Button
              variant="outline"
              className="w-full justify-start gap-2"
              onClick={async () => {
                await signOut()
                router.push("/sign-in")
                router.refresh()
              }}
            >
              <LogOut className="size-4" />
              Logout
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}
