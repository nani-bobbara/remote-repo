"use client"

import { useCallback } from "react"
import { Moon, Sun } from "lucide-react"
import { Button } from "@app/ui"

/** No React state: the `.dark` class on <html> is the source of truth. Both
 *  icons always render and CSS picks one, so server and client markup match.
 *  Do not seed state from localStorage — the server cannot read it. */
export function ThemeToggle() {
  const toggle = useCallback(() => {
    const isDark = document.documentElement.classList.toggle("dark")
    try {
      window.localStorage.setItem("theme", isDark ? "dark" : "light")
    } catch {
      // Private mode / storage disabled — the class still flips for this session.
    }
  }, [])

  return (
    <Button variant="outline" size="icon" aria-label="Toggle theme" title="Toggle theme" onClick={toggle}>
      <Sun className="hidden size-4 dark:block" />
      <Moon className="size-4 dark:hidden" />
    </Button>
  )
}
