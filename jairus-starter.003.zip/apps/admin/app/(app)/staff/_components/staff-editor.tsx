"use client"

import { useState, useTransition } from "react"
import { CheckCircle2, Clock, XCircle } from "lucide-react"
import { userStatus, type UserStatus } from "@app/domain"
import {
  Avatar,
  AvatarFallback,
  Input,
  Label,
  OptionGrid,
  toast,
  useRegisterWorkspaceActions,
  type GridOption,
} from "@app/ui"
import { setUserRole } from "../actions"

type StaffMember = {
  id: string
  email: string
  name: string | null
  role: string
  emailVerified: boolean
  banned: boolean
}

const STATUS_OPTIONS: GridOption[] = [
  { value: "active", label: "Active", icon: <CheckCircle2 />, tone: "success" },
  { value: "inactive", label: "Inactive", icon: <XCircle /> },
  { value: "invited", label: "Invited", icon: <Clock /> },
]

function initials(member: StaffMember) {
  const source = member.name?.trim() || member.email
  return source
    .split(/[\s@._-]+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part.charAt(0).toUpperCase())
    .join("")
}

export function StaffEditor({
  member,
  roles,
  canWrite,
}: {
  member: StaffMember
  roles: { name: string; label: string }[]
  canWrite: boolean
}) {
  const [mode, setMode] = useState<"display" | "edit">("display")
  const [role, setRole] = useState(member.role)
  const [pending, start] = useTransition()
  const status: UserStatus = userStatus(member)

  const readOnly = !canWrite || mode === "display"
  const dirty = role !== member.role
  const roleOptions: GridOption[] = roles.map((r) => ({ value: r.name, label: r.label }))

  function save() {
    start(async () => {
      const res = await setUserRole(member.id, role)
      if (res.error) {
        toast.error(res.error)
        return
      }
      toast.success("Member updated")
      setMode("display")
    })
  }

  // Drive the shared header toolbar: display → Edit; edit → Cancel + Save.
  useRegisterWorkspaceActions(
    !canWrite
      ? null
      : mode === "edit"
        ? {
            mode: "edit",
            onSave: save,
            onCancel: () => {
              setRole(member.role)
              setMode("display")
            },
            saveDisabled: !dirty,
            savePending: pending,
            saveLabel: "Save member",
          }
        : { mode: "display", onEdit: () => setMode("edit"), editLabel: "Edit member" }
  )

  return (
    <div className="space-y-7 p-6">
      <div className="flex items-center gap-4">
        <Avatar className="size-14">
          <AvatarFallback className="text-base font-semibold">{initials(member)}</AvatarFallback>
        </Avatar>
        <div className="min-w-0">
          <p className="truncate text-xl font-semibold tracking-tight">{member.name ?? member.email}</p>
          <p className="text-muted-foreground truncate text-sm">{member.email}</p>
        </div>
      </div>

      <div className="space-y-2">
        <Label className="text-subtle-foreground text-[11px] font-black uppercase tracking-[0.18em]">
          Display name
        </Label>
        {/* Read-only: no setName write path for staff yet. */}
        <Input value={member.name ?? ""} readOnly disabled aria-label="Display name" />
      </div>

      <div className="space-y-2">
        <Label className="text-subtle-foreground text-[11px] font-black uppercase tracking-[0.18em]">Role</Label>
        <OptionGrid
          label="Role"
          options={roleOptions}
          value={[role]}
          onChange={(next) => setRole(next[0] ?? role)}
          columns={4}
          disabled={readOnly}
        />
      </div>

      <div className="space-y-2">
        <Label className="text-subtle-foreground text-[11px] font-black uppercase tracking-[0.18em]">Status</Label>
        {/* Derived from emailVerified/banned — read-only until a setBanned port method exists. */}
        <OptionGrid label="Status" options={STATUS_OPTIONS} value={[status]} columns={3} disabled />
      </div>
    </div>
  )
}
