"use client"

import { useState, useTransition } from "react"
import { NativeSelect, toast } from "@app/ui"
import { setUserRole } from "../actions"

type Role = { name: string; label: string }

export function RoleSelect({
  userId,
  current,
  roles,
}: {
  userId: string
  current: string
  roles: Role[]
}) {
  const [pending, start] = useTransition()
  const [value, setValue] = useState(current)
  // Include the current role even if it's a legacy/unknown value, so it shows.
  const options = roles.some((r) => r.name === current)
    ? roles
    : [{ name: current, label: current }, ...roles]

  return (
    <NativeSelect
      value={value}
      disabled={pending}
      onChange={(e) => {
        const v = e.target.value
        setValue(v)
        start(async () => {
          const res = await setUserRole(userId, v)
          if (res.error) {
            toast.error(res.error)
            setValue(current)
          } else {
            toast.success("Role updated")
          }
        })
      }}
      className="shrink-0 capitalize"
    >
      {options.map((r) => (
        <option key={r.name} value={r.name}>
          {r.label}
        </option>
      ))}
    </NativeSelect>
  )
}
