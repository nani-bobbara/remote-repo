import Link from "next/link"
import { Plus, Users } from "lucide-react"
import { getSession } from "@app/auth"
import { can, PERMISSIONS } from "@app/domain"
import { dbAdminPort, dbPort } from "@app/adapters/db"
import { Button, ContentPane, InitialsAvatar, ListPanel, PageShell, WorkspaceLayout } from "@app/ui"
import { RefreshButton } from "../_components/refresh-button"
import { InviteForm } from "./_components/invite-form"
import { StaffEditor } from "./_components/staff-editor"

export const dynamic = "force-dynamic"

export default async function StaffPage({
  searchParams,
}: {
  searchParams: Promise<{ id?: string; mode?: string }>
}) {
  const session = await getSession()
  if (!session || !can(session, PERMISSIONS.STAFF_READ)) {
    return <p className="text-muted-foreground text-sm">You don&apos;t have access to staff management.</p>
  }
  const canWrite = can(session, PERMISSIONS.STAFF_WRITE)
  const [allUsers, roles] = await Promise.all([dbAdminPort.users.list(), dbPort.roles.list()])

  // Staff = anyone whose role can enter the admin app. Computed from the
  // permission, not a role name, so a role an admin creates later (sales, IT,
  // …) is included the moment it is granted admin:access.
  const staffRoles = roles.filter((r) => can(r, PERMISSIONS.ADMIN_ACCESS))
  const staffRoleNames = new Set(staffRoles.map((r) => r.name))

  // Admin plane only: portal users are absent, so a deep link to a subscriber
  // cannot select them and no dropdown here can demote someone out of the list.
  // Both server actions re-check this; the UI is not the boundary.
  const users = allUsers.filter((u) => staffRoleNames.has(u.role))

  const { id, mode } = await searchParams
  const creating = mode === "new" && canWrite
  const selected = creating ? null : (users.find((u) => u.id === id) ?? users[0] ?? null)

  return (
    <PageShell>
      <WorkspaceLayout
        cardIcon={<Users />}
        cardTitle="Staff Engine"
        cardSubtitle="Manage members, dynamic roles, and overall invite lifecycles."
        cardActions={
          <>
            <RefreshButton />
            {canWrite ? (
              <Button asChild variant="outline" size="icon" title="Invite staff" aria-label="Invite staff">
                <Link href="/staff?mode=new">
                  <Plus />
                </Link>
              </Button>
            ) : null}
          </>
        }
        collapsibleLeftPanel
        defaultLeftPanelWidth={240}
        leftPanel={
          <ListPanel
            searchPlaceholder="Search staff…"
            items={users.map((u) => ({
              id: u.id,
              label: u.name ?? u.email,
              icon: <InitialsAvatar label={u.name ?? u.email} />,
              href: `/staff?id=${u.id}`,
              active: selected?.id === u.id,
            }))}
            emptyMessage="No staff yet."
          />
        }
      >
        {creating ? (
          <div className="mx-auto w-full max-w-2xl space-y-4 p-6">
            <div>
              <h3 className="text-base font-semibold">Invite staff</h3>
              <p className="text-muted-foreground text-sm">Create a staff member with a temporary password and role.</p>
            </div>
            <InviteForm roles={staffRoles} />
          </div>
        ) : selected ? (
          <StaffEditor
            key={selected.id}
            member={selected}
            roles={staffRoles.map((r) => ({ name: r.name, label: r.label }))}
            canWrite={canWrite}
          />
        ) : (
          <ContentPane emptyTitle="No staff yet" emptyDescription="Invite a staff member from the header to begin." />
        )}
      </WorkspaceLayout>
    </PageShell>
  )
}
