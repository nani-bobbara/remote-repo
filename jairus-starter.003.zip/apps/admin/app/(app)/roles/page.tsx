import Link from "next/link"
import { getSession } from "@app/auth"
import { can, PERMISSIONS } from "@app/domain"
import { dbPort } from "@app/adapters/db"
import { Plus, ShieldCheck } from "lucide-react"
import { Badge, Button, ContentPane, InitialsAvatar, ListPanel, PageShell, WorkspaceLayout } from "@app/ui"
import { RefreshButton } from "../_components/refresh-button"
import { NewRoleForm } from "./_components/new-role-form"
import { PermissionEditor } from "./_components/permission-editor"

export const dynamic = "force-dynamic"

export default async function RolesPage({
  searchParams,
}: {
  searchParams: Promise<{ name?: string; mode?: string }>
}) {
  const session = await getSession()
  if (!session || !can(session, PERMISSIONS.ROLES_READ)) {
    return <p className="text-muted-foreground text-sm">You don&apos;t have access to role control.</p>
  }
  const canWrite = can(session, PERMISSIONS.ROLES_WRITE)
  const roles = await dbPort.roles.list()
  // The permission vocabulary is data now, not a code constant — see
  // /permissions for where it is curated.
  const catalog = await dbPort.permissions.list()
  const { name, mode } = await searchParams
  const creating = mode === "new" && canWrite
  const selected = creating ? null : (roles.find((r) => r.name === name) ?? roles[0] ?? null)

  return (
    <PageShell>
      <WorkspaceLayout
        cardIcon={<ShieldCheck />}
        cardTitle="Role Control Engine"
        cardSubtitle="Define access levels, custom roles, and permission hierarchies."
        cardActions={
          <>
            <RefreshButton />
            {canWrite ? (
              <Button asChild variant="outline" size="icon" title="New role" aria-label="New role">
                <Link href="/roles?mode=new">
                  <Plus />
                </Link>
              </Button>
            ) : null}
          </>
        }
        collapsibleLeftPanel
        defaultLeftPanelWidth={240}
        leftPanel={
          <ListPanel
            searchPlaceholder="Search roles…"
            items={roles.map((r) => ({
              id: r.name,
              label: r.label,
              icon: <InitialsAvatar label={r.label} />,
              // Same density as the Permissions list: the stable id as meta,
              // and a badge for the rows that behave differently.
              meta: r.name,
              badge: r.fullAccess ? (
                <Badge variant="outline">full access</Badge>
              ) : r.isSystem ? (
                <Badge variant="secondary">system</Badge>
              ) : null,
              href: `/roles?name=${r.name}`,
              active: selected?.name === r.name,
            }))}
            emptyMessage="No roles yet."
          />
        }
      >
        {creating ? (
          <div className="mx-auto w-full max-w-xl space-y-4 p-6">
            <div>
              <h3 className="text-base font-semibold">New role</h3>
              <p className="text-muted-foreground text-sm">Create a custom role, then set its permissions.</p>
            </div>
            <NewRoleForm />
          </div>
        ) : selected ? (
          <PermissionEditor key={selected.name} role={selected} catalog={catalog} canWrite={canWrite} />
        ) : (
          <ContentPane emptyTitle="No roles yet" emptyDescription="Create a role from the header to begin." />
        )}
      </WorkspaceLayout>
    </PageShell>
  )
}
