"use server"

import { revalidatePath } from "next/cache"
import { requirePermission } from "@app/auth"
import { PERMISSIONS } from "@app/domain"
import { dbPort } from "@app/adapters/db"

const slug = (s: string) => s.trim().toLowerCase().replace(/[^a-z0-9_]+/g, "_").replace(/^_+|_+$/g, "")

export async function createRole(input: { name: string; label: string }): Promise<{ error?: string }> {
  await requirePermission(PERMISSIONS.ROLES_WRITE)
  const name = slug(input.name)
  if (!name) return { error: "A role id is required" }
  if (await dbPort.roles.getByName(name)) return { error: "That role id already exists" }
  await dbPort.roles.upsert({
    name,
    label: input.label.trim() || name,
    description: null,
    permissions: [],
    // Superuser is never grantable through the admin UI — only the seed sets it.
    fullAccess: false,
    isSystem: false,
  })
  revalidatePath("/roles")
  return {}
}

export async function saveRole(input: {
  name: string
  label: string
  description: string
  permissions: string[]
}): Promise<{ error?: string }> {
  await requirePermission(PERMISSIONS.ROLES_WRITE)
  const existing = await dbPort.roles.getByName(input.name)
  if (!existing) return { error: "Role not found" }
  if (existing.isSystem) return { error: "System roles can't be edited" }
  await dbPort.roles.upsert({
    name: input.name,
    label: input.label.trim() || input.name,
    description: input.description.trim() || null,
    permissions: input.permissions,
    // Preserved from the stored row, never taken from the client.
    fullAccess: existing.fullAccess,
    isSystem: false,
  })
  revalidatePath("/roles")
  return {}
}
