"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { Input, toast, useRegisterWorkspaceActions } from "@app/ui"
import { createRole } from "../actions"

/** Create-role fields. Cancel/Create are surfaced in the workspace header (edit mode). */
export function NewRoleForm() {
  const [pending, start] = useTransition()
  const [name, setName] = useState("")
  const [label, setLabel] = useState("")
  const router = useRouter()

  function submit() {
    start(async () => {
      const res = await createRole({ name, label })
      if (res.error) {
        toast.error(res.error)
        return
      }
      const slug = name.trim().toLowerCase().replace(/[^a-z0-9_]+/g, "_")
      toast.success("Role created")
      router.push(`/roles?name=${slug}`)
    })
  }

  useRegisterWorkspaceActions({
    mode: "edit",
    onSave: submit,
    onCancel: () => router.push("/roles"),
    saveDisabled: !name.trim(),
    savePending: pending,
    saveLabel: "Create role",
  })

  return (
    <div className="grid gap-2">
      <Input placeholder="Label — e.g. Sales" value={label} onChange={(e) => setLabel(e.target.value)} />
      <Input placeholder="id — e.g. sales" value={name} onChange={(e) => setName(e.target.value)} />
    </div>
  )
}
