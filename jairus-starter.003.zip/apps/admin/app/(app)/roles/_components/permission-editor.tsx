"use client"

import { useState, useTransition } from "react"
import {
  Avatar,
  AvatarFallback,
  Badge,
  Input,
  Label,
  OptionGrid,
  toast,
  useRegisterWorkspaceActions,
} from "@app/ui"
import { saveRole } from "../actions"

type RoleDef = {
  name: string
  label: string
  description: string | null
  permissions: string[]
  fullAccess: boolean
  isSystem: boolean
}

type PermissionDef = {
  key: string
  label: string
  description: string | null
  resource: string
  isSystem: boolean
}

export function PermissionEditor({
  role,
  catalog,
  canWrite,
}: {
  role: RoleDef
  catalog: PermissionDef[]
  canWrite: boolean
}) {
  const editable = canWrite && !role.isSystem
  // fullAccess is its own column now, not a '*' entry smuggled into the list.
  const fullAccess = role.fullAccess
  const originalPerms = role.permissions

  const [mode, setMode] = useState<"display" | "edit">("display")
  const [label, setLabel] = useState(role.label)
  const [description, setDescription] = useState(role.description ?? "")
  const [selected, setSelected] = useState<Set<string>>(new Set(originalPerms))
  const [pending, start] = useTransition()

  const readOnly = !editable || mode === "display"

  // A role can still hold a key that has since been deleted from the catalog.
  // Surface it as an orphan rather than silently dropping it on the next save.
  const byKey = new Map(catalog.map((p) => [p.key, p]))
  const orphans: PermissionDef[] = originalPerms
    .filter((p) => !byKey.has(p))
    .map((p) => ({
      key: p,
      label: p,
      description: "no longer in the catalog",
      resource: "orphaned",
      isSystem: false,
    }))

  const groups = new Map<string, PermissionDef[]>()
  for (const def of [...catalog, ...orphans]) {
    const list = groups.get(def.resource) ?? []
    list.push(def)
    groups.set(def.resource, list)
  }
  const groupEntries = [...groups.entries()].sort(([a], [b]) => a.localeCompare(b))

  const dirty =
    label !== role.label ||
    description !== (role.description ?? "") ||
    selected.size !== originalPerms.length ||
    originalPerms.some((p) => !selected.has(p))

  function reset() {
    setLabel(role.label)
    setDescription(role.description ?? "")
    setSelected(new Set(originalPerms))
  }

  function save() {
    start(async () => {
      const res = await saveRole({ name: role.name, label, description, permissions: [...selected] })
      if (res.error) {
        toast.error(res.error)
        return
      }
      toast.success("Role saved")
      setMode("display")
    })
  }

  // Drive the shared header toolbar: display → Edit (disabled for protected
  // system / full-access roles); edit → Cancel + Save.
  useRegisterWorkspaceActions(
    !canWrite
      ? null
      : mode === "edit"
        ? {
            mode: "edit",
            onSave: save,
            onCancel: () => {
              reset()
              setMode("display")
            },
            saveDisabled: !dirty,
            savePending: pending,
            saveLabel: "Save role",
          }
        : {
            mode: "display",
            onEdit: () => setMode("edit"),
            editDisabled: !editable || fullAccess,
            editLabel: !editable || fullAccess ? "System role — read-only" : "Edit role",
          }
  )

  return (
    <div className="space-y-7 p-6">
      <div className="flex items-center gap-4">
        <Avatar className="size-14">
          <AvatarFallback className="text-base font-semibold">
            {(label || role.name).slice(0, 2).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <p className="truncate text-xl font-semibold tracking-tight">{label || role.name}</p>
            {role.isSystem ? <Badge variant="secondary">system</Badge> : null}
            {fullAccess ? <Badge variant="outline">full access</Badge> : null}
          </div>
          <p className="text-muted-foreground truncate text-sm">
            <code className="text-xs">{role.name}</code>
            {description ? ` · ${description}` : null}
          </p>
        </div>
      </div>

      {fullAccess ? (
        <p className="text-muted-foreground border-border-strong rounded-md border border-dashed p-3 text-sm leading-6">
          <span className="text-foreground font-medium">This role grants everything.</span> Full
          access is a flag on the role, not a permission in the matrix, so it cannot be assigned or
          revoked here — and it covers permissions added in future releases automatically.
        </p>
      ) : (
        <>
          {!role.isSystem ? (
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label className="text-subtle-foreground text-[11px] font-black uppercase tracking-[0.18em]">
                  Display name
                </Label>
                <Input value={label} onChange={(e) => setLabel(e.target.value)} disabled={readOnly} />
              </div>
              <div className="space-y-2">
                <Label className="text-subtle-foreground text-[11px] font-black uppercase tracking-[0.18em]">
                  Description
                </Label>
                <Input
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  disabled={readOnly}
                />
              </div>
            </div>
          ) : null}
          <div className="space-y-5">
            {groupEntries.map(([resource, defs]) => (
              <div key={resource} className="space-y-2">
                <Label className="text-subtle-foreground text-[11px] font-black uppercase tracking-[0.18em]">
                  {resource}
                </Label>
                  <OptionGrid
                    label={resource}
                    multiple
                    showCheckbox
                    columns={3}
                    options={defs.map((d) => ({
                      value: d.key,
                      label: d.label,
                      description: d.isSystem ? (d.description ?? undefined) : "not yet enforced",
                    }))}
                    value={defs.filter((d) => selected.has(d.key)).map((d) => d.key)}
                    onChange={(next) => {
                      // Each grid owns only its own group's keys, so merge with
                      // the rest of the selection instead of replacing it.
                      const owned = new Set(defs.map((d) => d.key))
                      setSelected((prev) => {
                        const merged = new Set([...prev].filter((k) => !owned.has(k)))
                        for (const k of next) merged.add(k)
                        return merged
                      })
                    }}
                    disabled={readOnly}
                  />
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
