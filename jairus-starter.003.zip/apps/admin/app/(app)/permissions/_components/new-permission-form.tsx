"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { Button, Input, Label, toast } from "@app/ui"
import { createPermission } from "../actions"

export function NewPermissionForm() {
  const router = useRouter()
  const [key, setKey] = useState("")
  const [label, setLabel] = useState("")
  const [resource, setResource] = useState("")
  const [pending, start] = useTransition()

  function submit() {
    start(async () => {
      const res = await createPermission({ key, label, resource })
      if (res.error) {
        toast.error(res.error)
        return
      }
      toast.success("Permission created")
      // Navigate with the key the SERVER produced. Re-deriving the slug here
      // would drift from slugKey() and land the user on the wrong row.
      if (res.key) router.push(`/permissions?key=${encodeURIComponent(res.key)}`)
    })
  }

  return (
    <div className="space-y-4">
      <div className="grid gap-2">
        <Label>Permission key</Label>
        <Input value={key} onChange={(e) => setKey(e.target.value)} placeholder="reports:export" />
        <p className="text-muted-foreground text-xs">
          Form <code className="text-xs">resource:action</code>. Nothing enforces this key until a
          developer calls <code className="text-xs">can()</code> with it.
        </p>
      </div>
      <div className="grid gap-2">
        <Label>Display name</Label>
        <Input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Export reports" />
      </div>
      <div className="grid gap-2">
        <Label>Resource group</Label>
        <Input value={resource} onChange={(e) => setResource(e.target.value)} placeholder="reports" />
        <p className="text-muted-foreground text-xs">Leave blank to use the part before the colon.</p>
      </div>
      <Button onClick={submit} disabled={pending || !key.trim()}>
        {pending ? "Creating…" : "Create permission"}
      </Button>
    </div>
  )
}
