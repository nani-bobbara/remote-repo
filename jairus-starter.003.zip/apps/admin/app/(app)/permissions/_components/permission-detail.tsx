"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { Trash2 } from "lucide-react"
import {
  Avatar,
  AvatarFallback,
  Badge,
  Button,
  Input,
  Label,
  toast,
  useRegisterWorkspaceActions,
} from "@app/ui"
import { deletePermission, savePermission } from "../actions"

type PermissionDef = {
  key: string
  label: string
  description: string | null
  resource: string
  isSystem: boolean
}

export function PermissionDetail({
  permission,
  canWrite,
}: {
  permission: PermissionDef
  canWrite: boolean
}) {
  const router = useRouter()
  const [mode, setMode] = useState<"display" | "edit">("display")
  const [label, setLabel] = useState(permission.label)
  const [description, setDescription] = useState(permission.description ?? "")
  const [resource, setResource] = useState(permission.resource)
  const [pending, start] = useTransition()

  const readOnly = !canWrite || mode === "display"
  const dirty =
    label !== permission.label ||
    description !== (permission.description ?? "") ||
    resource !== permission.resource

  function reset() {
    setLabel(permission.label)
    setDescription(permission.description ?? "")
    setResource(permission.resource)
  }

  function save() {
    start(async () => {
      const res = await savePermission({ key: permission.key, label, description, resource })
      if (res.error) {
        toast.error(res.error)
        return
      }
      toast.success("Permission saved")
      setMode("display")
    })
  }

  function remove() {
    start(async () => {
      const res = await deletePermission(permission.key)
      if (res.error) {
        toast.error(res.error)
        return
      }
      toast.success("Permission deleted")
      router.push("/permissions")
    })
  }

  useRegisterWorkspaceActions(
    !canWrite
      ? null
      : mode === "edit"
        ? {
            mode: "edit",
            onSave: save,
            onCancel: () => {
              reset()
              setMode("display")
            },
            saveDisabled: !dirty,
            savePending: pending,
            saveLabel: "Save permission",
          }
        : { mode: "display", onEdit: () => setMode("edit"), editLabel: "Edit permission" }
  )

  return (
    <div className="space-y-7 p-6">
      <div className="flex items-center gap-4">
        <Avatar className="size-14">
          <AvatarFallback className="text-base font-semibold">
            {permission.resource.slice(0, 2).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <p className="truncate text-xl font-semibold tracking-tight">
              {label || permission.key}
            </p>
            {permission.isSystem ? (
              <Badge variant="secondary">enforced</Badge>
            ) : (
              <Badge variant="outline">not yet enforced</Badge>
            )}
          </div>
          <p className="text-muted-foreground truncate text-sm">
            <code className="text-xs">{permission.key}</code>
            {` · ${permission.resource}`}
          </p>
        </div>
      </div>

      <p className="text-muted-foreground border-border-strong rounded-md border border-dashed p-3 text-sm leading-6">
        {permission.isSystem ? (
          <>
            <span className="text-foreground font-medium">A code path checks this key.</span> The
            key itself can&apos;t be changed or deleted, but its display name, description and
            grouping can — those are yours to curate and a redeploy will not overwrite them.
          </>
        ) : (
          <>
            <span className="text-foreground font-medium">Nothing enforces this key yet.</span> No
            code calls <code className="text-xs">can()</code> with it, so assigning it to a role
            grants nothing. It becomes live when a developer ships a check for it.
          </>
        )}
      </p>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <Label className="text-subtle-foreground text-[11px] font-black uppercase tracking-[0.18em]">
            Display name
          </Label>
          <Input value={label} onChange={(e) => setLabel(e.target.value)} disabled={readOnly} />
        </div>
        <div className="space-y-2">
          <Label className="text-subtle-foreground text-[11px] font-black uppercase tracking-[0.18em]">
            Resource group
          </Label>
          <Input
            value={resource}
            onChange={(e) => setResource(e.target.value)}
            disabled={readOnly}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label className="text-subtle-foreground text-[11px] font-black uppercase tracking-[0.18em]">
          Description
        </Label>
        <Input
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          disabled={readOnly}
        />
      </div>

      {canWrite && !permission.isSystem ? (
        <div className="space-y-2">
          <Label className="text-subtle-foreground text-[11px] font-black uppercase tracking-[0.18em]">
            Danger zone
          </Label>
          <div className="border-destructive/30 bg-destructive/5 flex items-center justify-between gap-4 rounded-md border p-3">
            <p className="text-muted-foreground text-sm">
              Removes the key from the catalog. Refused while any role still holds it.
            </p>
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={remove}
              disabled={pending}
              title="Delete permission"
              aria-label="Delete permission"
            >
              <Trash2 />
            </Button>
          </div>
        </div>
      ) : null}
    </div>
  )
}
