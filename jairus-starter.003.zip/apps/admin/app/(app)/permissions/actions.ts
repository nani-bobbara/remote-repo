"use server"

import { revalidatePath } from "next/cache"
import { requirePermission } from "@app/auth"
import { PERMISSIONS } from "@app/domain"
import { dbPort } from "@app/adapters/db"

/** Permission keys are 'resource:action' — lowercase, colon-separated. */
const slugKey = (s: string) =>
  s.trim().toLowerCase().replace(/[^a-z0-9:_]+/g, "_").replace(/^[_:]+|[_:]+$/g, "")

const slugResource = (s: string) =>
  s.trim().toLowerCase().replace(/[^a-z0-9_]+/g, "_").replace(/^_+|_+$/g, "")

// Returns the slugged key on success so the caller can navigate to the row it
// actually created. The client must NOT re-derive the slug — duplicating this
// transform is how a redirect ends up pointing at a key that does not exist.
export async function createPermission(input: {
  key: string
  label: string
  resource: string
}): Promise<{ error?: string; key?: string }> {
  await requirePermission(PERMISSIONS.PERMISSIONS_WRITE)
  const key = slugKey(input.key)
  if (!key) return { error: "A permission key is required" }
  if (!key.includes(":")) return { error: "Use the form resource:action, e.g. reports:export" }

  const existing = await dbPort.permissions.list()
  if (existing.some((p) => p.key === key)) return { error: "That permission key already exists" }

  await dbPort.permissions.upsert({
    key,
    label: input.label.trim() || key,
    description: null,
    resource: slugResource(input.resource) || (key.split(":")[0] ?? "custom"),
    // Admin-created keys are never system: no code calls can() with them yet.
    isSystem: false,
  })
  revalidatePath("/permissions")
  revalidatePath("/roles")
  return { key }
}

export async function savePermission(input: {
  key: string
  label: string
  description: string
  resource: string
}): Promise<{ error?: string }> {
  await requirePermission(PERMISSIONS.PERMISSIONS_WRITE)
  const all = await dbPort.permissions.list()
  const existing = all.find((p) => p.key === input.key)
  if (!existing) return { error: "Permission not found" }

  await dbPort.permissions.upsert({
    key: existing.key,
    label: input.label.trim() || existing.key,
    description: input.description.trim() || null,
    resource: slugResource(input.resource) || existing.resource,
    // Preserved, never taken from the client: only the seed may set this.
    isSystem: existing.isSystem,
  })
  revalidatePath("/permissions")
  revalidatePath("/roles")
  return {}
}

export async function deletePermission(key: string): Promise<{ error?: string }> {
  await requirePermission(PERMISSIONS.PERMISSIONS_WRITE)
  const all = await dbPort.permissions.list()
  const existing = all.find((p) => p.key === key)
  if (!existing) return { error: "Permission not found" }
  if (existing.isSystem) return { error: "Enforced permissions can't be deleted" }

  // The database already refuses this: role_permission.permission_key is
  // ON DELETE RESTRICT, so a delete of an assigned key raises 23001. This check
  // exists only to turn that into an actionable message naming the roles,
  // instead of surfacing a raw constraint violation. Integrity does not depend
  // on it — do not remove the FK on the assumption that this covers it.
  const roles = await dbPort.roles.list()
  const inUse = roles.filter((r) => r.permissions.includes(key)).map((r) => r.label)
  if (inUse.length) {
    return { error: `Still assigned to: ${inUse.join(", ")}. Unassign it first.` }
  }

  await dbPort.permissions.remove(key)
  revalidatePath("/permissions")
  revalidatePath("/roles")
  return {}
}
