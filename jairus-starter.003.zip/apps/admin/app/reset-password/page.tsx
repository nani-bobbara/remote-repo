import { Suspense } from "react"
import Link from "next/link"
import { ShieldCheck } from "lucide-react"
import { brand } from "@app/config/brand"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@app/ui"
import { NewPasswordForm } from "../_components/new-password-form"

export default function ResetPasswordPage() {
  return (
    <main className="bg-background grid min-h-dvh lg:grid-cols-2">
      <section className="bg-muted/20 relative hidden overflow-hidden lg:flex lg:items-center lg:justify-center">
        <div className="relative z-10 flex items-center gap-4">
          <span className="bg-primary/10 text-primary flex size-16 items-center justify-center rounded-2xl border border-primary/20">
            <ShieldCheck className="size-8" />
          </span>
          <div>
            <p className="text-4xl font-bold tracking-tight">{brand.name}</p>
            <p className="text-primary mt-1 text-sm font-semibold uppercase tracking-[0.22em]">Admin console</p>
          </div>
        </div>
        <div className="bg-primary/5 pointer-events-none absolute -left-32 -top-32 size-96 rounded-full blur-3xl" />
        <div className="bg-primary/5 pointer-events-none absolute -bottom-40 -right-24 size-96 rounded-full blur-3xl" />
      </section>

      <section className="flex items-center justify-center px-6 py-12 sm:px-10 lg:px-16">
        <div className="w-full max-w-sm">
          <div className="mb-8">
            <h1 className="text-3xl font-bold tracking-tight">Choose a new password</h1>
            <p className="text-muted-foreground mt-2 text-sm">This signs out your other sessions.</p>
          </div>
          <Card className="w-full shadow-sm">
            <CardHeader className="gap-2">
              <CardTitle>New password</CardTitle>
              <CardDescription>At least 8 characters.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4">
              {/* useSearchParams needs a Suspense boundary to keep the route
                  from opting the whole page into client-side rendering. */}
              <Suspense fallback={null}>
                <NewPasswordForm />
              </Suspense>
              <Link href="/forgot-password" className="text-muted-foreground hover:text-foreground text-sm underline-offset-4 hover:underline">
                Request a new link
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>
    </main>
  )
}
