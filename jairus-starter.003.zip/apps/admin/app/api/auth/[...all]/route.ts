import { authHandler } from '@app/auth'

// The admin console is invite-only: staff accounts are created on the Staff
// screen. Account-creating endpoints are closed here rather than via
// `emailAndPassword.disableSignUp`, which Better Auth checks inside the
// endpoint handler and would also block createStaff().
const BLOCKED = [
  /^\/api\/auth\/sign-up(\/|$)/,
  /^\/api\/auth\/sign-in\/social(\/|$)/,
  /^\/api\/auth\/callback(\/|$)/,
]

const isBlocked = (url: string) => BLOCKED.some((re) => re.test(new URL(url).pathname))
const notFound = () => Response.json({ error: 'Not found' }, { status: 404 })

export async function GET(req: Request) {
  return isBlocked(req.url) ? notFound() : authHandler.GET(req)
}

export async function POST(req: Request) {
  return isBlocked(req.url) ? notFound() : authHandler.POST(req)
}
