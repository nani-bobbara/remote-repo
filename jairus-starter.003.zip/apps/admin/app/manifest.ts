import type { MetadataRoute } from "next"
import { brand } from "@app/config/brand"

// PWA manifest — makes the app installable and run standalone (native-app feel).
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: `${brand.name} Admin`,
    short_name: `${brand.name} Admin`,
    description: `${brand.name} back-office`,
    start_url: "/",
    display: "standalone",
    background_color: "#ffffff",
    theme_color: "#ffffff",
    icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml" }],
  }
}
