"use client"

import { authClient } from "@app/auth/client"
import { RequestPasswordResetForm } from "@app/ui"

export function RequestResetForm() {
  return <RequestPasswordResetForm requestReset={authClient.requestPasswordReset} />
}
