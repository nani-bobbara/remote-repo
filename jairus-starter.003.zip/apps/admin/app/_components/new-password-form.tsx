"use client"

import { useRouter } from "next/navigation"
import { useSearchParams } from "next/navigation"

import { authClient } from "@app/auth/client"
import { ResetPasswordForm, toast } from "@app/ui"

export function NewPasswordForm() {
  const router = useRouter()
  const params = useSearchParams()

  return (
    <ResetPasswordForm
      token={params.get("token")}
      error={params.get("error")}
      resetPassword={authClient.resetPassword}
      onDone={() => {
        toast.success("Password updated. Sign in with your new password.")
        router.push("/sign-in")
      }}
    />
  )
}
