"use client"

import { useRouter } from "next/navigation"
import { signOut } from "@app/auth/client"
import { Button } from "@app/ui"

export function SignOutButton() {
  const router = useRouter()
  return (
    <Button
      variant="outline"
      onClick={async () => {
        await signOut()
        router.push("/")
        router.refresh()
      }}
    >
      Sign out
    </Button>
  )
}
