// OpenTelemetry bootstrap — Next.js auto-loads this file on server start.
// Flag-gated: OBSERVABILITY_ENABLED=false emits nothing (zero overhead).
// Vendor-neutral OTLP — point OTEL_EXPORTER_OTLP_ENDPOINT at any collector
// (Grafana, Honeycomb, a local otel-collector). No backend lock-in.
export async function register() {
  if (process.env.OBSERVABILITY_ENABLED !== 'true') return
  const { registerOTel } = await import('@vercel/otel')
  registerOTel({ serviceName: process.env.OTEL_SERVICE_NAME ?? 'portal' })
}
