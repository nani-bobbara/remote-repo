import { NextResponse, type NextRequest } from "next/server"
import { hasSessionCookie } from "@app/auth/edge"

// Outer bounce for signed-out requests. Cookie presence only —
// `(app)/layout.tsx` resolves the real session and blocks staff accounts.
export function middleware(request: NextRequest) {
  if (hasSessionCookie(request)) return NextResponse.next()

  const url = request.nextUrl.clone()
  url.pathname = "/sign-in"
  url.search = ""
  return NextResponse.redirect(url)
}

export const config = {
  // Membership area only; landing, auth pages and the Stripe webhook are public.
  matcher: ["/dashboard/:path*", "/profile/:path*", "/settings/:path*"],
}
