import Link from "next/link"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@app/ui"
import { SignUpForm } from "../_components/sign-up-form"

export default function SignUpPage() {
  return (
    <main className="flex min-h-dvh items-center justify-center px-6">
      <Card className="w-full max-w-sm">
        <CardHeader>
          <CardTitle>Create your account</CardTitle>
          <CardDescription>Start your free account in seconds.</CardDescription>
        </CardHeader>
        <CardContent>
          <SignUpForm />
          <p className="text-muted-foreground mt-4 text-center text-sm">
            Already have an account?{" "}
            <Link href="/sign-in" className="text-foreground underline underline-offset-4">
              Sign in
            </Link>
          </p>
        </CardContent>
      </Card>
    </main>
  )
}
