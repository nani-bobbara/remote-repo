"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"

import { authClient, useSession } from "@app/auth/client"
import {
  Button,
  Input,
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  toast,
} from "@app/ui"

const schema = z.object({ name: z.string().min(1, "Required") })
type Values = z.infer<typeof schema>

export function ProfileForm() {
  const { data } = useSession()
  const [pending, setPending] = useState(false)
  const form = useForm<Values>({
    resolver: zodResolver(schema),
    values: { name: data?.user?.name ?? "" },
  })

  async function onSubmit(values: Values) {
    setPending(true)
    const { error } = await authClient.updateUser({ name: values.name })
    setPending(false)
    if (error) {
      toast.error(error.message ?? "Update failed")
      return
    }
    toast.success("Profile updated")
  }

  return (
    <Form {...form}>
      {/* Without method="post" a pre-hydration submit falls back to a native
          GET, navigating away and echoing the field into the URL. */}
      <form method="post" onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Name</FormLabel>
              <FormControl>
                <Input placeholder="Your name" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button type="submit" disabled={pending} className="w-fit">
          {pending ? "Saving…" : "Save"}
        </Button>
      </form>
    </Form>
  )
}
