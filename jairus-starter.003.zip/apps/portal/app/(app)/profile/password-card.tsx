"use client"

import { authClient } from "@app/auth/client"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  ChangePasswordForm,
} from "@app/ui"

// Thin client wrapper: the page is a server component and cannot hand
// authClient.changePassword to the shared form directly. Same form the admin
// console uses — self-service password change is not role-dependent.
export function PasswordCard({ hasPassword }: { hasPassword: boolean }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Password</CardTitle>
        <CardDescription>Changing it signs out your other sessions.</CardDescription>
      </CardHeader>
      <CardContent>
        <ChangePasswordForm hasPassword={hasPassword} changePassword={authClient.changePassword} />
      </CardContent>
    </Card>
  )
}
