"use client"

import { useTransition } from "react"
import { Button, toast } from "@app/ui"
import type { PlanTier } from "@app/domain"
import { startCheckout } from "../actions"

export function UpgradeButton({ tier, label }: { tier: PlanTier; label: string }) {
  const [pending, start] = useTransition()
  return (
    <Button
      disabled={pending}
      onClick={() =>
        start(async () => {
          const res = await startCheckout(tier)
          // On success the action redirects; only a failure returns here.
          if (res?.error) toast.error(res.error)
        })
      }
    >
      {pending ? "Redirecting…" : label}
    </Button>
  )
}
