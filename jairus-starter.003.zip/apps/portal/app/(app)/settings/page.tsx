import { getSession } from "@app/auth"
import type { PlanTier } from "@app/domain"
import {
  Badge,
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
} from "@app/ui"
import { UpgradeButton } from "./_components/upgrade-button"
import { getPlan } from "../_lib/get-plan"

export const dynamic = "force-dynamic"

const RANK: Record<PlanTier, number> = { free: 0, basic: 1, pro: 2 }
const LABEL: Record<PlanTier, string> = { free: "Free", basic: "Basic", pro: "Pro" }

export default async function SettingsPage({
  searchParams,
}: {
  searchParams: Promise<{ upgraded?: string }>
}) {
  const session = await getSession()
  const plan: PlanTier = session ? await getPlan(session.userId) : "free"
  const { upgraded } = await searchParams

  const upgrades = (["basic", "pro"] as PlanTier[]).filter((t) => RANK[t] > RANK[plan])

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">Account and billing.</p>
      </div>

      {upgraded ? (
        <div className="border-primary/40 bg-primary/5 rounded-md border px-4 py-3 text-sm">
          Subscription updated — thanks! It may take a moment to reflect.
        </div>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle>Account</CardTitle>
          <CardDescription>Your sign-in email.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm">{session?.email}</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            Plan
            <Badge variant="secondary" className="capitalize">
              {plan}
            </Badge>
          </CardTitle>
          <CardDescription>Manage your subscription.</CardDescription>
        </CardHeader>
        <CardFooter className="gap-3">
          {upgrades.length > 0 ? (
            upgrades.map((t) => (
              <UpgradeButton key={t} tier={t} label={`Upgrade to ${LABEL[t]}`} />
            ))
          ) : (
            <p className="text-muted-foreground text-sm">You&apos;re on the top plan.</p>
          )}
        </CardFooter>
      </Card>
    </div>
  )
}
