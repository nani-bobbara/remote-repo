"use server"

import { redirect } from "next/navigation"
import { requireUser } from "@app/auth"
import { billing } from "@app/adapters/billing"
import type { PlanTier } from "@app/domain"

// Returns { error } if checkout can't start (e.g. Stripe not configured) so the
// client can toast it; on success it redirects to Stripe and never returns.
export async function startCheckout(
  tier: PlanTier
): Promise<{ error: string } | void> {
  const session = await requireUser()
  let url: string
  try {
    const res = await billing.createCheckout(session.userId, tier)
    url = res.url
  } catch (e) {
    return { error: e instanceof Error ? e.message : "Could not start checkout" }
  }
  redirect(url) // throws NEXT_REDIRECT — must stay outside the try/catch
}
