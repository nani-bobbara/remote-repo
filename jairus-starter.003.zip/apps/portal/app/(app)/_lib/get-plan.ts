import { cache } from "react"
import { dbPort } from "@app/adapters/db"
import { makeGetSubscription } from "@app/application"
import type { PlanTier } from "@app/domain"

// Cached per request: the shell layout and the page both read the plan, but this
// only queries the DB once per render (React cache dedupes by argument).
export const getPlan = cache(async (userId: string): Promise<PlanTier> => {
  const sub = await makeGetSubscription(dbPort)(userId)
  return sub?.tier ?? "free"
})
