import { getSession } from "@app/auth"
import { Card, CardHeader, CardTitle, CardDescription } from "@app/ui"
import { getPlan } from "../_lib/get-plan"

export const dynamic = "force-dynamic"

export default async function DashboardPage() {
  const session = await getSession()
  const plan = session ? await getPlan(session.userId) : "free"

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Welcome back{session ? `, ${session.email}` : ""}.</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <CardHeader>
            <CardDescription>Plan</CardDescription>
            <CardTitle className="capitalize">{plan}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Usage</CardDescription>
            <CardTitle>—</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Members</CardDescription>
            <CardTitle>1</CardTitle>
          </CardHeader>
        </Card>
      </div>
    </div>
  )
}
