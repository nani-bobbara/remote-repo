"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@app/ui"
import { navItems } from "./nav-items"

// Mobile bottom tab bar — key destinations, thumb-reachable, safe-area aware.
// Hidden on md+ (desktop uses the sidebar).
export function BottomTabs() {
  const pathname = usePathname()
  return (
    <nav
      className="bg-background fixed inset-x-0 bottom-0 z-40 flex border-t md:hidden"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      {navItems.map(({ href, label, icon: Icon }) => {
        const active = pathname === href || pathname.startsWith(href + "/")
        return (
          <Link
            key={href}
            href={href}
            className={cn(
              "flex flex-1 flex-col items-center justify-center gap-1 py-2 text-xs transition-colors",
              active ? "text-foreground font-medium" : "text-muted-foreground"
            )}
          >
            <Icon className="size-5" />
            {label}
          </Link>
        )
      })}
    </nav>
  )
}
