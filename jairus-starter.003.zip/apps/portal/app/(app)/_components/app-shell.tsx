import Link from "next/link"
import { brand } from "@app/config/brand"
import { Badge } from "@app/ui"
import { NavRail } from "./sidebar-nav"
import { UserMenu } from "./user-menu"
import { BottomTabs } from "./bottom-tabs"

export function AppShell({
  email,
  plan,
  children,
}: {
  email: string
  plan: string
  children: React.ReactNode
}) {
  return (
    <div className="flex min-h-dvh flex-col">
      <header
        className="bg-background sticky top-0 z-30 flex h-14 items-center gap-3 border-b px-4 sm:px-6"
        style={{ paddingTop: "env(safe-area-inset-top)" }}
      >
        <Link href="/dashboard" className="text-base font-semibold tracking-tight">
          {brand.name}
        </Link>
        <Badge variant="secondary" className="capitalize">
          {plan}
        </Badge>
        <div className="ml-auto">
          <UserMenu email={email} />
        </div>
      </header>

      <div className="flex flex-1">
        {/* Desktop: slim icon rail */}
        <aside className="hidden w-[76px] shrink-0 border-r py-3 md:block">
          <NavRail />
        </aside>
        {/* pb clears the mobile bottom tab bar */}
        <main className="mx-auto w-full max-w-5xl flex-1 p-4 pb-24 sm:p-6 md:pb-6">
          {children}
        </main>
      </div>

      {/* Mobile: native-style bottom key menu */}
      <BottomTabs />
    </div>
  )
}
