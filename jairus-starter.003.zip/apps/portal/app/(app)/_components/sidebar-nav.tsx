"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@app/ui"
import { navItems } from "./nav-items"

// Desktop slim icon rail (md+): icon over label, active pill.
export function NavRail() {
  const pathname = usePathname()
  return (
    <nav className="flex flex-col items-center gap-1 px-2">
      {navItems.map(({ href, label, icon: Icon }) => {
        const active = pathname === href || pathname.startsWith(href + "/")
        return (
          <Link
            key={href}
            href={href}
            className={cn(
              "flex w-full flex-col items-center gap-1 rounded-lg py-2 text-[11px] transition-colors",
              active
                ? "bg-accent text-accent-foreground font-medium"
                : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
            )}
          >
            <Icon className="size-5" />
            {label}
          </Link>
        )
      })}
    </nav>
  )
}
