import { LayoutDashboard, User, Settings, type LucideIcon } from "lucide-react"

export type NavItem = { href: string; label: string; icon: LucideIcon }

// Single source for the membership nav — shared by the desktop sidebar,
// the mobile bottom tab bar, and the mobile drawer.
export const navItems: NavItem[] = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/profile", label: "Profile", icon: User },
  { href: "/settings", label: "Settings", icon: Settings },
]
