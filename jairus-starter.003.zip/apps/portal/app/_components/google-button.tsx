"use client"

import { signIn } from "@app/auth/client"
import { Button } from "@app/ui"

export function GoogleButton({ label = "Continue with Google" }: { label?: string }) {
  return (
    <Button
      type="button"
      variant="outline"
      className="w-full"
      onClick={() => signIn.social({ provider: "google", callbackURL: "/dashboard" })}
    >
      {label}
    </Button>
  )
}
