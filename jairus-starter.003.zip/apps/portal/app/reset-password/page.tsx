import { Suspense } from "react"
import Link from "next/link"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@app/ui"
import { NewPasswordForm } from "../_components/new-password-form"

export default function ResetPasswordPage() {
  return (
    <main className="flex min-h-dvh items-center justify-center px-6">
      <Card className="w-full max-w-sm">
        <CardHeader>
          <CardTitle>Choose a new password</CardTitle>
          <CardDescription>At least 8 characters. This signs out your other sessions.</CardDescription>
        </CardHeader>
        <CardContent>
          {/* useSearchParams needs a Suspense boundary to keep the route from
              opting the whole page into client-side rendering. */}
          <Suspense fallback={null}>
            <NewPasswordForm />
          </Suspense>
          <p className="text-muted-foreground mt-4 text-center text-sm">
            <Link href="/forgot-password" className="text-foreground underline underline-offset-4">
              Request a new link
            </Link>
          </p>
        </CardContent>
      </Card>
    </main>
  )
}
