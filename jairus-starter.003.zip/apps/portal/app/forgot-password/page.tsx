import Link from "next/link"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@app/ui"
import { RequestResetForm } from "../_components/request-reset-form"

export default function ForgotPasswordPage() {
  return (
    <main className="flex min-h-dvh items-center justify-center px-6">
      <Card className="w-full max-w-sm">
        <CardHeader>
          <CardTitle>Forgot password</CardTitle>
          <CardDescription>We&apos;ll email you a link to set a new one.</CardDescription>
        </CardHeader>
        <CardContent>
          <RequestResetForm />
          <p className="text-muted-foreground mt-4 text-center text-sm">
            <Link href="/sign-in" className="text-foreground underline underline-offset-4">
              Back to sign in
            </Link>
          </p>
        </CardContent>
      </Card>
    </main>
  )
}
