"use client"
// Browser auth client — safe to import from client components.
// Defaults to the current origin, so the same client works for portal + admin.
import { createAuthClient } from "better-auth/react"

export const authClient = createAuthClient()
export const { signIn, signUp, signOut, useSession } = authClient
