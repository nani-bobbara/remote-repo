// Edge-safe helpers for middleware. Separate from ./index, which reaches the
// database adapter and Next's `headers()` — neither runs in the edge runtime.
import { getSessionCookie } from 'better-auth/cookies'

/** Cookie presence only: no signature, expiry or lookup check. A forged cookie
 *  passes, so treat this as a cheap filter, never as authorisation. */
export function hasSessionCookie(request: Request): boolean {
  return getSessionCookie(request) !== null
}
