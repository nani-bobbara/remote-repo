// The roles this platform ships with. Single definition site — no role id is
// written as a literal anywhere else in the codebase.
//
// Two user populations, governed differently:
//   Admin plane  — staff who run the platform. Permission-scoped: every screen
//                  and action checks can(session, PERMISSIONS.X).
//   Portal plane — subscribers who signed up. Ownership-scoped: pages check
//                  only that a session exists, and withUser bounds each query
//                  to that user's own rows.
// A portal role holding zero permissions is therefore correct, not an oversight.

/**
 * How a role's permissions are decided at seed time.
 *
 * This file deliberately names NO permission keys. `@app/config` is a leaf
 * package, so importing PERMISSIONS from @app/domain would invert the dependency
 * graph. Instead each role declares intent, and the seed — which lives in
 * @app/adapters and may depend on both — resolves it against the catalog
 * actually present in the database.
 */
export type RoleGrant =
  /** The fullAccess flag. Grants everything, including permissions added later. */
  | { kind: 'full-access' }
  /** admin:access plus every read permission in the catalog. Stays a mirror as the catalog grows. */
  | { kind: 'read-only-mirror' }
  /** No permissions at all. */
  | { kind: 'none' }

export type RoleSeed = {
  /** Stable id, stored in role.name and user.role. */
  id: string
  /** Display name shown in the admin UI. */
  label: string
  description: string
  grant: RoleGrant
}

/** Stable role ids. Reference these rather than writing the strings. */
export const ROLE_IDS = {
  ADMIN: 'admin',
  SUPPORT: 'support',
  PORTAL: 'regular',
} as const

/**
 * Assigned to anyone who signs up through the portal.
 *
 * This is also the `user.role` column default and Better Auth's defaultValue,
 * both of which import it from here. Changing this value means a migration to
 * alter the column default — it is not a code-only change.
 */
export const DEFAULT_PORTAL_ROLE: string = ROLE_IDS.PORTAL

/** The role the first admin user (from ADMIN_EMAIL) is promoted to at seed time. */
export const SUPERUSER_ROLE: string = ROLE_IDS.ADMIN

/**
 * Seeded on first insert only. Once an admin edits a role through the admin UI,
 * redeploying never overwrites it — same contract as the permission catalog's
 * curated labels.
 */
export const ROLE_SEEDS: RoleSeed[] = [
  {
    id: ROLE_IDS.ADMIN,
    label: 'Admin',
    description: 'Full control. Completes system setup and cannot be demoted or deleted.',
    grant: { kind: 'full-access' },
  },
  {
    id: ROLE_IDS.SUPPORT,
    label: 'Support',
    description: 'Read-only mirror of Admin. Can open every admin screen and change nothing.',
    grant: { kind: 'read-only-mirror' },
  },
  {
    id: ROLE_IDS.PORTAL,
    label: 'Portal User',
    description: 'Default for portal signups. Holds no permissions; bounded to their own data.',
    grant: { kind: 'none' },
  },
]
