import { DEFAULT_PALETTE, isPaletteId, type PaletteId } from './theme'

// Single source of brand identity. NEVER hardcode the product name or marketing
// copy anywhere else — import from here so every surface (shell, landing, page
// metadata, PWA manifest) stays consistent with one edit.
//
// Each value is an environment override with a sensible default, so a
// deployment can rebrand without a code change — set them in the Vercel
// dashboard per environment. A fresh clone works unconfigured.
//
// The NEXT_PUBLIC_ prefix is REQUIRED, not decorative. `brand` is imported by
// client components (apps/admin/.../admin-shell.tsx), and Next.js only inlines
// NEXT_PUBLIC_* into the client bundle. A bare BRAND_NAME would be the real
// value on the server and undefined on the client — the server would render the
// configured name, the client would hydrate the default, and React would report
// a hydration mismatch on the app header.

type BrandConfig = {
  name: string
  tagline: string
  description: string
  palette: PaletteId
}

/** Env value if it is set and non-blank, else the default. */
function env(value: string | undefined, fallback: string): string {
  const trimmed = value?.trim()
  return trimmed ? trimmed : fallback
}

export const brand: BrandConfig = {
  /** Product name shown in the shell/header, page titles and both PWA manifests. */
  name: env(process.env.NEXT_PUBLIC_BRAND_NAME, 'Acme'),

  /** Short marketing headline for the public landing hero. */
  tagline: env(process.env.NEXT_PUBLIC_BRAND_TAGLINE, 'Your SaaS starts here'),

  /** One-line description for the landing page, <meta> description and manifest. */
  description: env(
    process.env.NEXT_PUBLIC_BRAND_DESCRIPTION,
    'A production-ready starter — auth, billing, and a membership dashboard, ready to build on.',
  ),

  /**
   * Active design-token palette, stamped onto <html data-palette> by each app's
   * root layout so portal and admin always agree.
   *
   * Validated rather than cast: an unknown id matches no CSS selector and the
   * app renders with no tokens at all, whereas falling back here degrades to
   * the default palette. See @app/ui themes/ for what each looks like, or
   * preview them in the admin app under System Setup.
   */
  palette: isPaletteId(process.env.NEXT_PUBLIC_BRAND_PALETTE)
    ? process.env.NEXT_PUBLIC_BRAND_PALETTE
    : DEFAULT_PALETTE,
}
