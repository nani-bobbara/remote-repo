// DTOs — the shapes crossing the application boundary (input/output of use-cases).
import type { PlanTier, SubscriptionStatus } from '@app/domain'

export interface SubscriptionView {
  tier: PlanTier
  status: SubscriptionStatus
  currentPeriodEnd: Date | null
}
