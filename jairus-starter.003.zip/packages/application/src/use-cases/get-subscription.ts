// Example use-case: read the caller's own subscription.
// Runs through DbPort.withUser so the query is scoped to the caller. Follow this
// shape for every user-data read — it is the only thing enforcing ownership.
import type { DbPort } from '@app/domain'
import type { SubscriptionView } from '../dtos/index'

export function makeGetSubscription(db: DbPort) {
  return async function getSubscription(userId: string): Promise<SubscriptionView | null> {
    return db.withUser(userId, async (repos) => {
      const sub = await repos.subscriptions.getForUser(userId)
      if (!sub) return null
      return { tier: sub.tier, status: sub.status, currentPeriodEnd: sub.currentPeriodEnd }
    })
  }
}
