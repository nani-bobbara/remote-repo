"use client"

import * as React from "react"

/**
 * A vertical drag handle between two workspace columns. Reports the pointer
 * delta in px; the parent clamps and applies it. Desktop-only — panels stack on
 * mobile where dragging has no meaning.
 */
export function ResizeHandle({ onResize }: { onResize: (delta: number) => void }) {
  const isDragging = React.useRef(false)
  const lastX = React.useRef(0)

  const handleMouseDown = React.useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault()
      isDragging.current = true
      lastX.current = e.clientX

      const onMove = (ev: MouseEvent) => {
        if (!isDragging.current) return
        const delta = ev.clientX - lastX.current
        lastX.current = ev.clientX
        onResize(delta)
      }
      const onUp = () => {
        isDragging.current = false
        window.removeEventListener("mousemove", onMove)
        window.removeEventListener("mouseup", onUp)
      }
      window.addEventListener("mousemove", onMove)
      window.addEventListener("mouseup", onUp)
    },
    [onResize]
  )

  return (
    <div
      role="separator"
      aria-orientation="vertical"
      onMouseDown={handleMouseDown}
      className="bg-border hover:bg-primary group relative z-20 hidden w-px shrink-0 cursor-col-resize select-none transition-colors duration-150 md:block"
    >
      {/* Widened hit area so the 1px line is easy to grab. */}
      <div className="absolute inset-y-0 -left-1.5 -right-1.5" />
    </div>
  )
}
