"use client"

import * as React from "react"

export type WorkspaceMode = "display" | "edit"

/**
 * Header actions registered by client workspace content (an editor/form), so the
 * shared WorkspaceCardHeader renders one uniform toolbar driven by the content's
 * mode:
 *   display -> (page Refresh/Add) + Edit
 *   edit    -> Cancel + Save
 * Handlers are read via refs, so their identity need not be stable.
 */
export type WorkspaceRegisteredActions = {
  mode?: WorkspaceMode
  onEdit?: () => void
  onCancel?: () => void
  onSave?: () => void
  saveDisabled?: boolean
  savePending?: boolean
  saveLabel?: string
  editLabel?: string
  editDisabled?: boolean
}

type ContextValue = {
  actions: WorkspaceRegisteredActions
  register: (actions: WorkspaceRegisteredActions | null) => void
}

const WorkspaceActionsContext = React.createContext<ContextValue | null>(null)

export function WorkspaceActionsProvider({ children }: { children: React.ReactNode }) {
  const [actions, setActions] = React.useState<WorkspaceRegisteredActions>({})
  const register = React.useCallback((next: WorkspaceRegisteredActions | null) => {
    setActions(next ?? {})
  }, [])
  const value = React.useMemo(() => ({ actions, register }), [actions, register])
  return <WorkspaceActionsContext.Provider value={value}>{children}</WorkspaceActionsContext.Provider>
}

/** Read the registered toolbar (WorkspaceCardHeader). Returns {} outside a provider. */
export function useWorkspaceActions(): WorkspaceRegisteredActions {
  return React.useContext(WorkspaceActionsContext)?.actions ?? {}
}

/** Register the header toolbar for the current content. Pass null to clear. */
export function useRegisterWorkspaceActions(actions: WorkspaceRegisteredActions | null) {
  const ctx = React.useContext(WorkspaceActionsContext)
  const register = ctx?.register

  const editRef = React.useRef(actions?.onEdit)
  editRef.current = actions?.onEdit
  const cancelRef = React.useRef(actions?.onCancel)
  cancelRef.current = actions?.onCancel
  const saveRef = React.useRef(actions?.onSave)
  saveRef.current = actions?.onSave

  const visible = !!actions
  const mode = actions?.mode
  const hasEdit = !!actions?.onEdit
  const hasCancel = !!actions?.onCancel
  const hasSave = !!actions?.onSave
  const saveDisabled = actions?.saveDisabled ?? false
  const savePending = actions?.savePending ?? false
  const saveLabel = actions?.saveLabel
  const editLabel = actions?.editLabel
  const editDisabled = actions?.editDisabled ?? false

  React.useEffect(() => {
    if (!register) return
    if (!visible) {
      register(null)
      return
    }
    register({
      mode,
      onEdit: hasEdit ? () => editRef.current?.() : undefined,
      onCancel: hasCancel ? () => cancelRef.current?.() : undefined,
      onSave: hasSave ? () => saveRef.current?.() : undefined,
      saveDisabled,
      savePending,
      saveLabel,
      editLabel,
      editDisabled,
    })
    return () => register(null)
  }, [register, visible, mode, hasEdit, hasCancel, hasSave, saveDisabled, savePending, saveLabel, editLabel, editDisabled])
}
