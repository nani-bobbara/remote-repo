"use client"

import { useState } from "react"
import { Loader2 } from "lucide-react"

import { Button } from "@app/ui/components/ui/button"
import { Input } from "@app/ui/components/ui/input"
import { Label } from "@app/ui/components/ui/label"

type Result = { error?: { message?: string } | null }

/**
 * Step 1 — ask for a reset link.
 *
 * The confirmation is identical whether or not the address exists, matching
 * Better Auth's response: revealing which emails are registered turns this into
 * an account-enumeration endpoint.
 */
export function RequestPasswordResetForm({
  requestReset,
}: {
  requestReset: (input: { email: string; redirectTo: string }) => Promise<Result>
}) {
  const [email, setEmail] = useState("")
  const [pending, setPending] = useState(false)
  const [sent, setSent] = useState(false)

  if (sent) {
    return (
      <p className="text-muted-foreground text-sm">
        If that address has an account, a reset link is on its way. The link expires in an hour.
      </p>
    )
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!email.trim() || pending) return
    setPending(true)
    await requestReset({ email: email.trim(), redirectTo: "/reset-password" })
    setPending(false)
    setSent(true)
  }

  return (
    <form method="post" onSubmit={submit} className="grid gap-4">
      <div className="grid gap-2">
        <Label htmlFor="fp-email">Email</Label>
        <Input
          id="fp-email"
          type="email"
          autoComplete="email"
          placeholder="you@example.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </div>
      <Button type="submit" disabled={!email.trim() || pending}>
        {pending ? (
          <>
            <Loader2 className="size-4 animate-spin" /> Sending…
          </>
        ) : (
          "Send reset link"
        )}
      </Button>
    </form>
  )
}

/** Step 2 — choose a new password, reached from the emailed link. */
export function ResetPasswordForm({
  token,
  error,
  resetPassword,
  onDone,
}: {
  /** From `?token=`; absent when Better Auth rejected the link. */
  token: string | null
  /** From `?error=`, e.g. INVALID_TOKEN for an expired or reused link. */
  error: string | null
  resetPassword: (input: { newPassword: string; token: string }) => Promise<Result>
  onDone: () => void
}) {
  const [next, setNext] = useState("")
  const [confirm, setConfirm] = useState("")
  const [pending, setPending] = useState(false)
  const [failed, setFailed] = useState<string | null>(null)

  if (error || !token) {
    return (
      <p className="text-muted-foreground text-sm">
        This reset link is invalid or has expired. Request a new one to try again.
      </p>
    )
  }

  const tooShort = next.length > 0 && next.length < 8
  const mismatch = confirm.length > 0 && next !== confirm
  const ready = next.length >= 8 && next === confirm && !pending

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!ready || !token) return
    setPending(true)
    setFailed(null)
    const { error: err } = await resetPassword({ newPassword: next, token })
    setPending(false)
    if (err) {
      setFailed(err.message ?? "Could not reset password")
      return
    }
    onDone()
  }

  return (
    <form method="post" onSubmit={submit} className="grid gap-4">
      <div className="grid gap-2">
        <Label htmlFor="rp-new">New password</Label>
        <Input
          id="rp-new"
          type="password"
          autoComplete="new-password"
          value={next}
          onChange={(e) => setNext(e.target.value)}
        />
        {tooShort ? <p className="text-destructive text-sm">Use at least 8 characters.</p> : null}
      </div>
      <div className="grid gap-2">
        <Label htmlFor="rp-confirm">Confirm new password</Label>
        <Input
          id="rp-confirm"
          type="password"
          autoComplete="new-password"
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
        />
        {mismatch ? <p className="text-destructive text-sm">Passwords don&apos;t match.</p> : null}
      </div>
      {failed ? <p className="text-destructive text-sm">{failed}</p> : null}
      <Button type="submit" disabled={!ready}>
        {pending ? (
          <>
            <Loader2 className="size-4 animate-spin" /> Saving…
          </>
        ) : (
          "Set new password"
        )}
      </Button>
    </form>
  )
}
