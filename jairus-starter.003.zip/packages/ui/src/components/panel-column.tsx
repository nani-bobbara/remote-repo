import * as React from "react"

import { cn } from "@app/ui/lib/utils"

export type PanelTone = "surface" | "muted" | "bg"

const TONE_CLASS: Record<PanelTone, string> = {
  surface: "bg-card",
  muted: "bg-muted",
  bg: "bg-background",
}

/**
 * A single workspace column. Fixed pixel width on md+ (driven by the parent's
 * resize state via `--pw`), full-width with a capped height on mobile so a panel
 * can never dominate the viewport. Optional header row with a title + toolbar slot.
 *
 * Presentational — width and the collapse toggle live in `WorkspaceLayout`.
 */
export function PanelColumn({
  width,
  title,
  toolbar,
  tone = "surface",
  className,
  children,
}: {
  /** Pixel width — controlled by the parent's resize state. */
  width: number
  /** Optional label shown at the top of the panel. */
  title?: string
  /** Optional icon-button toolbar rendered to the right of the title. */
  toolbar?: React.ReactNode
  /** Background tone: surface (raised), muted (subdued), bg (base page). */
  tone?: PanelTone
  className?: string
  children: React.ReactNode
}) {
  const hasHeader = Boolean(title || toolbar)

  return (
    <div
      style={{ "--pw": `${width}px` } as React.CSSProperties}
      className={cn(
        "w-full max-h-[35vh] shrink-0 md:w-(--pw) md:max-h-none",
        "custom-scrollbar relative z-10 flex flex-col overflow-y-auto",
        TONE_CLASS[tone],
        className
      )}
    >
      {hasHeader ? (
        <div className="bg-muted flex h-10 shrink-0 items-center justify-between border-b px-4">
          {title ? (
            <span className="text-subtle-foreground truncate text-[11px] font-black uppercase tracking-[0.2em]">
              {title}
            </span>
          ) : (
            <div />
          )}
          {toolbar ? <div className="ml-2 flex shrink-0 items-center gap-1">{toolbar}</div> : null}
        </div>
      ) : null}
      <div className="min-h-0 w-[inherit] flex-1">{children}</div>
    </div>
  )
}
