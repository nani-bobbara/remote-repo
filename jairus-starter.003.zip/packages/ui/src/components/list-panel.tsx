"use client"

import * as React from "react"
import { Search } from "lucide-react"

import { Input } from "@app/ui/components/ui/input"
import { ListRow, type ListRowSize } from "@app/ui/components/list-row"
import { useLeftPanelCollapsed } from "@app/ui/components/panel-collapse-context"
import { cn } from "@app/ui/lib/utils"

export type ListPanelItem<T = unknown> = {
  id: string
  label: string
  /** A rendered element (`<Crown />`), not a component type — see ListRow. */
  icon?: React.ReactNode
  /** Link-based selection, for server-component pages. */
  href?: string
  meta?: string
  badge?: React.ReactNode
  active?: boolean
  /** Raw record, handed back via the panel's `onSelect` so callers keep their types. */
  data?: T
}

/**
 * The shared workspace list panel: a search box at the top (in place of a title),
 * then the rows. Used by every "Active <thing>" list so they can't drift — only
 * the data and the search placeholder vary. Rows are `ListRow`, the same control
 * the sidebar uses. When collapsed, search hides and rows go icon-only.
 */
export function ListPanel<T = unknown>({
  items,
  onSelect,
  searchPlaceholder = "Search…",
  emptyMessage = "No active items yet.",
  size = "sm",
  collapsed = false,
  footer,
  className,
}: {
  items: ListPanelItem<T>[]
  /**
   * Click handler for client-component pages. Receives the whole item, so
   * `item.data` comes back typed — `<ListPanel<Role> …>` yields a `Role`.
   * Server pages use `item.href` instead and omit this.
   */
  onSelect?: (item: ListPanelItem<T>) => void
  searchPlaceholder?: string
  emptyMessage?: string
  size?: ListRowSize
  collapsed?: boolean
  footer?: React.ReactNode
  className?: string
}) {
  const [query, setQuery] = React.useState("")
  // Collapse is owned by WorkspaceLayout; honor it (or an explicit prop) so the
  // panel goes icon-only when narrowed, matching the main sidebar.
  const ctxCollapsed = useLeftPanelCollapsed()
  const isCollapsed = collapsed || ctxCollapsed

  const visible = React.useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return items
    return items.filter((i) => i.label.toLowerCase().includes(q))
  }, [items, query])

  return (
    <div className={cn("flex h-full min-h-0 flex-col", className)}>
      {!isCollapsed ? (
        <div className="relative shrink-0 border-b p-3">
          <Search className="text-subtle-foreground pointer-events-none absolute left-6 top-1/2 size-4 -translate-y-1/2" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={searchPlaceholder}
            aria-label={searchPlaceholder}
            className="pl-9"
          />
        </div>
      ) : null}

      <div className="custom-scrollbar min-h-0 flex-1 overflow-y-auto py-1">
        {visible.length > 0 ? (
          visible.map((item) => (
            <ListRow
              key={item.id}
              label={item.label}
              icon={item.icon}
              meta={isCollapsed ? undefined : item.meta}
              badge={item.badge}
              active={item.active}
              href={item.href}
              onClick={onSelect ? () => onSelect(item) : undefined}
              size={size}
              collapsed={isCollapsed}
            />
          ))
        ) : (
          <div className="text-subtle-foreground flex h-full items-center justify-center px-4 text-center text-[11px]">
            {query ? "No matches." : emptyMessage}
          </div>
        )}
      </div>

      {footer && !isCollapsed ? <div className="shrink-0 border-t p-3">{footer}</div> : null}
    </div>
  )
}
