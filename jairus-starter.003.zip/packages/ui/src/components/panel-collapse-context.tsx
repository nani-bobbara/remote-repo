"use client"

import * as React from "react"

/**
 * Lets the left workspace panel's content (e.g. ListPanel) know when
 * WorkspaceLayout has collapsed it, so it can switch to icon-only mode without
 * the page having to thread the state through. Defaults to false, so a panel
 * used outside a WorkspaceLayout behaves normally.
 */
const LeftPanelCollapsedContext = React.createContext(false)

export const LeftPanelCollapsedProvider = LeftPanelCollapsedContext.Provider

export function useLeftPanelCollapsed(): boolean {
  return React.useContext(LeftPanelCollapsedContext)
}
