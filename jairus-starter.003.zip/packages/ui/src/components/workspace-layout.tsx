"use client"

import * as React from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"

import { cn } from "@app/ui/lib/utils"
import { PanelColumn } from "@app/ui/components/panel-column"
import { ResizeHandle } from "@app/ui/components/resize-handle"
import { WorkspaceCardHeader } from "@app/ui/components/workspace-card-header"
import { LeftPanelCollapsedProvider } from "@app/ui/components/panel-collapse-context"
import { WorkspaceActionsProvider } from "@app/ui/components/workspace-actions-context"

const MIN_PANEL_WIDTH = 160
const MAX_PANEL_WIDTH = 640
const COLLAPSED_WIDTH = 72

/**
 * The three-column workspace card — MachineControl's PageLayout, retokenized.
 *
 * A bordered card with an optional header bar and up to three columns:
 * left (collapsible + resizable), middle (resizable), and the main content.
 * The layout mode is inferred from which panels are passed:
 *   leftPanel + middlePanel -> three columns
 *   leftPanel only          -> two columns
 *   neither                 -> single column
 *
 * `"use client"` because it owns panel-width state, the collapse toggle, and the
 * drag handlers. Slots are `ReactNode`, so pages stay server components: they
 * render content server-side and pass it in. The workflow ribbon is NOT here —
 * it lives once in the shell (see ContextBar).
 */
export function WorkspaceLayout({
  cardIcon,
  cardTitle,
  cardSubtitle,
  cardActions,
  cardHeaderClassName,
  leftPanel,
  leftPanelTitle,
  leftPanelToolbar,
  leftPanelClassName,
  defaultLeftPanelWidth = 256,
  collapsibleLeftPanel = false,
  middlePanel,
  middlePanelTitle,
  middlePanelToolbar,
  middlePanelClassName,
  defaultMiddlePanelWidth = 320,
  contentClassName,
  className,
  children,
}: {
  cardIcon?: React.ReactNode
  cardTitle?: string
  cardSubtitle?: string
  cardActions?: React.ReactNode
  cardHeaderClassName?: string
  leftPanel?: React.ReactNode
  leftPanelTitle?: string
  leftPanelToolbar?: React.ReactNode
  leftPanelClassName?: string
  defaultLeftPanelWidth?: number
  collapsibleLeftPanel?: boolean
  middlePanel?: React.ReactNode
  middlePanelTitle?: string
  middlePanelToolbar?: React.ReactNode
  middlePanelClassName?: string
  defaultMiddlePanelWidth?: number
  contentClassName?: string
  className?: string
  children?: React.ReactNode
}) {
  const [isLeftCollapsed, setIsLeftCollapsed] = React.useState(false)
  const [leftWidth, setLeftWidth] = React.useState(defaultLeftPanelWidth)
  const [middleWidth, setMiddleWidth] = React.useState(defaultMiddlePanelWidth)

  const handleLeftResize = React.useCallback(
    (d: number) => {
      if (isLeftCollapsed) setIsLeftCollapsed(false)
      setLeftWidth((w) => Math.max(MIN_PANEL_WIDTH, Math.min(MAX_PANEL_WIDTH, w + d)))
    },
    [isLeftCollapsed]
  )
  const handleMiddleResize = React.useCallback(
    (d: number) => setMiddleWidth((w) => Math.max(MIN_PANEL_WIDTH, Math.min(MAX_PANEL_WIDTH, w + d))),
    []
  )

  // Header renders whenever there's identity/page-actions; registered edit/save
  // actions are read from context by the header itself.
  const hasCardHeader = Boolean(cardIcon || cardTitle || cardSubtitle || cardActions)
  const hasLeftPanel = Boolean(leftPanel)
  const hasMiddlePanel = Boolean(middlePanel) && hasLeftPanel
  const layoutMode = hasLeftPanel ? (hasMiddlePanel ? "three-column" : "two-column") : "single-column"

  return (
    <WorkspaceActionsProvider>
    <div
      className={cn(
        // Mobile: a tall card that grows with content (jairus mobile-native flow).
        // Desktop: fills the shell's fixed-height content column like MachineControl,
        // so only the inner columns scroll — no whole-page scroll.
        "bg-card relative flex min-h-[70dvh] w-full flex-col overflow-hidden rounded-xl border shadow-lg md:h-full md:min-h-0",
        // Desktop: open the bottom edge so the scrollable content reads as a
        // continuous channel ("scroll for more") rather than a closed box. The
        // card runs flush to the viewport bottom (main has md:pb-0). Mobile keeps
        // the fully-closed card since it page-scrolls.
        "md:rounded-b-none md:border-b-0",
        className
      )}
    >
      {hasCardHeader ? (
        <WorkspaceCardHeader
          cardIcon={cardIcon}
          cardTitle={cardTitle}
          cardSubtitle={cardSubtitle}
          cardActions={cardActions}
          className={cardHeaderClassName}
        />
      ) : null}

      <div className="flex h-full min-h-0 w-full flex-1 flex-col md:flex-row" data-layout={layoutMode}>
        {hasLeftPanel ? (
          <>
            <div
              className="group relative flex w-full shrink-0 flex-col transition-[width] duration-300 ease-in-out md:w-(--pw)"
              style={{ "--pw": `${isLeftCollapsed ? COLLAPSED_WIDTH : leftWidth}px` } as React.CSSProperties}
              data-collapsed={isLeftCollapsed ? "true" : "false"}
            >
              <PanelColumn
                width={isLeftCollapsed ? COLLAPSED_WIDTH : leftWidth}
                title={!isLeftCollapsed ? leftPanelTitle : undefined}
                toolbar={leftPanelToolbar}
                tone="surface"
                className={leftPanelClassName}
              >
                <div className="flex h-full w-full flex-col overflow-hidden">
                  {/* Collapsed: the expand toggle sits in a header row at the top of
                      the rail (matching MachineControl), with the icon list below —
                      instead of floating on the edge. */}
                  {collapsibleLeftPanel && isLeftCollapsed ? (
                    <div className="flex h-12 shrink-0 items-center justify-center border-b">
                      <button
                        type="button"
                        onClick={() => setIsLeftCollapsed(false)}
                        className="bg-card text-subtle-foreground hover:text-foreground flex size-7 items-center justify-center rounded-full border shadow-sm transition-colors"
                        title="Expand panel"
                        aria-label="Expand panel"
                      >
                        <ChevronRight className="size-4" />
                      </button>
                    </div>
                  ) : null}
                  <LeftPanelCollapsedProvider value={isLeftCollapsed}>{leftPanel}</LeftPanelCollapsedProvider>
                </div>
              </PanelColumn>

              {/* Expanded: collapse toggle floats on the panel's right edge (desktop
                  only). When collapsed, the toggle lives in the rail header above. */}
              {collapsibleLeftPanel && !isLeftCollapsed ? (
                <button
                  type="button"
                  onClick={() => setIsLeftCollapsed(true)}
                  className="bg-card text-subtle-foreground hover:text-foreground absolute -right-[14px] top-12 z-30 hidden size-7 items-center justify-center rounded-full border shadow-sm transition-colors md:flex"
                  title="Collapse panel"
                  aria-label="Collapse panel"
                >
                  <ChevronLeft className="size-4" />
                </button>
              ) : null}
            </div>
            <ResizeHandle onResize={handleLeftResize} />
          </>
        ) : null}

        {hasMiddlePanel ? (
          <>
            <PanelColumn
              width={middleWidth}
              title={middlePanelTitle}
              toolbar={middlePanelToolbar}
              tone="muted"
              className={middlePanelClassName}
            >
              {middlePanel}
            </PanelColumn>
            <ResizeHandle onResize={handleMiddleResize} />
          </>
        ) : null}

        <div
          className={cn(
            "bg-background custom-scrollbar relative min-h-0 min-w-0 flex-1 overflow-y-auto md:h-full",
            contentClassName
          )}
        >
          {children}
        </div>
      </div>
    </div>
    </WorkspaceActionsProvider>
  )
}
