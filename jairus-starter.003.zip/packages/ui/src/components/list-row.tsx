"use client"

import * as React from "react"
import Link from "next/link"

import { cn } from "@app/ui/lib/utils"

export type ListRowSize = "sm" | "md"

/**
 * One selectable row: icon + label, with the shared active treatment
 * (brand left-border, tinted fill, brand text).
 *
 * Used by the sidebar's nav sub-items AND by workspace list panels
 * (Active Roles, Active Staff), so the three stay visually identical.
 *
 * `collapsed` renders icon-only and centred — the row is never removed, matching
 * how both the sidebar and the left panel behave when narrowed.
 *
 * `icon` is a ReactNode (`<Crown />`), not a component type. React elements cross
 * the server→client boundary; component functions do not, so a server page could
 * never pass `icon={Crown}`. The wrapper sizes whatever svg it's given.
 *
 * Link is imported directly rather than injected, for the same reason.
 */
export function ListRow({
  label,
  icon,
  active = false,
  badge,
  meta,
  href,
  onClick,
  size = "sm",
  collapsed = false,
  className,
}: {
  label: string
  icon?: React.ReactNode
  active?: boolean
  badge?: React.ReactNode
  meta?: string
  href?: string
  onClick?: () => void
  size?: ListRowSize
  collapsed?: boolean
  className?: string
}) {
  const classes = cn(
    "flex w-full items-center rounded-r-md border-l-2 text-left transition-colors",
    collapsed ? "justify-center px-0" : "gap-2.5",
    !collapsed && (size === "sm" ? "px-3 py-2 text-sm" : "px-4 py-3 text-[15px]"),
    collapsed && (size === "sm" ? "py-2.5" : "py-3.5"),
    active
      ? "border-primary bg-primary/15 text-primary font-medium"
      : "text-muted-foreground hover:bg-accent hover:text-accent-foreground border-transparent",
    className
  )

  const iconSlot = icon ? (
    <span
      className={cn(
        "flex shrink-0 items-center justify-center",
        size === "sm" ? "[&>svg]:size-4" : "[&>svg]:size-5"
      )}
    >
      {icon}
    </span>
  ) : null

  const body = collapsed ? (
    (iconSlot ?? <span className="text-xs">{label.charAt(0)}</span>)
  ) : (
    <>
      {iconSlot}
      <span className="min-w-0 flex-1">
        <span className="block truncate">{label}</span>
        {meta ? <span className="text-muted-foreground block truncate text-xs">{meta}</span> : null}
      </span>
      {badge ? <span className="shrink-0">{badge}</span> : null}
    </>
  )

  if (href) {
    return (
      <Link href={href} aria-current={active ? "page" : undefined} className={classes} title={label}>
        {body}
      </Link>
    )
  }

  return (
    <button type="button" onClick={onClick} aria-current={active ? "page" : undefined} className={classes} title={label}>
      {body}
    </button>
  )
}
