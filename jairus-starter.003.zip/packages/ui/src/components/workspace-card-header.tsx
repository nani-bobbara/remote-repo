"use client"

import * as React from "react"
import { Loader2, Pencil, Save, X } from "lucide-react"

import { Button } from "@app/ui/components/ui/button"
import { useWorkspaceActions } from "@app/ui/components/workspace-actions-context"
import { cn } from "@app/ui/lib/utils"

/**
 * The workspace card's header: icon + title/subtitle on the left, one uniform
 * action toolbar on the right. The toolbar is mode-driven:
 *   display -> `cardActions` (page-level Refresh/Add) + Edit (if the content registered one)
 *   edit    -> Cancel + Save (registered by the content)
 * All actions are icon-only, `variant="outline" size="icon"`, evenly spaced.
 */
export function WorkspaceCardHeader({
  cardIcon,
  cardTitle,
  cardSubtitle,
  cardActions,
  className,
}: {
  cardIcon?: React.ReactNode
  cardTitle?: string
  cardSubtitle?: string
  /** Display-mode, page-level actions (Refresh/Add) as a fragment of icon buttons. Hidden in edit mode. */
  cardActions?: React.ReactNode
  className?: string
}) {
  const a = useWorkspaceActions()
  const editMode = a.mode === "edit"

  return (
    <div className={cn("bg-card flex h-14 shrink-0 items-center justify-between border-b px-6", className)}>
      <div className="flex min-w-0 items-center gap-3">
        {cardIcon ? (
          <div className="text-primary flex size-10 items-center justify-center [&_svg]:size-5">{cardIcon}</div>
        ) : null}
        {cardTitle || cardSubtitle ? (
          <div className="flex min-w-0 flex-col">
            {cardTitle ? (
              <h2 className="text-foreground truncate text-base font-bold tracking-wide">{cardTitle}</h2>
            ) : null}
            {cardSubtitle ? (
              <p className="text-muted-foreground mt-0.5 truncate text-[11px] leading-snug">{cardSubtitle}</p>
            ) : null}
          </div>
        ) : null}
      </div>

      <div className="flex shrink-0 items-center gap-2">
        {editMode ? (
          <>
            {a.onCancel ? (
              <Button type="button" variant="outline" size="icon" onClick={a.onCancel} title="Cancel" aria-label="Cancel">
                <X />
              </Button>
            ) : null}
            {a.onSave ? (
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={a.onSave}
                disabled={a.saveDisabled || a.savePending}
                title={a.saveLabel ?? "Save"}
                aria-label={a.saveLabel ?? "Save"}
              >
                {a.savePending ? <Loader2 className="animate-spin" /> : <Save />}
              </Button>
            ) : null}
          </>
        ) : (
          <>
            {cardActions}
            {a.onEdit ? (
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={a.onEdit}
                disabled={a.editDisabled}
                title={a.editLabel ?? "Edit"}
                aria-label={a.editLabel ?? "Edit"}
              >
                <Pencil />
              </Button>
            ) : null}
          </>
        )}
      </div>
    </div>
  )
}
