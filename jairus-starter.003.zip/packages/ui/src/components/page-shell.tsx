import * as React from "react"

import { cn } from "@app/ui/lib/utils"

export function PageShell({
  children,
  className,
}: {
  children: React.ReactNode
  className?: string
}) {
  return (
    <div className={cn("w-full space-y-6 md:flex md:min-h-0 md:flex-1 md:flex-col", className)}>
      {children}
    </div>
  )
}