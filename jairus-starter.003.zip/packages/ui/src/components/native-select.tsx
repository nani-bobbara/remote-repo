import * as React from "react"

import { cn } from "@app/ui/lib/utils"

/**
 * A native `<select>`, styled to match `Input`. The option list uses the same
 * popover tokens as DropdownMenu. Without them Chromium paints the list from
 * the select's own (transparent) background rather than the active palette.
 * Safari ignores option styling and falls back to `color-scheme`.
 *
 * Not in `components/ui/` — that folder is shadcn-generated and
 * `npx shadcn add select` would collide with the name.
 */
function NativeSelect({ className, children, ...props }: React.ComponentProps<"select">) {
  return (
    <select
      data-slot="native-select"
      className={cn(
        "dark:bg-input/30 border-input flex h-9 w-full min-w-0 rounded-md border bg-transparent px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
        "focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]",
        "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",
        "[&_option]:bg-popover [&_option]:text-popover-foreground [&_optgroup]:bg-popover [&_optgroup]:text-popover-foreground",
        className
      )}
      {...props}
    >
      {children}
    </select>
  )
}

export { NativeSelect }
