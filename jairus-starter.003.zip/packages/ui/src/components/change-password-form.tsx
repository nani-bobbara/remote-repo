"use client"

import { useState } from "react"
import { Loader2 } from "lucide-react"

import { toast } from "sonner"

import { Button } from "@app/ui/components/ui/button"
import { Input } from "@app/ui/components/ui/input"
import { Label } from "@app/ui/components/ui/label"

/**
 * Self-service password change, shared by both apps. Available to every
 * signed-in user: owning your credential is ownership-scoped, not a permission.
 *
 * `changePassword` is injected so this stays free of an auth dependency. All
 * enforcement is server-side in Better Auth; nothing here is a security control.
 */
export function ChangePasswordForm({
  hasPassword,
  changePassword,
}: {
  /** False for OAuth-only accounts, which have no password to change. */
  hasPassword: boolean
  changePassword: (input: {
    currentPassword: string
    newPassword: string
    revokeOtherSessions: boolean
  }) => Promise<{ error?: { message?: string } | null }>
}) {
  const [current, setCurrent] = useState("")
  const [next, setNext] = useState("")
  const [confirm, setConfirm] = useState("")
  const [pending, setPending] = useState(false)

  if (!hasPassword) {
    return (
      <p className="text-muted-foreground text-sm">
        You sign in with a connected account, so there is no password to change here.
      </p>
    )
  }

  // Mirrors Better Auth's minimum for feedback before the round-trip.
  const tooShort = next.length > 0 && next.length < 8
  const mismatch = confirm.length > 0 && next !== confirm
  const ready = current.length > 0 && next.length >= 8 && next === confirm && !pending

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!ready) return
    setPending(true)
    // Any session opened with the old password must die; the current one is
    // re-issued so this tab stays signed in.
    const { error } = await changePassword({
      currentPassword: current,
      newPassword: next,
      revokeOtherSessions: true,
    })
    setPending(false)
    if (error) {
      toast.error(error.message ?? "Could not change password")
      return
    }
    setCurrent("")
    setNext("")
    setConfirm("")
    toast.success("Password changed. Other sessions were signed out.")
  }

  return (
    <form method="post" onSubmit={submit} className="grid max-w-sm gap-4">
      <div className="grid gap-2">
        <Label htmlFor="cp-current">Current password</Label>
        <Input
          id="cp-current"
          type="password"
          autoComplete="current-password"
          value={current}
          onChange={(e) => setCurrent(e.target.value)}
        />
      </div>
      <div className="grid gap-2">
        <Label htmlFor="cp-new">New password</Label>
        <Input
          id="cp-new"
          type="password"
          autoComplete="new-password"
          value={next}
          onChange={(e) => setNext(e.target.value)}
        />
        {tooShort ? <p className="text-destructive text-sm">Use at least 8 characters.</p> : null}
      </div>
      <div className="grid gap-2">
        <Label htmlFor="cp-confirm">Confirm new password</Label>
        <Input
          id="cp-confirm"
          type="password"
          autoComplete="new-password"
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
        />
        {mismatch ? <p className="text-destructive text-sm">Passwords don&apos;t match.</p> : null}
      </div>
      <Button type="submit" disabled={!ready} className="justify-self-start">
        {pending ? (
          <>
            <Loader2 className="size-4 animate-spin" /> Changing…
          </>
        ) : (
          "Change password"
        )}
      </Button>
    </form>
  )
}
