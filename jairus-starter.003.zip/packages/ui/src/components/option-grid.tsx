"use client"

import * as React from "react"
import { Check } from "lucide-react"

import { cn } from "@app/ui/lib/utils"

export type OptionTone = "primary" | "success"

export type GridOption = {
  value: string
  label: string
  /** Optional second line, rendered muted under the label. */
  description?: string
  /** A rendered element (`<CheckCircle />`), not a component type. */
  icon?: React.ReactNode
  /** Colour applied when this option is selected. Defaults to brand. */
  tone?: OptionTone
  disabled?: boolean
}

const SELECTED_TONE: Record<OptionTone, string> = {
  primary: "border-primary bg-primary/15 text-primary",
  success: "border-success bg-success/15 text-success",
}

/**
 * A grid of selectable option chips — the shared control behind the Roles page's
 * permission matrix (multi-select, with checkboxes) and the Staff page's
 * Role / Status pickers (single-select).
 *
 * `value` is always an array so one component covers both modes; in single-select
 * a click emits `[clicked]`.
 */
export function OptionGrid({
  options,
  value,
  onChange,
  multiple = false,
  columns = 3,
  showCheckbox = false,
  disabled = false,
  label,
  className,
}: {
  options: GridOption[]
  value: string[]
  onChange?: (next: string[]) => void
  multiple?: boolean
  columns?: 2 | 3 | 4
  showCheckbox?: boolean
  /** Renders every chip non-interactive — used for derived, read-only state. */
  disabled?: boolean
  /** Accessible group label. */
  label?: string
  className?: string
}) {
  const selected = React.useMemo(() => new Set(value), [value])

  function handle(option: GridOption) {
    if (disabled || option.disabled || !onChange) return
    if (!multiple) {
      onChange([option.value])
      return
    }
    const next = new Set(selected)
    if (next.has(option.value)) next.delete(option.value)
    else next.add(option.value)
    onChange([...next])
  }

  return (
    <div
      role={multiple ? "group" : "radiogroup"}
      aria-label={label}
      className={cn(
        "grid gap-3",
        columns === 2 && "sm:grid-cols-2",
        columns === 3 && "sm:grid-cols-2 lg:grid-cols-3",
        columns === 4 && "sm:grid-cols-2 lg:grid-cols-4",
        className
      )}
    >
      {options.map((option) => {
        const isSelected = selected.has(option.value)
        const isDisabled = disabled || option.disabled
        return (
          <button
            key={option.value}
            type="button"
            role={multiple ? "checkbox" : "radio"}
            aria-checked={isSelected}
            disabled={isDisabled}
            onClick={() => handle(option)}
            className={cn(
              "flex items-center gap-2.5 rounded-md border px-4 py-3 text-left text-sm font-semibold transition-colors",
              "focus-visible:ring-ring focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2",
              isSelected
                ? SELECTED_TONE[option.tone ?? "primary"]
                : "border-border bg-card text-muted-foreground hover:bg-accent hover:text-accent-foreground",
              isDisabled ? "cursor-not-allowed opacity-60" : "cursor-pointer",
              "[&>svg]:size-4"
            )}
          >
            {showCheckbox ? (
              <span
                aria-hidden="true"
                className={cn(
                  "flex size-4 shrink-0 items-center justify-center rounded-[4px] border",
                  isSelected ? "border-primary bg-primary text-primary-foreground" : "border-border"
                )}
              >
                {isSelected ? <Check className="size-3" /> : null}
              </span>
            ) : null}
            {option.icon ? <span className="flex shrink-0 [&>svg]:size-4">{option.icon}</span> : null}
            <span className="flex min-w-0 flex-col items-start">
              <span className="min-w-0 truncate">{option.label}</span>
              {option.description ? (
                <span className="text-subtle-foreground min-w-0 truncate text-[11px]">
                  {option.description}
                </span>
              ) : null}
            </span>
          </button>
        )
      })}
    </div>
  )
}
