"use client"

import * as React from "react"
import Link from "next/link"

import { cn } from "@app/ui/lib/utils"

export type ChevronStep = {
  href: string
  label: string
  icon?: React.ComponentType<{ className?: string }>
}

// Chevron silhouette. The first step keeps a flat left edge; every later step
// carries the `14px 50%` vertex that bites around the previous step's point.
const STEP_CLIP =
  "[clip-path:polygon(0_0,calc(100%-18px)_0,100%_50%,calc(100%-18px)_100%,0_100%,14px_50%)]"
const STEP_CLIP_FIRST =
  "[clip-path:polygon(0_0,calc(100%-18px)_0,100%_50%,calc(100%-18px)_100%,0_100%)]"

/**
 * Presentational workflow ribbon. Knows nothing about routing or nav config —
 * the caller resolves which group is active and passes its steps in.
 *
 * Link is imported directly rather than injected — a function prop cannot cross
 * the server→client boundary.
 */
export function ChevronRibbon({
  eyebrow,
  eyebrowIcon: EyebrowIcon,
  steps,
  activeIndex,
  trailing,
  className,
}: {
  eyebrow: string
  eyebrowIcon?: React.ComponentType<{ className?: string }>
  steps: ChevronStep[]
  activeIndex: number
  trailing?: React.ReactNode
  className?: string
}) {
  return (
    <div
      className={cn(
        "bg-card no-scrollbar flex h-14 items-stretch overflow-x-auto rounded-xl border p-1",
        className
      )}
    >
      <div className="flex shrink-0 items-center border-r px-4 pr-5">
        <span className="text-foreground inline-flex items-center gap-2.5 whitespace-nowrap text-[11px] font-black uppercase tracking-[0.14em]">
          {EyebrowIcon ? <EyebrowIcon className="size-4" /> : null}
          <span>{eyebrow}</span>
        </span>
      </div>

      <div className="flex min-w-max items-center pl-3">
        {steps.map((step, index) => {
          const Icon = step.icon
          const state = index === activeIndex ? "active" : index < activeIndex ? "complete" : "pending"
          return (
            <Link
              key={step.href}
              href={step.href}
              aria-current={state === "active" ? "page" : undefined}
              aria-label={`Go to ${step.label}`}
              className={cn(
                "focus-visible:ring-ring focus-visible:ring-offset-background relative h-11 min-w-[132px] px-6 text-center text-[11px] font-bold tracking-[0.04em] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2",
                index === 0 ? STEP_CLIP_FIRST : cn(STEP_CLIP, "-ml-3"),
                state === "active" && "bg-primary text-primary-foreground hover:bg-primary/90 z-20",
                state === "complete" && "bg-primary/15 text-muted-foreground hover:bg-primary/25 z-10",
                state === "pending" && "bg-muted text-muted-foreground hover:bg-accent hover:text-accent-foreground z-0"
              )}
            >
              <span className="inline-flex h-full items-center justify-center gap-2 whitespace-nowrap">
                {Icon ? <Icon className="size-3.5" /> : null}
                <span className="truncate">{step.label}</span>
              </span>
            </Link>
          )
        })}
      </div>

      {/* pr-5 (20px) + outer p-1 (4px) = 24px right inset, matching the card header's px-6
          so the ribbon action(s) right-align with the page header actions below. */}
      {trailing ? <div className="ml-auto flex shrink-0 items-center border-l pl-3 pr-5">{trailing}</div> : null}
    </div>
  )
}
