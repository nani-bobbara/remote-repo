import * as React from "react"
import { Globe2 } from "lucide-react"

import { cn } from "@app/ui/lib/utils"

/**
 * Column-3 wrapper for non-preview pages: a padded, scrollable surface that
 * falls back to a centered empty state when it has no children — the
 * "Awaiting Selection" placeholder a stubbed workspace shows.
 */
export function ContentPane({
  children,
  emptyTitle = "Awaiting Selection",
  emptyDescription = "This workspace is ready — select or stage an item to begin.",
  noPadding = false,
  className,
}: {
  children?: React.ReactNode
  emptyTitle?: string
  emptyDescription?: string
  /** Remove default padding when the child manages its own layout. */
  noPadding?: boolean
  className?: string
}) {
  return (
    <div className={cn("custom-scrollbar h-full overflow-y-auto", !noPadding && "p-5 md:p-6", className)}>
      {children ?? (
        <div className="flex h-full items-center justify-center px-8 text-center">
          <div>
            <Globe2 className="text-subtle-foreground mx-auto size-11" />
            <div className="text-muted-foreground mt-4 text-[11px] font-bold uppercase tracking-[0.22em]">
              {emptyTitle}
            </div>
            <p className="text-muted-foreground mt-3 max-w-sm text-sm leading-relaxed">{emptyDescription}</p>
          </div>
        </div>
      )}
    </div>
  )
}
