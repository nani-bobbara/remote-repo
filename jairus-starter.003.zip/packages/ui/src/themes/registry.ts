import type { PaletteId } from "@app/config/theme"

/**
 * Display metadata for a palette. Deliberately free of React and of any CSS
 * import so it can be read from a server component, a node test, or (later) an
 * admin form without pulling the UI package's client runtime.
 */
type PaletteMeta = {
  /** Stable id. Matches the filename and the `data-palette` attribute value. */
  id: PaletteId
  /** Human-readable name. Shown wherever a person picks a palette. */
  label: string
  /** One line on the palette's character, to make a choice without previewing. */
  description: string
}

/**
 * The canonical palette list.
 *
 * Typed as `Record<PaletteId, PaletteMeta>` on purpose: adding an id to
 * `PaletteId` without adding it here is a compile error, so the registry can
 * never silently fall behind. `palette-parity.test.ts` closes the other side of
 * the loop by checking these ids against the CSS files actually on disk.
 */
export const PALETTES: Record<PaletteId, PaletteMeta> = {
  "neutral-zinc": {
    id: "neutral-zinc",
    label: "Neutral Zinc",
    description: "Stock shadcn greyscale. A brand-free starting point.",
  },
  "industrial-orange": {
    id: "industrial-orange",
    label: "Industrial Orange",
    description: "Safety-orange accents on deep navy-black. High-contrast, control-room feel.",
  },
  "midnight-indigo": {
    id: "midnight-indigo",
    label: "Midnight Indigo",
    description: "Indigo on cool slate. Calm and precise, suited to productivity and dev tools.",
  },
  "forest-emerald": {
    id: "forest-emerald",
    label: "Forest Emerald",
    description: "Deep emerald on warm stone with soft corners. Grounded, for finance or wellness.",
  },
  "terracotta-sand": {
    id: "terracotta-sand",
    label: "Terracotta Sand",
    description: "Burnt clay on warm paper with crisp corners. Editorial and crafted.",
  },
}

/** Stable-order list for rendering a picker. */
export const PALETTE_LIST: readonly PaletteMeta[] = Object.values(PALETTES)

// The runtime guard lives in @app/config/theme (isPaletteId), beside the id
// list it validates. Duplicating it here would mean two predicates that can
// disagree, and this package only imports the type from config — pulling in a
// function would promote @app/config from a devDependency to a dependency.
