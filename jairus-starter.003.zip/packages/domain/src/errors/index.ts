// Domain errors — thrown by use-cases, mapped to HTTP by the delivery layer.
export class DomainError extends Error {
  constructor(message: string, public readonly code: string) {
    super(message)
    this.name = new.target.name
  }
}
export class UnauthorizedError extends DomainError {
  constructor(msg = 'Authentication required') { super(msg, 'UNAUTHORIZED') }
}
export class ForbiddenError extends DomainError {
  constructor(msg = 'Forbidden') { super(msg, 'FORBIDDEN') }
}
export class NotFoundError extends DomainError {
  constructor(msg = 'Not found') { super(msg, 'NOT_FOUND') }
}
export class ValidationError extends DomainError {
  constructor(msg: string) { super(msg, 'VALIDATION_ERROR') }
}
