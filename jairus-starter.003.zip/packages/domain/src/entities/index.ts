// Domain entities — plain data shapes owned by the domain. No framework/vendor types.
import type { PlanTier } from '../value-objects/index'

// Roles are DATA, not a fixed enum — each app defines its own roles/permissions
// through the admin app as features evolve. A role holds a set of string
// permissions ('resource:action'), each of which must exist in the permission
// catalog — the `role_permission` join enforces that with a foreign key.
//
// Which roles ship by default is CONFIGURATION, not domain logic: see
// @app/config/roles. The domain defines only the shape and the check.
export interface RoleDef {
  name: string           // stable id, e.g. 'support'
  label: string          // display name, e.g. 'Support'
  description: string | null
  permissions: string[]  // every entry is a real permission.key (FK-enforced)
  /** Superuser. Grants everything, including permissions added later. */
  fullAccess: boolean
  isSystem: boolean      // seeded/protected: cannot be deleted or demoted
}

/**
 * Permission check — pure. A session carries its role's resolved permissions
 * plus its fullAccess flag.
 *
 * fullAccess replaced an earlier '*' sentinel stored inside the permissions
 * array. A sentinel cannot satisfy the foreign key that now guarantees every
 * stored permission is a real catalog key, and "can do everything" is a
 * property of the role rather than something assignable in the matrix.
 */
export function can(
  subject: { permissions: string[]; fullAccess?: boolean },
  permission: string,
): boolean {
  return subject.fullAccess === true || subject.permissions.includes(permission)
}

export const PERMISSIONS = {
  ADMIN_ACCESS: 'admin:access',   // may enter the admin app at all
  ROLES_READ: 'roles:read',
  ROLES_WRITE: 'roles:write',
  STAFF_READ: 'staff:read',
  STAFF_WRITE: 'staff:write',
  PERMISSIONS_READ: 'permissions:read',
  PERMISSIONS_WRITE: 'permissions:write',
} as const

/** A catalog row as stored in the `permission` table and read back. */
export interface PermissionDef {
  key: string
  label: string
  description: string | null
  /** Groups the permission matrix. Free-form; by convention the part before the colon. */
  resource: string
  /** true = a code path calls can() with this key. Written only by the seed. */
  isSystem: boolean
}

// Deriving a human-readable label from a key is presentation, not domain —
// see packages/adapters/src/db/permission-meta.ts, beside the seed that uses it.

export interface User {
  id: string
  email: string
  name: string | null
  role: string           // role name (see RoleDef)
  createdAt: Date
  emailVerified: boolean // false until the invite is accepted
  banned: boolean        // access revoked without deleting the account
}

/** Derived account state shown in the admin console. Not a stored column. */
export type UserStatus = 'active' | 'inactive' | 'invited'

export function userStatus(u: Pick<User, 'emailVerified' | 'banned'>): UserStatus {
  if (u.banned) return 'inactive'
  return u.emailVerified ? 'active' : 'invited'
}

// Tenancy is deliberately absent. The people who run the platform are STAFF
// throughout — the /staff route, the staff:read / staff:write permissions, and
// every identifier. "Team" is not used as a synonym anywhere; it would read as
// a group of portal users sharing data, which this template does not model.
//
// Adding real tenancy means a tenant table, membership, tenant-scoped RLS, and
// a tenant_id on every domain row — a feature, not a type. It gets designed
// when it is built rather than sitting here as an unbacked shape.

export type SubscriptionStatus = 'active' | 'trialing' | 'past_due' | 'canceled'

export interface Subscription {
  id: string
  userId: string
  tier: PlanTier
  status: SubscriptionStatus
  stripeCustomerId: string | null
  currentPeriodEnd: Date | null
}

// AuditLog was declared here with no table, no adapter and no consumer. An
// audit trail is a feature — it needs a table, a write path on every mutating
// action, retention rules, and an admin screen gated by its own permission
// (e.g. 'audit:read'). It gets designed when it is built, not left as a shape.
