// Value objects — small, validated, immutable. Pure (no external deps).

export type PlanTier = 'free' | 'basic' | 'pro'

// EmailAddress and Money used to live here with zero consumers. Both were
// superseded by the vendors this template already commits to: Better Auth
// validates and normalises email at the boundary, and Stripe is the source of
// truth for amounts and currency. Re-introducing them would mean two
// representations of the same fact.
//
// Add a value object here when the domain genuinely owns an invariant that no
// adapter enforces for it.
