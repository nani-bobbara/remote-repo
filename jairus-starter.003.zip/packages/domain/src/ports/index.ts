// Ports — abstract interfaces the application depends on. Adapters implement these.
// The domain depends on NOTHING; these are the seams that keep vendors swappable + testable.
import type { PermissionDef, RoleDef, Subscription, User } from '../entities/index'
import type { PlanTier } from '../value-objects/index'

// role = the user's role name; permissions = that role's resolved permissions (for can()).
export interface Session {
  userId: string
  email: string
  role: string
  permissions: string[]
  /** Mirrors the role's fullAccess flag; `can()` short-circuits on it. */
  fullAccess: boolean
}

// There is deliberately no AuthPort. Session resolution needs Next.js request
// headers, so it lives in @app/auth rather than behind a domain interface —
// see getSession() there. A port with no implementer and no caller is not a
// seam, it is a decoration.

/** Data access — user-scoped repositories (implemented by the Drizzle/Neon adapter). */
export interface UserRepo {
  findById(id: string): Promise<User | null>
  findByEmail(email: string): Promise<User | null>
  list(): Promise<User[]>                                  // admin/staff management (privileged path)
  setRole(userId: string, role: string): Promise<void>     // assign a role (staff management)
  setName(userId: string, name: string): Promise<void>     // update display name (self-service profile)
  /** Does this user sign in with a password, or only through an OAuth provider?
   *  Drives whether the profile screen offers a change-password form — an
   *  OAuth-only account has no credential to change. */
  hasCredential(userId: string): Promise<boolean>
}
export interface SubscriptionRepo {
  getForUser(userId: string): Promise<Subscription | null>
  upsert(sub: Omit<Subscription, 'id'>): Promise<Subscription>   // system path (webhook)
}
/** Role catalog — data-driven roles managed via the admin app. Not user-scoped. */
export interface RolesRepo {
  getByName(name: string): Promise<RoleDef | null>
  list(): Promise<RoleDef[]>
  upsert(role: RoleDef): Promise<RoleDef>
}
/** Permission catalog — the RBAC vocabulary. Not user-scoped, like RolesRepo. */
export interface PermissionsRepo {
  list(): Promise<PermissionDef[]>
  upsert(p: PermissionDef): Promise<PermissionDef>
  remove(key: string): Promise<void>
}
export interface DbPort {
  users: UserRepo
  subscriptions: SubscriptionRepo
  roles: RolesRepo
  permissions: PermissionsRepo
  /** Run a callback scoped to one user: gives repos whose queries are filtered
   *  to them, and publishes the user id as DB session context. */
  withUser<T>(userId: string, fn: (repos: DbPort) => Promise<T>): Promise<T>
}

/** Billing — checkout + subscription lifecycle (implemented by the Stripe adapter). */
export interface BillingPort {
  createCheckout(userId: string, tier: PlanTier): Promise<{ url: string }>
  parseWebhook(payload: string, signature: string): Promise<{ type: string; data: unknown }>
}

/** Email — transactional send (implemented by the Resend adapter). */
export interface EmailPort {
  send(message: EmailMessage): Promise<void>
}

export type EmailMessage = {
  to: string
  subject: string
  /** Always required: the plain-text part is what reaches clients that refuse
   *  HTML, and it keeps a message readable in logs. */
  text: string
  html?: string
}

/** AI — text generation (implemented by the Vercel AI SDK adapter; optional). */
export interface AiPort {
  generate(prompt: string): Promise<string>
}

/** Feature flags (optional). */
export interface FlagsPort {
  isEnabled(key: string, userId?: string): Promise<boolean>
}
