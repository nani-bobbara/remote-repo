import { defineConfig } from 'drizzle-kit'

// Single source of truth for migrations (drives both apps). Uses the admin/owner URL
// so DDL runs with full privileges; runtime queries use the scoped DATABASE_URL.
export default defineConfig({
  schema: './src/db/schema.ts',
  out: './drizzle',
  dialect: 'postgresql',
  dbCredentials: {
    url: process.env.DATABASE_URL_ADMIN ?? process.env.DATABASE_URL ?? '',
  },
})
