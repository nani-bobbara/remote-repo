// Email adapter — Resend, implements the domain EmailPort.
// Lazy-constructed client so importing this module is build-safe without a key.
import { Resend } from 'resend'
import type { EmailMessage, EmailPort } from '@app/domain'

// The value .env.example ships. Treated as unconfigured, otherwise a fresh
// clone looks configured and every send fails against Resend instead.
const PLACEHOLDER_KEY = 're_xxx'

function apiKey(): string | null {
  const key = process.env.RESEND_API_KEY?.trim()
  return key && key !== PLACEHOLDER_KEY ? key : null
}

let _resend: Resend | null = null
function resend(key: string): Resend {
  if (!_resend) _resend = new Resend(key)
  return _resend
}

export const email: EmailPort = {
  async send(message: EmailMessage) {
    // Without a key there is nothing to send through. In development the
    // message goes to the server log so flows that depend on a link (password
    // reset) remain testable; anywhere else a silent no-op would hide a broken
    // production setup, so it fails loudly instead.
    const key = apiKey()
    if (!key) {
      if (process.env.NODE_ENV === 'production') {
        throw new Error('RESEND_API_KEY is not configured — cannot send email')
      }
      console.warn(
        `\n[email] RESEND_API_KEY not configured; message not sent.\n` +
          `  to:      ${message.to}\n  subject: ${message.subject}\n\n${message.text}\n`,
      )
      return
    }

    const { error } = await resend(key).emails.send({
      from: process.env.EMAIL_FROM ?? 'noreply@example.com',
      to: message.to,
      subject: message.subject,
      text: message.text,
      ...(message.html ? { html: message.html } : {}),
    })
    // Resend reports failures in the response rather than throwing.
    if (error) throw new Error(`Email send failed: ${error.message}`)
  },
}
