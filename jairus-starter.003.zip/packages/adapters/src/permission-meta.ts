/**
 * Starter metadata for a permission key, used once at seed time.
 *
 * Lives beside seed.ts, its only caller. Not in @app/domain, because turning
 * 'staff:write' into the string 'Staff write' is presentation — word splitting
 * and title casing for a human reader — and the pure core has no business
 * knowing what reads nicely. Not in db/ either: it touches no database, and
 * that folder is for the Drizzle adapter and schema.
 *
 * A separate file rather than a function inside seed.ts only so it can be unit
 * tested; seed.ts runs main() on import.
 *
 * The catalog's human-readable content belongs to the database anyway: admins
 * curate labels and descriptions in the admin app, and the seed must not
 * overwrite those edits. This only has to produce something legible on first
 * insert.
 *
 * Total, by design: any string yields a non-empty resource and label, so a
 * malformed key can never seed a blank row.
 */
export function derivePermissionMeta(key: string): { resource: string; label: string } {
  const [head = '', ...rest] = key.split(':')
  const resource = head.trim() || 'general'
  const words = `${resource} ${rest.join(' ')}`.replace(/[_\s]+/g, ' ').trim()
  return { resource, label: words.charAt(0).toUpperCase() + words.slice(1) }
}
