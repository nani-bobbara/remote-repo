// Auth adapter — Better Auth instance (email+password + optional Google).
// Better Auth handles credentials + sessions only. Roles/permissions are OUR concern
// (data-driven `role` table + can()), so we don't use Better Auth's admin/AC plugin:
// new users get their role from the DB column default; staff are created by an
// admin through the admin app (signUpEmail + set role). Session resolution and
// guards live in @app/auth, where request headers exist.
import { betterAuth } from 'better-auth'
import { drizzleAdapter } from 'better-auth/adapters/drizzle'
import { brand } from '@app/config/brand'
import { DEFAULT_PORTAL_ROLE } from '@app/config/roles'
import { db } from '../db/index'
import { email } from '../email/index'
import * as schema from '../db/schema'

const google = process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET
  ? { google: { clientId: process.env.GOOGLE_CLIENT_ID, clientSecret: process.env.GOOGLE_CLIENT_SECRET } }
  : undefined

export const auth = betterAuth({
  // Pass the schema so Better Auth can find the user/session/account/verification models.
  database: drizzleAdapter(db, { provider: 'pg', schema }),
  emailAndPassword: {
    enabled: true,
    // `url` already points at this app: Better Auth builds it from baseURL,
    // which each app sets via its own BETTER_AUTH_URL, so a staff reset lands
    // on the admin host and a subscriber's on the portal.
    sendResetPassword: async ({ user, url }) => {
      await email.send({
        to: user.email,
        subject: `Reset your ${brand.name} password`,
        text: [
          `Someone asked to reset the password for this ${brand.name} account.`,
          ``,
          `Open this link to choose a new one — it expires in an hour:`,
          url,
          ``,
          `If this wasn't you, ignore this email. Your password stays as it is.`,
        ].join('\n'),
      })
    },
    resetPasswordTokenExpiresIn: 60 * 60,
  },
  ...(google ? { socialProviders: google } : {}),
  // Storage is in-memory, so on serverless each instance counts separately —
  // best-effort, not a distributed limit. Put a WAF in front, or configure
  // `secondaryStorage` (Redis) and set storage: 'secondary-storage'.
  rateLimit: {
    enabled: true,
    window: 10,
    max: 100,
    // Endpoints that take a password.
    customRules: {
      '/sign-in/email': { window: 60, max: 5 },
      '/sign-up/email': { window: 60, max: 3 },
      '/request-password-reset': { window: 60, max: 3 },
      '/reset-password': { window: 60, max: 5 },
      '/change-password': { window: 60, max: 5 },
    },
  },
  // Surface the role column on the session user (input:false so clients can't set it).
  // Role is assigned server-side only — signup default from @app/config/roles,
  // staff roles set by an admin through the admin app.
  user: {
    additionalFields: {
      role: { type: 'string', required: false, defaultValue: DEFAULT_PORTAL_ROLE, input: false },
    },
  },
})

export type Auth = typeof auth
