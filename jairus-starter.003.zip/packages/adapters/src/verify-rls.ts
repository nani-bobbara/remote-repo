// `pnpm db:verify-rls` — asserts row-level security is enforced for the role in
// DATABASE_URL, and exits non-zero when it is not, so CI can gate on it.
//
// RLS fails silently: a correct policy does nothing if the connecting role holds
// BYPASSRLS (Neon's default owner does), even under FORCE. Nothing errors and
// queries keep returning other users' rows, so it is checked empirically.
import { loadEnvFile } from "node:process"
try {
  loadEnvFile() // packages/adapters/.env, before db/index reads process.env
} catch {
  // No local .env: env comes from the shell or the platform.
}

const checks: { name: string; ok: boolean; detail: string }[] = []
const record = (name: string, ok: boolean, detail: string) => {
  checks.push({ name, ok, detail })
  console.log(`${ok ? "  PASS" : "  FAIL"}  ${name}\n        ${detail}`)
}

async function main() {
  const { default: postgres } = await import("postgres")

  const url = process.env.DATABASE_URL
  if (!url) {
    console.error("DATABASE_URL is not set — nothing to verify.")
    process.exit(1)
  }

  const sql = postgres(url, { prepare: false, max: 1 })
  console.log("\nVerifying row-level security on `subscription`\n")

  try {
    // 1) The runtime role must not be able to opt out of RLS.
    const [role] = await sql<{ name: string; superuser: boolean; bypass: boolean }[]>`
      select current_user as name, rolsuper as superuser, rolbypassrls as bypass
      from pg_roles where rolname = current_user`
    record(
      "runtime role cannot bypass RLS",
      !!role && !role.bypass && !role.superuser,
      role
        ? `DATABASE_URL connects as "${role.name}" (superuser=${role.superuser}, bypassrls=${role.bypass})`
        : "could not resolve current_user",
    )

    // 2) The table must have RLS switched on, and FORCE so ownership alone is
    //    not an escape hatch.
    const [table] = await sql<{ enabled: boolean; forced: boolean; owner: string }[]>`
      select c.relrowsecurity as enabled, c.relforcerowsecurity as forced,
             pg_get_userbyid(c.relowner) as owner
      from pg_class c join pg_namespace n on n.oid = c.relnamespace
      where n.nspname = 'public' and c.relname = 'subscription'`
    record(
      "subscription has RLS enabled and forced",
      !!table && table.enabled && table.forced,
      table
        ? `enabled=${table.enabled}, forced=${table.forced}, owner=${table.owner}`
        : "table `subscription` not found — run pnpm db:migrate",
    )

    // 3) The policy itself must exist.
    const policies = await sql<{ policyname: string }[]>`
      select policyname from pg_policies
      where schemaname = 'public' and tablename = 'subscription'`
    record(
      "isolation policy present",
      policies.some((p) => p.policyname === "subscription_user_isolation"),
      policies.length ? policies.map((p) => p.policyname).join(", ") : "no policies on subscription",
    )

    // 4) The behavioural check. Ground truth comes from the owner connection:
    //    reading 0 rows proves nothing when the table is empty, so that case is
    //    reported inconclusive rather than as a pass.
    const adminUrl = process.env.DATABASE_URL_ADMIN
    const admin = adminUrl ? postgres(adminUrl, { prepare: false, max: 1 }) : null
    try {
      const actual = admin
        ? ((await admin<{ n: number }[]>`select count(*)::int as n from subscription`)[0]?.n ?? 0)
        : null
      const total = (await sql<{ total: number }[]>`
        select count(*)::int as total from subscription`)[0]?.total ?? 0

      if (actual === null) {
        console.log(
          "  SKIP  unscoped read hides rows it does not own\n" +
            "        DATABASE_URL_ADMIN not set, so there is no ground truth to compare against",
        )
      } else if (actual === 0) {
        console.log(
          "  ????  unscoped read hides rows it does not own\n" +
            "        INCONCLUSIVE: the subscription table is empty, so reading 0 rows\n" +
            "        proves nothing. Re-run once a subscription exists.",
        )
      } else {
        record(
          "unscoped read hides rows it does not own",
          total === 0,
          `${actual} row(s) exist; an unscoped read saw ${total}` +
            (total > 0 ? " — these leak to any query that forgets withUser()" : ""),
        )
      }

      // 5) A scoped read must still see its own row, or the policy has broken
      //    the application rather than secured it.
      const probe = admin
        ? (await admin<{ user_id: string }[]>`select user_id from subscription limit 1`)[0]
        : undefined
      if (probe) {
        const visible = await sql.begin(async (tx) => {
          await tx`select set_config('app.user_id', ${probe.user_id}, true)`
          const rows = await tx<{ n: number }[]>`select count(*)::int as n from subscription`
          return rows[0]?.n ?? -1
        })
        record(
          "scoped read still sees the owner's own row",
          visible === 1,
          `withUser(${probe.user_id.slice(0, 8)}…) saw ${visible} row(s); expected exactly 1`,
        )
      } else {
        console.log(
          "  SKIP  scoped read still sees the owner's own row\n" +
            "        no subscription rows exist to probe with",
        )
      }
    } finally {
      await admin?.end()
    }
  } finally {
    await sql.end()
  }

  const failed = checks.filter((c) => !c.ok)
  if (failed.length) {
    console.error(
      `\n${failed.length} of ${checks.length} checks FAILED. RLS is not protecting this database.\n` +
        "If DATABASE_URL still points at the owner role, create app_user and repoint\n" +
        "DATABASE_URL at it — see README → Setup → Database roles.\n",
    )
    process.exit(1)
  }
  console.log(`\nAll ${checks.length} checks passed — RLS is enforced for this connection.\n`)
}

main().catch((e) => {
  console.error("verify-rls failed to run:", e)
  process.exit(1)
})
