// Feature-flags adapter — STUB (port defined; activate via /jairus:extend feature-flags).
import type { FlagsPort } from '@app/domain'
export const flags: FlagsPort = { async isEnabled() { return false } }
