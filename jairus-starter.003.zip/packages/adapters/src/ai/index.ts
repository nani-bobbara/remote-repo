// AI adapter — STUB (port defined; activate via /jairus:extend ai).
import type { AiPort } from '@app/domain'
export const ai: AiPort = {
  async generate() { throw new Error('ai adapter not enabled — add via /jairus:extend ai') },
}
