// Seed the RBAC bootstrap: the permission catalog, the system roles from
// @app/config/roles, and the first admin user (credentials from the env).
// Idempotent — safe to re-run. `pnpm --filter @app/adapters seed:admin`.
import { loadEnvFile } from "node:process"
try {
  loadEnvFile() // load packages/adapters/.env before the db/auth modules read process.env
} catch {
  // No local .env: env comes from the shell or the platform.
}

async function main() {
  // Dynamic imports so env is loaded before db/index constructs its Postgres client.
  const { eq } = await import("drizzle-orm")
  const { PERMISSIONS } = await import("@app/domain")
  const { ROLE_SEEDS, SUPERUSER_ROLE } = await import("@app/config/roles")
  const { derivePermissionMeta } = await import("./permission-meta")
  const { dbAdmin } = await import("./db")
  const {
    role: roleT,
    rolePermission: rolePermT,
    user: userT,
    permission: permT,
  } = await import("./db/schema")
  const { auth } = await import("./auth")

  // 0) Permission catalog — every key code enforces, as isSystem=true.
  // Labels/resources are DERIVED from the key, only for the initial insert.
  // On conflict we set isSystem ONLY: that promotes a row an admin created
  // before code shipped enforcement for it, without clobbering the label,
  // description, or grouping an admin has since edited. Admin-created keys
  // that code does not enforce are left untouched entirely.
  const enforcedKeys = Object.values(PERMISSIONS)
  for (const key of enforcedKeys) {
    const meta = derivePermissionMeta(key)
    await dbAdmin
      .insert(permT)
      .values({ key, label: meta.label, description: null, resource: meta.resource, isSystem: true })
      .onConflictDoUpdate({
        target: permT.key,
        set: { isSystem: true, updatedAt: new Date() },
      })
  }
  console.log(`✓ permission catalog seeded (${enforcedKeys.length} keys)`)

  // 1) System roles, from @app/config/roles. Protected, and first-insert-only:
  // onConflictDoNothing means an admin's edits in the admin UI survive every
  // redeploy, exactly as curated permission labels do above.
  //
  // Each role declares intent (full-access / read-only-mirror / none) and we
  // resolve it HERE against the catalog just seeded, because @app/config is a
  // leaf package and may not import PERMISSIONS.
  const catalogKeys = await dbAdmin.select({ key: permT.key }).from(permT)

  /** admin:access plus every read permission that exists. Recomputed each seed,
   *  so Support keeps mirroring Admin as the catalog grows. */
  const readOnlyMirrorKeys = catalogKeys
    .map((r) => r.key)
    .filter((key) => key === PERMISSIONS.ADMIN_ACCESS || key.endsWith(":read"))

  for (const seed of ROLE_SEEDS) {
    const [inserted] = await dbAdmin
      .insert(roleT)
      .values({
        name: seed.id,
        label: seed.label,
        description: seed.description,
        fullAccess: seed.grant.kind === "full-access",
        isSystem: true,
      })
      .onConflictDoNothing()
      .returning({ name: roleT.name })

    // No row returned = the role already existed. Leave its assignments alone.
    if (!inserted) continue

    const keys = seed.grant.kind === "read-only-mirror" ? readOnlyMirrorKeys : []
    if (keys.length > 0) {
      await dbAdmin
        .insert(rolePermT)
        .values(keys.map((permissionKey) => ({ roleName: seed.id, permissionKey })))
        .onConflictDoNothing()
    }
  }
  console.log(`✓ system roles seeded (${ROLE_SEEDS.map((r) => r.id).join(", ")})`)

  // There used to be a self-heal step here, resetting users whose role had
  // fallen out of the catalog. It is gone: user.role is now a foreign key with
  // ON DELETE RESTRICT, so a role cannot be deleted while anyone holds it and
  // an unknown role cannot be written in the first place. The invariant is the
  // database's to keep, not the seed's to repair.

  // 2) First admin user, credentials from the environment.
  const email = process.env.ADMIN_EMAIL
  const password = process.env.ADMIN_INITIAL_PASSWORD
  if (!email || !password) {
    console.log("• ADMIN_EMAIL / ADMIN_INITIAL_PASSWORD not set — skipping admin user")
    return
  }
  const [existing] = await dbAdmin.select().from(userT).where(eq(userT.email, email))
  if (!existing) {
    await auth.api.signUpEmail({ body: { email, password, name: "Admin" } })
    console.log("✓ admin user created:", email)
  } else {
    console.log("• admin user already exists:", email)
  }
  await dbAdmin.update(userT).set({ role: SUPERUSER_ROLE }).where(eq(userT.email, email))
  console.log(`✓ admin promoted to ${SUPERUSER_ROLE}:`, email)
}

main()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error("seed failed:", e)
    process.exit(1)
  })
