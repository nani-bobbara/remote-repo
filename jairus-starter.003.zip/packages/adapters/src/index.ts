// @app/adapters — infrastructure implementations of the domain ports.
export { db, dbAdmin, dbPort, dbAdminPort } from './db/index'
export { auth, type Auth } from './auth/index'
export { billing } from './billing/index'
export { email } from './email/index'
export { ai } from './ai/index'
export { flags } from './flags/index'
