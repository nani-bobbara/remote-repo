// Billing adapter — Stripe, implements the domain BillingPort.
// The Stripe client is lazy-constructed so importing this module is build-safe
// even when STRIPE_SECRET_KEY is absent (it only throws when actually used).
import Stripe from 'stripe'
import type { BillingPort, PlanTier } from '@app/domain'

let _stripe: Stripe | null = null
function stripe(): Stripe {
  if (!_stripe) {
    const key = process.env.STRIPE_SECRET_KEY
    if (!key) throw new Error('STRIPE_SECRET_KEY is not set')
    _stripe = new Stripe(key)
  }
  return _stripe
}

function priceFor(tier: PlanTier): string | undefined {
  return {
    free: undefined,    
    basic: process.env.STRIPE_PRICE_BASIC,
    pro: process.env.STRIPE_PRICE_PRO,
  }[tier]
}

export const billing: BillingPort = {
  async createCheckout(userId, tier) {
    const price = priceFor(tier)
    if (!price) throw new Error(`No Stripe price configured for tier "${tier}"`)
    const base = process.env.BETTER_AUTH_URL ?? 'http://localhost:3001'
    const s = await stripe().checkout.sessions.create({
      mode: 'subscription',
      line_items: [{ price, quantity: 1 }],
      client_reference_id: userId,
      metadata: { userId, tier },
      subscription_data: { metadata: { userId, tier } },
      success_url: `${base}/settings?upgraded=1`,
      cancel_url: `${base}/settings`,
    })
    return { url: s.url ?? base }
  },
  async parseWebhook(payload, signature) {
    const secret = process.env.STRIPE_WEBHOOK_SECRET
    if (!secret) throw new Error('STRIPE_WEBHOOK_SECRET is not set')
    const evt = stripe().webhooks.constructEvent(payload, signature, secret)
    return { type: evt.type, data: evt.data.object }
  },
}
