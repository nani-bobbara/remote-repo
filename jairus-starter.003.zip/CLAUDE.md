# jairus-starter

Deterministic base template for a Neon + Next.js micro-SaaS. Cloned by the jairus
plugin's Foundation phase instead of being regenerated, so features start from a
compiling, deployable walking skeleton (portal + admin, working auth).

## Architecture — hexagonal / ports & adapters

Dependencies point inward. `domain` knows nothing about frameworks; `adapters`
implement domain ports; apps + `application` wire them together.

```
packages/
  domain        @app/domain      entities, value-objects, errors, PORTS (zero deps)
  application   @app/application  use-cases orchestrating ports (framework-free)
  adapters      @app/adapters     Drizzle/Neon, Better Auth, Stripe, Resend + ai/flags stubs
  auth          @app/auth         request-scoped session + requireUser / requirePermission / requireStaff (needs headers)
  ui            @app/ui           shared shadcn-style primitives + swappable palette tokens (themes/*.css)
  config        @app/config       shared tsconfig base + brand, roles (RBAC seed intent), theme palette id
apps/
  portal        public, read-heavy — open email + Google signup
  admin         restricted, write-heavy — seeded admin role, no self-signup, staff-only via one (app) layout gate
```

Both apps consume the same packages, so shared logic is written once. Extend a
package when a feature needs it; never duplicate plumbing into an app.

## Two-layer data scoping

- **Layer 1 — application.** All user-data queries route through `DbPort.withUser(userId, …)`,
  which opens a transaction, sets `app.user_id`, and hands back repos whose queries filter to
  that user.
- **Layer 2 — Postgres RLS.** `subscription` has `ENABLE` + `FORCE ROW LEVEL SECURITY` and a
  fail-closed policy on `current_setting('app.user_id', true)` (migration
  `0000_init`). Unset context reads as NULL, so a query that forgets `withUser`
  returns **zero** rows instead of everyone's.
- **Only `subscription` is covered, by design.** The Better Auth tables (`user`, `session`,
  `account`, `verification`) are read during sign-in, *before* any user identity exists —
  a policy there would break authentication. The `role`/`permission` catalogs are not
  user-scoped at all. Any new table holding per-user rows should get the same treatment.
- **RLS only binds if `DATABASE_URL` is an unprivileged role.** A role with `BYPASSRLS` —
  which Neon's default `neondb_owner` has — ignores every policy, even under FORCE, and
  fails silently. `DATABASE_URL` must be `app_user`; `DATABASE_URL_ADMIN` stays the owner.
  Setup steps are in README → Setup → Database roles.
- **`pnpm db:verify-rls` is the proof.** It connects as the configured runtime role and
  asserts it cannot read rows it does not own, exiting non-zero otherwise. Run it after any
  change to database roles or connection strings; never assume a policy is enforcing.
- Cross-user / system work uses `dbAdmin` (unscoped, bypasses RLS as the owner) — guard
  every call with `requireStaff()` / `requirePermission(...)`.

## Commands

```
pnpm install
pnpm -r type-check          # strict, zero errors, no `any`
pnpm -r lint                # eslint (CI-gating)
pnpm turbo build
pnpm gen:secret             # generate BETTER_AUTH_SECRET
pnpm db:generate            # drizzle: create a migration from schema.ts
pnpm db:migrate             # apply migrations (CI runs this on merge)
pnpm db:seed                # seed the permission catalog, the default roles + the first admin
pnpm db:verify-rls          # prove RLS is enforced for the runtime role (exits non-zero if not)
```

Schema source of truth: `packages/adapters/src/db/schema.ts` (drives migrations AND both apps' types).

## Local ports

- portal → `http://localhost:3001`
- admin  → `http://localhost:3002`
- Grafana `otel-lgtm` UI → `http://localhost:3000` (default; kept clear of the apps)
- OTLP collector → `:4318`

Apps deliberately avoid `3000` so a local Grafana/otel-lgtm keeps its default UI port.
Each app needs its own `BETTER_AUTH_URL` (portal `:3001`, admin `:3002`) — set per Vercel
project in prod; for local dev, set it in each app's own env.

## Observability

Each app has `instrumentation.ts` (Next.js auto-loads it) that registers OpenTelemetry
via `@vercel/otel` — vendor-neutral OTLP, no backend lock-in.

- Master switch: `OBSERVABILITY_ENABLED` (default `true`). Set `false` to emit nothing.
- Export target: `OTEL_EXPORTER_OTLP_ENDPOINT` — any OTel collector (Grafana, Honeycomb, local).
- `OTEL_SERVICE_NAME` names the service per app (defaults to `portal` / `admin`).
- Vendor build telemetry (Next.js + Turborepo) is disabled via `NEXT_TELEMETRY_DISABLED` /
  `TURBO_TELEMETRY_DISABLED`, so the only telemetry emitted is your own OTLP.

## Frontend development guidelines (follow for EVERY page/feature)

These are non-negotiable conventions so the two apps stay one consistent system.
The jairus plugin and all future features must follow them.

1. **Components come from `@app/ui`.** Use the shared shadcn (new-york) components —
   never hand-roll a button/input/card in an app. Need a component that doesn't exist yet?
   Add it to `@app/ui` via `pnpm dlx shadcn add <name>` (it lands in `packages/ui/src/components/ui`),
   then re-export from `packages/ui/src/index.ts`. Apps import from the `@app/ui` barrel.
2. **Theme tokens only — never hardcode colors.** Use token utilities (`bg-background`,
   `text-foreground`, `bg-primary`, `text-muted-foreground`, `border`, `bg-card`, …).
   No hex, no `text-gray-500`, no inline colors. Tokens live in per-palette files under
   `packages/ui/src/themes/*.css` (registered in `themes/registry.ts`); a palette is selected
   by the `html[data-palette="<id>"]` attribute, driven by `@app/config` (`brand.palette` /
   `NEXT_PUBLIC_BRAND_PALETTE`) — don't edit `:root` to reskin. Dark mode is automatic via the
   `.dark` class + tokens. Every palette must declare the full token set in both light and
   dark and keep foreground/background pairs readable.
3. **Forms = react-hook-form + zod + shadcn `Form`.** Validate with a zod schema and
   `zodResolver`; render fields with `FormField`/`FormItem`/`FormLabel`/`FormControl`/`FormMessage`.
   Surface errors with a `toast` (sonner, re-exported from `@app/ui`).
4. **Auth-gated areas** live under the `app/(app)/…` route group with a `layout.tsx` that
   resolves the session (`getSession` from `@app/auth`) and `redirect()`s to `/sign-in` when
   absent. The admin app additionally gates its whole `(app)` group on the `admin:access`
   permission (`can(session, PERMISSIONS.ADMIN_ACCESS)` / `requireStaff()`) — data-driven RBAC,
   never a `role === "admin"` literal. Each app's `middleware.ts` adds a cheap outer bounce for
   requests with no session cookie; extend its `matcher` when you add a route group. Middleware
   checks cookie **presence only** — never put an authorisation decision there.
   The admin app is invite-only: its `api/auth/[...all]/route.ts` 404s the sign-up, social and
   OAuth-callback endpoints. Don't "fix" that by setting `emailAndPassword.disableSignUp` on the
   shared auth config — Better Auth checks that flag inside the endpoint handler, so it would
   also break `createStaff()`, which provisions staff via `auth.api.signUpEmail()`.
5. **Client vs server split.** Default to server components. Mark a file `"use client"` only
   when it needs hooks/interactivity (forms, menus, `usePathname`). Import the browser auth
   client from `@app/auth/client` (never `@app/auth`, which is server-only).
6. **Icons = `lucide-react`.** Size with `size-4` etc.; color via `text-*` tokens.
7. **Data flows through the layers:** pages call `@app/application` use-cases, which depend on
   domain ports; adapters (`@app/adapters`) supply the implementations. Pages never import a
   vendor SDK directly. Import adapters from their **subpath** (`@app/adapters/db`,
   `@app/adapters/billing`, `@app/adapters/email`, …), NOT the `@app/adapters` barrel: the
   barrel pulls Stripe, Resend and the Postgres driver into every route that touches any one
   of them. Each client is lazy-constructed, so a missing key only throws on use, but the
   bundle cost is real and a DB-only route has no business importing Stripe.
8. **Every new `@app/*` an app imports** must be added to that app's `package.json`
   dependencies AND its `next.config.ts` `transpilePackages`.
9. **Branding is never hardcoded.** Product name and marketing copy come from
   `@app/config/brand` (`brand.name` / `brand.tagline` / `brand.description` / `brand.palette`).
   Each has an env override (`NEXT_PUBLIC_BRAND_*`) so a deployment can rebrand without a code
   change; the `NEXT_PUBLIC_` prefix is required because client components import `brand`.
   Every surface (shell, landing, `<meta>`, manifest) reads from there — no literal product
   names or taglines in pages/components.
10. **Mobile-native by default.** Use `min-h-dvh` (never `min-h-screen`/`100vh`), respect
    safe areas with `env(safe-area-inset-*)`, keep tap targets ≥44px, and no horizontal
    overflow. The membership shell is responsive: sidebar on `md+`, bottom tab bar + a
    hamburger drawer on mobile. Each app is an installable PWA (`app/manifest.ts`,
    `viewport-fit=cover`, `theme-color`) — keep it that way.

## App shell (membership area)

`apps/portal/app/(app)/` holds the authenticated shell: `layout.tsx` (auth gate + plan
fetch) → `AppShell` (topbar + user menu + sidebar) wrapping `dashboard`, `profile`, `settings`.
New authenticated pages go under this group and inherit the shell automatically.
