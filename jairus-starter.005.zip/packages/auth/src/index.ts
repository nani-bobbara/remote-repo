// @app/auth — request-scoped session resolution + route guards.
// Lives here (not in adapters) because it needs Next.js request headers.
import { cache } from 'react'
import { cookies, headers } from 'next/headers'
import { toNextJsHandler } from 'better-auth/next-js'
import { DEFAULT_PORTAL_ROLE } from '@app/config/roles'
import { auth } from '@app/adapters/auth'
import { dbPort } from '@app/adapters/db'
import { LIMITS, rateLimit } from '@app/adapters/rate-limit'
import {
  can,
  canInOrg,
  ForbiddenError,
  RateLimitedError,
  UnauthorizedError,
  PERMISSIONS,
  type Session,
  type Organization,
  type OrgAction,
  type OrgRole,
} from '@app/domain'

/** Better Auth route handler — mount at app/api/auth/[...all]/route.ts. */
export const authHandler = toNextJsHandler(auth)

/** Resolve the current session (+ the role's resolved permissions) from request headers.
 *  Cached per request so layout + page share one round-trip. */
export const getSession = cache(async (): Promise<Session | null> => {
  const res = await auth.api.getSession({ headers: await headers() })
  if (!res?.user) return null
  const u = res.user as { id: string; email: string; role?: string | null }
  const role = typeof u.role === 'string' && u.role ? u.role : DEFAULT_PORTAL_ROLE
  const roleDef = await dbPort.roles.getByName(role)
  return {
    userId: u.id,
    email: u.email,
    role,
    permissions: roleDef?.permissions ?? [],
    fullAccess: roleDef?.fullAccess ?? false,
  }
})

/** Require an authenticated user; throws UnauthorizedError otherwise. */
export async function requireUser(): Promise<Session> {
  const session = await getSession()
  if (!session) throw new UnauthorizedError('Authentication required')
  return session
}

/** Require a specific permission (data-driven RBAC; a full-access role passes). */
export async function requirePermission(permission: string): Promise<Session> {
  const session = await requireUser()
  if (!can(session, permission)) throw new ForbiddenError(`Missing permission: ${permission}`)
  return session
}

/** Admin-app gate — any staff role granting admin:access (full access always passes). */
export async function requireStaff(): Promise<Session> {
  return requirePermission(PERMISSIONS.ADMIN_ACCESS)
}

/** Cookie naming the user's chosen organization. Never trusted: always re-checked
 *  against membership, and withOrg re-checks it again in the txn. */
export const ACTIVE_ORG_COOKIE = 'active_org'

export interface OrgContext {
  session: Session
  organization: Organization
  role: OrgRole
  /** How many organizations the user belongs to (a switcher only makes sense at >1). */
  membershipCount: number
}

/** Resolve the active organization: the `active_org` cookie if the user is a member
 *  of it, else their oldest owner membership, else their oldest membership.
 *  Cached per request.
 *
 *  This is the ONLY place a personal organization is created. It is portal-only
 *  by construction: staff are rejected just below, and the admin app never
 *  calls requireOrg(). So staff and seeded users never get an organization —
 *  no inference about how an account was created. createPersonalOrg is
 *  idempotent, and the list read before it makes it a no-op once a membership
 *  exists. */
const resolveOrg = cache(async (): Promise<OrgContext> => {
  const session = await requireUser()
  // The portal plane: staff hold no memberships and must not be given one.
  if (can(session, PERMISSIONS.ADMIN_ACCESS)) throw new ForbiddenError('Staff accounts have no organization')
  const list = () => dbPort.withUser(session.userId, (repos) => repos.orgs.listForUser(session.userId))
  let memberships = await list()
  if (memberships.length === 0) {
    const user = await dbPort.withUser(session.userId, (repos) => repos.users.findById(session.userId))
    await dbPort.createPersonalOrg(session.userId, user?.name ?? null)
    memberships = await list()
  }
  const wanted = (await cookies()).get(ACTIVE_ORG_COOKIE)?.value
  const active =
    memberships.find((m) => m.organization.id === wanted) ??
    memberships.find((m) => m.role === 'owner') ??
    memberships[0]
  if (!active) throw new ForbiddenError('No organization')
  return { session, organization: active.organization, role: active.role, membershipCount: memberships.length }
})

/** Require a signed-in portal user with an active organization; optionally require
 *  a organization action (e.g. 'billing:manage' → owner). Throws ForbiddenError. */
export async function requireOrg(action?: OrgAction): Promise<OrgContext> {
  const ctx = await resolveOrg()
  if (action && !canInOrg(ctx.role, action)) throw new ForbiddenError(`Requires organization permission: ${action}`)
  return ctx
}

/** Per-user budget for mutating server actions. Returns the message to hand
 *  back as `{ error }` when exhausted, otherwise null. */
export async function actionLimit(session: Session): Promise<string | null> {
  const { ok } = await rateLimit.hit(`action:${session.userId}`, LIMITS.action)
  return ok ? null : new RateLimitedError().message
}

export { auth } from '@app/adapters/auth'
