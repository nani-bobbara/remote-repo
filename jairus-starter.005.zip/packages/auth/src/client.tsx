"use client"
// Browser auth client — safe to import from client components.
// Defaults to the current origin, so the same client works for portal + admin.
import type { ComponentProps } from "react"
import { useRouter } from "next/navigation"
import { createAuthClient } from "better-auth/react"
import { Button } from "@app/ui"

export const authClient = createAuthClient()
export const { signIn, signUp, signOut, useSession } = authClient

/** The one sign-out flow: end the session, navigate, then refresh so server
 *  components re-render without it. Every sign-out control goes through this. */
export function useSignOut(redirectTo = "/") {
  const router = useRouter()
  return async () => {
    await signOut()
    router.push(redirectTo)
    router.refresh()
  }
}

/** Shared sign-out button. Defaults to an outline "Sign out"; pass children /
 *  Button props for other looks (e.g. an icon button). */
export function SignOutButton({
  redirectTo,
  children = "Sign out",
  variant = "outline",
  ...props
}: Omit<ComponentProps<typeof Button>, "onClick"> & { redirectTo?: string }) {
  const onSignOut = useSignOut(redirectTo)
  return (
    <Button type="button" variant={variant} onClick={onSignOut} {...props}>
      {children}
    </Button>
  )
}
