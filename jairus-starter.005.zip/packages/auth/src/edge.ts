// Edge-safe helpers for the proxy (formerly middleware). Separate from ./index, which reaches the
// database adapter and Next's `headers()` — neither runs in the edge runtime.
import { getSessionCookie } from 'better-auth/cookies'
import { NextResponse, type NextRequest } from 'next/server'

/** Cookie presence only: no signature, expiry or lookup check. A forged cookie
 *  passes, so treat this as a cheap filter, never as authorisation. */
export function hasSessionCookie(request: Request): boolean {
  return getSessionCookie(request) !== null
}

/**
 * The shared signed-out bounce for both apps' proxy (Next 16's renamed middleware): no session cookie →
 * redirect to `signInPath` (query cleared). Apps supply only `config.matcher`.
 * Cookie presence only — each app's `(app)/layout.tsx` resolves the real session
 * and authorisation. Never decide authorisation in the proxy.
 */
export function createSessionProxy(signInPath = '/sign-in') {
  return function proxy(request: NextRequest) {
    if (hasSessionCookie(request)) return NextResponse.next()
    const url = request.nextUrl.clone()
    url.pathname = signInPath
    url.search = ''
    return NextResponse.redirect(url)
  }
}
