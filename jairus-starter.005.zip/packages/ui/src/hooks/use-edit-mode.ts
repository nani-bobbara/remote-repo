"use client"

import { useState, useTransition } from "react"
import { toast } from "sonner"

import {
  useRegisterWorkspaceActions,
  type WorkspaceMode,
} from "@app/ui/components/workspace-actions-context"

/**
 * Display/edit state for a workspace editor, wired to the shared header
 * toolbar: display -> Edit; edit -> Cancel + Save. `save` runs the action in a
 * transition, toasts the result and drops back to display on success.
 * `start`/`pending` are exposed for other mutations (e.g. delete).
 */
export function useEditMode({
  canWrite,
  dirty,
  onSave,
  onReset,
  successMessage,
  saveLabel,
  editLabel,
  editDisabled,
}: {
  canWrite: boolean
  dirty: boolean
  onSave: () => Promise<{ error?: string | null }>
  onReset: () => void
  successMessage: string
  saveLabel: string
  editLabel: string
  editDisabled?: boolean
}) {
  const [mode, setMode] = useState<WorkspaceMode>("display")
  const [pending, start] = useTransition()

  function save() {
    start(async () => {
      const res = await onSave()
      if (res.error) {
        toast.error(res.error)
        return
      }
      toast.success(successMessage)
      setMode("display")
    })
  }

  useRegisterWorkspaceActions(
    !canWrite
      ? null
      : mode === "edit"
        ? {
            mode: "edit",
            onSave: save,
            onCancel: () => {
              onReset()
              setMode("display")
            },
            saveDisabled: !dirty,
            savePending: pending,
            saveLabel,
          }
        : { mode: "display", onEdit: () => setMode("edit"), editDisabled, editLabel }
  )

  return { mode, pending, start }
}
