// Single source of truth for "where am I in the nav". AppShell's sidebar,
// ribbon, mobile drawer and bottom tabs all resolve through these, so no two
// surfaces can disagree. Pure: no React, no app knowledge — each app supplies
// its own groups and visibility rule.
import type { LucideIcon } from "lucide-react"

/** `Extra` carries an app's own gating fields (admin: `permission`). */
export type NavItem<Extra extends object = object> = {
  href: string
  label: string
  icon: LucideIcon
} & Extra

export type NavGroup<Extra extends object = object> = {
  id: string
  label: string
  icon: LucideIcon
  items: NavItem<Extra>[]
}

export type ActiveNav<Extra extends object = object> = {
  group: NavGroup<Extra>
  items: NavItem<Extra>[]
  activeIndex: number
}

export const isActiveHref = (pathname: string, href: string) =>
  pathname === href || pathname.startsWith(`${href}/`)

/** Groups with items filtered by `isVisible`. A group declaring no items is
 *  kept (placeholder section); one emptied by filtering is dropped. */
export function visibleGroups<E extends object>(
  groups: NavGroup<E>[],
  isVisible: (item: NavItem<E>) => boolean = () => true,
): NavGroup<E>[] {
  return groups
    .filter((group) => group.items.length === 0 || group.items.some(isVisible))
    .map((group) => ({ ...group, items: group.items.filter(isVisible) }))
}

/** Which group and item own `pathname` among already-visible `groups`, or null.
 *  Longest href wins, so `/reports/archive` beats `/reports` regardless of
 *  config order. */
export function resolveActive<E extends object>(pathname: string, groups: NavGroup<E>[]): ActiveNav<E> | null {
  let best: ActiveNav<E> | null = null
  let bestLength = -1
  for (const group of groups) {
    for (const [index, item] of group.items.entries()) {
      if (!isActiveHref(pathname, item.href) || item.href.length <= bestLength) continue
      bestLength = item.href.length
      best = { group, items: group.items, activeIndex: index }
    }
  }
  return best
}
