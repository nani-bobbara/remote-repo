// Inline, render-blocking script for each app's root <head>. Applies the saved
// light/dark choice — or the OS preference when none is saved — before first
// paint, so the page never flashes the wrong theme. ThemeToggle writes the same
// `theme` key. The <html> element needs suppressHydrationWarning, because this
// changes its class list before React hydrates.
export const THEME_INIT_SCRIPT = `(function(){try{var t=localStorage.getItem('theme');if(t!=='light'&&t!=='dark'){t=window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'}document.documentElement.classList.toggle('dark',t==='dark')}catch(e){}})()`
