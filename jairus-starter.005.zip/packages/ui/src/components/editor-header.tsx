import * as React from "react"

import { Avatar, AvatarFallback } from "@app/ui/components/ui/avatar"

/**
 * Identity header for a workspace detail editor: large initials avatar, title
 * (with optional badges beside it) and a muted subtitle line.
 */
export function EditorHeader({
  initials,
  title,
  badges,
  subtitle,
}: {
  initials: string
  title: React.ReactNode
  badges?: React.ReactNode
  subtitle?: React.ReactNode
}) {
  const heading = <p className="truncate text-xl font-semibold tracking-tight">{title}</p>
  return (
    <div className="flex items-center gap-4">
      <Avatar className="size-14">
        <AvatarFallback className="text-base font-semibold">{initials}</AvatarFallback>
      </Avatar>
      <div className="min-w-0">
        {badges === undefined ? heading : <div className="flex items-center gap-2">{heading}{badges}</div>}
        <p className="text-muted-foreground truncate text-sm">{subtitle}</p>
      </div>
    </div>
  )
}
