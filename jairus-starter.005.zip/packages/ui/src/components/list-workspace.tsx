import * as React from "react"
import Link from "next/link"
import { Plus } from "lucide-react"

import { Button } from "@app/ui/components/ui/button"
import { ContentPane } from "@app/ui/components/content-pane"
import { ListPanel, type ListPanelItem } from "@app/ui/components/list-panel"
import { PageShell } from "@app/ui/components/page-shell"
import { WorkspaceLayout } from "@app/ui/components/workspace-layout"

/**
 * The admin master-detail screen: searchable list on the left, and on the
 * right either a create form (`creating`), the selected item's `detail`, or an
 * empty state. `create` (omit when the viewer can't write) adds the header's
 * "+" link; `actions` render before it (e.g. a Refresh button).
 */
export function ListWorkspace({
  icon,
  title,
  subtitle,
  actions,
  create,
  searchPlaceholder,
  items,
  emptyMessage,
  creating,
  detail,
  emptyTitle,
  emptyDescription,
}: {
  icon: React.ReactNode
  title: string
  subtitle: string
  actions?: React.ReactNode
  create?: { href: string; label: string } | null
  searchPlaceholder: string
  items: ListPanelItem[]
  emptyMessage: string
  creating?: { title: string; description: string; form: React.ReactNode; wide?: boolean } | null
  detail?: React.ReactNode
  emptyTitle: string
  emptyDescription: string
}) {
  return (
    <PageShell>
      <WorkspaceLayout
        cardIcon={icon}
        cardTitle={title}
        cardSubtitle={subtitle}
        cardActions={
          <>
            {actions}
            {create ? (
              <Button asChild variant="outline" size="icon" title={create.label} aria-label={create.label}>
                <Link href={create.href}>
                  <Plus />
                </Link>
              </Button>
            ) : null}
          </>
        }
        collapsibleLeftPanel
        defaultLeftPanelWidth={240}
        leftPanel={<ListPanel searchPlaceholder={searchPlaceholder} items={items} emptyMessage={emptyMessage} />}
      >
        {creating ? (
          <div
            className={creating.wide ? "mx-auto w-full max-w-2xl space-y-4 p-6" : "mx-auto w-full max-w-xl space-y-4 p-6"}
          >
            <div>
              <h3 className="text-base font-semibold">{creating.title}</h3>
              <p className="text-muted-foreground text-sm">{creating.description}</p>
            </div>
            {creating.form}
          </div>
        ) : detail ? (
          detail
        ) : (
          <ContentPane emptyTitle={emptyTitle} emptyDescription={emptyDescription} />
        )}
      </WorkspaceLayout>
    </PageShell>
  )
}
