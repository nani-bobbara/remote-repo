import * as React from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@app/ui/components/ui/card"

/**
 * Centered single-card page for error / not-found states. Server-safe; pass
 * client buttons as `children`. Never put raw error text in `description` —
 * server errors reach the browser redacted, and only the digest is meaningful.
 */
export function StatusPage({
  title,
  description,
  footnote,
  children,
}: {
  title: React.ReactNode
  description: React.ReactNode
  footnote?: React.ReactNode
  children?: React.ReactNode
}) {
  return (
    <main className="bg-background mx-auto flex min-h-dvh max-w-2xl flex-col items-center justify-center p-8">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>{title}</CardTitle>
          <CardDescription>{description}</CardDescription>
        </CardHeader>
        {(children || footnote) && (
          <CardContent className="flex flex-col gap-3">
            {children && <div className="flex gap-2">{children}</div>}
            {footnote && <p className="text-muted-foreground text-xs">{footnote}</p>}
          </CardContent>
        )}
      </Card>
    </main>
  )
}
