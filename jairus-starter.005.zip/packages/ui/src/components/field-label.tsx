import * as React from "react"

import { Label } from "@app/ui/components/ui/label"
import { cn } from "@app/ui/lib/utils"

/** The small uppercase caption above a field group in workspace editors. */
export function FieldLabel({ className, ...props }: React.ComponentProps<typeof Label>) {
  return (
    <Label
      className={cn("text-subtle-foreground text-[11px] font-black uppercase tracking-[0.18em]", className)}
      {...props}
    />
  )
}

/** Dashed explanatory note — "why this is read-only / what this does". */
export function InfoPanel({ className, ...props }: React.ComponentProps<"p">) {
  return (
    <p
      className={cn(
        "text-muted-foreground border-border-strong rounded-md border border-dashed p-3 text-sm leading-6",
        className
      )}
      {...props}
    />
  )
}
