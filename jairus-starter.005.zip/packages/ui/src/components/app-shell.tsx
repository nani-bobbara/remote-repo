"use client"

import Link from "next/link"
import { useState } from "react"
import { usePathname } from "next/navigation"
import { ChevronDown, ChevronRight, House, Menu, type LucideIcon } from "lucide-react"

import { Button } from "@app/ui/components/ui/button"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@app/ui/components/ui/sheet"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@app/ui/components/ui/breadcrumb"
import { ChevronRibbon } from "@app/ui/components/chevron-ribbon"
import { CollapseToggle } from "@app/ui/components/collapse-toggle"
import { ListRow } from "@app/ui/components/list-row"
import { cn } from "@app/ui/lib/utils"
import { isActiveHref, resolveActive, visibleGroups, type NavGroup, type NavItem } from "@app/ui/lib/app-nav"

/**
 * The shared application frame: grouped sidebar, mobile drawer and bottom
 * tabs, so navigation looks and behaves the same everywhere. `layout` picks
 * the main area:
 *
 * - `page` — a fixed header (breadcrumb left, `actions` right) over a
 *   scrolling, centred content column. The member portal.
 * - `workspace` — the chevron ribbon (`actions` at its right end) over a main
 *   area whose WorkspaceLayout card scrolls itself. Matches the admin console.
 */
export function AppShell<E extends object>({
  groups: allGroups,
  isVisible,
  homeHref,
  brandName,
  brandIcon: BrandIcon,
  actions,
  drawerFooter,
  layout,
  children,
}: {
  groups: NavGroup<E>[]
  /** Hide items the session may not use. Omit to show everything. */
  isVisible?: (item: NavItem<E>) => boolean
  homeHref: string
  brandName: string
  brandIcon: LucideIcon
  /** Account controls: header right in `page`, ribbon end in `workspace`. */
  actions?: React.ReactNode
  /** Bottom of the mobile drawer — account details and sign-out. */
  drawerFooter?: React.ReactNode
  layout: "workspace" | "page"
  children: React.ReactNode
}) {
  const [collapsed, setCollapsed] = useState(false)
  const groups = visibleGroups(allGroups, isVisible)

  return (
    <div className={cn("bg-muted/20 flex min-h-dvh md:h-dvh md:overflow-hidden", layout === "workspace" && "md:pt-[5px]")}>
      <aside className={`bg-background relative hidden shrink-0 flex-col border-r transition-[width] duration-200 md:flex ${collapsed ? "w-20" : "w-60"}`}>
        <div className="flex h-14 items-center px-4">
          <Link href={homeHref} className="flex min-w-0 items-center gap-2 text-base font-semibold tracking-tight">
            <BrandIcon className="text-primary size-6 shrink-0" aria-hidden="true" />
            {!collapsed ? <span className="truncate">{brandName}</span> : null}
          </Link>
        </div>
        {/* In `page` the top edge is taken by the header and the first nav rows,
            so the button sits at the bottom, where the sidebar is empty. */}
        <CollapseToggle
          expanded={!collapsed}
          onToggle={() => setCollapsed((value) => !value)}
          target="sidebar"
          className={cn("absolute -right-4.5 z-10", layout === "page" ? "bottom-6" : "top-11.5")}
        />
        <div className="flex-1 overflow-y-auto">
          <SidebarNav groups={groups} collapsed={collapsed} />
        </div>
      </aside>

      {layout === "page" ? (
        <div className="flex min-w-0 flex-1 flex-col md:min-h-0">
          <header
            className="bg-background sticky top-0 z-30 flex h-14 shrink-0 items-center gap-2 border-b px-4 sm:px-6"
            style={{ paddingTop: "env(safe-area-inset-top)" }}
          >
            <MobileDrawer groups={groups} footer={drawerFooter} />
            <PageBreadcrumb groups={groups} homeHref={homeHref} />
            {actions ? <div className="ml-auto flex shrink-0 items-center gap-2">{actions}</div> : null}
          </header>
          <main className="flex-1 p-4 pb-24 sm:p-6 md:min-h-0 md:overflow-y-auto md:pb-6">
            <div className="mx-auto w-full max-w-5xl">{children}</div>
          </main>
        </div>
      ) : (
        <div className="flex min-w-0 flex-1 flex-col md:min-h-0">
          <header className="bg-muted/20 sticky top-0 z-30 flex h-14 items-center gap-2 px-4 md:hidden sm:px-6" style={{ paddingTop: "env(safe-area-inset-top)" }}>
            <MobileDrawer groups={groups} footer={drawerFooter} />
            <Link href={homeHref} className="flex items-center gap-2 text-base font-semibold tracking-tight md:hidden">
              <BrandIcon className="text-primary size-5" aria-hidden="true" />
              <span>{brandName}</span>
            </Link>
          </header>
          <main className="flex flex-1 flex-col p-4 pb-24 sm:p-6 md:min-h-0 md:overflow-hidden md:pb-0 md:pt-0">
            <div className="mb-4 w-full shrink-0">
              <Ribbon groups={groups} trailing={actions} />
            </div>
            {children}
          </main>
        </div>
      )}

      <BottomTabs groups={groups} />
    </div>
  )
}

function SidebarNav<E extends object>({ groups, collapsed = false }: { groups: NavGroup<E>[]; collapsed?: boolean }) {
  const pathname = usePathname()
  const active = resolveActive(pathname, groups)

  // Expanding a group by hand is a browsing gesture, not a selection, so the
  // next navigation clears it and the sidebar re-agrees with the ribbon. Reset
  // during render on route change (React's "adjust state on prop change").
  const [override, setOverride] = useState<string | null>(null)
  const [seenPath, setSeenPath] = useState(pathname)
  if (pathname !== seenPath) {
    setSeenPath(pathname)
    setOverride(null)
  }
  const openGroup = override ?? active?.group.id ?? groups[0]?.id ?? ""

  return (
    <nav className={cn("flex flex-col gap-5 pb-6 pt-4", collapsed ? "px-2" : "px-3")}>
      {groups.map((group) => {
        const GroupIcon = group.icon
        const isOpen = openGroup === group.id
        return (
          <div key={group.id} className="flex flex-col gap-1">
            <button
              type="button"
              onClick={() => setOverride(isOpen ? "" : group.id)}
              className={cn(
                "text-muted-foreground flex w-full items-center rounded-md py-2 text-left text-[11px] font-semibold tracking-[0.14em] uppercase transition-colors hover:bg-accent hover:text-accent-foreground",
                collapsed ? "justify-center px-2" : "gap-2 px-3"
              )}
              aria-label={collapsed ? group.label : undefined}
              title={collapsed ? group.label : undefined}
            >
              <GroupIcon className="size-4 shrink-0" />
              {!collapsed ? <span className="flex-1">{group.label}</span> : null}
              {!collapsed ? (isOpen ? <ChevronDown className="size-3.5" /> : <ChevronRight className="size-3.5" />) : null}
            </button>
            {/* Collapsed: group icons only; children are hidden, not shrunk. */}
            {!collapsed && isOpen
              ? group.items.map(({ href, label, icon: Icon }) => (
                  <ListRow key={href} href={href} label={label} icon={<Icon />} active={isActiveHref(pathname, href)} />
                ))
              : null}
          </div>
        )
      })}
    </nav>
  )
}

/** Home › group › page, from the same resolver as the sidebar. On the home page
 *  the trail is just the home icon. The group is plain text (groups have no
 *  route) and is dropped on narrow screens; the page links back when you are
 *  below it. */
function PageBreadcrumb<E extends object>({ groups, homeHref }: { groups: NavGroup<E>[]; homeHref: string }) {
  const pathname = usePathname()
  const atHome = pathname === homeHref
  const active = atHome ? null : resolveActive(pathname, groups)
  const item = active?.items[active.activeIndex]
  const home = <House className="size-4" />
  return (
    <Breadcrumb className="min-w-0 flex-1">
      <BreadcrumbList className="flex-nowrap">
        <BreadcrumbItem>
          {atHome ? (
            <BreadcrumbPage aria-label="Home" title="Home">{home}</BreadcrumbPage>
          ) : (
            <BreadcrumbLink asChild>
              <Link href={homeHref} aria-label="Home" title="Home">{home}</Link>
            </BreadcrumbLink>
          )}
        </BreadcrumbItem>
        {active && item ? (
          <>
            <BreadcrumbSeparator className="hidden sm:block" />
            <BreadcrumbItem className="hidden sm:inline-flex">{active.group.label}</BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem className="min-w-0">
              {pathname === item.href ? (
                <BreadcrumbPage className="truncate">{item.label}</BreadcrumbPage>
              ) : (
                <BreadcrumbLink asChild>
                  <Link href={item.href} className="truncate">{item.label}</Link>
                </BreadcrumbLink>
              )}
            </BreadcrumbItem>
          </>
        ) : null}
      </BreadcrumbList>
    </Breadcrumb>
  )
}

/** The active group as eyebrow, its items as steps. */
function Ribbon<E extends object>({ groups, trailing }: { groups: NavGroup<E>[]; trailing?: React.ReactNode }) {
  const active = resolveActive(usePathname(), groups)
  if (!active) return null
  return (
    <ChevronRibbon
      eyebrow={active.group.label}
      eyebrowIcon={active.group.icon}
      steps={active.items.map(({ href, label, icon }) => ({ href, label, icon }))}
      activeIndex={active.activeIndex}
      trailing={trailing}
    />
  )
}

function MobileDrawer<E extends object>({ groups, footer }: { groups: NavGroup<E>[]; footer?: React.ReactNode }) {
  const [open, setOpen] = useState(false)
  const pathname = usePathname()
  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden" aria-label="Open menu">
          <Menu className="size-5" />
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-72 p-0">
        <SheetHeader className="border-b">
          <SheetTitle>Menu</SheetTitle>
        </SheetHeader>
        <div key={pathname} className="flex flex-1 flex-col overflow-y-auto">
          {/* Close on navigation only — a group header click must expand the
              group, not dismiss the drawer. */}
          <div
            className="flex-1"
            onClick={(event) => {
              if ((event.target as HTMLElement).closest("a")) setOpen(false)
            }}
          >
            <SidebarNav groups={groups} />
          </div>
          {footer ? <div className="border-t p-3">{footer}</div> : null}
        </div>
      </SheetContent>
    </Sheet>
  )
}

function BottomTabs<E extends object>({ groups }: { groups: NavGroup<E>[] }) {
  const pathname = usePathname()
  const items = groups.flatMap((g) => g.items)
  return (
    <nav className="bg-background fixed inset-x-0 bottom-0 z-40 flex border-t md:hidden" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
      {items.map(({ href, label, icon: Icon }) => (
        <Link
          key={href}
          href={href}
          className={cn(
            "flex flex-1 flex-col items-center justify-center gap-1 py-2 text-[11px] transition-colors",
            isActiveHref(pathname, href) ? "text-foreground font-medium" : "text-muted-foreground"
          )}
        >
          <Icon className="size-5" />
          {label}
        </Link>
      ))}
    </nav>
  )
}
