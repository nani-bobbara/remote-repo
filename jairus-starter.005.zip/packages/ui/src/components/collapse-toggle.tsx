"use client"

import { ChevronLeft, ChevronRight } from "lucide-react"

import { Button } from "@app/ui/components/ui/button"
import { cn } from "@app/ui/lib/utils"

/**
 * The one collapse/expand control for sidebars and side panels. Callers only
 * position it via `className`; the look lives here so every instance matches.
 *
 * Opaque in both themes: it usually straddles a border, and the outline
 * variant's translucent dark fill would let that border show through.
 */
export function CollapseToggle({
  expanded,
  onToggle,
  target,
  className,
}: {
  expanded: boolean
  onToggle: () => void
  /** What it collapses, for the accessible label: "sidebar", "panel". */
  target: string
  className?: string
}) {
  const label = `${expanded ? "Collapse" : "Expand"} ${target}`
  return (
    <Button
      type="button"
      variant="outline"
      size="icon"
      onClick={onToggle}
      aria-label={label}
      aria-expanded={expanded}
      title={label}
      className={cn("bg-background dark:bg-background dark:hover:bg-accent rounded-full", className)}
    >
      {expanded ? <ChevronLeft /> : <ChevronRight />}
    </Button>
  )
}
