import * as React from "react"

import { cn } from "@app/ui/lib/utils"

/** Up-to-two-letter initials from a name, label, or email. */
export function toInitials(label: string): string {
  return (
    label
      .split(/[\s@._-]+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part.charAt(0).toUpperCase())
      .join("") || "?"
  )
}

/**
 * A small neutral initials chip for list rows — the uniform stand-in for a
 * per-item avatar across every dynamic (DB-backed) list.
 */
export function InitialsAvatar({ label, className }: { label: string; className?: string }) {
  return (
    <span
      className={cn(
        "bg-muted text-foreground flex size-5 shrink-0 items-center justify-center rounded-full text-[9px] font-semibold",
        className
      )}
    >
      {toInitials(label)}
    </span>
  )
}
