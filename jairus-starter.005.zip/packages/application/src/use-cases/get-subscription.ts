// Example use-case: read the active organization's subscription.
// Runs through DbPort.withOrg, which verifies membership inside the
// transaction before any business row is reachable. Follow this shape for every
// business-data read — it is the only thing enforcing tenancy.
import type { DbPort } from '@app/domain'
import type { SubscriptionView } from '../dtos/index'

export function makeGetSubscription(db: DbPort) {
  return async function getSubscription(userId: string, orgId: string): Promise<SubscriptionView | null> {
    return db.withOrg(userId, orgId, async (repos) => {
      const sub = await repos.subscriptions.getForOrganization(orgId)
      if (!sub) return null
      return { tier: sub.tier, status: sub.status, currentPeriodEnd: sub.currentPeriodEnd }
    })
  }
}
