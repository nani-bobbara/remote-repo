// Use-case: apply a billing-provider event exactly once.
//
// This is the reference shape for application logic (decision D3): business
// rules live here, take their ports as parameters, and import no vendor or
// framework code. The route is a thin edge (verify → call → respond); a test can
// call this with an in-memory DbPort and assert outcomes without Stripe or a DB.
//
// Tenancy: a webhook has no session, so it enters business data through the
// one system path, SystemDbPort.asOrgSystem — it sets only the organization
// scope. That port is lint-restricted to the webhook route, which passes it here.
//
// Idempotency: the event is recorded in the SAME transaction as its effect. A redelivery finds it already recorded and is skipped; a failed effect
// rolls the record back so the provider's retry is applied.
import type { BillingEvent, SystemDbPort } from '@app/domain'

export type BillingEventOutcome = 'applied' | 'duplicate' | 'ignored'

export function makeHandleBillingEvent(system: SystemDbPort) {
  return async function handleBillingEvent(event: BillingEvent): Promise<BillingEventOutcome> {
    if (event.kind === 'ignored') return 'ignored'

    // checkout.completed — scoped to the paying organization, so RLS bounds the write.
    return system.asOrgSystem(event.orgId, async (repos) => {
      const isNew = await repos.billingEvents.record(event.id, event.kind)
      if (!isNew) return 'duplicate'
      await repos.subscriptions.upsert({
        orgId: event.orgId,
        tier: event.tier,
        status: 'active',
        stripeCustomerId: event.stripeCustomerId,
        currentPeriodEnd: null,
      })
      await repos.audit.record({
        orgId: event.orgId, actorUserId: null, actorKind: 'system',
        action: 'billing.checkout_completed', targetType: 'subscription', targetId: event.orgId,
        metadata: { tier: event.tier, eventId: event.id, paidBy: event.userId },
      })
      return 'applied'
    })
  }
}
