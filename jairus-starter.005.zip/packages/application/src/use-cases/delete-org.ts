// Use-case (F8): an owner deletes their organization.
//
// Billing first, data second. The org's Stripe customer is deleted BEFORE the
// rows go — deleting a customer cancels its subscriptions immediately. In the
// other order a failed Stripe call would leave a deleted org still being
// charged; in this order a failed DB delete leaves an org with no billing,
// which the owner can simply retry (deleteCustomer is idempotent). Refusing
// until the owner cancels was the alternative, but there is no billing portal
// to cancel from, so it would be a dead end.
import { canInOrg, ForbiddenError, type BillingPort, type DbPort } from '@app/domain'

export function makeDeleteOrg(db: DbPort, billing: Pick<BillingPort, 'deleteCustomer'>) {
  return async function deleteOrg(userId: string, orgId: string): Promise<void> {
    // Authorise and read the billing link in a short txn — no network call inside it.
    const customerId = await db.withOrg(userId, orgId, async (repos, { role }) => {
      if (!canInOrg(role, 'org:delete')) throw new ForbiddenError('Only an owner can delete the organization')
      return (await repos.subscriptions.getForOrganization(orgId))?.stripeCustomerId ?? null
    })
    if (customerId) await billing.deleteCustomer(customerId)
    // The audit row is written first, in the same txn; it has no FK, so it
    // outlives the org. RLS lets only an owner delete; membership and business
    // rows cascade.
    await db.withOrg(userId, orgId, async (repos) => {
      await repos.audit.record({
        orgId, actorUserId: userId, actorKind: 'user',
        action: 'org.deleted', targetType: 'organization', targetId: orgId,
        metadata: { stripeCustomerDeleted: customerId !== null },
      })
      await repos.orgs.delete(orgId)
    })
  }
}
