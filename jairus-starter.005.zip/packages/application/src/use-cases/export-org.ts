// Use-case (F8): an owner exports everything their organization holds —
// organization, members, subscription and its audit trail — as plain data.
// Runs in one withOrg transaction, so RLS bounds every read to this org.
import { canInOrg, ForbiddenError, NotFoundError, type DbPort, type OrgExport } from '@app/domain'

export function makeExportOrg(db: DbPort) {
  return function exportOrg(userId: string, orgId: string): Promise<OrgExport> {
    return db.withOrg(userId, orgId, async (repos, { role }) => {
      if (!canInOrg(role, 'data:export')) throw new ForbiddenError('Only an owner can export the organization')
      const organization = (await repos.orgs.listForUser(userId)).find((m) => m.organization.id === orgId)?.organization
      if (!organization) throw new NotFoundError('Organization not found')
      const [members, subscription, audit] = [
        await repos.orgs.listMembers(orgId),
        await repos.subscriptions.getForOrganization(orgId),
        await repos.audit.listForOrg(orgId),
      ]
      await repos.audit.record({
        orgId, actorUserId: userId, actorKind: 'user',
        action: 'org.exported', targetType: 'organization', targetId: orgId,
      })
      return { exportedAt: new Date().toISOString(), organization, members, subscription, audit }
    })
  }
}
