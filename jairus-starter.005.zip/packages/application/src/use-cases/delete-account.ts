// Use-case (F8): a user deletes their account.
//
// Enforces the ≥1-owner invariant (RLS does not): for every membership —
//   member, or an owner alongside another owner → they simply leave
//   sole owner AND sole member (e.g. the personal org) → the org is deleted
//   sole owner with other members                     → REFUSED: transfer
//     ownership or delete that organization first.
// All checks run before anything changes. Then the identity is deleted, which
// cascades account, session and the remaining memberships.
import { ValidationError, type BillingPort, type DbPort } from '@app/domain'
import { makeDeleteOrg } from './delete-org'

export function makeDeleteAccount(db: DbPort, billing: Pick<BillingPort, 'deleteCustomer'>) {
  const deleteOrg = makeDeleteOrg(db, billing)
  return async function deleteAccount(userId: string): Promise<void> {
    const memberships = await db.withUser(userId, (repos) => repos.orgs.listForUser(userId))
    const toDelete: string[] = []
    const toLeave: string[] = []
    for (const m of memberships) {
      const orgId = m.organization.id
      const members = await db.withOrg(userId, orgId, (repos) => repos.orgs.listMembers(orgId))
      const anotherOwner = members.some((x) => x.userId !== userId && x.role === 'owner')
      if (m.role !== 'owner' || anotherOwner) toLeave.push(orgId)
      else if (members.length === 1) toDelete.push(orgId)
      else throw new ValidationError(
        `You are the last owner of "${m.organization.name}". Transfer ownership or delete that organization first.`,
      )
    }

    for (const orgId of toDelete) await deleteOrg(userId, orgId)
    await db.withUser(userId, async (repos) => {
      for (const orgId of toLeave) {
        await repos.audit.record({
          orgId, actorUserId: userId, actorKind: 'user',
          action: 'membership.removed', targetType: 'membership', targetId: userId,
          metadata: { reason: 'account deleted' },
        })
      }
      await repos.audit.record({
        orgId: null, actorUserId: userId, actorKind: 'user',
        action: 'user.deleted', targetType: 'user', targetId: userId,
        metadata: { orgsDeleted: toDelete, orgsLeft: toLeave },
      })
      await repos.users.delete(userId)
    })
  }
}
