// `pnpm db:verify-rls` — proves the three-role security model is in force, and
// exits non-zero when it is not, so CI can gate on it.
//
// RLS fails silently: a correct policy does nothing for a role holding BYPASSRLS,
// even under FORCE. Nothing errors and queries keep returning other users' rows,
// so every claim is checked empirically. Table classification mirrors the
// schema.ts header — keep the two lists in sync when you add a table.
//
// The tenancy proofs (section 6) write throwaway rows as app_user inside ONE
// transaction that always ROLLs BACK, so a run leaves no residue.
import { randomUUID } from "node:crypto"
import { loadEnvFile } from "node:process"
try {
  loadEnvFile() // packages/adapters/.env, before anything reads process.env
} catch {
  // No local .env: env comes from the shell or the platform.
}

/** IDENTITY tables: owner-only policy, reached through withUser(). */
const IDENTITY = [
  { table: "user", ownerCol: "id", policy: "user_self_isolation" },
  { table: "account", ownerCol: "user_id", policy: "account_user_isolation" },
  { table: "session", ownerCol: "user_id", policy: "session_user_isolation" },
] as const
/** BUSINESS tables: org_id + orgPolicy, reached through withOrg(). */
const BUSINESS = [
  { table: "subscription", policy: "subscription_org_isolation" },
] as const
/** TENANT DIRECTORY: membership-scoped, via the SECURITY DEFINER helpers. */
const TENANT_DIR = [
  { table: "organization", policies: ["organization_member_read", "organization_bootstrap_insert", "organization_admin_update", "organization_owner_delete"] },
  { table: "membership", policies: ["membership_read", "membership_insert", "membership_update", "membership_delete"] },
] as const
/** The policy helpers (hand-written at the top of drizzle/0000_init.sql). */
const RLS_FUNCTIONS = ["app_is_org_member", "app_is_org_admin", "app_is_org_owner", "app_org_is_empty", "app_org_access"]
/** AUTH-PRIVATE: RLS on, no policy, app_user denied entirely. */
const AUTH_PRIVATE = ["verification"] as const
/** SYSTEM: append-only ledgers — app_user may INSERT, never read. */
const SYSTEM = [{ table: "billing_event", policy: "billing_event_append_only" }] as const
/** SYSTEM audit trail: INSERT for app_user, SELECT only for org owners/admins (RLS). */
const AUDIT = { table: "audit_log", policies: { audit_log_append_only: "INSERT", audit_log_org_admin_read: "SELECT" } } as const
/** What auth_user may touch — and business tables it must NOT. */
const AUTH_TABLES = ["user", "account", "session", "verification"] as const
const NOT_FOR_AUTH = ["organization", "membership", "subscription", "audit_log", "role", "permission", "role_permission", "billing_event"] as const

type Sql = import("postgres").Sql
type Tx = import("postgres").TransactionSql
/** Thrown to end the proof transaction: postgres.js rolls back on any throw. */
class Rollback extends Error {}
const checks: { name: string; ok: boolean }[] = []
const record = (name: string, ok: boolean, detail: string) => {
  checks.push({ name, ok })
  console.log(`${ok ? "  PASS" : "  FAIL"}  ${name}\n        ${detail}`)
}
const skip = (name: string, why: string) => console.log(`  SKIP  ${name}\n        ${why}`)

/** Runs a read; returns its row count, or "denied" for a privilege error (42501). */
async function tryCount(sql: Sql, table: string): Promise<number | "denied"> {
  try {
    const [r] = await sql.unsafe<{ n: number }[]>(`select count(*)::int as n from "${table}"`)
    return r?.n ?? 0
  } catch (e) {
    if ((e as { code?: string }).code === "42501") return "denied"
    throw e
  }
}

async function roleFlags(sql: Sql) {
  const [r] = await sql<{ name: string; superuser: boolean; bypass: boolean }[]>`
    select current_user as name, rolsuper as superuser, rolbypassrls as bypass
    from pg_roles where rolname = current_user`
  return r
}

async function main() {
  const { default: postgres } = await import("postgres")
  const appUrl = process.env.DATABASE_URL
  if (!appUrl) {
    console.error("DATABASE_URL is not set — nothing to verify.")
    process.exit(1)
  }
  const app = postgres(appUrl, { prepare: false, max: 1 })
  const adminUrl = process.env.DATABASE_URL_ADMIN
  const admin = adminUrl ? postgres(adminUrl, { prepare: false, max: 1 }) : null
  const authUrl = process.env.DATABASE_URL_AUTH
  const authDb = authUrl ? postgres(authUrl, { prepare: false, max: 1 }) : null

  try {
    // ── 1. app_user (DATABASE_URL) ────────────────────────────────────────
    console.log("\napp_user — DATABASE_URL\n")
    const appRole = await roleFlags(app)
    record(
      "app role cannot bypass RLS",
      !!appRole && !appRole.bypass && !appRole.superuser,
      appRole ? `"${appRole.name}" superuser=${appRole.superuser}, bypassrls=${appRole.bypass}` : "unresolved",
    )

    const meta = await app<{ table: string; enabled: boolean; forced: boolean; owner: string }[]>`
      select c.relname as table, c.relrowsecurity as enabled, c.relforcerowsecurity as forced,
             pg_get_userbyid(c.relowner) as owner
      from pg_class c join pg_namespace n on n.oid = c.relnamespace
      where n.nspname = 'public' and c.relkind = 'r'`
    const policies = await app<{ table: string; policy: string; cmd: string }[]>`
      select tablename as table, policyname as policy, cmd from pg_policies where schemaname = 'public'`
    const metaOf = (t: string) => meta.find((m) => m.table === t)

    if (appRole && meta.some((m) => m.owner === appRole.name)) {
      record("app role owns no tables", false, `app_user must not be the table owner (owns: ${meta
        .filter((m) => m.owner === appRole.name).map((m) => m.table).join(", ")})`)
    } else record("app role owns no tables", true, "RLS binds it as a non-owner")

    // ── 2. IDENTITY tables ────────────────────────────────────────────────
    console.log("\nIDENTITY tables\n")
    for (const { table, ownerCol, policy } of IDENTITY) {
      const m = metaOf(table)
      record(`${table}: RLS enabled + forced`, !!m && m.enabled && m.forced,
        m ? `enabled=${m.enabled}, forced=${m.forced}` : "table not found — run pnpm db:migrate")
      record(`${table}: isolation policy present`,
        policies.some((p) => p.table === table && p.policy === policy),
        policies.filter((p) => p.table === table).map((p) => p.policy).join(", ") || "no policies")

      if (!admin) { skip(`${table}: unscoped read hides other rows`, "DATABASE_URL_ADMIN not set — no ground truth"); continue }
      const actual = await tryCount(admin, table)
      const seen = await tryCount(app, table)
      if (actual === 0) {
        console.log(`  ????  ${table}: unscoped read hides other rows\n        INCONCLUSIVE: table is empty — re-run once it has data`)
        continue
      }
      record(`${table}: unscoped read hides other rows`, seen === 0 || seen === "denied",
        `${actual} row(s) exist; app_user without withUser() saw ${seen}`)

      // Own-row probe: inside withUser(owner) the owner must still see exactly
      // their rows, or the policy broke the app rather than securing it.
      const [probe] = await admin.unsafe<{ owner: string }[]>(`select "${ownerCol}" as owner from "${table}" limit 1`)
      if (!probe) continue
      const [{ n: expected } = { n: -1 }] = await admin.unsafe<{ n: number }[]>(
        `select count(*)::int as n from "${table}" where "${ownerCol}" = $1`, [probe.owner])
      const visible = await app.begin(async (tx) => {
        await tx`select set_config('app.user_id', ${probe.owner}, true)`
        const [r] = await tx.unsafe<{ n: number }[]>(`select count(*)::int as n from "${table}"`)
        return r?.n ?? -1
      })
      record(`${table}: withUser(owner) sees exactly its own rows`, visible === expected,
        `owner ${probe.owner.slice(0, 8)}… saw ${visible}, owns ${expected}`)
    }

    // ── 2b. BUSINESS + TENANT DIRECTORY tables (structure) ─────────────────
    console.log("\nBUSINESS + TENANT DIRECTORY tables\n")
    for (const { table, policy } of BUSINESS) {
      const m = metaOf(table)
      record(`${table}: RLS enabled + forced`, !!m && m.enabled && m.forced,
        m ? `enabled=${m.enabled}, forced=${m.forced}` : "table not found — run pnpm db:migrate")
      record(`${table}: organization policy present`,
        policies.some((p) => p.table === table && p.policy === policy),
        policies.filter((p) => p.table === table).map((p) => p.policy).join(", ") || "no policies")
    }
    for (const { table, policies: expected } of TENANT_DIR) {
      const m = metaOf(table)
      record(`${table}: RLS enabled + forced`, !!m && m.enabled && m.forced,
        m ? `enabled=${m.enabled}, forced=${m.forced}` : "table not found — run pnpm db:migrate")
      const have = policies.filter((p) => p.table === table).map((p) => p.policy)
      const missing = expected.filter((p) => !have.includes(p))
      record(`${table}: membership policies present`, missing.length === 0,
        missing.length ? `missing: ${missing.join(", ")}` : have.join(", "))
    }
    const fns = await app<{ name: string; definer: boolean; exec: boolean; owner: string; ownerBypass: boolean }[]>`
      select p.proname as name, p.prosecdef as definer, has_function_privilege(p.oid, 'EXECUTE') as exec,
             r.rolname as owner, (r.rolbypassrls or r.rolsuper) as "ownerBypass"
      from pg_proc p join pg_namespace n on n.oid = p.pronamespace join pg_roles r on r.oid = p.proowner
      where n.nspname = 'public' and p.proname = any(${RLS_FUNCTIONS}::text[])`
    for (const name of RLS_FUNCTIONS) {
      const f = fns.find((x) => x.name === name)
      record(`${name}(): SECURITY DEFINER, executable by app_user`, !!f && f.definer && f.exec,
        f ? `definer=${f.definer}, app_user execute=${f.exec}` : "function not found — run pnpm db:migrate")
      // Owned by a NOBYPASSRLS role, FORCE would apply the membership policies
      // inside the helper and recurse (or filter) — it must be the owner role.
      record(`${name}(): owned by a BYPASSRLS role`, !!f && f.ownerBypass,
        f ? `owner "${f.owner}" bypassrls=${f.ownerBypass}` : "function not found")
    }

    // ── 3. AUTH-PRIVATE tables ────────────────────────────────────────────
    console.log("\nAUTH-PRIVATE tables\n")
    for (const table of AUTH_PRIVATE) {
      const m = metaOf(table)
      record(`${table}: RLS enabled + forced`, !!m && m.enabled && m.forced,
        m ? `enabled=${m.enabled}, forced=${m.forced}` : "table not found")
      const pols = policies.filter((p) => p.table === table)
      record(`${table}: has NO policy`, pols.length === 0, pols.map((p) => p.policy).join(", ") || "none")
      const seen = await tryCount(app, table)
      record(`${table}: app_user denied entirely`, seen === "denied" || seen === 0,
        seen === "denied" ? "privilege revoked (strongest)" : `RLS returned ${seen} row(s)`)
    }

    // ── 3b. SYSTEM tables (append-only) ───────────────────────────────────
    console.log("\nSYSTEM tables\n")
    for (const { table, policy } of SYSTEM) {
      const m = metaOf(table)
      record(`${table}: RLS enabled + forced`, !!m && m.enabled && m.forced,
        m ? `enabled=${m.enabled}, forced=${m.forced}` : "table not found")
      const pols = policies.filter((p) => p.table === table)
      record(`${table}: only an INSERT policy`,
        pols.length === 1 && pols[0]?.policy === policy && pols[0]?.cmd === "INSERT",
        pols.map((p) => `${p.policy}(${p.cmd})`).join(", ") || "no policies")
      // Reading must yield nothing: history is invisible to the app role.
      if (admin && (await tryCount(admin, table)) === 0) {
        console.log(`  ????  ${table}: app_user cannot read history\n        INCONCLUSIVE: table is empty`)
      } else {
        const seen = await tryCount(app, table)
        record(`${table}: app_user cannot read history`, seen === 0 || seen === "denied", `app_user saw ${seen}`)
      }
    }

    {
      const m = metaOf(AUDIT.table)
      record(`${AUDIT.table}: RLS enabled + forced`, !!m && m.enabled && m.forced,
        m ? `enabled=${m.enabled}, forced=${m.forced}` : "table not found")
      const pols = policies.filter((p) => p.table === AUDIT.table)
      const want = Object.entries(AUDIT.policies)
      record(`${AUDIT.table}: exactly an INSERT + an org-admin SELECT policy`,
        pols.length === want.length && want.every(([n, cmd]) => pols.some((p) => p.policy === n && p.cmd === cmd)),
        pols.map((p) => `${p.policy}(${p.cmd})`).join(", ") || "no policies")
      const [priv] = await app<{ upd: boolean; del: boolean }[]>`
        select has_table_privilege('public.audit_log', 'UPDATE') as upd, has_table_privilege('public.audit_log', 'DELETE') as del`
      record(`${AUDIT.table}: app_user holds no UPDATE/DELETE`, !!priv && !priv.upd && !priv.del,
        priv ? `update=${priv.upd}, delete=${priv.del}` : "unresolved")
    }

    // ── 4. auth_user (DATABASE_URL_AUTH) — Better Auth only ───────────────
    console.log("\nauth_user — DATABASE_URL_AUTH\n")
    if (!authDb) {
      record("DATABASE_URL_AUTH is set", !!appRole?.bypass,
        appRole?.bypass
          ? "unset, but DATABASE_URL bypasses RLS (single-role dev) — acceptable locally only"
          : "UNSET while DATABASE_URL is RLS-bound: Better Auth would see zero rows and sign-in breaks")
    } else {
      const authRole = await roleFlags(authDb)
      record("auth role bypasses RLS (reads before identity)", !!authRole?.bypass && !authRole.superuser,
        authRole ? `"${authRole.name}" bypassrls=${authRole.bypass}, superuser=${authRole.superuser}` : "unresolved")
      record("auth role is distinct from the app role", authRole?.name !== appRole?.name,
        `auth="${authRole?.name}", app="${appRole?.name}"`)
      for (const t of AUTH_TABLES) {
        const r = await tryCount(authDb, t)
        record(`auth role can read ${t}`, r !== "denied", r === "denied" ? "permission denied" : `${r} row(s)`)
      }
      for (const t of NOT_FOR_AUTH) {
        const r = await tryCount(authDb, t)
        record(`auth role CANNOT read ${t}`, r === "denied",
          r === "denied" ? "permission denied — bypass reaches nothing here" : `read ${r} row(s): GRANTs too broad`)
      }
      // No privilege at all (not just SELECT) on the tenant + business tables.
      const privs = await authDb<{ table: string; any: boolean }[]>`
        select t as table, has_table_privilege('public.' || quote_ident(t), 'SELECT,INSERT,UPDATE,DELETE') as any
        from unnest(${["organization", "membership", "subscription", "audit_log"]}::text[]) as t`
      for (const p of privs) {
        record(`auth role has NO privilege on ${p.table}`, !p.any, p.any ? "holds a DML privilege — revoke it" : "none")
      }
      const [authFns] = await authDb<{ n: number }[]>`
        select count(*)::int as n from pg_proc p join pg_namespace n on n.oid = p.pronamespace
        where n.nspname = 'public' and p.proname = any(${RLS_FUNCTIONS}::text[])
          and has_function_privilege(p.oid, 'EXECUTE')`
      record("auth role cannot execute the RLS helpers", (authFns?.n ?? 0) === 0,
        `${authFns?.n ?? 0} executable — EXECUTE must be revoked from PUBLIC`)
    }

    // ── 5. owner (DATABASE_URL_ADMIN) ─────────────────────────────────────
    console.log("\nowner — DATABASE_URL_ADMIN\n")
    if (!admin) skip("owner bypasses RLS", "DATABASE_URL_ADMIN not set")
    else {
      const ownerRole = await roleFlags(admin)
      // Under FORCE, ownership alone no longer bypasses — the owner needs
      // BYPASSRLS or every dbAdminPort read (overview, staff) returns nothing.
      record("owner bypasses RLS (dbAdminPort works under FORCE)", !!ownerRole?.bypass || !!ownerRole?.superuser,
        ownerRole ? `"${ownerRole.name}" bypassrls=${ownerRole.bypass}` : "unresolved")
    }

    // ── 6. Tenancy proofs (app_user, rolled back) ─────────────────────────
    console.log("\ntenancy proofs — app_user, one transaction, ROLLED BACK\n")
    await tenancyProofs(app)
  } finally {
    await Promise.all([app.end(), admin?.end(), authDb?.end()])
  }

  const failed = checks.filter((c) => !c.ok)
  if (failed.length) {
    console.error(`\n${failed.length} of ${checks.length} checks FAILED. Fix with packages/adapters/sql/provision-roles.sql (see README → Database roles).\n`)
    process.exit(1)
  }
  console.log(`\nAll ${checks.length} checks passed — the three-role RLS model is enforced.\n`)
}

/** Empirical tenancy proofs. Every row is created by app_user through the same
 *  policies the app relies on (a user may insert its own `user` row under
 *  user_self_isolation), and the whole transaction is rolled back. */
async function tenancyProofs(app: Sql) {
  const tag = randomUUID().slice(0, 8)
  const [A, B, C, D, E] = ["a", "b", "c", "d", "e"].map((x) => `verify-rls-${tag}-${x}`) as [string, string, string, string, string]
  const ws = `verify-rls-${tag}-ws`
  try {
    await app.begin(async (tx) => {
      // Same GUCs as DbPort: '' reads as unset to every policy.
      const as = (userId: string | null, orgId: string | null) =>
        tx`select set_config('app.user_id', ${userId ?? ""}, true), set_config('app.org_id', ${orgId ?? ""}, true)`
      // "ok", or "rls" for an RLS / privilege refusal (42501); anything else is a real error.
      const attempt = async (fn: (sp: Tx) => Promise<unknown>): Promise<"ok" | "rls"> => {
        try {
          await tx.savepoint(fn)
          return "ok"
        } catch (e) {
          if ((e as { code?: string }).code === "42501") return "rls"
          throw e
        }
      }
      const count = async (q: Promise<{ n: number }[]>) => (await q)[0]?.n ?? -1

      for (const u of [A, B, C, D, E]) {
        await as(u, null)
        await tx`insert into "user" (id, name, email) values (${u}, ${u}, ${`${u}@verify-rls.invalid`})`
      }

      // (i) A self-creates a personal organization — the createOrg path:
      // publish user + new organization id, insert organization, insert self as owner.
      await as(A, ws)
      const created = await attempt(async (sp) => {
        await sp`insert into organization (id, name, slug) values (${ws}, 'verify-rls', ${ws})`
        await sp`insert into membership (organization_id, user_id, role) values (${ws}, ${A}, 'owner')`
      })
      record("(i) self-owner on an EMPTY organization succeeds (createOrg)", created === "ok", `result: ${created}`)
      if (created !== "ok") throw new Rollback()
      const seesOwn = await count(tx`select count(*)::int as n from organization where id = ${ws}`)
      record("    creator sees the organization via membership", seesOwn === 1, `saw ${seesOwn}`)

      // (ii) B tries to self-grant owner on A's (now non-empty) organization.
      await as(B, ws)
      const hijack = await attempt((sp) => sp`insert into membership (organization_id, user_id, role) values (${ws}, ${B}, 'owner')`)
      record("(ii) self-owner on a NON-empty organization is refused", hijack === "rls", `result: ${hijack}`)

      // (iii) owner A adds C as member (allowed); member C adds D (refused).
      await as(A, ws)
      const ownerAdds = await attempt((sp) => sp`insert into membership (organization_id, user_id, role) values (${ws}, ${C}, 'member')`)
      record("    owner can add a member", ownerAdds === "ok", `result: ${ownerAdds}`)
      await as(C, ws)
      const memberAdds = await attempt((sp) => sp`insert into membership (organization_id, user_id, role) values (${ws}, ${D}, 'member')`)
      record("(iii) a plain member cannot add members", memberAdds === "rls", `result: ${memberAdds}`)

      // Business table: a subscription in A's organization.
      await as(A, ws)
      const subIns = await attempt((sp) => sp`insert into subscription (org_id) values (${ws})`)
      record("    member writes a business row in the active organization", subIns === "ok", `result: ${subIns}`)
      await as(C, ws)
      const memberSees = await count(tx`select count(*)::int as n from subscription`)
      record("    co-member sees it with the organization active", memberSees === 1, `saw ${memberSees}`)

      await as(A, null)
      const noGuc = await count(tx`select count(*)::int as n from subscription`)
      record("no app.org_id → subscription returns 0 rows", noGuc === 0, `saw ${noGuc}`)

      await as(B, ws)
      const sub = await count(tx`select count(*)::int as n from subscription`)
      const others = await count(tx`select count(*)::int as n from membership where user_id <> ${B}`)
      const wsRows = await count(tx`select count(*)::int as n from organization where id = ${ws}`)
      record("non-member organization GUC → 0 business rows", sub === 0, `subscription: saw ${sub}`)
      record("non-member organization GUC → 0 membership-of-others", others === 0, `membership: saw ${others}`)
      record("non-member organization GUC → organization invisible", wsRows === 0, `organization: saw ${wsRows}`)

      // Audit (F5): any app path may append; only owners/admins read the org's
      // rows; nobody rewrites them.
      await as(A, ws)
      const auditIns = await attempt((sp) => sp`
        insert into audit_log (org_id, actor_user_id, actor_kind, action, target_type, target_id)
        values (${ws}, ${A}, 'user', 'verify.probe', 'organization', ${ws})`)
      record("    app_user can append to audit_log", auditIns === "ok", `result: ${auditIns}`)
      const ownerReads = await count(tx`select count(*)::int as n from audit_log where org_id = ${ws}`)
      record("    org owner reads its org's audit rows", ownerReads >= 1, `saw ${ownerReads}`)
      const auditUpd = await attempt((sp) => sp`update audit_log set action = 'tampered' where org_id = ${ws}`)
      const auditDel = await attempt((sp) => sp`delete from audit_log where org_id = ${ws}`)
      record("audit_log is append-only for app_user (UPDATE/DELETE refused)", auditUpd === "rls" && auditDel === "rls",
        `update: ${auditUpd}, delete: ${auditDel}`)
      await as(C, ws)
      const memberReads = await count(tx`select count(*)::int as n from audit_log where org_id = ${ws}`)
      record("a non-admin member cannot read the org's audit_log", memberReads === 0, `saw ${memberReads}`)

      // createPersonalOrg path (DbPort): advisory lock, re-check, insert only
      // when the user has no membership. Run twice → still one membership.
      const personalOrg = async (userId: string) => {
        await as(userId, null)
        await tx`select pg_advisory_xact_lock(hashtextextended(${`personal_org:${userId}`}, 0))`
        const [has] = await tx`select 1 from membership where user_id = ${userId} limit 1`
        if (has) return
        const org = `${userId}-org`
        await as(userId, org)
        await tx`insert into organization (id, name, slug) values (${org}, 'verify-rls', ${org})`
        await tx`insert into membership (organization_id, user_id, role) values (${org}, ${userId}, 'owner')`
      }
      await personalOrg(E)
      await personalOrg(E)
      await as(E, null)
      const eMemberships = await count(tx`select count(*)::int as n from membership where user_id = ${E}`)
      record("createPersonalOrg is idempotent (twice → one membership)", eMemberships === 1, `memberships: ${eMemberships}`)

      throw new Rollback()
    })
  } catch (e) {
    if (!(e instanceof Rollback)) throw e
  }
}

main().catch((e) => {
  console.error("verify-rls failed to run:", e)
  process.exit(1)
})
