// Jobs adapter — implements JobsPort with an inline runner.
// The handler runs in-process right away; a failure is reported, not thrown,
// so the request that enqueued it still succeeds. There is no retry and no
// durability: a crash mid-job loses it. That is the right default for dev and
// for low-stakes jobs like a welcome email. When a job must survive failures,
// replace `enqueue` with a queue client (Inngest `inngest.send`, QStash
// `publishJSON`, Vercel Queues) that calls back into a route which runs
// `handlers[name]` — the handlers and every caller stay unchanged.
import type { JobName, JobPayloads, JobsPort } from '@app/domain'
import { brand } from '@app/config/brand'
import { email } from '../email/index'
import { errorReporter } from '../errors/index'

const handlers: { [N in JobName]: (payload: JobPayloads[N]) => Promise<void> } = {
  'email.welcome': async ({ to, name }) => {
    await email.send({
      to,
      subject: `Welcome to ${brand.name}`,
      text: [`Hi ${name},`, ``, `Your ${brand.name} account is ready.`, ``, `— The ${brand.name} team`].join('\n'),
    })
  },
}

// Per-process dedupe, bounded. A real queue dedupes durably by the same key.
const seen = new Set<string>()

export const jobs: JobsPort = {
  async enqueue(name, payload, opts) {
    const key = opts?.idempotencyKey
    if (key) {
      if (seen.has(key)) return
      if (seen.size > 10_000) seen.clear()
      seen.add(key)
    }
    try {
      await handlers[name](payload)
    } catch (e) {
      errorReporter.capture(e, { job: name })
    }
  },
}
