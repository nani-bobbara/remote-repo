// Error-reporting adapter — implements ErrorReporterPort.
// Default: one structured line on the server log (picked up by Vercel/any log
// drain). With SENTRY_DSN set, the same error also goes to Sentry, tagged with
// userId/orgId. The SDK is imported lazily, so it costs nothing unset.
import type { ErrorContext, ErrorReporterPort } from '@app/domain'
import { getEnv } from '@app/config/env'

type Sentry = typeof import('@sentry/node')
let sentry: Promise<Sentry | null> | null = null

function loadSentry(): Promise<Sentry | null> {
  if (!sentry) {
    const { SENTRY_DSN, SENTRY_ENVIRONMENT } = getEnv('errors')
    sentry = SENTRY_DSN
      ? import('@sentry/node').then((s) => {
          s.init({ dsn: SENTRY_DSN, environment: SENTRY_ENVIRONMENT ?? process.env.NODE_ENV })
          return s
        })
      : Promise.resolve(null)
  }
  return sentry
}

export const errorReporter: ErrorReporterPort = {
  capture(error: unknown, context: ErrorContext = {}) {
    const err = error instanceof Error ? error : new Error(String(error))
    console.error(JSON.stringify({ level: 'error', msg: err.message, name: err.name, stack: err.stack, ...context }))
    // Fire-and-forget: reporting must never throw into, or delay, the caller.
    void loadSentry()
      .then((s) =>
        s?.withScope((scope) => {
          if (context.userId) scope.setUser({ id: context.userId })
          for (const [k, v] of Object.entries(context)) if (v !== undefined) scope.setTag(k, v)
          s.captureException(err)
        }),
      )
      .catch(() => {})
  },
}
