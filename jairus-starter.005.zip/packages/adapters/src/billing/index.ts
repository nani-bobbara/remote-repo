// Billing adapter — Stripe, implements the domain BillingPort.
// The Stripe client is lazy-constructed so importing this module is build-safe
// even when STRIPE_SECRET_KEY is absent (it only throws when actually used).
// All Stripe payload knowledge lives HERE: parseWebhook normalises events into
// the domain BillingEvent, so no vendor shape reaches the application.
import Stripe from 'stripe'
import type { BillingEvent, BillingPort, PlanTier } from '@app/domain'
import { PLANS, isPlanId, type PlanId } from '@app/config/plans'
import { getEnv } from '@app/config/env'

// Compile-time guard: the domain's PlanTier and the config catalog must name
// exactly the same plans. Adding a plan to one without the other fails here.
type Exact<A, B> = [A] extends [B] ? ([B] extends [A] ? true : false) : false
const tiersMatchCatalog: Exact<PlanTier, PlanId> = true
void tiersMatchCatalog

let _stripe: Stripe | null = null
function stripe(): Stripe {
  if (!_stripe) {
    _stripe = new Stripe(getEnv('billing').STRIPE_SECRET_KEY)
  }
  return _stripe
}

function priceFor(tier: PlanTier): string | undefined {
  const env = PLANS[tier].priceEnv
  return env ? (getEnv('billing') as Record<string, string | undefined>)[env] : undefined
}

function toBillingEvent(evt: Stripe.Event): BillingEvent {
  if (evt.type !== 'checkout.session.completed') {
    return { id: evt.id, kind: 'ignored', providerType: evt.type, reason: 'event type not handled' }
  }
  const s = evt.data.object
  // The subscription belongs to the ORGANIZATION; the user is carried for audit.
  const orgId = s.metadata?.orgId ?? s.client_reference_id ?? null
  const tier = s.metadata?.tier
  if (!orgId) {
    return { id: evt.id, kind: 'ignored', providerType: evt.type, reason: 'no orgId on session' }
  }
  // No silent fallback tier: an unknown/missing tier must not grant a paid plan.
  if (!isPlanId(tier)) {
    return { id: evt.id, kind: 'ignored', providerType: evt.type, reason: `unknown tier "${String(tier)}"` }
  }
  return {
    id: evt.id,
    kind: 'checkout.completed',
    orgId,
    userId: s.metadata?.userId ?? null,
    tier,
    stripeCustomerId: typeof s.customer === 'string' ? s.customer : null,
  }
}

export const billing: BillingPort = {
  async createCheckout({ orgId, userId }, tier) {
    const price = priceFor(tier)
    if (!price) throw new Error(`No Stripe price configured for tier "${tier}"`)
    // This app's validated origin — no localhost fallback in production (L3).
    const base = getEnv('auth').BETTER_AUTH_URL
    const s = await stripe().checkout.sessions.create({
      mode: 'subscription',
      line_items: [{ price, quantity: 1 }],
      client_reference_id: orgId,
      metadata: { orgId, userId, tier },
      subscription_data: { metadata: { orgId, userId, tier } },
      success_url: `${base}/settings?upgraded=1`,
      cancel_url: `${base}/settings`,
    })
    return { url: s.url ?? base }
  },
  async deleteCustomer(customerId) {
    try {
      await stripe().customers.del(customerId)
    } catch (e) {
      // Already gone (deleted earlier, or in the dashboard) is the goal state.
      if ((e as { code?: string }).code === 'resource_missing') return
      throw e
    }
  },
  async parseWebhook(payload, signature) {
    const secret = getEnv('billing').STRIPE_WEBHOOK_SECRET
    return toBillingEvent(stripe().webhooks.constructEvent(payload, signature, secret))
  },
}
