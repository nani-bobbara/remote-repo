// Email adapter — Resend, implements the domain EmailPort.
// Lazy-constructed client so importing this module is build-safe without a key.
import { Resend } from 'resend'
import type { EmailMessage, EmailPort } from '@app/domain'
import { getEnv } from '@app/config/env'

// The env schema maps the .env.example placeholder to "unset", so a fresh
// clone is treated as unconfigured instead of failing every send.
function apiKey(): string | null {
  return getEnv('email').RESEND_API_KEY ?? null
}

let _resend: Resend | null = null
function resend(key: string): Resend {
  if (!_resend) _resend = new Resend(key)
  return _resend
}

export const email: EmailPort = {
  async send(message: EmailMessage) {
    // Without a key there is nothing to send through. In development the
    // message goes to the server log so flows that depend on a link (password
    // reset) remain testable; anywhere else a silent no-op would hide a broken
    // production setup, so it fails loudly instead.
    const key = apiKey()
    if (!key) {
      if (process.env.NODE_ENV === 'production') {
        throw new Error('RESEND_API_KEY is not configured — cannot send email')
      }
      console.warn(
        `\n[email] RESEND_API_KEY not configured; message not sent.\n` +
          `  to:      ${message.to}\n  subject: ${message.subject}\n\n${message.text}\n`,
      )
      return
    }

    const { error } = await resend(key).emails.send({
      // Required in production by the env schema; the default is dev-only.
      from: getEnv('email').EMAIL_FROM ?? 'noreply@example.com',
      to: message.to,
      subject: message.subject,
      text: message.text,
      ...(message.html ? { html: message.html } : {}),
    })
    // Resend reports failures in the response rather than throwing.
    if (error) throw new Error(`Email send failed: ${error.message}`)
  },
}
