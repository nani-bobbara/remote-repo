// Rate-limit adapter — in-memory fixed window, implements RateLimitPort.
// Per process: on serverless each instance counts separately, so this is a
// best-effort brake, not a distributed limit. For a shared limit, implement
// RateLimitPort over Upstash Redis (@upstash/ratelimit) or any Redis INCR +
// EXPIRE and export it here instead — callers only see the port.
import type { RateLimitPort } from '@app/domain'

const windows = new Map<string, { count: number; resetAt: number }>()

export const rateLimit: RateLimitPort = {
  async hit(key, { max, windowSec }) {
    const now = Date.now()
    let w = windows.get(key)
    if (!w || w.resetAt <= now) {
      // Opportunistic sweep keeps the map bounded by active keys.
      if (windows.size > 10_000) for (const [k, v] of windows) if (v.resetAt <= now) windows.delete(k)
      w = { count: 0, resetAt: now + windowSec * 1000 }
      windows.set(key, w)
    }
    w.count++
    return { ok: w.count <= max, retryAfterSec: Math.max(0, Math.ceil((w.resetAt - now) / 1000)) }
  },
}

/** Shared budgets, so call sites don't invent numbers. */
export const LIMITS = {
  /** Mutating server actions, per user. */
  action: { max: 30, windowSec: 60 },
  /** Inbound webhooks, per source IP (Stripe retries are well under this). */
  webhook: { max: 100, windowSec: 10 },
} as const
