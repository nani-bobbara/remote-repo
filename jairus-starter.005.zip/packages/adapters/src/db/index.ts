// DB adapter — implements the domain DbPort with Drizzle + Neon (postgres.js driver).
// Three connections, three Postgres roles (least privilege):
//   `db`      DATABASE_URL       app_user  (NOBYPASSRLS) — every app request; identity
//                                           data via withUser(), business data via
//                                           withOrg(), RLS-enforced.
//   `dbAuth`  DATABASE_URL_AUTH  auth_user (BYPASSRLS)   — Better Auth ONLY. It reads
//                                           user/session/account/verification before
//                                           an identity exists, so it cannot be RLS-scoped.
//   `dbAdmin` DATABASE_URL_ADMIN owner                   — migrations, seed, guarded
//                                           cross-user admin work. Never in the portal.
// RLS binds only for NOBYPASSRLS roles and fails silently otherwise — check with
// `pnpm db:verify-rls`. Table classification lives in the schema.ts header.
import { randomBytes, randomUUID } from 'node:crypto'
import { drizzle } from 'drizzle-orm/postgres-js'
import postgres from 'postgres'
import { and, asc, desc, eq, inArray, sql } from 'drizzle-orm'
import { getEnv } from '@app/config/env'
import { ForbiddenError, personalOrgName, slugify } from '@app/domain'
import type {
  AuditActorKind, AuditEntry, AuditEvent, DbPort, PermissionDef, RoleDef, Subscription, SystemDbPort, User, Organization, OrgRole,
} from '@app/domain'
import {
  account as accountT,
  auditLog as auditT,
  billingEvent as billingEventT,
  membership as memT,
  permission as permT,
  role as roleT,
  rolePermission as rolePermT,
  subscription as subT,
  user as userT,
  organization as orgT,
} from './schema'

const env = getEnv('db')
const scopedClient = postgres(env.DATABASE_URL, { prepare: false })
// Falls back to DATABASE_URL (the portal, which never holds the owner URL and is
// lint-barred from dbAdminPort). Direct URL = pooled host minus "-pooler".
const adminClient = postgres(env.DATABASE_URL_ADMIN ?? env.DATABASE_URL, { prepare: false })
export const db = drizzle(scopedClient, { schema: { userT, subT, roleT } })
export const dbAdmin = drizzle(adminClient, { schema: { userT, subT, roleT } })  // unscoped — system/admin only
// The Better Auth connection is deliberately NOT created here: it lives privately
// inside ../auth/index.ts so no application code can import a bypass client.

type Drizzle = typeof db

function toUser(r: typeof userT.$inferSelect): User {
  return {
    id: r.id, email: r.email, name: r.name, role: r.role, createdAt: r.createdAt,
    emailVerified: r.emailVerified, banned: r.banned ?? false,
  }
}
// Permissions live in role_permission now, so a role is only whole once its
// assigned keys are joined in. Every caller goes through loadRoles below.
function toRole(r: typeof roleT.$inferSelect, permissions: string[]): RoleDef {
  return {
    name: r.name,
    label: r.label,
    description: r.description,
    permissions,
    fullAccess: r.fullAccess,
    isSystem: r.isSystem,
  }
}

/**
 * Fetch roles with their permission keys in two queries rather than N+1.
 * `names` undefined = all roles.
 */
async function loadRoles(conn: Drizzle, names?: string[]): Promise<RoleDef[]> {
  const rows = names
    ? await conn.select().from(roleT).where(inArray(roleT.name, names)).orderBy(roleT.name)
    : await conn.select().from(roleT).orderBy(roleT.name)
  if (rows.length === 0) return []

  const links = await conn
    .select()
    .from(rolePermT)
    .where(inArray(rolePermT.roleName, rows.map((r) => r.name)))
    .orderBy(rolePermT.permissionKey)

  const byRole = new Map<string, string[]>()
  for (const l of links) {
    const list = byRole.get(l.roleName) ?? []
    list.push(l.permissionKey)
    byRole.set(l.roleName, list)
  }
  return rows.map((r) => toRole(r, byRole.get(r.name) ?? []))
}
function toPermission(r: typeof permT.$inferSelect): PermissionDef {
  return { key: r.key, label: r.label, description: r.description, resource: r.resource, isSystem: r.isSystem }
}
function toSub(r: typeof subT.$inferSelect): Subscription {
  return {
    id: r.id, orgId: r.orgId, tier: r.tier as Subscription['tier'],
    status: r.status as Subscription['status'], stripeCustomerId: r.stripeCustomerId,
    currentPeriodEnd: r.currentPeriodEnd,
  }
}

/** Bootstrap, inside the caller's transaction: publish the new id, then insert
 *  organization + self-owner membership. RLS allows the self-owner row only
 *  while the organization is empty, so this cannot join an existing one. */
// No RETURNING: audit_log is insert-only for app_user (no general SELECT).
async function recordAudit(conn: Drizzle, e: AuditEvent): Promise<void> {
  await conn.insert(auditT).values({ ...e, metadata: e.metadata ?? {} })
}
function toAudit(r: typeof auditT.$inferSelect): AuditEntry {
  return { ...r, actorKind: r.actorKind as AuditActorKind }
}

async function insertOrg(tx: Drizzle, userId: string, name: string): Promise<Organization> {
  const org: Organization = { id: randomUUID(), name, slug: `${slugify(name).slice(0, 40) || 'organization'}-${randomBytes(3).toString('hex')}` }
  await tx.execute(sql`select set_config('app.user_id', ${userId}, true)`)
  await tx.execute(sql`select set_config('app.org_id', ${org.id}, true)`)
  await tx.insert(orgT).values(org)
  await tx.insert(memT).values({ organizationId: org.id, userId, role: 'owner' })
  await recordAudit(tx, {
    orgId: org.id, actorUserId: userId, actorKind: 'user',
    action: 'org.created', targetType: 'organization', targetId: org.id, metadata: { name },
  })
  return org
}

function makePort(conn: Drizzle): DbPort {
  return {
    users: {
      async findById(id) { const [r] = await conn.select().from(userT).where(eq(userT.id, id)); return r ? toUser(r) : null },
      async findByEmail(email) { const [r] = await conn.select().from(userT).where(eq(userT.email, email)); return r ? toUser(r) : null },
      async list() { const rs = await conn.select().from(userT).orderBy(userT.createdAt); return rs.map(toUser) },
      async setRole(userId, role) { await conn.update(userT).set({ role }).where(eq(userT.id, userId)) },
      async setName(userId, name) { await conn.update(userT).set({ name }).where(eq(userT.id, userId)) },
      // 'credential' is Better Auth's providerId for email+password; a social
      // login stores the provider's id and leaves password null.
      async hasCredential(userId) {
        const [row] = await conn.select({ id: accountT.id }).from(accountT)
          .where(and(
            eq(accountT.userId, userId),
            eq(accountT.providerId, 'credential'),
            sql`${accountT.password} is not null`,
          ))
          .limit(1)
        return row !== undefined
      },
      async delete(userId) { await conn.delete(userT).where(eq(userT.id, userId)) },
    },
    subscriptions: {
      async getForOrganization(orgId) { const [r] = await conn.select().from(subT).where(eq(subT.orgId, orgId)); return r ? toSub(r) : null },
      async upsert(sub) {
        const [r] = await conn.insert(subT).values(sub).onConflictDoUpdate({
          target: subT.orgId, set: { tier: sub.tier, status: sub.status, stripeCustomerId: sub.stripeCustomerId, currentPeriodEnd: sub.currentPeriodEnd, updatedAt: new Date() },
        }).returning()
        return toSub(r!)
      },
    },
    billingEvents: {
      // No RETURNING: billing_event is append-only for app_user (INSERT policy,
      // no SELECT), and RETURNING would need SELECT. The affected-row count says
      // whether this call recorded it (1) or it was already there (0).
      async record(eventId, kind) {
        const res = await conn.insert(billingEventT).values({ eventId, kind })
          .onConflictDoNothing({ target: billingEventT.eventId })
        return (res as unknown as { count: number }).count === 1
      },
    },
    orgs: {
      async listForUser(userId) {
        const rs = await conn
          .select({ m: memT, w: { id: orgT.id, name: orgT.name, slug: orgT.slug } })
          .from(memT)
          .innerJoin(orgT, eq(orgT.id, memT.organizationId))
          .where(eq(memT.userId, userId))
          .orderBy(asc(memT.createdAt))
        return rs.map(({ m, w }) => ({ organization: w, userId: m.userId, role: m.role as OrgRole, createdAt: m.createdAt }))
      },
      async listMembers(orgId) {
        const rs = await conn.select().from(memT).where(eq(memT.organizationId, orgId)).orderBy(asc(memT.createdAt))
        return rs.map((m) => ({ userId: m.userId, role: m.role as OrgRole, createdAt: m.createdAt }))
      },
      async delete(orgId) { await conn.delete(orgT).where(eq(orgT.id, orgId)) },
    },
    audit: {
      record: (e) => recordAudit(conn, e),
      async listForOrg(orgId) {
        const rs = await conn.select().from(auditT).where(eq(auditT.orgId, orgId)).orderBy(desc(auditT.createdAt))
        return rs.map(toAudit)
      },
      async listRecent(limit) {
        const rs = await conn.select().from(auditT).orderBy(desc(auditT.createdAt)).limit(limit)
        return rs.map(toAudit)
      },
    },
    roles: {
      async getByName(name) { const [r] = await loadRoles(conn, [name]); return r ?? null },
      async list() { return loadRoles(conn) },
      async upsert(r) {
        // The role row and its assignments must move together: a half-applied
        // save would leave a role holding the wrong permissions.
        return conn.transaction(async (tx) => {
          const [row] = await tx.insert(roleT).values({
            name: r.name, label: r.label, description: r.description,
            fullAccess: r.fullAccess, isSystem: r.isSystem,
          }).onConflictDoUpdate({
            target: roleT.name,
            set: { label: r.label, description: r.description, fullAccess: r.fullAccess, isSystem: r.isSystem, updatedAt: new Date() },
          }).returning()

          // Replace the assignment set. Deleting first keeps this idempotent
          // and lets the caller pass the desired end state rather than a diff.
          await tx.delete(rolePermT).where(eq(rolePermT.roleName, r.name))
          if (r.permissions.length > 0) {
            // A key that is not in the catalog raises a foreign-key violation
            // here — which is the point of the join table.
            await tx.insert(rolePermT).values(
              r.permissions.map((permissionKey) => ({ roleName: r.name, permissionKey })),
            )
          }
          return toRole(row!, [...r.permissions].sort())
        })
      },
    },
    permissions: {
      async list() {
        const rs = await conn.select().from(permT).orderBy(permT.resource, permT.key)
        return rs.map(toPermission)
      },
      async upsert(p) {
        const [row] = await conn.insert(permT).values(p).onConflictDoUpdate({
          target: permT.key,
          set: { label: p.label, description: p.description, resource: p.resource, isSystem: p.isSystem, updatedAt: new Date() },
        }).returning()
        return toPermission(row!)
      },
      async remove(key) { await conn.delete(permT).where(eq(permT.key, key)) },
    },
    // set_config publishes the user id the RLS policy reads; the repos also
    // filter in their WHERE clauses. is_local=true scopes the setting to this
    // transaction, which is what makes it safe on a pooled connection.
    withUser<T>(userId: string, fn: (repos: DbPort) => Promise<T>): Promise<T> {
      return conn.transaction(async (tx) => {
        await tx.execute(sql`select set_config('app.user_id', ${userId}, true)`)
        return fn(makePort(tx as unknown as Drizzle))
      })
    },
    // Membership is checked INSIDE the transaction, before app.org_id is
    // published: a forged active_org cookie fails here and nothing runs.
    withOrg(userId, orgId, fn) {
      return conn.transaction(async (tx) => {
        await tx.execute(sql`select set_config('app.user_id', ${userId}, true)`)
        const [m] = await tx.select({ role: memT.role }).from(memT)
          .where(and(eq(memT.organizationId, orgId), eq(memT.userId, userId)))
        if (!m) throw new ForbiddenError('Not a member of this organization')
        await tx.execute(sql`select set_config('app.org_id', ${orgId}, true)`)
        return fn(makePort(tx as unknown as Drizzle), { role: m.role as OrgRole })
      })
    },
    createOrg(userId, name) {
      return conn.transaction((tx) => insertOrg(tx as unknown as Drizzle, userId, name))
    },
    // Idempotent: returns the user's oldest organization if they have one.
    // The advisory lock (per user, released at commit) serialises concurrent
    // first requests — e.g. two tabs. Without it both would see no membership
    // and each create an org with a DIFFERENT id, so the membership PK would
    // not stop the duplicate. The second waits, then finds the first's row.
    createPersonalOrg(userId, userName) {
      return conn.transaction(async (tx) => {
        await tx.execute(sql`select set_config('app.user_id', ${userId}, true)`)
        await tx.execute(sql`select pg_advisory_xact_lock(hashtextextended(${`personal_org:${userId}`}, 0))`)
        const [existing] = await makePort(tx as unknown as Drizzle).orgs.listForUser(userId)
        if (existing) return existing.organization
        return insertOrg(tx as unknown as Drizzle, userId, personalOrgName(userName))
      })
    },
  }
}

/** Default port (portal + feature use-cases). Identity via .withUser, business
 *  data via .withOrg. */
export const dbPort: DbPort = makePort(db)
/** The webhook's system entry into business data: sets ONLY app.org_id
 *  (no user — a webhook has no session). Lint-banned in the apps except the
 *  Stripe webhook route; see @app/config/eslint-boundaries. */
export const systemDbPort: SystemDbPort = {
  asOrgSystem(orgId, fn) {
    return db.transaction(async (tx) => {
      await tx.execute(sql`select set_config('app.org_id', ${orgId}, true)`)
      return fn(makePort(tx as unknown as Drizzle))
    })
  },
}
/** Unscoped port. System/webhook/admin cross-user ONLY — guard every call with
 *  requireStaff() or requirePermission(...) from @app/auth. */
export const dbAdminPort: DbPort = makePort(dbAdmin)
