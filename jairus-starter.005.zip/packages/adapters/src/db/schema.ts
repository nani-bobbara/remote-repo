// Drizzle schema — the single source of truth (drives migrations AND both apps' types).
// The Better Auth tables (user/session/account/verification) must match what Better Auth
// + its enabled plugins expect. Field (JS key) names must match Better Auth's model fields;
// regenerate with `npx @better-auth/cli generate` if you change the auth config/plugins.
//
// ── Row-level security: every table is classified ─────────────────────────
// Two transaction-local GUCs (NULL when unset → fail closed):
//   app.user_id       who is calling  — set by DbPort.withUser / withOrg
//   app.org_id  which tenant    — set ONLY by withOrg (after membership
//                     is verified in the same txn), createOrg (bootstrap) and
//                     SystemDbPort.asOrgSystem (the webhook's system entry).
// RLS binds the runtime role `app_user` (NOBYPASSRLS); every RLS table is also
// FORCEd in the migration so table ownership is no escape.
//
//   IDENTITY     user, account, session — ownerPolicy: the person's own rows.
//                Reached only through DbPort.withUser(userId).
//   TENANT DIR   organization, membership — visible through membership of
//                app.user_id; writes bounded to the active organization, member
//                writes owner/admin only, self-owner only on an EMPTY organization.
//   BUSINESS     subscription + every future business table — org_id NOT
//                NULL + orgPolicy. Reached through withOrg.
//   AUTH-PRIVATE verification — RLS on, NO policy: app_user sees nothing.
//                Only Better Auth (auth_user) touches it.
//   CATALOG      role, permission, role_permission — global platform RBAC.
//                Writes guarded in code by requirePermission(). No RLS by design.
//   SYSTEM       billing_event — append-only ledger written by the app; app_user
//                may INSERT but never read, update or delete it.
//                audit_log — append-only too (UPDATE/DELETE revoked); readable
//                only by owners/admins of the row's org (staff: dbAdminPort).
//
// Policies on organization/membership must read membership, which would recurse
// ("infinite recursion detected in policy for relation membership"). They call
// SECURITY DEFINER helpers instead — app_is_org_member(org), app_is_org_admin(org),
// app_is_org_owner(org), app_org_is_empty(org), app_org_access() — hand-written at the TOP of drizzle/0000_init.sql
// (drizzle-kit cannot emit functions). They run as the table owner (BYPASSRLS),
// read app.user_id / app.org_id themselves, and are EXECUTE-granted to
// app_user only.
//
// Better Auth runs as `auth_user` (BYPASSRLS, GRANTed only the four auth tables)
// because it reads auth tables before an identity exists. Owner/admin work runs
// as the owner (BYPASSRLS). See packages/adapters/sql/provision-roles.sql.
//
// RULE for every new table: classify it here. A business table ⇒ org_id
// NOT NULL + orgPolicy(). A table keyed on user_id must justify being
// IDENTITY. `pnpm db:verify-rls` checks the classification lists.
import { sql } from 'drizzle-orm'
import { pgTable, text, timestamp, boolean, uuid, jsonb, primaryKey, index, check, pgPolicy, type AnyPgColumn } from 'drizzle-orm/pg-core'
import { ORG_ROLES } from '@app/domain'
import { DEFAULT_PORTAL_ROLE } from '@app/config/roles'
import { DEFAULT_PLAN } from '@app/config/plans'

/** The IDENTITY isolation policy: a row is visible and writable only inside
 *  withUser(owner). Targeted at `public` because naming a role would break
 *  db:migrate on a clone where that role does not exist yet. */
const ownerPolicy = (name: string, owner: AnyPgColumn) =>
  pgPolicy(name, {
    as: 'permissive',
    for: 'all',
    to: 'public',
    using: sql`${owner} = current_setting('app.user_id', true)`,
    withCheck: sql`${owner} = current_setting('app.user_id', true)`,
  })

/** The BUSINESS isolation policy: rows of the active organization only, and only
 *  while the caller is a member of it (or is the userless system path) — see
 *  public.app_org_access() in the migration. The sub-select makes it an initplan,
 *  evaluated once per statement rather than per row. */
const orgPolicy = (name: string, ws: AnyPgColumn) =>
  pgPolicy(name, {
    as: 'permissive',
    for: 'all',
    to: 'public',
    using: sql`${ws} = current_setting('app.org_id', true) and (select public.app_org_access())`,
    withCheck: sql`${ws} = current_setting('app.org_id', true) and (select public.app_org_access())`,
  })

// ── Better Auth core + admin plugin ───────────────────────────────────────
export const user = pgTable('user', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  email: text('email').notNull().unique(),
  emailVerified: boolean('email_verified').default(false).notNull(),
  image: text('image'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
  // Role name, FK into the `role` catalog. RESTRICT rather than SET DEFAULT:
  // deleting a role that people hold must be refused, not silently demote them.
  // The default comes from @app/config/roles so the id is written in one place;
  // changing it there requires a migration to alter this column default.
  role: text('role')
    .notNull()
    .default(DEFAULT_PORTAL_ROLE)
    .references(() => role.name, { onDelete: 'restrict', onUpdate: 'cascade' }),
  banned: boolean('banned').default(false),
  banReason: text('ban_reason'),
  banExpires: timestamp('ban_expires'),
}, (t) => [
  // Postgres does not index the child side of a foreign key. Without this,
  // deleting a role scans every user row.
  index('user_role_idx').on(t.role),
  ownerPolicy('user_self_isolation', t.id),
]).enableRLS()

export const session = pgTable('session', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => user.id, { onDelete: 'cascade' }),
  token: text('token').notNull().unique(),
  expiresAt: timestamp('expires_at').notNull(),
  ipAddress: text('ip_address'),
  userAgent: text('user_agent'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
  // admin plugin (impersonation)
  impersonatedBy: text('impersonated_by'),
}, (t) => [
  // Read on session lookup and scanned on every user delete (cascade).
  index('session_user_id_idx').on(t.userId),
  ownerPolicy('session_user_isolation', t.userId),
]).enableRLS()

export const account = pgTable('account', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => user.id, { onDelete: 'cascade' }),
  accountId: text('account_id').notNull(),
  providerId: text('provider_id').notNull(),
  accessToken: text('access_token'),
  refreshToken: text('refresh_token'),
  idToken: text('id_token'),
  accessTokenExpiresAt: timestamp('access_token_expires_at'),
  refreshTokenExpiresAt: timestamp('refresh_token_expires_at'),
  scope: text('scope'),
  password: text('password'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (t) => [
  index('account_user_id_idx').on(t.userId),
  ownerPolicy('account_user_isolation', t.userId),
]).enableRLS()

export const verification = pgTable('verification', {
  id: text('id').primaryKey(),
  identifier: text('identifier').notNull(),
  value: text('value').notNull(),
  expiresAt: timestamp('expires_at').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}).enableRLS()  // AUTH-PRIVATE: RLS on, no policy — app_user is denied entirely.

// ── Roles (data-driven RBAC catalog) ──────────────────────────────────────
// Managed via the admin app. Permissions are not stored here: they are rows in
// `role_permission` keyed into the `permission` catalog, so a typo or a deleted
// key is rejected by the database. Seeded roles carry isSystem=true.
export const role = pgTable('role', {
  name: text('name').primaryKey(),                          // 'admin', 'support', 'regular', …
  label: text('label').notNull(),
  description: text('description'),
  // Superuser flag. Replaces the old '*' sentinel that lived in permissions[]:
  // a sentinel string cannot satisfy a foreign key, and "can do everything" is a
  // property of the role rather than a permission anyone can be granted.
  fullAccess: boolean('full_access').default(false).notNull(),
  isSystem: boolean('is_system').default(false).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
})

// Role ↔ permission assignment. Replaces role.permissions text[], which could
// hold a typo or a deleted key with nothing to stop it.
//   permission_key ON DELETE RESTRICT — the database refuses to drop a
//     permission that is still assigned, so integrity no longer depends on an
//     application-level check remembering to look.
//   role_name ON DELETE CASCADE — deleting a role takes its assignments with it.
export const rolePermission = pgTable(
  'role_permission',
  {
    roleName: text('role_name').notNull().references(() => role.name, { onDelete: 'cascade' }),
    permissionKey: text('permission_key').notNull().references(() => permission.key, { onDelete: 'restrict' }),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (t) => [
    primaryKey({ columns: [t.roleName, t.permissionKey] }),
    // The composite PK indexes role_name (leading column) but NOT
    // permission_key. That column carries ON DELETE RESTRICT, so without this
    // index every permission delete — and every "which roles use this key?"
    // lookup — scans the whole table.
    index('role_permission_permission_key_idx').on(t.permissionKey),
  ],
)

// ── Permission catalog (vocabulary for the RBAC matrix) ───────────────────
// Metadata only. Enforcement lives in code: can(session, '<key>').
// isSystem=true means a code path calls can() with this key — written only by
// the seed, for the keys in PERMISSIONS. Admin-created keys are isSystem=false
// and are surfaced in the UI as "not yet enforced".
// label/description/resource are curated by admins in the admin app; the seed
// only derives a starting value on first insert and never overwrites them.
export const permission = pgTable('permission', {
  key: text('key').primaryKey(),                            // 'staff:write'
  label: text('label').notNull(),                           // 'Manage staff'
  description: text('description'),
  resource: text('resource').notNull(),                     // 'staff' — groups the matrix
  isSystem: boolean('is_system').default(false).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
})

// ── Tenant directory ──────────────────────────────────────────────────────
// The active organization is a cookie validated against membership per request —
// identity tables hold no tenant state. The "≥1 owner" invariant is enforced in
// the use-case only (direct/admin writes can violate it).
export const organization = pgTable('organization', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  slug: text('slug').notNull().unique(),              // slugify(name) + random suffix
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (t) => [
  pgPolicy('organization_member_read', {
    as: 'permissive', for: 'select', to: 'public',
    using: sql`public.app_is_org_member(${t.id})`,
  }),
  // Bootstrap: only the id createOrg just published. No RETURNING on this
  // insert — the row has no member yet, so SELECT cannot see it.
  pgPolicy('organization_bootstrap_insert', {
    as: 'permissive', for: 'insert', to: 'public',
    withCheck: sql`${t.id} = current_setting('app.org_id', true)`,
  }),
  pgPolicy('organization_admin_update', {
    as: 'permissive', for: 'update', to: 'public',
    using: sql`public.app_is_org_admin(${t.id})`,
    withCheck: sql`public.app_is_org_admin(${t.id})`,
  }),
  // Owner only (the delete-org use-case checks too). Cascades membership and
  // business rows; audit_log has no FK, so the trail survives.
  pgPolicy('organization_owner_delete', {
    as: 'permissive', for: 'delete', to: 'public',
    using: sql`public.app_is_org_owner(${t.id})`,
  }),
]).enableRLS()

export const membership = pgTable('membership', {
  organizationId: text('organization_id').notNull().references(() => organization.id, { onDelete: 'cascade' }),
  userId: text('user_id').notNull().references(() => user.id, { onDelete: 'cascade' }),
  role: text('role').notNull(),                       // ORG_ROLES (closed set, in code)
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (t) => [
  primaryKey({ columns: [t.organizationId, t.userId] }),
  index('membership_user_id_idx').on(t.userId),       // "my organizations"
  check('membership_role_check', sql.raw(`role in (${ORG_ROLES.map((r) => `'${r}'`).join(', ')})`)),
  // My own memberships, plus co-members of the active organization I belong to.
  pgPolicy('membership_read', {
    as: 'permissive', for: 'select', to: 'public',
    using: sql`${t.userId} = current_setting('app.user_id', true)
      or (${t.organizationId} = current_setting('app.org_id', true) and public.app_is_org_member(${t.organizationId}))`,
  }),
  // Owner/admin adds anyone to the active organization; otherwise only the
  // self-owner bootstrap on an EMPTY organization (createOrg).
  pgPolicy('membership_insert', {
    as: 'permissive', for: 'insert', to: 'public',
    withCheck: sql`${t.organizationId} = current_setting('app.org_id', true) and (
      public.app_is_org_admin(${t.organizationId})
      or (${t.userId} = current_setting('app.user_id', true) and ${t.role} = 'owner' and public.app_org_is_empty(${t.organizationId})))`,
  }),
  pgPolicy('membership_update', {
    as: 'permissive', for: 'update', to: 'public',
    using: sql`${t.organizationId} = current_setting('app.org_id', true) and public.app_is_org_admin(${t.organizationId})`,
    withCheck: sql`${t.organizationId} = current_setting('app.org_id', true) and public.app_is_org_admin(${t.organizationId})`,
  }),
  // Owner/admin removes members; anyone may leave.
  pgPolicy('membership_delete', {
    as: 'permissive', for: 'delete', to: 'public',
    using: sql`${t.organizationId} = current_setting('app.org_id', true) and (
      public.app_is_org_admin(${t.organizationId}) or ${t.userId} = current_setting('app.user_id', true))`,
  }),
]).enableRLS()

// ── Business tables ───────────────────────────────────────────────────────
export const subscription = pgTable('subscription', {
  id: uuid('id').defaultRandom().primaryKey(),
  // One subscription per organization (enables upsert-on-conflict).
  orgId: text('org_id').notNull().unique().references(() => organization.id, { onDelete: 'cascade' }),
  // Deliberately unconstrained. Tiers are THIS product's pricing, not a
  // platform invariant: a CHECK or enum would bake one price list into
  // migration history, and every rename or new tier would need a migration in
  // every environment. PlanTier in @app/domain is the compile-time guard and
  // Stripe owns the real product catalog.
  tier: text('tier').default(DEFAULT_PLAN).notNull(),
  // Constrained, unlike tier: this vocabulary is Stripe's, not ours, so it does
  // not change with pricing decisions.
  status: text('status').default('active').notNull(),
  stripeCustomerId: text('stripe_customer_id'),
  currentPeriodEnd: timestamp('current_period_end'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (t) => [
  check(
    'subscription_status_check',
    sql`${t.status} in ('active', 'trialing', 'past_due', 'canceled')`,
  ),
  // BUSINESS. A query outside withOrg() matches nothing.
  orgPolicy('subscription_org_isolation', t.orgId),
]).enableRLS()

// ── Billing event ledger (SYSTEM) ─────────────────────────────────────────
// Webhook idempotency: the provider's event id is the primary key, so a
// redelivered event cannot be recorded twice. It is inserted in the SAME
// transaction as its effect (see @app/application handle-billing-event): if the
// effect fails, the record rolls back and the provider's retry applies it.
// Holds provider ids and kinds only — no personal data.
export const billingEvent = pgTable('billing_event', {
  eventId: text('event_id').primaryKey(),
  kind: text('kind').notNull(),
  processedAt: timestamp('processed_at').defaultNow().notNull(),
}, () => [
  // INSERT only: app_user can append a record and nothing else. No SELECT
  // policy, so history is invisible to the app and cannot be rewritten by it.
  pgPolicy('billing_event_append_only', {
    as: 'permissive',
    for: 'insert',
    to: 'public',
    withCheck: sql`true`,
  }),
]).enableRLS()

// ── Audit log (SYSTEM, F5) ────────────────────────────────────────────────
// Append-only. org_id deliberately has NO foreign key: the trail must outlive
// the organization (an FK with ON DELETE SET NULL would erase which org an
// 'org.deleted' row was about). actor_user_id likewise survives user deletion.
export const auditLog = pgTable('audit_log', {
  id: uuid('id').defaultRandom().primaryKey(),
  orgId: text('org_id'),                              // null = platform/staff event
  actorUserId: text('actor_user_id'),                 // null = system
  actorKind: text('actor_kind').notNull(),
  action: text('action').notNull(),
  targetType: text('target_type').notNull(),
  targetId: text('target_id'),
  metadata: jsonb('metadata').$type<Record<string, unknown>>().default({}).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (t) => [
  index('audit_log_org_id_created_at_idx').on(t.orgId, t.createdAt),
  check('audit_log_actor_kind_check', sql`${t.actorKind} in ('user', 'staff', 'system')`),
  // INSERT for any app path (like billing_event). No RETURNING on insert.
  pgPolicy('audit_log_append_only', {
    as: 'permissive', for: 'insert', to: 'public',
    withCheck: sql`true`,
  }),
  // Owners/admins read their own org's trail. No UPDATE/DELETE policy, and
  // provision-roles.sql revokes both privileges.
  pgPolicy('audit_log_org_admin_read', {
    as: 'permissive', for: 'select', to: 'public',
    using: sql`public.app_is_org_admin(${t.orgId})`,
  }),
]).enableRLS()
