-- provision-roles.sql — the three-role security model. Run as the OWNER
-- (Neon SQL editor, or `psql "$DATABASE_URL_ADMIN"`). Once per database
-- (dev branch, preview, production).
--
--   owner      DATABASE_URL_ADMIN  BYPASSRLS (Neon default). Migrations, seed,
--                                  guarded cross-user admin work. Admin app only.
--   app_user   DATABASE_URL        NOBYPASSRLS, NOT the table owner. Every app
--                                  request. RLS binds it (see schema.ts header).
--   auth_user  DATABASE_URL_AUTH   BYPASSRLS, but GRANTed ONLY the four auth
--                                  tables. Better Auth only — it reads auth tables
--                                  before any identity exists, so it cannot be
--                                  RLS-scoped. Its bypass reaches nothing else.
--
-- Replace each <password> with a value from `pnpm gen:secret` (Neon will not let
-- the owner run ALTER ROLE … PASSWORD later — set it here, rotate via Neon).
-- Afterwards `pnpm db:verify-rls` must pass.

-- ════════════════════════════════════════════════════════════════════════
-- PART A — BEFORE the first `pnpm db:migrate`
-- ════════════════════════════════════════════════════════════════════════

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'app_user') THEN
    CREATE ROLE app_user LOGIN NOBYPASSRLS NOSUPERUSER NOCREATEDB NOCREATEROLE
      PASSWORD '<app_user password>';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'auth_user') THEN
    -- BYPASSRLS is safe ONLY because of the table-scoped GRANTs in PART B.
    CREATE ROLE auth_user LOGIN BYPASSRLS NOSUPERUSER NOCREATEDB NOCREATEROLE
      PASSWORD '<auth_user password>';
  END IF;
END $$;

GRANT USAGE ON SCHEMA public TO app_user;
GRANT USAGE ON SCHEMA public TO auth_user;

-- app_user: full DML on every table the owner creates from now on (migrations).
-- RLS — not GRANTs — is what scopes its rows. auth_user deliberately gets NO
-- default privileges: it must never silently gain access to a new table.
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO app_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO app_user;

-- ════════════════════════════════════════════════════════════════════════
-- PART B — AFTER `pnpm db:migrate` (tables must exist).
-- Re-run whenever a migration adds/renames an auth table.
-- ════════════════════════════════════════════════════════════════════════

-- auth_user: the four Better Auth tables, nothing else. No organization, no
-- membership, no subscription, no role/permission catalog, no future business
-- table — tenant data is never reachable through its bypass. (Foreign-key checks on
-- user.role run with the referenced table owner's rights, so no GRANT on role
-- is needed.)
GRANT SELECT, INSERT, UPDATE, DELETE ON "user", account, session, verification TO auth_user;

-- app_user never needs verification (password-reset / email tokens). RLS with no
-- policy already returns zero rows; revoking the privilege too means a mistake
-- in RLS alone cannot expose it.
REVOKE ALL ON verification FROM app_user;

-- billing_event is an append-only ledger (SYSTEM): app_user may only INSERT.
-- RLS has no SELECT policy already; revoking UPDATE/DELETE means history cannot
-- be rewritten even if a policy is later loosened. SELECT is left granted:
-- INSERT … ON CONFLICT DO NOTHING checks the key, and RLS still hides every row.
REVOKE UPDATE, DELETE ON billing_event FROM app_user;

-- audit_log is append-only too (SYSTEM): app_user may INSERT and, through RLS,
-- org owners/admins may read their org's rows. History can never be rewritten.
REVOKE UPDATE, DELETE ON audit_log FROM app_user;

-- Tenancy RLS helpers (created by the migration, EXECUTE revoked from PUBLIC).
-- The migration grants app_user when the role already exists; this covers
-- roles created after the first migrate. auth_user gets nothing.
GRANT EXECUTE ON FUNCTION app_is_org_member(text), app_is_org_admin(text), app_is_org_owner(text), app_org_is_empty(text), app_org_access() TO app_user;

-- ════════════════════════════════════════════════════════════════════════
-- ONLY IF setting up roles AFTER tables already existed (default privileges
-- cover future tables only):
-- ════════════════════════════════════════════════════════════════════════
-- GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO app_user;
-- GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO app_user;
-- REVOKE ALL ON verification FROM app_user;
-- REVOKE UPDATE, DELETE ON billing_event FROM app_user;
-- REVOKE UPDATE, DELETE ON audit_log FROM app_user;
-- GRANT EXECUTE ON FUNCTION app_is_org_member(text), app_is_org_admin(text), app_is_org_owner(text), app_org_is_empty(text), app_org_access() TO app_user;
-- (organization, membership and subscription are covered by the ALL TABLES grant
--  above — app_user needs full DML on them; RLS scopes the rows. Nothing for
--  auth_user.)
