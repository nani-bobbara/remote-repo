-- Hand-written (drizzle-kit cannot emit functions). RLS helpers for the tenant
-- directory: policies on organization/membership must read membership, which
-- from inside a membership policy recurses ("infinite recursion detected in
-- policy for relation membership"). These SECURITY DEFINER functions read it
-- with the function OWNER's rights instead.
--
-- OWNERSHIP: they must be OWNED BY the owner role (BYPASSRLS) — the role that
-- runs migrations, so they are. Owned by a NOBYPASSRLS role, FORCE would apply
-- the membership policies inside them and recurse. db:verify-rls asserts it.
--
-- Ordering: they sit at the TOP, before any table exists. LANGUAGE plpgsql
-- bodies are only syntax-checked at CREATE time (tables resolve at call time),
-- so the drizzle-generated CREATE POLICY statements below can reference them.
-- LANGUAGE sql would need the tables first (check_function_bodies).
--
-- Hardening: search_path = '' and every name schema-qualified, so nothing a
-- caller puts on its path (e.g. a temp table named membership) is consulted.
-- They return a boolean only — never row data. EXECUTE is revoked from PUBLIC;
-- app_user is granted below when the role exists (else provision-roles.sql B).
CREATE FUNCTION public.app_is_org_member(org text) RETURNS boolean
  LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $$
BEGIN
  RETURN EXISTS (SELECT 1 FROM public.membership m
                 WHERE m.organization_id = org
                   AND m.user_id = pg_catalog.current_setting('app.user_id', true));
END $$;--> statement-breakpoint
CREATE FUNCTION public.app_is_org_admin(org text) RETURNS boolean
  LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $$
BEGIN
  RETURN EXISTS (SELECT 1 FROM public.membership m
                 WHERE m.organization_id = org
                   AND m.user_id = pg_catalog.current_setting('app.user_id', true)
                   AND m.role IN ('owner', 'admin'));
END $$;--> statement-breakpoint
CREATE FUNCTION public.app_is_org_owner(org text) RETURNS boolean
  LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $$
BEGIN
  RETURN EXISTS (SELECT 1 FROM public.membership m
                 WHERE m.organization_id = org
                   AND m.user_id = pg_catalog.current_setting('app.user_id', true)
                   AND m.role = 'owner');
END $$;--> statement-breakpoint
CREATE FUNCTION public.app_org_is_empty(org text) RETURNS boolean
  LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $$
BEGIN
  -- True only for a brand-new organization: gates the self-owner bootstrap insert.
  RETURN NOT EXISTS (SELECT 1 FROM public.membership m WHERE m.organization_id = org);
END $$;--> statement-breakpoint
CREATE FUNCTION public.app_org_access() RETURNS boolean
  LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $$
DECLARE
  org text := NULLIF(pg_catalog.current_setting('app.org_id', true), '');
  uid text := NULLIF(pg_catalog.current_setting('app.user_id', true), '');
BEGIN
  -- Business-table gate (orgPolicy): an organization must be active, and the
  -- caller must be a member of it — unless there is no user at all, which is
  -- the webhook's SystemDbPort.asOrgSystem path.
  RETURN org IS NOT NULL AND (uid IS NULL OR public.app_is_org_member(org));
END $$;--> statement-breakpoint
REVOKE ALL ON FUNCTION public.app_is_org_member(text), public.app_is_org_admin(text), public.app_is_org_owner(text), public.app_org_is_empty(text), public.app_org_access() FROM PUBLIC;--> statement-breakpoint
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'app_user') THEN
    GRANT EXECUTE ON FUNCTION public.app_is_org_member(text), public.app_is_org_admin(text), public.app_is_org_owner(text), public.app_org_is_empty(text), public.app_org_access() TO app_user;
  END IF;
END $$;--> statement-breakpoint
CREATE TABLE "account" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"account_id" text NOT NULL,
	"provider_id" text NOT NULL,
	"access_token" text,
	"refresh_token" text,
	"id_token" text,
	"access_token_expires_at" timestamp,
	"refresh_token_expires_at" timestamp,
	"scope" text,
	"password" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "account" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "audit_log" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" text,
	"actor_user_id" text,
	"actor_kind" text NOT NULL,
	"action" text NOT NULL,
	"target_type" text NOT NULL,
	"target_id" text,
	"metadata" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "audit_log_actor_kind_check" CHECK ("audit_log"."actor_kind" in ('user', 'staff', 'system'))
);
--> statement-breakpoint
ALTER TABLE "audit_log" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "billing_event" (
	"event_id" text PRIMARY KEY NOT NULL,
	"kind" text NOT NULL,
	"processed_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "billing_event" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "membership" (
	"organization_id" text NOT NULL,
	"user_id" text NOT NULL,
	"role" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "membership_organization_id_user_id_pk" PRIMARY KEY("organization_id","user_id"),
	CONSTRAINT "membership_role_check" CHECK (role in ('owner', 'admin', 'member'))
);
--> statement-breakpoint
ALTER TABLE "membership" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "organization" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"slug" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "organization_slug_unique" UNIQUE("slug")
);
--> statement-breakpoint
ALTER TABLE "organization" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "permission" (
	"key" text PRIMARY KEY NOT NULL,
	"label" text NOT NULL,
	"description" text,
	"resource" text NOT NULL,
	"is_system" boolean DEFAULT false NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "role" (
	"name" text PRIMARY KEY NOT NULL,
	"label" text NOT NULL,
	"description" text,
	"full_access" boolean DEFAULT false NOT NULL,
	"is_system" boolean DEFAULT false NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "role_permission" (
	"role_name" text NOT NULL,
	"permission_key" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "role_permission_role_name_permission_key_pk" PRIMARY KEY("role_name","permission_key")
);
--> statement-breakpoint
CREATE TABLE "session" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"token" text NOT NULL,
	"expires_at" timestamp NOT NULL,
	"ip_address" text,
	"user_agent" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	"impersonated_by" text,
	CONSTRAINT "session_token_unique" UNIQUE("token")
);
--> statement-breakpoint
ALTER TABLE "session" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "subscription" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"org_id" text NOT NULL,
	"tier" text DEFAULT 'free' NOT NULL,
	"status" text DEFAULT 'active' NOT NULL,
	"stripe_customer_id" text,
	"current_period_end" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "subscription_org_id_unique" UNIQUE("org_id"),
	CONSTRAINT "subscription_status_check" CHECK ("subscription"."status" in ('active', 'trialing', 'past_due', 'canceled'))
);
--> statement-breakpoint
ALTER TABLE "subscription" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "user" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"email" text NOT NULL,
	"email_verified" boolean DEFAULT false NOT NULL,
	"image" text,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	"role" text DEFAULT 'regular' NOT NULL,
	"banned" boolean DEFAULT false,
	"ban_reason" text,
	"ban_expires" timestamp,
	CONSTRAINT "user_email_unique" UNIQUE("email")
);
--> statement-breakpoint
ALTER TABLE "user" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "verification" (
	"id" text PRIMARY KEY NOT NULL,
	"identifier" text NOT NULL,
	"value" text NOT NULL,
	"expires_at" timestamp NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "verification" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "account" ADD CONSTRAINT "account_user_id_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."user"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "membership" ADD CONSTRAINT "membership_organization_id_organization_id_fk" FOREIGN KEY ("organization_id") REFERENCES "public"."organization"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "membership" ADD CONSTRAINT "membership_user_id_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."user"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "role_permission" ADD CONSTRAINT "role_permission_role_name_role_name_fk" FOREIGN KEY ("role_name") REFERENCES "public"."role"("name") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "role_permission" ADD CONSTRAINT "role_permission_permission_key_permission_key_fk" FOREIGN KEY ("permission_key") REFERENCES "public"."permission"("key") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "session" ADD CONSTRAINT "session_user_id_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."user"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "subscription" ADD CONSTRAINT "subscription_org_id_organization_id_fk" FOREIGN KEY ("org_id") REFERENCES "public"."organization"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "user" ADD CONSTRAINT "user_role_role_name_fk" FOREIGN KEY ("role") REFERENCES "public"."role"("name") ON DELETE restrict ON UPDATE cascade;--> statement-breakpoint
CREATE INDEX "account_user_id_idx" ON "account" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "audit_log_org_id_created_at_idx" ON "audit_log" USING btree ("org_id","created_at");--> statement-breakpoint
CREATE INDEX "membership_user_id_idx" ON "membership" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "role_permission_permission_key_idx" ON "role_permission" USING btree ("permission_key");--> statement-breakpoint
CREATE INDEX "session_user_id_idx" ON "session" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "user_role_idx" ON "user" USING btree ("role");--> statement-breakpoint
CREATE POLICY "account_user_isolation" ON "account" AS PERMISSIVE FOR ALL TO public USING ("account"."user_id" = current_setting('app.user_id', true)) WITH CHECK ("account"."user_id" = current_setting('app.user_id', true));--> statement-breakpoint
CREATE POLICY "audit_log_append_only" ON "audit_log" AS PERMISSIVE FOR INSERT TO public WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "audit_log_org_admin_read" ON "audit_log" AS PERMISSIVE FOR SELECT TO public USING (public.app_is_org_admin("audit_log"."org_id"));--> statement-breakpoint
CREATE POLICY "billing_event_append_only" ON "billing_event" AS PERMISSIVE FOR INSERT TO public WITH CHECK (true);--> statement-breakpoint
CREATE POLICY "membership_read" ON "membership" AS PERMISSIVE FOR SELECT TO public USING ("membership"."user_id" = current_setting('app.user_id', true)
      or ("membership"."organization_id" = current_setting('app.org_id', true) and public.app_is_org_member("membership"."organization_id")));--> statement-breakpoint
CREATE POLICY "membership_insert" ON "membership" AS PERMISSIVE FOR INSERT TO public WITH CHECK ("membership"."organization_id" = current_setting('app.org_id', true) and (
      public.app_is_org_admin("membership"."organization_id")
      or ("membership"."user_id" = current_setting('app.user_id', true) and "membership"."role" = 'owner' and public.app_org_is_empty("membership"."organization_id"))));--> statement-breakpoint
CREATE POLICY "membership_update" ON "membership" AS PERMISSIVE FOR UPDATE TO public USING ("membership"."organization_id" = current_setting('app.org_id', true) and public.app_is_org_admin("membership"."organization_id")) WITH CHECK ("membership"."organization_id" = current_setting('app.org_id', true) and public.app_is_org_admin("membership"."organization_id"));--> statement-breakpoint
CREATE POLICY "membership_delete" ON "membership" AS PERMISSIVE FOR DELETE TO public USING ("membership"."organization_id" = current_setting('app.org_id', true) and (
      public.app_is_org_admin("membership"."organization_id") or "membership"."user_id" = current_setting('app.user_id', true)));--> statement-breakpoint
CREATE POLICY "organization_member_read" ON "organization" AS PERMISSIVE FOR SELECT TO public USING (public.app_is_org_member("organization"."id"));--> statement-breakpoint
CREATE POLICY "organization_bootstrap_insert" ON "organization" AS PERMISSIVE FOR INSERT TO public WITH CHECK ("organization"."id" = current_setting('app.org_id', true));--> statement-breakpoint
CREATE POLICY "organization_admin_update" ON "organization" AS PERMISSIVE FOR UPDATE TO public USING (public.app_is_org_admin("organization"."id")) WITH CHECK (public.app_is_org_admin("organization"."id"));--> statement-breakpoint
CREATE POLICY "organization_owner_delete" ON "organization" AS PERMISSIVE FOR DELETE TO public USING (public.app_is_org_owner("organization"."id"));--> statement-breakpoint
CREATE POLICY "session_user_isolation" ON "session" AS PERMISSIVE FOR ALL TO public USING ("session"."user_id" = current_setting('app.user_id', true)) WITH CHECK ("session"."user_id" = current_setting('app.user_id', true));--> statement-breakpoint
CREATE POLICY "subscription_org_isolation" ON "subscription" AS PERMISSIVE FOR ALL TO public USING ("subscription"."org_id" = current_setting('app.org_id', true) and (select public.app_org_access())) WITH CHECK ("subscription"."org_id" = current_setting('app.org_id', true) and (select public.app_org_access()));--> statement-breakpoint
CREATE POLICY "user_self_isolation" ON "user" AS PERMISSIVE FOR ALL TO public USING ("user"."id" = current_setting('app.user_id', true)) WITH CHECK ("user"."id" = current_setting('app.user_id', true));--> statement-breakpoint
-- Hand-appended (drizzle-kit emits ENABLE but not FORCE, and FORCE is absent from
-- the snapshot). FORCE applies the policies to the table owner too; roles holding
-- BYPASSRLS are exempt regardless, which is why DATABASE_URL must be the
-- unprivileged app_user role (README → Database roles).
ALTER TABLE "user" FORCE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "account" FORCE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "session" FORCE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "verification" FORCE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "organization" FORCE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "membership" FORCE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "subscription" FORCE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "billing_event" FORCE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "audit_log" FORCE ROW LEVEL SECURITY;
