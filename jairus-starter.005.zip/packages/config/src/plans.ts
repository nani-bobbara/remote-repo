// The plans this product sells. Single definition site — no tier id, label,
// rank or price variable is written anywhere else (plan item L2).
//
// Each plan's entitlements are what the app checks, via entitled()/limitOf()
// in @app/domain — never the plan name. Moving a feature between tiers or
// renaming a tier is an edit here, not a code change.
//
// `@app/config` is a leaf package: it defines its own ids and imports nothing.
// @app/domain's PlanTier must name exactly these keys; @app/adapters asserts that
// at compile time (packages/adapters/src/billing/index.ts).
//
// The feature keys and limits below are TEMPLATE EXAMPLES — replace them with
// your product's. Stripe remains the source of truth for amounts and currency.

export type PlanDef = {
  label: string
  /** Order for upgrade paths: higher = more. */
  rank: number
  /** Name of the env var holding this plan's Stripe price id; null = free. */
  priceEnv: string | null
  features: readonly string[]
  limits: Readonly<Record<string, number>>
}

export const PLANS = {
  free: {
    label: 'Free',
    rank: 0,
    priceEnv: null,
    features: [],
    limits: { seats: 1 },
  },
  basic: {
    label: 'Basic',
    rank: 1,
    priceEnv: 'STRIPE_PRICE_BASIC',
    features: ['export'],
    limits: { seats: 3 },
  },
  pro: {
    label: 'Pro',
    rank: 2,
    priceEnv: 'STRIPE_PRICE_PRO',
    features: ['export', 'priority_support'],
    limits: { seats: 10 },
  },
} as const satisfies Record<string, PlanDef>

export type PlanId = keyof typeof PLANS

/** Plan a user has before (or without) any subscription. Also the DB column default. */
export const DEFAULT_PLAN: PlanId = 'free'

export function isPlanId(value: unknown): value is PlanId {
  return typeof value === 'string' && Object.hasOwn(PLANS, value)
}

/** Paid plans ranked above `current`, cheapest first — the upgrade path. */
export function upgradesFrom(current: PlanId): PlanId[] {
  return (Object.keys(PLANS) as PlanId[])
    .filter((id) => PLANS[id].rank > PLANS[current].rank)
    .sort((a, b) => PLANS[a].rank - PLANS[b].rank)
}
