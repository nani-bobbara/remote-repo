// Validated server configuration (plan item F3). SERVER-ONLY — never import from
// a client component; browser-visible NEXT_PUBLIC_* values live in ./brand.
// Enforced by the app lint (@app/config/eslint-boundaries): a "use client" file
// importing this module fails the build.
//
// SKIP_ENV_VALIDATION=1 is for CI *builds* only. Never set it in a deployed
// runtime: it disables getEnv() and assertEnv() entirely.
//
// Env is grouped by what needs it, because the apps differ on purpose: the
// portal must NOT be required to hold DATABASE_URL_ADMIN, the admin app needs
// no Stripe keys. Each app asserts its groups once at boot (instrumentation.ts)
// so a missing secret crashes the deploy, not a customer's checkout; adapters
// read through getEnv() so every value they use has passed its schema.
//
// Validation is skipped during `next build` (route modules are imported to
// collect page data, and CI builds hold no secrets) and when
// SKIP_ENV_VALIDATION=1. It still runs at boot and on first use at runtime.
import { z } from 'zod'
import { PLANS } from './plans'

const isProd = () => process.env.NODE_ENV === 'production'
const pgUrl = z.string().regex(/^postgres(ql)?:\/\//, 'must be a postgres:// connection string')

const schemas = {
  /** Every app + scripts. */
  db: z
    .object({
      DATABASE_URL: pgUrl,
      // Better Auth's role. Optional only for single-role local dev (owner as
      // DATABASE_URL); required in production — see adapters/sql/provision-roles.sql.
      DATABASE_URL_AUTH: pgUrl.optional(),
      // Optional here (the portal never holds it); the `dbAdmin` group makes it
      // required where it is actually needed.
      DATABASE_URL_ADMIN: pgUrl.optional(),
    })
    .refine((e) => !isProd() || !!e.DATABASE_URL_AUTH, {
      message: 'DATABASE_URL_AUTH is required in production (Better Auth runs as auth_user)',
      path: ['DATABASE_URL_AUTH'],
    }),

  /** Admin app + scripts only. The portal never holds the owner URL. */
  dbAdmin: z.object({ DATABASE_URL_ADMIN: pgUrl }),

  /** Every app + scripts. */
  auth: z
    .object({
      BETTER_AUTH_SECRET: z
        .string()
        .min(32, 'must be at least 32 characters — generate with `pnpm gen:secret`')
        .refine((s) => !/^https?:\/\//.test(s), 'is a URL — it must be a random secret (`pnpm gen:secret`)')
        .refine((s) => !s.startsWith('change-me'), 'is still the .env.example placeholder'),
      BETTER_AUTH_URL: z.string().url('must be this app\'s origin, e.g. http://localhost:3001'),
      GOOGLE_CLIENT_ID: z.string().min(1).optional(),
      GOOGLE_CLIENT_SECRET: z.string().min(1).optional(),
    })
    .refine((e) => !!e.GOOGLE_CLIENT_ID === !!e.GOOGLE_CLIENT_SECRET, {
      message: 'set both GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET, or neither',
      path: ['GOOGLE_CLIENT_SECRET'],
    }),

  /** Portal only. Price variables come from the plan catalog, so a new paid plan's
   *  price is validated automatically. */
  billing: z
    .object({
      STRIPE_SECRET_KEY: z.string().regex(/^(sk|rk)_/, 'must be a Stripe secret key (sk_… / rk_…)'),
      STRIPE_WEBHOOK_SECRET: z.string().startsWith('whsec_', 'must be a webhook signing secret (whsec_…)'),
    })
    .and(
      z.object(
        Object.fromEntries(
          Object.values(PLANS)
            .map((p) => p.priceEnv)
            .filter((v): v is NonNullable<typeof v> => v !== null)
            .map((name) => [name, z.string().startsWith('price_', 'must be a Stripe price id (price_…)')]),
        ) as Record<string, z.ZodString>,
      ),
    ),

  /** Transactional email. Optional in dev (the adapter logs instead of sending). */
  email: z
    .object({
      // The .env.example placeholder counts as unset, so a fresh clone is
      // "unconfigured" (dev logs mail instead of sending) rather than broken.
      RESEND_API_KEY: z.preprocess(
        (v) => (typeof v === 'string' && v.trim() && v.trim() !== 're_xxx' ? v.trim() : undefined),
        z.string().startsWith('re_', 'must be a Resend key (re_…)').optional(),
      ),
      EMAIL_FROM: z.string().min(3).optional(),
    })
    .refine((e) => !isProd() || (!!e.RESEND_API_KEY && !!e.EMAIL_FROM), {
      message: 'RESEND_API_KEY and EMAIL_FROM are required in production',
      path: ['RESEND_API_KEY'],
    }),

  /** Error reporting. Optional: unset, errors go to the server log only. */
  errors: z.object({
    SENTRY_DSN: z.preprocess((v) => (v === '' ? undefined : v), z.string().url('must be a Sentry DSN URL').optional()),
    SENTRY_ENVIRONMENT: z.string().min(1).optional(),
  }),

  /** `pnpm db:seed` only. */
  seed: z.object({
    ADMIN_EMAIL: z.string().email(),
    ADMIN_INITIAL_PASSWORD: z.string().min(12, 'must be at least 12 characters'),
  }),
} as const

export type EnvGroup = keyof typeof schemas
export type Env<G extends EnvGroup> = z.infer<(typeof schemas)[G]>

export class EnvError extends Error {
  constructor(group: string, issues: z.ZodIssue[]) {
    const lines = issues.map((i) => `  - ${i.path.join('.') || '(env)'}: ${i.message}`)
    super(`Invalid environment for "${group}" — fix your .env (see .env.example):\n${lines.join('\n')}`)
    this.name = 'EnvError'
  }
}

const skip = () =>
  process.env.SKIP_ENV_VALIDATION === '1' || process.env.NEXT_PHASE === 'phase-production-build'

const cache = new Map<EnvGroup, unknown>()

/** Validated values for one group; parsed once, then cached. Throws EnvError. */
export function getEnv<G extends EnvGroup>(group: G): Env<G> {
  if (skip()) return process.env as unknown as Env<G>
  if (!cache.has(group)) {
    const res = schemas[group].safeParse(process.env)
    if (!res.success) throw new EnvError(group, res.error.issues)
    cache.set(group, res.data)
  }
  return cache.get(group) as Env<G>
}

/** Boot-time check: validates every listed group and reports ALL problems at
 *  once (not just the first), so a deploy fails with the full list. */
export function assertEnv(groups: readonly EnvGroup[]): void {
  if (skip()) return
  const errors: string[] = []
  for (const g of groups) {
    try {
      getEnv(g)
    } catch (e) {
      errors.push(e instanceof Error ? e.message : String(e))
    }
  }
  if (errors.length) throw new Error(errors.join('\n'))
}
