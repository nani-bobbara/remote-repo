// Shared architecture-boundary lint for the apps (plan F10 / M8). Lint turns the
// hexagonal + least-privilege rules into build failures instead of conventions.
//
//   - Apps never import a vendor SDK: those live only in @app/adapters, behind ports.
//   - Apps never import the adapters barrel: it eagerly constructs every vendor
//     client and fails the build when their keys are absent. Use subpaths.
//   - Apps never touch raw Drizzle clients or the schema — only DbPort.
//   - The portal never touches dbAdminPort: it does not hold DATABASE_URL_ADMIN.
//   - No app touches systemDbPort (sets app.org_id with no user) — except
//     the files in `systemPortFiles` (the Stripe webhook route), which pass it
//     straight into the webhook use-case.
//     (Better Auth's bypass client is not exported at all — see adapters/auth.)

const VENDOR_SDKS = [
  "drizzle-orm", "drizzle-orm/*",
  "postgres",
  "stripe",
  "resend",
  "better-auth", "better-auth/*",
  "@sentry/*",
]

/** @param {string[]} bannedDbNames @param {boolean} allowAdminPort */
function restrictedImports(bannedDbNames, allowAdminPort) {
  return ["error", {
    paths: [
      {
        name: "@app/adapters",
        message: "Import adapters from their subpath (@app/adapters/db, @app/adapters/billing) — the barrel constructs every vendor client.",
      },
      {
        name: "@app/adapters/db",
        importNames: bannedDbNames,
        message: allowAdminPort
          ? "Use dbPort (withUser / withOrg) or dbAdminPort behind requireStaff()/requirePermission() — never a raw Drizzle client or systemDbPort (webhook only)."
          : "The portal uses dbPort.withUser / withOrg only. dbAdminPort/raw clients bypass RLS, and systemDbPort is reserved for the Stripe webhook route.",
      },
    ],
    patterns: [
      {
        group: VENDOR_SDKS,
        message: "Vendor SDKs live only in @app/adapters (hexagonal boundary) — go through a port.",
      },
      {
        group: ["@app/adapters/db/schema", "@app/adapters/src/*"],
        message: "Apps never touch the schema or adapter internals — use DbPort.",
      },
    ],
  }]
}

/**
 * Returns a flat-config ARRAY — spread it into the app's config.
 * @param {{ allowAdminPort: boolean, systemPortFiles?: string[] }} opts
 *   allowAdminPort  — true for the admin app (guarded cross-user work), false for the portal.
 *   systemPortFiles — the only files that may import systemDbPort (the billing webhook route).
 */
export function appBoundaries({ allowAdminPort, systemPortFiles = [] }) {
  const bypassNames = ["db", "dbAdmin", "systemDbPort", ...(allowAdminPort ? [] : ["dbAdminPort"])]
  return [
    {
      files: ["**/*.{ts,tsx}"],
      rules: {
        // Server config must never reach the browser. Enforced here rather than
        // with `import 'server-only'`: that package throws under plain Node, which
        // would break `pnpm db:seed` (tsx), which legitimately reads server env.
        "no-restricted-syntax": ["error", {
          selector:
            "Program:has(> ExpressionStatement[directive='use client']) ImportDeclaration[source.value=/^@app\\/(config\\/env|adapters)/]",
          message:
            "Client components must not import server config (@app/config/env) or adapters — they carry secrets. Read on the server and pass values as props.",
        }],
        "no-restricted-imports": restrictedImports(bypassNames, allowAdminPort),
      },
    },
    // Later config wins for these files: same bans, minus systemDbPort.
    ...(systemPortFiles.length
      ? [{
          files: systemPortFiles,
          rules: { "no-restricted-imports": restrictedImports(bypassNames.filter((n) => n !== "systemDbPort"), allowAdminPort) },
        }]
      : []),
  ]
}
