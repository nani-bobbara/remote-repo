// Shared security headers for both apps' next.config (plan F6). Plain .mjs so
// next.config can load it without a transpile step.
//
// CSP compromise: script-src allows 'unsafe-inline'. The theme-init script in
// each root layout must run before paint, and Next injects inline bootstrap
// scripts; a nonce would fix both but forces every page to render dynamically
// (no static/ISR). Everything else is locked to 'self', framing is denied, and
// form-action admits only the redirects the apps make (Stripe Checkout, Google
// sign-in). To go nonce-based: generate a nonce in proxy.ts, set the CSP there,
// and read it in the layout via headers().

const isDev = process.env.NODE_ENV !== 'production'

const csp = [
  "default-src 'self'",
  // 'unsafe-eval' is dev-only: React Refresh needs it.
  `script-src 'self' 'unsafe-inline'${isDev ? " 'unsafe-eval'" : ''}`,
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob: https:",
  "font-src 'self' data:",
  `connect-src 'self'${isDev ? ' ws:' : ''}`,
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self' https://checkout.stripe.com https://accounts.google.com",
  "frame-ancestors 'none'",
  ...(isDev ? [] : ['upgrade-insecure-requests']),
].join('; ')

/** @returns {Promise<{ source: string, headers: { key: string, value: string }[] }[]>} */
export async function securityHeaders() {
  return [
    {
      source: '/:path*',
      headers: [
        { key: 'Content-Security-Policy', value: csp },
        { key: 'X-Frame-Options', value: 'DENY' },
        { key: 'X-Content-Type-Options', value: 'nosniff' },
        { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
        { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=(), payment=()' },
        // HSTS only in production: on localhost it would pin http dev ports to https.
        ...(isDev ? [] : [{ key: 'Strict-Transport-Security', value: 'max-age=63072000; includeSubDomains; preload' }]),
      ],
    },
  ]
}
