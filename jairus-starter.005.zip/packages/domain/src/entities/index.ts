// Domain entities — plain data shapes owned by the domain. No framework/vendor types.
import type { PlanTier } from '../value-objects/index'

// Roles are DATA, not a fixed enum — each app defines its own roles/permissions
// through the admin app as features evolve. A role holds a set of string
// permissions ('resource:action'), each of which must exist in the permission
// catalog — the `role_permission` join enforces that with a foreign key.
//
// Which roles ship by default is CONFIGURATION, not domain logic: see
// @app/config/roles. The domain defines only the shape and the check.
export interface RoleDef {
  name: string           // stable id, e.g. 'support'
  label: string          // display name, e.g. 'Support'
  description: string | null
  permissions: string[]  // every entry is a real permission.key (FK-enforced)
  /** Superuser. Grants everything, including permissions added later. */
  fullAccess: boolean
  isSystem: boolean      // seeded/protected: cannot be deleted or demoted
}

/**
 * Permission check — pure. A session carries its role's resolved permissions
 * plus its fullAccess flag.
 *
 * fullAccess replaced an earlier '*' sentinel stored inside the permissions
 * array. A sentinel cannot satisfy the foreign key that now guarantees every
 * stored permission is a real catalog key, and "can do everything" is a
 * property of the role rather than something assignable in the matrix.
 */
export function can(
  subject: { permissions: string[]; fullAccess?: boolean },
  permission: string,
): boolean {
  return subject.fullAccess === true || subject.permissions.includes(permission)
}

export const PERMISSIONS = {
  ADMIN_ACCESS: 'admin:access',   // may enter the admin app at all
  ROLES_READ: 'roles:read',
  ROLES_WRITE: 'roles:write',
  STAFF_READ: 'staff:read',
  STAFF_WRITE: 'staff:write',
  PERMISSIONS_READ: 'permissions:read',
  PERMISSIONS_WRITE: 'permissions:write',
  AUDIT_READ: 'audit:read',       // the admin audit-log screen
} as const

/** A catalog row as stored in the `permission` table and read back. */
export interface PermissionDef {
  key: string
  label: string
  description: string | null
  /** Groups the permission matrix. Free-form; by convention the part before the colon. */
  resource: string
  /** true = a code path calls can() with this key. Written only by the seed. */
  isSystem: boolean
}

// Deriving a human-readable label from a key is presentation, not domain —
// see packages/adapters/src/db/permission-meta.ts, beside the seed that uses it.

export interface User {
  id: string
  email: string
  name: string | null
  role: string           // role name (see RoleDef)
  createdAt: Date
  emailVerified: boolean // false until the invite is accepted
  banned: boolean        // access revoked without deleting the account
}

/** Derived account state shown in the admin console. Not a stored column. */
export type UserStatus = 'active' | 'inactive' | 'invited'

export function userStatus(u: Pick<User, 'emailVerified' | 'banned'>): UserStatus {
  if (u.banned) return 'inactive'
  return u.emailVerified ? 'active' : 'invited'
}

// ── Tenancy: organizations + membership (docs/design/organizations.md) ───────────────
// The people who run the platform are STAFF (admin plane, user.role + can()).
// Customers belong to ORGANIZATIONS (portal plane, membership.role + canInOrg()).
// The two planes never grant each other anything; staff hold no memberships.

/** Closed set, in code — not rows in the `role` catalog (that is the platform plane). */
export const ORG_ROLES = ['owner', 'admin', 'member'] as const
export type OrgRole = (typeof ORG_ROLES)[number]

export interface Organization {
  id: string
  name: string
  slug: string
}

export interface Membership {
  organization: Organization
  userId: string
  role: OrgRole
  createdAt: Date
}

/** Organization actions → the roles allowed to perform them. Fixed map, not data:
 *  customer-editable organization roles are a later feature. */
export const ORG_ACTIONS = {
  'billing:manage': ['owner'],
  'members:manage': ['owner', 'admin'],
  'data:write': ['owner', 'admin', 'member'],
  'data:export': ['owner'],
  'org:delete': ['owner'],
} as const satisfies Record<string, readonly OrgRole[]>
export type OrgAction = keyof typeof ORG_ACTIONS

/** Organization permission check — pure, the portal-plane twin of can(). */
export function canInOrg(role: OrgRole, action: OrgAction): boolean {
  return (ORG_ACTIONS[action] as readonly OrgRole[]).includes(role)
}

/** Name of the organization created for every portal sign-up. */
export function personalOrgName(userName: string | null | undefined): string {
  const n = userName?.trim()
  return n ? `${n}'s organization` : 'My organization'
}

export type SubscriptionStatus = 'active' | 'trialing' | 'past_due' | 'canceled'

/** One per organization (business-owned, keyed by org_id). */
export interface Subscription {
  id: string
  orgId: string
  tier: PlanTier
  status: SubscriptionStatus
  stripeCustomerId: string | null
  currentPeriodEnd: Date | null
}

/**
 * What a plan grants. Products gate on capabilities, never on plan names, so a
 * pricing change (rename a tier, move a feature between tiers) is a catalog edit
 * — not a code change. Which plans ship, and what each grants, is CONFIGURATION:
 * see @app/config/plans. The domain defines only the shape and the checks,
 * exactly as it does for roles and can().
 */
export interface Entitlements {
  /** Feature keys this plan unlocks, e.g. 'export'. */
  features: readonly string[]
  /** Numeric quotas, e.g. { seats: 3 }. */
  limits: Readonly<Record<string, number>>
}

/** Feature check — pure, mirrors can(). */
export function entitled(plan: Entitlements, feature: string): boolean {
  return plan.features.includes(feature)
}

/** Quota for `key`; 0 when the plan does not grant it (fail closed). */
export function limitOf(plan: Entitlements, key: string): number {
  return plan.limits[key] ?? 0
}

/**
 * A billing-provider event, normalised by the billing adapter so no vendor
 * payload shape reaches the application. Anything the template does not act on
 * arrives as 'ignored' (still acknowledged, so the provider stops retrying).
 */
export type BillingEvent =
  | {
      id: string                       // provider event id — the idempotency key
      kind: 'checkout.completed'
      orgId: string              // the tenant the subscription belongs to
      userId: string | null            // who paid — audit only, never the key
      tier: PlanTier
      stripeCustomerId: string | null
    }
  | { id: string; kind: 'ignored'; providerType: string; reason: string }

/**
 * Audit trail (F5). Meaningful events only — mutations, deletions, exports and
 * staff access to a specific tenant's data — never routine reads. Append-only:
 * the app can add rows, never change them. `orgId` is null for platform events
 * (staff/role/permission changes, account deletion).
 */
export type AuditActorKind = 'user' | 'staff' | 'system'
export interface AuditEvent {
  orgId: string | null
  actorUserId: string | null
  actorKind: AuditActorKind
  action: string                       // 'org.created', 'role.saved', …
  targetType: string                   // 'organization', 'role', 'user', …
  targetId: string | null
  metadata?: Record<string, unknown>   // before/after or context — no secrets
}
export interface AuditEntry extends AuditEvent {
  id: string
  createdAt: Date
}

/** Everything one organization holds, as handed to its owner on export (F8). */
export interface OrgExport {
  exportedAt: string
  organization: Organization
  members: OrgMember[]
  subscription: Subscription | null
  audit: AuditEntry[]
}
export interface OrgMember {
  userId: string
  role: OrgRole
  createdAt: Date
}
