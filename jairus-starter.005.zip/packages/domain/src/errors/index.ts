// Domain errors — thrown by use-cases, mapped to HTTP by the delivery layer.
export class DomainError extends Error {
  constructor(message: string, public readonly code: string) {
    super(message)
    this.name = new.target.name
  }
}
export class UnauthorizedError extends DomainError {
  constructor(msg = 'Authentication required') { super(msg, 'UNAUTHORIZED') }
}
export class ForbiddenError extends DomainError {
  constructor(msg = 'Forbidden') { super(msg, 'FORBIDDEN') }
}
export class NotFoundError extends DomainError {
  constructor(msg = 'Not found') { super(msg, 'NOT_FOUND') }
}
export class ValidationError extends DomainError {
  constructor(msg: string) { super(msg, 'VALIDATION_ERROR') }
}
export class RateLimitedError extends DomainError {
  constructor(msg = 'Too many requests — try again shortly') { super(msg, 'RATE_LIMITED') }
}

/** The message a user may see for any thrown value. Domain errors are written
 *  for users; anything else (driver, vendor, bug) may leak internals, so it
 *  collapses to a generic line — report the original, show this. */
export function userMessage(error: unknown, fallback = 'Something went wrong. Please try again.'): string {
  return error instanceof DomainError ? error.message : fallback
}
