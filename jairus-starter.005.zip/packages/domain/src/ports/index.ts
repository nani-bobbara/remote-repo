// Ports — abstract interfaces the application depends on. Adapters implement these.
// The domain depends on NOTHING; these are the seams that keep vendors swappable + testable.
import type {
  AuditEntry, AuditEvent, BillingEvent, Membership, OrgMember, PermissionDef, RoleDef, Subscription, User, Organization, OrgRole,
} from '../entities/index'
import type { PlanTier } from '../value-objects/index'

// role = the user's role name; permissions = that role's resolved permissions (for can()).
export interface Session {
  userId: string
  email: string
  role: string
  permissions: string[]
  /** Mirrors the role's fullAccess flag; `can()` short-circuits on it. */
  fullAccess: boolean
}

// There is deliberately no AuthPort. Session resolution needs Next.js request
// headers, so it lives in @app/auth rather than behind a domain interface —
// see getSession() there. A port with no implementer and no caller is not a
// seam, it is a decoration.

/** Data access — user-scoped repositories (implemented by the Drizzle/Neon adapter). */
export interface UserRepo {
  findById(id: string): Promise<User | null>
  findByEmail(email: string): Promise<User | null>
  list(): Promise<User[]>                                  // admin/staff management (privileged path)
  setRole(userId: string, role: string): Promise<void>     // assign a role (staff management)
  setName(userId: string, name: string): Promise<void>     // update display name (self-service profile)
  /** Does this user sign in with a password, or only through an OAuth provider?
   *  Drives whether the profile screen offers a change-password form — an
   *  OAuth-only account has no credential to change. */
  hasCredential(userId: string): Promise<boolean>
  /** Delete the identity (cascades account, session, membership). Call only
   *  through the delete-account use-case, which enforces the ≥1-owner rule. */
  delete(userId: string): Promise<void>
}
/** Business table — only meaningful inside withOrg / asOrgSystem. */
export interface SubscriptionRepo {
  getForOrganization(orgId: string): Promise<Subscription | null>
  upsert(sub: Omit<Subscription, 'id'>): Promise<Subscription>   // system path (webhook)
}
/** Tenant directory — the caller's memberships (RLS: own rows only). */
export interface OrgRepo {
  /** Oldest first, with the organization joined in. */
  listForUser(userId: string): Promise<Membership[]>
  /** Members of the ACTIVE organization (inside withOrg). */
  listMembers(orgId: string): Promise<OrgMember[]>
  /** Owner-only by RLS; cascades membership + business rows. */
  delete(orgId: string): Promise<void>
}
/** Audit trail — append-only (F5). */
export interface AuditPort {
  record(event: AuditEvent): Promise<void>
}
export interface AuditRepo extends AuditPort {
  /** The org's trail — visible to its owners/admins (RLS), or to staff via dbAdminPort. */
  listForOrg(orgId: string): Promise<AuditEntry[]>
  /** Newest first, across everything — admin path only. */
  listRecent(limit: number): Promise<AuditEntry[]>
}
/** Role catalog — data-driven roles managed via the admin app. Not user-scoped. */
export interface RolesRepo {
  getByName(name: string): Promise<RoleDef | null>
  list(): Promise<RoleDef[]>
  upsert(role: RoleDef): Promise<RoleDef>
}
/** Permission catalog — the RBAC vocabulary. Not user-scoped, like RolesRepo. */
export interface PermissionsRepo {
  list(): Promise<PermissionDef[]>
  upsert(p: PermissionDef): Promise<PermissionDef>
  remove(key: string): Promise<void>
}
/** Processed billing-provider events — the webhook idempotency ledger. Append-only. */
export interface BillingEventRepo {
  /** Records the event. Returns false when it was already recorded (a redelivery),
   *  so the caller skips it. Call inside the same transaction as the effect, so a
   *  failed effect rolls the record back and the provider's retry still applies. */
  record(eventId: string, kind: string): Promise<boolean>
}
export interface DbPort {
  users: UserRepo
  subscriptions: SubscriptionRepo
  roles: RolesRepo
  permissions: PermissionsRepo
  billingEvents: BillingEventRepo
  orgs: OrgRepo
  audit: AuditRepo
  /** Run a callback scoped to one user: gives repos whose queries are filtered
   *  to them, and publishes the user id as DB session context. Identity data only. */
  withUser<T>(userId: string, fn: (repos: DbPort) => Promise<T>): Promise<T>
  /** Business-data scope. Verifies membership INSIDE the transaction, then
   *  publishes the organization id; throws ForbiddenError (nothing runs) if the
   *  user is not a member. */
  withOrg<T>(
    userId: string,
    orgId: string,
    fn: (repos: DbPort, ctx: { role: OrgRole }) => Promise<T>,
  ): Promise<T>
  /** Create a organization with the caller as its first owner (RLS bootstrap path:
   *  self-owner is only allowed on a brand-new, empty organization). */
  createOrg(userId: string, name: string): Promise<Organization>
  /** The user's personal organization: created on first need, otherwise the
   *  existing (oldest) one is returned. Idempotent and safe under concurrency. */
  createPersonalOrg(userId: string, userName: string | null): Promise<Organization>
}

/** The single system entry into business data: no session, so no user — sets
 *  only the organization scope. Lint-restricted to the billing webhook (see
 *  @app/config/eslint-boundaries); never hand it to anything user-driven. */
export interface SystemDbPort {
  asOrgSystem<T>(orgId: string, fn: (repos: DbPort) => Promise<T>): Promise<T>
}

/** Billing — checkout + subscription lifecycle (implemented by the Stripe adapter). */
export interface BillingPort {
  /** The subscription belongs to the organization; the user is recorded for audit. */
  createCheckout(ref: { orgId: string; userId: string }, tier: PlanTier): Promise<{ url: string }>
  /** Verifies the signature (throws if invalid) and normalises the provider
   *  payload into a domain BillingEvent. */
  parseWebhook(payload: string, signature: string): Promise<BillingEvent>
  /** Delete the provider customer, which cancels its subscriptions immediately.
   *  Idempotent: an already-deleted customer is not an error. */
  deleteCustomer(customerId: string): Promise<void>
}

/** Email — transactional send (implemented by the Resend adapter). */
export interface EmailPort {
  send(message: EmailMessage): Promise<void>
}

export type EmailMessage = {
  to: string
  subject: string
  /** Always required: the plain-text part is what reaches clients that refuse
   *  HTML, and it keeps a message readable in logs. */
  text: string
  html?: string
}

/** AI — text generation (implemented by the Vercel AI SDK adapter; optional). */
export interface AiPort {
  generate(prompt: string): Promise<string>
}

/** Feature flags (optional). */
export interface FlagsPort {
  isEnabled(key: string, userId?: string): Promise<boolean>
}

/** Background jobs — work that must not hold up (or fail) the request that
 *  caused it. Each job name maps to one payload type, so enqueue is checked
 *  end to end. Add a job by adding an entry here and a handler in the adapter. */
export interface JobPayloads {
  'email.welcome': { to: string; name: string }
}
export type JobName = keyof JobPayloads
export interface JobsPort {
  /** A repeated idempotencyKey is dropped, so callers on retried paths
   *  (webhooks, auth hooks) can enqueue without double-sending. */
  enqueue<N extends JobName>(name: N, payload: JobPayloads[N], opts?: { idempotencyKey?: string }): Promise<void>
}

/** Rate limiting — fixed-window counter keyed by caller + scope. */
export interface RateLimitPort {
  /** Counts one hit against `key`. ok=false once `max` hits land in the window. */
  hit(key: string, rule: { max: number; windowSec: number }): Promise<{ ok: boolean; retryAfterSec: number }>
}

/** Error reporting — exceptions the user never sees the detail of. */
export interface ErrorContext {
  userId?: string
  orgId?: string
  [tag: string]: string | undefined
}
export interface ErrorReporterPort {
  capture(error: unknown, context?: ErrorContext): void
}
