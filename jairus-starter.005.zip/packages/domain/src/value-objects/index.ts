// Value objects — small, validated, immutable. Pure (no external deps).

export type PlanTier = 'free' | 'basic' | 'pro'

/**
 * Canonical identifier slug: lowercase, runs of anything outside [a-z0-9_]
 * collapsed to "_", leading/trailing "_" trimmed. Used for role ids and
 * permission resources. Servers derive it and return it — clients must never
 * re-derive a slug to navigate (that drift caused a redirect to a missing row).
 */
export function slugify(s: string): string {
  return s.trim().toLowerCase().replace(/[^a-z0-9_]+/g, '_').replace(/^_+|_+$/g, '')
}

// EmailAddress and Money used to live here with zero consumers. Both were
// superseded by the vendors this template already commits to: Better Auth
// validates and normalises email at the boundary, and Stripe is the source of
// truth for amounts and currency. Re-introducing them would mean two
// representations of the same fact.
//
// Add a value object here when the domain genuinely owns an invariant that no
// adapter enforces for it.
