# Admin console shell

**Living document.** Describes the admin console as built.
**Scope:** `packages/ui` + `apps/admin`. The portal uses the same sidebar through the
shared `AppShell` in `@app/ui` (`layout="page"`), with a fixed breadcrumb header in place of
the ribbon; the admin still has its own copy of these components in
`apps/admin/app/(app)/_components/`.

The shell is a grouped collapsible sidebar, a chevron "workflow ribbon" under
the top bar, and a resizable workspace card. Its one architectural rule:

> **Exactly one function decides "where am I in the nav".**

Everything below follows from that.

## Why that rule exists

The shell this was ported from kept two nav configs — one for the sidebar, one
for the ribbon — which disagreed in production: the sidebar read
"System Setup / Role Control / Team Setup" while the ribbon read
"Systems / Roles / Teams". Our earlier version had the same shape of bug:
`context-bar.tsx` owned a private `steps` array pinned to the Management group,
so it printed a MANAGEMENT eyebrow on Analytics pages and could advertise
destinations the sidebar deliberately hid.

Both are the same root cause: more than one thing deciding where you are. The
port carried across the structure and the visual language; it deliberately did
not carry the duplicated config.

## 1. One nav config, one resolver

`apps/admin/app/(app)/_components/nav-items.ts` is the only nav config. Three
groups:

| Group | Items |
|---|---|
| Analytics | Overview |
| Management | System Setup · Permissions · Role control · Staff |
| Settings | Profile |

Each item may carry a `permission`; items the session lacks are filtered out.

`nav-resolve.ts` is pure, has no React, and exports two functions the sidebar,
ribbon, bottom tabs and mobile drawer all read:

- **`visibleGroups(access, groups?)`** — groups the session may see, each with
  its items permission-filtered.
- **`resolveActive(pathname, access, groups?)`** — which group and item own the
  current path. Matches the **longest** href first, so `/reports/archive` wins
  over `/reports` rather than whichever appears first in config.

Both take a `NavAccess` object — `{ permissions, fullAccess }` — never a bare
`string[]`. That shape is load-bearing: `admin` holds `fullAccess` with an
**empty** permission list, so filtering on the list alone hid every item from
the superuser. Requiring the object makes omitting the flag a compile error
rather than a silent lockout. See [rbac.md](./rbac.md).

`groups` is injectable so a caller can pass a fixture instead of the live config.

### Two kinds of empty group, treated differently

- **Natively empty** (`items: []` in config) — a placeholder for a section not
  built yet. **Kept**, so the sidebar still renders its header.
- **Emptied by permissions** (had items, all filtered out) — the session may
  see none of it. **Dropped**, header included.

## 2. Sidebar and ribbon stay in lockstep

Both derive from `resolveActive`, so they cannot disagree.

**Sidebar** — the open group is `override ?? active?.group.id ?? groups[0]?.id`.
It follows navigation by default; the override exists only so a user can expand
a different group by hand, and it resets on the next navigation. It is not
seeded to a hardcoded group.

**Ribbon** — `context-bar.tsx` renders the active group as the eyebrow and that
group's visible items as steps, straight from `active.items`.

**Residual case:** a group with no routes of its own can never be "active", so
it shows in the sidebar but never drives the ribbon. That is correct — it owns
nothing to be at.

## 3. Primitives live in `@app/ui`

The shell's pieces are app-agnostic and sit in `packages/ui/src/components/`:

| Component | Role |
|---|---|
| `workspace-layout.tsx` | the resizable workspace card — panels, collapse, header actions |
| `panel-column.tsx`, `resize-handle.tsx` | column mechanics and drag-to-resize |
| `panel-collapse-context.tsx` | collapse state shared without prop drilling |
| `workspace-card-header.tsx`, `workspace-actions-context.tsx` | the header toolbar a page registers into |
| `chevron-ribbon.tsx` | the stepped ribbon |
| `list-panel.tsx`, `list-row.tsx` | the left-hand list every management page uses |
| `content-pane.tsx`, `page-shell.tsx` | page scaffolding and empty states |
| `option-grid.tsx` | the permission matrix and the role/status pickers |
| `native-select.tsx` | every dropdown — the System Setup palette picker and the staff role pickers |
| `initials-avatar.tsx` | avatar fallback |
| `change-password-form.tsx` | self-service password change, shared with the portal |
| `password-reset-forms.tsx` | the signed-out request/reset pair, shared with the portal |

**`useRegisterWorkspaceActions`** is how a page puts Edit / Save / Cancel into
the shared header instead of rendering its own toolbar. Six components drive
the same header that way — the role, permission, staff and profile editors plus
the two create forms — so none of them ships a private toolbar that could drift
from the others.

The chevron silhouette is an inline arbitrary `clip-path` utility inside
`chevron-ribbon.tsx`, not a global class. The shape belongs to the component
that draws it.

## 4. Theme

Colors come from theme tokens only — no hardcoded colors in components, ever.
The palette itself is swappable and ships neutral; see
[theming.md](./theming.md).

Two additive tokens exist because shadcn ships three text tiers and this shell
needs four plus a heavier structural border:

- `--subtle-foreground` → `text-subtle-foreground` — group labels, placeholders, hints
- `--border-strong` → `border-border-strong` — structural borders vs plain dividers

Depth uses Tailwind's built-in `shadow-sm` / `shadow-lg`. Light/dark follows
system preference through the existing `ThemeToggle` (localStorage, falling back
to `prefers-color-scheme`); dark mode is not forced.

## 5. Pages

All render through `WorkspaceLayout`.

| Route | Left panel | Content |
|---|---|---|
| `/overview` | — | KPI cards (users, staff, roles) |
| `/system-setup` | — | protected-operations and core-services cards + Branding Configs (palette picker + live preview + copy-config) |
| `/roles` | role list + create | `PermissionEditor` — the permission matrix |
| `/permissions` | permission list + create | `PermissionDetail` |
| `/staff` | staff list + invite | `StaffEditor` |
| `/settings/profile` | — | display name + self-service password change |

Three routes sit outside the shell because they are reached signed out:
`/sign-in`, `/forgot-password` and `/reset-password`. All three are exempt from
the proxy bounce in `apps/admin/proxy.ts`.

`/staff` lists only staff — users whose role grants `admin:access`. Portal
subscribers are not shown and cannot be re-roled from there; both server
actions enforce that independently of the UI.

## 6. Resolution behavior

`nav-resolve.ts` is pure and easy to reason about (`groups` is injectable, so it
can be exercised against fixtures). Its intended guarantees:

- exact path → group and index
- nested path → its owning group, not the first group
- longest-href wins for overlapping prefixes
- items the session lacks permission for are omitted, and the active index
  still points at the right item
- a natively empty group survives; a permission-emptied one does not
- an unknown path (`/sign-in`) resolves to `null`
- a natively empty group never becomes active

## Deliberately not carried over

From the original port proposal, dropped and not missed:

- **A custom `--shadow-*` token scale** — Tailwind's built-in shadows cover it.
- **Status badge triads** (success/danger/warning/info bg-text-border) — nothing
  needs them yet.
- **A `/pipeline` route** — it would have been an empty placeholder.
- **`ModuleScaffold`** — it existed to hold the second nav config. With one
  resolver there is nothing for it to do.
