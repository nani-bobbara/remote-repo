# Organizations — tenancy via organizations + membership

Status: **Implemented** (2026-10-08). Reverses D1 (user-scoped). Pre-prod, so the single
`0000_init` baseline was regenerated rather than migrated. Decisions taken on the open questions:
system webhook path (`systemDbPort.asOrgSystem`, lint-restricted to the webhook route); `slug`
now (`slugify(name)` + random suffix); invites later.

Implementation notes:

- **≥1-owner invariant is use-case only.** No trigger: direct SQL or admin (owner/BYPASSRLS) writes
  can leave an organization ownerless. Any future remove/demote use-case must enforce it.
- Policies that read `membership` use SECURITY DEFINER helpers (`app_is_org_member`, `app_is_org_admin`,
  `app_org_is_empty`, `app_org_access`) at the top of `0000_init.sql` — a membership
  policy querying membership directly recurses. They use `search_path = ''` with schema-qualified
  names, return booleans only, are EXECUTE-granted to `app_user` only, and must be owned by the
  BYPASSRLS owner role (migrations run as it; `db:verify-rls` asserts it).
- The business policy also requires membership (or no user at all = the webhook system path), so an
  organization GUC set without `withOrg` still yields nothing for a non-member.
- **Personal organization is created in `requireOrg()` only — not in the sign-up hook** (that hook
  only enqueues the welcome email). `requireOrg()` is portal-only by construction: it rejects staff
  before creating anything and the admin app never calls it, so staff and seeded users never get an
  organization, with no inference about how an account was created. It calls
  `dbPort.createPersonalOrg(userId, name)` — a no-op returning the existing organization once a
  membership exists (and `requireOrg` lists memberships first, so the steady state is one read).
- `createPersonalOrg` is concurrency-safe: inside its transaction it takes
  `pg_advisory_xact_lock(hashtextextended('personal_org:' || userId, 0))`, re-checks membership and
  inserts only if none. Two simultaneous first requests (two tabs) would otherwise each create an
  organization with a different id — the membership primary key cannot stop that.
- **Known cross-tenant risk: the admin app.** `dbAdminPort` connects as the owner (BYPASSRLS) and can
  read every organization. It is mitigated by `requirePermission` on every admin screen/action, not by
  RLS. F5 records staff mutations, and admin screens that read a specific org's/user's data must call
  `auditStaff()` with that org (none exist yet — the only admin reads are aggregate lists).
- **F5 audit (implemented).** `audit_log` (SYSTEM): INSERT for app_user, SELECT for the org's
  owners/admins via `app_is_org_admin(org_id)`, UPDATE/DELETE revoked. `org_id` has no FK — the trail
  must outlive the org, and `ON DELETE SET NULL` would erase which org an `org.deleted` row concerned.
- **F8 lifecycle (implemented).** `makeExportOrg` (owner, `data:export`), `makeDeleteOrg` (owner,
  `org:delete`; RLS policy `organization_owner_delete` via `app_is_org_owner`), `makeDeleteAccount`
  (enforces ≥1 owner: leave / delete sole-member orgs / refuse). Stripe: the org's customer is
  deleted before its rows (cancels subscriptions immediately, no proration). Deleting your last org
  gives you a fresh personal org on the next request. Steps span several transactions, not one.
- No organization switcher yet (no invites ⇒ nobody has >1 membership).

Backlog:

- **Stripe customer → organization mapping** (store `stripe_customer_id`/subscription id → organization) is
  needed before handling `customer.subscription.updated` / `.deleted`, which carry no checkout
  metadata. Today only `checkout.session.completed` is applied.
- Invites (email → membership), organization switcher, ownership transfer / leave.

## 1. Tables

```ts
organization   (id text pk, name text not null, slug text unique not null,
             created_at, updated_at)
membership  (organization_id fk→organization cascade, user_id fk→user cascade,
             role text not null check in ('owner','admin','member'),
             created_at, PRIMARY KEY (organization_id, user_id))
             index (user_id)                       -- "my organizations" lookup
```

- `membership.role` is a **closed enum in code** (`ORG_ROLES` in `@app/domain`), not a row in
  the `role` catalog — see §4.
- Invariant: every organization has ≥1 `owner`. Enforced in the use-case (remove/demote last owner →
  `DomainError`), not by trigger. Lean; revisit if it ever bites.
- No `user.active_org_id` column. The active organization is a **cookie** (`active_org`) validated
  against membership on every request (§3). Keeps identity tables free of tenant state.

## 2. Ownership split

| Class | Tables | Keyed by | Change |
|---|---|---|---|
| identity (user-owned) | `user`, `account`, `session` | `app.user_id` | **unchanged** — a credential belongs to a person |
| auth-private | `verification` | — | unchanged |
| **tenant directory** | `organization`, `membership` | membership of `app.user_id` | **new** |
| **business (organization-owned)** | `subscription` + every future business table | `app.org_id` | **re-keyed**: `user_id` → `org_id` (unique; one sub per organization) |
| system | `billing_event` | — | unchanged (insert-only) |
| catalog | `role`, `permission`, `role_permission` | — | unchanged (platform RBAC) |

Rule for future tables (goes in CLAUDE.md): **business table ⇒ `org_id not null` +
`orgPolicy()`**. A table keyed on `user_id` must justify being identity.

## 3. RLS contexts

Two GUCs, both set with `set_config(..., true)` (transaction-local):

- `app.user_id` — who is calling. Set by `withUser`.
- `app.org_id` — which tenant. Set **only** by `withOrg`, and only after membership is
  verified **inside the same transaction**.

```ts
dbPort.withUser(userId, fn)                       // identity-scoped (profile, sessions)
dbPort.withOrg(userId, orgId, fn)     // business-scoped
  // 1. set app.user_id
  // 2. SELECT role FROM membership WHERE organization_id=$ws AND user_id=$user  (RLS-visible, see below)
  //    none → throw ForbiddenError (no GUC set, nothing runs)
  // 3. set app.org_id ; fn(tx, { role })
```

Policies (helper names mirror `ownerPolicy`):

```sql
-- business tables
orgPolicy: USING (org_id = current_setting('app.org_id', true))
                 WITH CHECK (same)
-- membership: see my own memberships; see co-members of the active organization
USING (user_id = current_setting('app.user_id', true)
       OR org_id = current_setting('app.org_id', true))
WITH CHECK (org_id = current_setting('app.org_id', true))   -- writes only in active ws
                                                     -- (INSERT is tighter still — see §5)
-- organization: visible if I'm a member
USING (EXISTS (SELECT 1 FROM membership m WHERE m.organization_id = organization.id
               AND m.user_id = current_setting('app.user_id', true)))
```

- Fail-closed: no `withOrg` ⇒ `app.org_id` NULL ⇒ business tables return zero rows.
- Defence in depth: even a forged `active_org` cookie can't read data — step 2 fails, and the policy
  alone would still require the GUC that only step 2 sets.
- Membership writes beyond role checks (invite/remove/role change) are gated in the use-case by
  `membership.role` (owner/admin) — RLS only bounds them to the active organization.
- Admin app's `dbAdminPort` (owner, BYPASSRLS) is unchanged: staff see all organizations, guarded by
  `requirePermission`.

## 4. RBAC reconciliation — two planes, no overlap

| Plane | Source | Gates | Where checked |
|---|---|---|---|
| **Platform** | `user.role` → `role`/`permission` catalog, `can()` | the **admin app** (operators/staff) | `requireStaff`, `requirePermission` — unchanged |
| **Organization** | `membership.role` (`owner`/`admin`/`member`) | **portal** actions on organization data | new `requireOrg(min?)` guard + `canInOrg(role, action)` |

- Platform roles never grant organization access, and organization roles never grant admin access. The
  existing "staff can't use the portal" rule stays — staff have no memberships.
- Organization actions are a small fixed map in domain (e.g. `billing:manage` → owner;
  `members:manage` → owner|admin; `data:write` → any). Not data-driven: customer-editable
  per-organization roles are a later feature, and adding them would extend this plane only.
- `user.role` for portal users stays `regular` and becomes irrelevant to the portal.

## 5. Personal organization (first portal request — see Implementation notes; originally planned in the sign-up hook)

- Better Auth `databaseHooks.user.create.after` (already used for the F4 welcome job) calls
  `makeCreatePersonalOrganization(db)`: inserts `organization` ("<name>'s organization") + `membership(owner)`.
  Not on `auth_user` (no grant on tenant tables, by design) and not on the owner connection (the
  portal never holds it). It runs on `app_user` through `dbPort.createOrg(userId, name)`:
  one txn that generates the id, sets `app.user_id` + `app.org_id = newId`, then inserts both
  rows. Bootstrap INSERT policies:
  - `organization`: `WITH CHECK (id = current_setting('app.org_id', true))`
  - `membership`: `WITH CHECK (organization_id = app.org_id AND (` caller is owner/admin of it
    `OR (user_id = app.user_id AND role = 'owner' AND NOT EXISTS (any membership of that organization))))`
    — so self-granting owner only works on a brand-new, empty organization; joining an existing one
    needs an owner/admin.
- Skipped for staff accounts (invite path in admin app) — staff have no organization.
- Idempotent: if the user already has a membership, no-op (re-run safe).
- Portal: `active_org` cookie absent → default to the user's oldest owner membership. A organization
  switcher in the portal header appears only when the user has >1 membership (B2C users never see it).

## 6. Migration / provisioning / verification

- Regenerate `0000_init` (delete `drizzle/`, `db:generate --name init`, re-append FORCE block +
  `organization`, `membership`). Dev branches reset (same procedure as the last squash).
- `provision-roles.sql`: default privileges already grant new tables to `app_user`; nothing for
  `auth_user` (it must not see tenant tables). Add both tables to the ONLY-IF block.
- `verify-rls.ts`: add `organization`, `membership` to the policy check; new behavioural checks:
  1. `withUser` only (no organization GUC) → `subscription` returns 0 rows.
  2. GUC set to a organization the user is **not** a member of → 0 rows on business + membership-of-others.
  3. `auth_user` has no privilege on `organization`/`membership`/`subscription`.
- Seed: no organizations for staff. Optionally a demo organization behind a flag — not by default.

## 7. Deltas to already-cleared work

| Item | Change |
|---|---|
| M8 schema | `subscription.user_id` → `org_id` unique, `ownerPolicy` → `orgPolicy`; add `organization`, `membership`; classification header gets "tenant directory" + "business" classes |
| M8 verify-rls | §6 checks; OWNED list split into IDENTITY and BUSINESS |
| F2 checkout | Stripe `client_reference_id` / metadata carry `orgId` (+ `userId` for audit); require `billing:manage` (owner) |
| F2 webhook use-case | `BillingEvent` carries `orgId`; `handle-billing-event` upserts by organization via `withOrg`-equivalent **system** path (webhook has no session — use a dedicated `dbPort.asOrgSystem(orgId)` that sets only `app.org_id`, callable only from the webhook use-case; documented as the single system entry) |
| F2 entitlements | `getPlan(orgId)`; `entitled()`/`limitOf()` unchanged (pure) |
| Portal pages | dashboard/settings read via `withOrg(active)`; settings shows billing only to owners |
| F4 jobs | job payloads that touch business data carry `orgId` |
| F7 errors | `orgId` context field (already in the type) now set by `withOrg` callers |
| F5 audit / F8 lifecycle | build on this: audit rows keyed by `org_id` + actor `user_id`; export/delete per organization, with user deletion = leave/transfer-ownership then identity delete |

## Open questions for review

1. Webhook system path (`asOrgSystem`) vs. resolving through the paying user's membership —
   recommended: system path; the payer may leave the organization later.
2. Organization `slug` now or later? Recommended: now (cheap; needed for URLs/invites).
3. Invites (email → membership) — in scope now, or later? Recommended: later, as its own feature;
   this pass ships personal organizations + schema/RLS/guards only.
