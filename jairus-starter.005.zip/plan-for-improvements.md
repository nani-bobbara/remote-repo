# Jairus‑Starter — Improvement Plan (FINALIZED)

> **Status:** Finalized 2026-10-05 — execution-ready. This is the single authoritative plan; it merges the original hygiene review, the validation pass, and the architecture-durability review into one ordered backlog. Prior stacked review sections are superseded by this document (history remains in git).
> **Scope:** `jairus-starter` monorepo (`apps/admin`, `apps/portal`, `packages/{domain,application,adapters,auth,ui,config}`).
> **Goal:** keep this a **future-proof, reusable template** — remove duplication, close design-principle violations, and add the durability layer so the shape stays correct once real products store data.
> **In flight:** branch `feat/dynamic-nav-ribbon` (uncommitted UI polish; several edits correctly landed in `@app/ui` — keep them, see Guardrails).

---

## How to use this plan

- **Phases run in order.** Phase 0 can start **immediately** — it depends on no open decision.
- Each item is `ID · evidence (file:line) · fix · done-when`. All evidence verified against current code.
- **`⚠ DECISION Dn`** items must be resolved (below) before their phase starts.
- Item IDs are preserved from the source reviews: `H/M/L` = code-hygiene; `F` = architecture durability. "retrofit cost" = how expensive the fix becomes once products ship data.

---

## Decisions required (resolve before the gated phase)

These four shape everything downstream. Recommendations given; **the executing session must get explicit sign-off before the phase that depends on each.** None block Phase 0.

| # | Decision | Options | Recommendation | Gates |
|---|---|---|---|---|
| **D1** | **Tenancy model (F1)** | (a) add `workspace` + `membership` now; (b) stay user-scoped, retrofit later | **(a) now** — it's cheap with zero data and the single most expensive migration later; auto-create a personal workspace on signup so B2C never notices | Phase 1 |
| **D2** | **Testing direction (§4/F10)** | (a) full Vitest suite; (b) executable **invariants only** (verify-rls in CI, boundary lint, one checkout→webhook smoke); (c) none | **(b)** — respects the earlier deliberate removal of the test suite while keeping the template safe for Model A releases. Treated as (b) throughout this plan. | Phase 1 (verify-rls), Phase 4 |
| **D3** | **Application-layer convention (L1)** | (a) server actions are the composition layer; (b) non-trivial flows live in `@app/application` use-cases | **(b)** — F8's account export/delete gives the layer a first real job; makes the convention demonstrable | Phase 3 |
| **D4** | **Template lifecycle (F9, "Model A")** | (a) versioned `@jairus/*` core packages + `/jairus:upgrade`; (b) clone-and-fork forever | **(a)** — but it is **blocked by H1**; you can't package a core the admin app has forked | Phase 4 (prereq: H1) |

### ✅ Resolved 2026-10-07 (user sign-off)

- **D1 — Tenancy: ADD TENANCY NOW (REVERSED 2026-10-07, later same day).** Originally user-scoped; the user reversed it before Phase 3, because audit (F5) and data-lifecycle (F8) are ownership-coupled and there is no data yet (cheapest moment). Add `workspace` + `membership(user, workspace, role)`; **business** tables (subscription + future) re-key to `workspace_id` with `app.workspace_id` RLS; **identity** tables (user/account/session/verification) stay user-scoped; auto-create a personal workspace on signup (B2C transparent). **Design-first** — reviewed before implementing. Partially revises the already-cleared M8 (subscription policy) and F2 (subscription keying, checkout/webhook → workspace). Tracked as **T0** at the head of Phase 3; gates F5/F8.
- **D2 — Testing: scoped, DI-based suite, DEFERRED to a pre-prod phase** (user-confirmed 2026-10-07, revised). Rationale: avoid over-engineering the early phases. **Design for testability now** — core logic in `@app/application` use-cases that receive ports (D3) — but write the Vitest suite later, as a dedicated **Phase 5 (pre-production)** step before first deploy. Still scoped to **essential template cases** (not exhaustive), **dependency-injected** (fake ports). F10 CI invariants remain the minimum that ships earlier.
- **D3 — (implied by D2) adopt the use-case + DI convention.** Core business logic lives in `@app/application` use-cases that receive ports as parameters, so unit tests inject in-memory/fake ports. This is what makes D2 achievable. *(Flag if you disagree; otherwise treated as decided.)*
- **D4 — unchanged** (Model A, still after H1).

---

## Scorecard (2026-10-05)

| Dimension | Score | Read |
|---|---|---|
| Layering / hexagonal boundaries | 8.5/10 | Clean; domain/application vendor-free, Drizzle contained in adapters. |
| AuthN + data-driven RBAC | 8/10 | Strong; permission catalog + roles as data. |
| Data isolation (RLS) | 3/10 | 1 of 7 tables protected (M8). |
| Tenancy model | 2/10 | None — everything user-scoped (F1). |
| Billing robustness | 4/10 | Works; no event log / entitlements (F2). |
| Operability (config, errors, jobs) | 3/10 | No env validation, error tracking, or job runner (F3/F4/F7). |
| Edge security (headers, rate limits) | 4/10 | Auth rate-limited only; no CSP/headers (F6). |
| Template lifecycle (upgrades) | 2/10 | Clone-and-fork; no versioned core (F9). |
| Verification | 1/10 | Suite removed by decision; only `verify-rls.ts` remains (D2/F10). |

**Overall: ~5.5/10 as a production base — the shape is right, the durability layer is missing.**

> **Closing step (do when all phases land):** re-score this exact table and record the delta vs this 5.5 baseline. Dimensions intentionally capped by decision stay flagged, not counted as failures: **Verification** (D2 — only rises at Phase 5 when the DI test suite lands). **Tenancy is now being ADDED** (D1 reversed 2026-10-07), so it should rise materially too — no longer a deliberate hold. Everything else should move up once Phases 1–4 are in. Note which rows are "deferred-by-decision" so the revised card reads honestly.

---

## Baseline — what's already right (do not regress)

- Drizzle/SQL fully contained in `packages/adapters`; no app/UI imports `drizzle-orm`/`postgres`/raw `db`/`schema`.
- `domain` + `application` import no React/Next/vendor code — dependency direction correct.
- Theme discipline: zero raw color utilities / leftover MachineControl tokens in `.tsx`; hex only in token CSS.
- `packages/config/{roles,brand,theme}.ts` centralized and env-overridable.
- `subscription` RLS policy correctly fail-closed.
- Portal is a faithful thin consumer of `@app/ui`.

**Root cause of most hygiene findings:** `apps/admin` **forks the shared `AppShell`** (`packages/ui/src/components/app-shell.tsx`, whose `layout="workspace"` is documented *"Matches the admin console"*) instead of consuming it. Portal consumes it correctly. The fork is actively drifting — recent polish landed partly in the fork, partly in the shared components.

---

## Phase 0 — Correctness & safe quick wins  *(start now; no decision needed)*

- **H2 · slug bug (real defect).** `roles/_components/new-role-form.tsx:22` re-derives the role-id slug from `roles/actions.ts:8` but omits the `^_+|_+$` trim, so e.g. `"_admin_"` redirects to `admin_` (missing row). **Fix:** return the slug from `createRole` and navigate with it (mirror `createPermission`, which already returns `{key}` and warns against re-deriving). **Done-when:** create-role redirect lands on the new row for underscore/edge-case names.
- **M7 · unguarded `dbAdminPort`.** `overview/page.tsx:13` calls `dbAdminPort.users.list()`/`roles.list()` after only `getSession()`; adapter contract (`db/index.ts:170-172`) requires `requireStaff()`/`requirePermission()` on every bypass-port call. **Fix:** add `await requireStaff()` at top; drop the `session?.email` `?.`. **Done-when:** page calls `requireStaff()` before any admin-port read.
- **M3 · domain types redeclared.** `RoleDef`/`PermissionDef`/`StaffMember` hand-copied in `permission-editor.tsx:16,25`, `permission-detail.tsx:18`, `staff-editor.tsx:18`. **Fix:** import from `@app/domain` (`entities/index.ts:11,48`). **Done-when:** no local redeclarations remain.
- **M5 · duplicated helpers/middleware.** `slug` (`roles/actions.ts:8`) ≡ `slugResource` (`permissions/actions.ts:12`) → one `slugify()` in `@app/domain` (pairs with H2). Middleware bodies identical (`apps/admin/middleware.ts:7-14` ≡ `apps/portal/middleware.ts:6-13`) → `createSessionMiddleware()` factory in `@app/auth/edge`; apps supply only `matcher`. **Done-when:** single `slugify`; both middlewares call the factory.
- **L5 · dead component.** `apps/admin/app/(app)/staff/_components/role-select.tsx` imported nowhere, superseded by `StaffEditor`'s `OptionGrid`. **Fix:** delete. **Done-when:** removed, build green.
- **Trivial dedupes** (subset of H1, safe in isolation): admin `theme-toggle.tsx` → import `ThemeToggle` from `@app/ui`; admin `layout.tsx:46-50` inline theme-init → import `THEME_INIT_SCRIPT` from `@app/ui/lib/theme-script` (portal already does). **Done-when:** admin has no local copy of either.

---

## Phase 1 — Foundations that get expensive later  *(D1, D2 resolved — ready)*

Schema-shaping work — must land before any product stores real data.

- **M8 · data isolation (RLS) — refined design (user-approved 2026-10-07).** retrofit cost: HIGH. *(D1: stay user-scoped; F1 tenancy deferred.)*
  **Why refined:** a naive "`app.user_id` policy on every user table" breaks Better Auth, which reads `user`/`session`/`account`/`verification` **before identity exists** (login, token lookup) on the RLS-subject `app_user` connection → zero rows → auth breaks. And `role`/`permission`/`role_permission` are **global catalogs** every session reads to resolve permissions — a per-user policy there is a misclassification.
  **Design:**
  - **Dedicated `auth_user` Postgres role** (`BYPASSRLS`, pooled) via new env `DATABASE_URL_AUTH` + a new `dbAuth` client used **only** by Better Auth. GRANTs scoped to the **auth tables only** (user, account, session, verification) so BYPASSRLS can't touch business tables — DATABASE_URL_AUTH ships in both apps, so limit its blast radius.
  - **`app_user` (RLS subject) policies:** `user` → self-row (`id = app.user_id`); `account`,`session` → `user_id = app.user_id`; `verification` → RLS ON + FORCE, **no policy** (app_user fully denied); `subscription` unchanged.
  - **Catalogs** (`role`/`permission`/`role_permission`) → no user RLS; app-guarded (`requirePermission` on writes); documented as a deliberate global-catalog classification.
  - `dbAdmin` must bypass via **BYPASSRLS** (FORCE subjects owners too, so ownership alone won't bypass). `dbAuth`/`dbAdmin` must be unimportable by feature code (boundary-lint, F10). New migration ENABLE + FORCE; `verify-rls` extended to every table + asserts the auth-role scoping; README/.env.example get the role-setup SQL + `DATABASE_URL_AUTH`; schema-header documents the pattern + the deferred `workspace_id` migration.
  **Done-when:** cross-user read returns zero rows; `verify-rls` green across every table (incl. auth_user cannot read business tables, app_user denied verification); **all auth flows still work** — sign-in, session resolution, OAuth callback, password reset, profile `hasCredential`, staff invite (verified or explicitly reasoned).
- **F1 · tenancy — DEFERRED (D1).** Not built now. Schema-header note: per-user tables will later re-key on `workspace_id`; keep new tables single-owner so the migration is mechanical.
- **F2 (+L2) · billing event log + entitlements.** retrofit cost: HIGH.
  Evidence: no Stripe event table / processed-event check (only role assignment is idempotent, `db/index.ts:128`); tiers scattered across `settings/page.tsx:17-18`, `billing/index.ts:17-23`, `schema.ts:144`, `webhook/route.ts:27` (L2).
  **Fix:** (a) `billing_event(stripe_event_id unique, type, processed_at)` — insert-first/skip-on-conflict → real webhook idempotency + audit; (b) single **entitlements** catalog in `@app/config` (`plan → {features, limits}`) + pure `entitled(subscription, feature)` in `@app/domain`, mirroring `can()`; products check capabilities, never plan names; (c) move webhook reconciliation into a DI use-case in `@app/application` (establishes the D3 pattern the deferred tests will target). **Done-when:** replaying a webhook is a no-op; no tier string is referenced outside the catalog.
- **F3 · validated configuration.** retrofit cost: MEDIUM.
  Evidence: 26 raw `process.env.*` reads; no schema; `billing/index.ts:29` hard-falls-back to `http://localhost:3001` (L3).
  **Fix:** one `@app/config/env` with zod schemas (server vs `NEXT_PUBLIC_`), parsed once, fail-fast at boot. **Done-when:** missing `STRIPE_WEBHOOK_SECRET` fails the build/boot, not a customer checkout.

---

## Phase 2 — One canonical shape  *(makes the core packageable; prereq for D4)*

- **H1 · consolidate admin onto shared `AppShell`** *(biggest hygiene leverage — ⚠ gated, see Guardrails).*
  Shared, unused by admin: `app-shell.tsx` (`SidebarNav`/`MobileDrawer`/`BottomTabs`/`Ribbon`/`CollapseToggle`), `lib/app-nav.ts`. Fork to delete: `admin-shell.tsx`, `sidebar.tsx`, `bottom-tabs.tsx`, `mobile-drawer.tsx`, `context-bar.tsx`, `nav-resolve.ts`.
  **Fix:** render `<AppShell layout="workspace" groups isVisible={(i)=>!i.permission||can(access,i.permission)} actions={<LogoutButton/>} drawerFooter={…}>`. **Resolves** the collapse-offset magic number, theme-toggle/theme-init dupes, and the nav/bottom-tabs/mobile-drawer/ribbon forks. **Done-when:** admin imports `AppShell`; the six fork files are gone; the approved layout is visually unchanged (see Guardrails diff).
- **H3 · one sign-out.** 5 impls (`admin/_components/sign-out-button.tsx:7` ≡ `portal/.../sign-out-button.tsx:7`; `logout-button.tsx:9`; `mobile-drawer.tsx:44-55`; `user-menu.tsx:34-43`). **Fix:** `useSignOut()` hook + `<SignOutButton variant icon? redirectTo>` in `@app/ui`.
- **M1 · `<ListWorkspace>`.** Same `PageShell > WorkspaceLayout` master-detail scaffold in `roles/page.tsx:31-87`, `staff/page.tsx:40-93`, `permissions/page.tsx:30-87` → extract to `@app/ui` (items/selected/create-slot/detail-slot).
- **M2 · `useEditMode()` + `<EditorHeader>`.** Mode/dirty/save + `useRegisterWorkspaceActions` + avatar header repeated in `permission-editor.tsx:47-123`, `staff-editor.tsx:52-90`, `permission-detail.tsx:34-92` (create forms repeat the edit half).
- **M4 · `<FieldLabel>` + info-panel variant.** Field-label class repeated 12× (`permission-detail/editor`, `staff-editor`, `branding-configs`); dashed info-panel 3×.
- **M6 · `<AuthLayout>`.** Admin hero panel copy-pasted (`sign-in/page.tsx:9-23`, `forgot-password/page.tsx:9-23`, `reset-password/page.tsx:11-25`); portal auth pages can share it.
- **L4 · unify `InitialsAvatar`.** Ad-hoc initials in `staff-editor.tsx:33-41`, `permission-editor.tsx:130`, `permission-detail.tsx:99` → `@app/ui` `InitialsAvatar`.
- **L3 / L6 · minor** — route checkout base URL through `@app/config/env` (folds into F3); optionally collapse thin auth wrappers / `<EmailPasswordForm>`.

---

## Phase 3 — Operability  *(production readiness; F8 needs D3)*

- **T0 · Tenancy (D1 reversed) — DESIGN-FIRST, gates F5/F8.** Add `workspace` + `membership`; re-key business tables (subscription + future) to `workspace_id` + `app.workspace_id` RLS; keep identity tables (user/account/session/verification) user-scoped; auto-create a personal workspace on signup. Revises M8 (subscription policy), F2 (subscription keying + checkout/webhook → workspace), `verify-rls`, `provision-roles`; regenerate the 0000 baseline. RBAC: keep platform/staff `can()` global; `membership.role` governs workspace access — define the split. F4/F6/F7 are ownership-agnostic and run in parallel; F5/F8 build on this. **Design approved 2026-10-08** (`docs/design/tenancy.md`), **with review revisions (re-review before impl):**
  - **Rename tenant concept `workspace`→`organization`** everywhere (table `organization`, `org_id`, GUC `app.org_id`, `withOrg`/`requireOrg`/`canInOrg`, `ORG_ROLES`, cookie `active_org`, `ErrorContext.workspaceId`→`orgId`). **UI `workspace` names stay** (WorkspaceLayout etc.) — the rename exists to end that collision.
  - **RLS self-recursion fix (blocker):** membership's policy querying membership → "infinite recursion detected in policy". Use `SECURITY DEFINER` helpers (`is_org_admin`/`is_org_member`) owned by the BYPASSRLS owner, `SET search_path=''`, `STABLE`, boolean-only, EXECUTE to app_user; hand-append to 0000_init; verify-rls asserts they exist.
  - `asOrgSystem` added to the boundary lint (webhook-only).
  - Idempotent **ensure-personal-org** fallback on first portal request (failed after-create hook).
  - Admin `dbAdminPort` cross-org reads: document as a known risk + audit in F5.
  - verify-rls must PROVE the bootstrap INSERT policies (self-create empty org OK; self-join existing FAILS; member can't add members); ≥1-owner invariant is use-case-only (document). Report implementation as its own reviewed chunk (it revises M8 + F2).
- **F4 · background work.** No queue/runner; email + webhook reconciliation run inline. **Fix:** `JobsPort` in `@app/domain` + a serverless adapter (Inngest/QStash); one real job (welcome email) establishes the pattern. retrofit: MEDIUM.
- **F5 · admin audit trail.** `AuditLog` was removed as dead (`entities/index.ts:99`); role/staff/permission mutations leave no record. **Fix:** `audit_event(actor, action, target, before, after, at)` written by every admin action via a small `AuditPort`. retrofit: MEDIUM.
- **F6 · edge security.** No `headers()`/CSP in either `next.config`; rate limiting only inside Better Auth (`auth/index.ts:47`). **Fix:** shared security-headers helper in `@app/config` used by both configs; `RateLimitPort` on mutating actions + webhooks. retrofit: LOW.
- **F7 · error tracking.** OTEL tracing is flag-gated; no exception capture. **Fix:** Sentry (or OTEL logs) in `instrumentation.ts`, tagged `userId`/`workspaceId`. retrofit: LOW.
- **F8 (+L1) · data lifecycle.** No account export/delete, no soft-delete convention. **Fix:** `DeleteAccount`/`ExportAccount` use-cases in `@app/application` (this is L1's first real job — per D3), cascading through ports + Stripe customer cleanup. retrofit: MEDIUM.

---

## Phase 4 — Lifecycle  *(makes improvements compound across projects; needs D4)*

- **F9 · Model A packaging.** Publish the locked core as versioned `@jairus/*` packages (lockstep, git-tag deps to start); clone only the shell; `/jairus:upgrade` codemods. **Prereq: H1** (can't package a forked core). retrofit: HIGH per project.
- **F10 · CI invariants (minimum guardrails).** (1) `verify-rls` covering every user-owned table; (2) boundary lint (no vendor SDK outside `@app/adapters`, no adapter import in `domain`/`application`); (3) one checkout→webhook→entitlement smoke. These ship with Phase 4; the full DI-based unit suite (T1) lands in Phase 5. Together they make Model A lockstep releases safe.

---

## Phase 5 — Pre-production verification  *(D2: before first deploy; core features first)*

- **T1 · DI-based test suite.** Deliberately deferred to here (D2 — build core features first), but the code is designed for it (D3: use-cases receive ports). Vitest at the workspace root; fake/in-memory ports injected into use-cases + domain. Scope: **essential template cases** (not exhaustive) — `can()`/permission resolution, `slugify`, `withUser`/RLS scoping, `entitled()` + billing-event idempotency, the webhook reconciliation use-case. **Done-when:** `pnpm -r test` green in CI; core use-cases have DI unit tests; no unit test hits a real network/DB.

---

## Backlog → Feature roadmap (ACTIVE 2026-10-08) — close out template basic/common features

User approved building these to completion, in priority order, **checkpoint-first (serialized)**: Phase 0–3 is verify-rls'd + committed first, then all backlog work proceeds. (The "low-risk parallel" idea was dropped — even those items edit checkpoint files, so they can't run isolated; see the Sequencing note below.) Every item still passes the five-dimension gate; no commits without user sign-off.

**Priority order**
- **P1 — tenancy / B2B completeness:** org invites (email→membership), switcher, leave / transfer-ownership; `@app/ui` **Dialog** + typed-confirm.
- **P2 — operator console (B1, detailed below):** subscribers list/detail + staff-access model (`subscribers:*`) + PII boundary; subscriber controls (suspend via `setBanned` + auth enforcement; plan via Stripe / comp-override); activity timeline (consumes F5) + audit filters; thin send-email comms.
- **P3 — billing & deletion robustness:** Stripe customer→org mapping + `subscription.updated/deleted`; deletion atomicity / all-customers; soft-delete + grace; audit retention.
- **P4 — quality & lifecycle:** Phase 5 DI tests; Phase 4 Model A packaging → Jairus-plugin update.

**Sequencing (corrected 2026-10-08):** even the "low-risk" items (Dialog wiring, `/audit` filters) edit files that are IN the Phase 0–3 checkpoint diff (`@app/ui` index, portal Danger zone, admin `/audit`), so nothing can run isolated. **All backlog work waits for the checkpoint commit.** Critical path: **user runs `verify-rls` → reviewer commits Phase 0–3 → peer starts P1 + Dialog/audit-filters.**

### B1 — Subscribers / Organizations admin console (common micro-SaaS operator feature)
An operator view in the **admin app** of customers (portal subscribers) and their organizations. Strong fit for the template's "common admin features" mission.
- **Depends on (build after):** tenancy (org/membership), F2 (subscription + entitlements), F5 (audit → activity), F4/email (comms), F8 (data lifecycle). Building before these reworks.
- **Scope — keep it bounded:**
  - **Orgs/subscribers list + detail:** org, members, plan tier, subscription status, seats. Cross-tenant reads via `dbAdminPort`, **guarded by a new permission (e.g. `subscribers:read`/`:write`) and AUDITED** (operator access to customer data is sensitive — ties to F5).
  - **Subscriber controls (sensitive — guarded + `auditStaff({orgId})`):**
    - **Suspend / reactivate** a portal user via the existing `user.banned`/`ban_expires` columns — needs a `setBanned` port + guarded admin action **AND auth enforcement**: `getSession`/`requireUser` must reject a banned user and revoke their sessions (a flag alone is not a ban). The staff editor already has a stub awaiting this.
    - **Plan/tier changes — do NOT edit the Stripe-synced `subscription` row directly** (the webhook would overwrite it; it drifts from Stripe). Either (a) **deep-link to Stripe / call the Stripe API** and let the webhook reconcile (needs the deferred customer→org mapping), or (b) add an explicit **manual entitlement override** ("comp") kept separate from the Stripe subscription so operator overrides and real billing never fight.
  - **Staff access model (admin / sales / support) + PII boundary:** differentiate roles via the platform RBAC — new granular permissions (`subscribers:read`, `subscribers:write`, `subscription:manage`, `user:suspend`) assigned per role (admin = all; support = read + support actions; sales = narrower read). **Principle: staff manage the *account*, not the *person's* data.** Operational data (subscription/status/suspend/plan-via-Stripe-or-override) is the staff-editable surface. **Customer PII (name/email/billing identity) is customer-owned → NOT staff-editable** (the subscriber edits it in their own profile); PII *reads* are role-gated, minimized to need, ideally masked for lower-trust roles, and always audited (`auditStaff`, since access is cross-tenant via `dbAdminPort`).
  - **Billing:** summary + **deep-link to the Stripe dashboard** (do NOT rebuild Stripe); history from the `billing_event` ledger.
  - **Activity/monitoring:** per-subscriber timeline that **consumes** the F5 audit trail + `billing_event` (reads it, does NOT rebuild or re-record); filter/segment by plan tier.
  - **Communications:** a thin "send email" to a subscriber via F4/Resend. Full support/ticketing is OUT — integrate a vendor (Intercom/Zendesk), don't build a helpdesk into the template.
- **Security:** every cross-org read `requirePermission`-guarded + audited; never expose Stripe secrets or another org's data.

### Deferred follow-ups (captured from F5 / F8 / tenancy so they're not lost)

Small, additive items deferred during the phases. **F5 audit is the FOUNDATION** (immutable trail + raw `/audit` feed); these build on it or on tenancy — none re-implement it.
- **Audit:** filters/search on the `/audit` page; an audit retention policy. *(B1's per-subscriber timeline is the richer consumer view of this same data — not a second audit system.)*
- **Org lifecycle:** ownership transfer; member **invites** (email → membership); the >1-org **switcher**; `leave` flow. The data model already supports these — they're additive features, not schema changes.
- **Deletion robustness:** soft-delete / grace period; make the multi-txn delete atomic (today it's retryable, not atomic); delete *all* historical Stripe customers (today: latest only).
- **Billing lifecycle:** a Stripe **customer→org mapping** so `subscription.updated/deleted` events can resolve an org (checkout metadata only covers `checkout.completed` today).
- **UX:** replace `window.confirm` on destructive actions with a shared Dialog + typed-confirm (needs a `@app/ui` Dialog).

---

## Deliberate non-goals (keep out of the template)

i18n, multi-region, public REST API/SDK, feature-flag vendor lock-in, microservices. Add per product; baking them in raises the floor for every idea.

---

## Plugin-surface change log (for the later Jairus-plugin update)

The Jairus plugin holds outdated info about these. Do NOT touch the plugin now — accumulate here; update the plugin after jairus-starter is complete.

- **Phase 0** — new `@app/auth/edge` export `createSessionMiddleware()` (canonical middleware pattern; scaffold via factory, never hand-roll). New `@app/domain` export `slugify()` (server derives slugs, clients never re-derive). Create-actions return the created id (`createRole → {name}`, `createPermission → {key}`). Admin no longer has a local `ThemeToggle` — use `@app/ui`.
- **Phase 1 / M8 (done, review-passed)** — new required env `DATABASE_URL_AUTH` + a **third DB role** (`auth_user`, BYPASSRLS, GRANT-scoped to the 4 auth tables) + a module-private `dbAuth` client. New canonical `packages/adapters/sql/provision-roles.sql` (two-part flow: before/after migrate) — affects Foundation role-setup/secrets (F5/F9), **both Vercel projects**, and the `neon` skill. New shared `@app/config/eslint-boundaries` (boundary lint) wired into both apps. Schema **classification rule** (USER-OWNED / AUTH-PRIVATE / CATALOG + "classify every new table") → designer/developer/reviewer agents + neon skill must teach it. `pnpm db:verify-rls` is the M8 gate (must run green on a live branch).
- **Phase 1 / F2 (done, review-passed)** — new `@app/config/plans` catalog (`PLANS`, `PlanId`, `DEFAULT_PLAN`, `upgradesFrom`) + `entitled()`/`limitOf()` in `@app/domain` (fail-closed; take an `Entitlements` param — no config import). Developer/designer agents + **stripe skill** must gate on capabilities, never plan names. `BillingPort.parseWebhook` signature changed → returns a domain `BillingEvent` union (Stripe shape contained in the adapter). New `DbPort.billingEvents` repo. New **SYSTEM** table class = append-only ledger (INSERT-only policy + FORCE + `REVOKE UPDATE,DELETE`) → **neon skill**. `makeHandleBillingEvent(db)` is the **DI reference pattern** for all application logic (developer agent). **Behaviour change:** unknown/missing tier → `ignored` (never silently grants `pro`) — release-note it. `verify-rls` extended with the SYSTEM section.
- **Phase 1 / F3 (done, review-passed)** — new `@app/config/env` (`getEnv`/`assertEnv`; groups db/dbAdmin/auth/billing/email/seed). Developer agent: read config via `getEnv`, never raw `process.env`. Per-app boot `assertEnv` in `instrumentation.ts` (portal: db/auth/billing/email — never dbAdmin; admin: db/dbAdmin/auth/email — no Stripe) → Foundation F9 secrets-per-Vercel-project. `SKIP_ENV_VALIDATION` = CI-build only (never runtime). `@app/config` now depends on `zod` (still a workspace leaf). Follow-up: add `import 'server-only'` to env.ts.
- **Phase 2 / H1 (done)** — admin consumes the shared `AppShell` (`layout="workspace"`); the admin shell fork is deleted. Plugin must scaffold an admin app via `AppShell` + `isVisible`, never a hand-rolled shell.
- **Phase 2 / H3 + migration squash (done)** — `@app/auth/client` exports `useSignOut()` + `SignOutButton` (canonical sign-out; no per-app copies). `@app/auth` now depends on `@app/ui` (no cycle). Dev migrations squashed to a single `drizzle/0000_init.sql` (9 tables, 5 policies, 6 FORCE) — existing dev branches must be reset before `db:migrate` (neon skill + developer scaffolding). README setup rewritten.
- **Phase 3 / F4+F6+F7 (done, review-passed)** — new ports: `JobsPort` (+ `@app/adapters/jobs` inline runner; Inngest/QStash seam), `RateLimitPort` (+ `@app/adapters/rate-limit`; Upstash seam) with `actionLimit()` in `@app/auth`, `ErrorReporterPort` (+ `@app/adapters/errors`; lazy Sentry). New `@app/config/security-headers.mjs` used by both `next.config`s (CSP with documented nonce upgrade path — `unsafe-inline` is the known tradeoff). New env `SENTRY_DSN`/`SENTRY_ENVIRONMENT` (`errors` group). New `@app/ui` `StatusPage` + per-app error.tsx/global-error.tsx/not-found.tsx. Developer agent: enqueue via JobsPort, gate mutations with `actionLimit`, report via ErrorReporterPort, never leak error detail (digest + `userMessage` only). Root `pnpm.packageExtensions` pins `@hookform/resolvers` to zod 3. Open nuance: staff invite currently fires `email.welcome` (should be an invite email).
- **Phase 3 / T0 tenancy — IMPLEMENTED + review-passed 2026-10-08 (live verify-rls run still pending on a dev branch).** Named **organization** (NOT workspace — the UI keeps its `workspace` names). New `organization` + `membership` tables; `DbPort.withOrg(userId, orgId, fn)` + `createOrg`/`createPersonalOrg` (advisory-lock race-safe, lazy via `requireOrg` — staff never traverse it) + `SystemDbPort.asOrgSystem(orgId)` (lint-banned outside the Stripe webhook); `app.org_id` RLS GUC + `orgPolicy`; **4 SECURITY DEFINER helpers** (owned by the BYPASSRLS owner, `search_path=''`) break the membership-policy recursion; `subscription` re-keyed `user_id`→`org_id` (supersedes the M8 subscription policy + F2 keying); `requireOrg()`/`canInOrg()`/`ORG_ROLES` in `@app/domain`; `active_org` cookie; `ErrorContext.orgId`. CLAUDE.md rule: "business table ⇒ `org_id` + `orgPolicy()`". Large plugin surface: neon skill (table classes, 2nd GUC, the SECURITY DEFINER helper pattern), developer/designer agents (withOrg, two RBAC planes, org guards). Deferred: switcher, invites, leave/transfer, Stripe customer→org mapping.
- **Phase 3 / F5 audit + F8 lifecycle (done, review-passed)** — new `audit_log` (append-only, org_admin_read, no FKs, FORCE, UPDATE/DELETE revoked) + `AuditPort.record`/`AuditRepo`; `audit:read` permission; admin `/audit` page. New `app_is_org_owner` helper + `organization_owner_delete` policy. New DI use-cases `makeExportOrg`/`makeDeleteOrg`/`makeDeleteAccount` (Stripe-first delete, no network in txn); port methods `users.delete`, `orgs.listMembers`/`delete`, `BillingPort.deleteCustomer`; `ORG_ACTIONS` += `data:export`/`org:delete`. Portal "Danger zone". **Developer-agent rule:** any per-org admin read MUST call `auditStaff({orgId})` (gates B1). Backlog: Dialog + typed-confirm for destructive UX.
- *(append further surface changes as phases land)*

---

## Guardrails — read before touching the shell (H1 / Phase 2)

- **Do not blind-delete the admin shell fork.** First diff the shared `AppShell`/`CollapseToggle` against the layout approved on `feat/dynamic-nav-ribbon` and **port any gaps into the shared components**:
  - ribbon = fixed `h-14`, trailing action right-inset = card `px-6`, brand↔ribbon top band synced;
  - sidebar collapse toggle on the sidebar's right border at the ribbon↔card seam (`-right-[18px] top-[46px]`);
  - panel collapse toggle: header-at-top of the rail in collapsed mode, floating right-edge seam when expanded;
  - shadcn **base border reset** (`styles.css` `@layer base *,::before,::after { border-color: var(--border) }`) — keep; all borders must resolve to `--border`.
  Only after the shared shell matches, delete the fork.
- Keep the session's shared-`@app/ui` edits (`chevron-ribbon.tsx`, `workspace-layout.tsx`, `styles.css`) — they are correctly placed.
- Portal uses `layout="page"`; admin must adopt `layout="workspace"`.

---

## One-line summary for the executing session

**Phases 0–3 COMPLETE (reviewed, green, uncommitted):** P0 hygiene; P1 M8/F2/F3; P2 H1/H3/M1/M2/M4/M6/L4 + proxy; P3 F4/F6/F7 + T0 tenancy (organization) + F5 audit + F8 lifecycle. Decisions: D1 reversed→tenancy added; D2 tests deferred to Phase 5. **Remaining: Phase 4** (F9 Model A packaging — tied to the Jairus-plugin update — + F10 CI invariants) and **Phase 5** (DI test suite) — awaiting user direction on sequencing. **Outstanding (user, live Neon dev branch):** reset → provision A → db:migrate → provision B → db:seed → db:verify-rls (RLS + org bootstrap proofs) green; replay a Stripe event → 'duplicate'; eyeball /overview + roles list. Commits held until the user's review.
