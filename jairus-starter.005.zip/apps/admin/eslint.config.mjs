import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";
import { appBoundaries } from "@app/config/eslint-boundaries";

const eslintConfig = defineConfig([
  ...nextVitals,
  ...nextTs,
  // Admin may use dbAdminPort (guarded); never vendor SDKs or raw Drizzle clients.
  ...appBoundaries({ allowAdminPort: true }),
  // Override default ignores of eslint-config-next.
  globalIgnores([
    // Default ignores of eslint-config-next:
    ".next/**",
    "out/**",
    "build/**",
    "next-env.d.ts",
  ]),
]);

export default eslintConfig;
