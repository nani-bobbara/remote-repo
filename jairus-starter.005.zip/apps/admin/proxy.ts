import { createSessionProxy } from "@app/auth/edge"

// Outer bounce for signed-out requests, so a route added outside the `(app)`
// group is closed by default. `(app)/layout.tsx` checks `admin:access`.
export const proxy = createSessionProxy()

export const config = {
  // Password recovery is reached by definition while signed out, so those
  // routes are exempt alongside sign-in. The root route is exempt too: it
  // renders its own redirect and the "Unknown user" denial for non-staff.
  matcher: [
    "/((?!sign-in|forgot-password|reset-password|api/auth|_next/static|_next/image|favicon.ico|manifest.webmanifest|$).*)",
  ],
}
