"use client"

import { useEffect, useState } from "react"
import { Copy, Palette, RotateCcw } from "lucide-react"
import {
  Button,
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  FieldLabel,
  InfoPanel,
  Input,
  Label,
  NativeSelect,
  PALETTE_LIST,
  toast,
} from "@app/ui"

type Brand = {
  name: string
  tagline: string
  description: string
  palette: string
}

/**
 * Branding preview. Does not persist — branding is compiled from
 * packages/config/src/brand.ts, so this emits the config to paste instead of
 * pretending to save. The palette preview is real: setting `data-palette` on
 * <html> repaints the app, no server round-trip.
 */
export function BrandingConfigs({ current }: { current: Brand }) {
  const [palette, setPalette] = useState(current.palette)
  const [name, setName] = useState(current.name)
  const [tagline, setTagline] = useState(current.tagline)
  const [description, setDescription] = useState(current.description)

  useEffect(() => {
    document.documentElement.setAttribute("data-palette", palette)
  }, [palette])

  // Restore on unmount, or the preview leaks into every other page.
  useEffect(() => {
    const saved = current.palette
    return () => {
      document.documentElement.setAttribute("data-palette", saved)
    }
  }, [current.palette])

  const dirty =
    palette !== current.palette ||
    name !== current.name ||
    tagline !== current.tagline ||
    description !== current.description

  const snippet = [
    `  name: ${JSON.stringify(name)},`,
    `  tagline: ${JSON.stringify(tagline)},`,
    `  description:`,
    `    ${JSON.stringify(description)},`,
    `  palette: ${JSON.stringify(palette)},`,
  ].join("\n")

  async function copy() {
    try {
      await navigator.clipboard.writeText(snippet)
      toast.success("Config copied — paste into packages/config/src/brand.ts")
    } catch {
      toast.error("Clipboard unavailable — select the text and copy manually")
    }
  }

  function reset() {
    setPalette(current.palette)
    setName(current.name)
    setTagline(current.tagline)
    setDescription(current.description)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Palette className="text-primary size-4" /> Branding Configs
        </CardTitle>
        <CardDescription>
          Preview the product name, marketing copy and theme palette. Selecting a palette repaints
          this app immediately so you can judge it in place.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        <InfoPanel>
          <span className="text-foreground font-medium">Nothing here is saved.</span> Branding is
          compiled from <code className="text-xs">packages/config/src/brand.ts</code>. Copy the
          config below, paste it there and redeploy. Leaving this page restores the current palette.
        </InfoPanel>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="grid gap-2">
            <Label htmlFor="brand-palette">Theme palette</Label>
            <NativeSelect
              id="brand-palette"
              value={palette}
              onChange={(e) => setPalette(e.target.value)}
            >
              {PALETTE_LIST.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.label}
                </option>
              ))}
            </NativeSelect>
            <p className="text-muted-foreground min-h-10 text-xs leading-5">
              {PALETTE_LIST.find((p) => p.id === palette)?.description}
            </p>
          </div>
          <div />
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="grid gap-2">
            <Label htmlFor="brand-name">Product name</Label>
            <Input id="brand-name" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="brand-tagline">Tagline</Label>
            <Input id="brand-tagline" value={tagline} onChange={(e) => setTagline(e.target.value)} />
          </div>
        </div>

        <div className="grid gap-2">
          <Label htmlFor="brand-description">Description</Label>
          <Input
            id="brand-description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <FieldLabel>
            Preview
          </FieldLabel>
          <div className="bg-background rounded-lg border p-4">
            <div className="flex items-center gap-2 border-b pb-3">
              <span className="bg-primary text-primary-foreground grid size-6 place-items-center rounded text-[11px] font-bold">
                {(name.trim()[0] ?? "?").toUpperCase()}
              </span>
              <span className="font-semibold">{name || "Untitled"}</span>
              <span className="text-subtle-foreground text-xs">Admin</span>
            </div>
            <p className="pt-3 text-lg font-semibold">{tagline || "—"}</p>
            <p className="text-muted-foreground text-sm">{description || "—"}</p>
          </div>
        </div>

        <div className="space-y-2">
          <FieldLabel>
            Resulting config
          </FieldLabel>
          <pre className="bg-muted custom-scrollbar overflow-x-auto rounded-md p-3 text-xs leading-6">
            {snippet}
          </pre>
          <div className="flex gap-2">
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={copy}
              disabled={!dirty}
              title="Copy config"
              aria-label="Copy config"
            >
              <Copy />
            </Button>
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={reset}
              disabled={!dirty}
              title="Reset changes"
              aria-label="Reset changes"
            >
              <RotateCcw />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
