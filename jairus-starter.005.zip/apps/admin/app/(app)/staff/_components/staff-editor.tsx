"use client"

import { useState } from "react"
import { CheckCircle2, Clock, XCircle } from "lucide-react"
import { userStatus, type User, type UserStatus } from "@app/domain"
import {
  EditorHeader,
  FieldLabel,
  Input,
  OptionGrid,
  toInitials,
  useEditMode,
  type GridOption,
} from "@app/ui"
import { setUserRole } from "../actions"

/** The User fields the editor needs — derived from the domain, not re-declared. */
type StaffMember = Pick<User, "id" | "email" | "name" | "role" | "emailVerified" | "banned">

const STATUS_OPTIONS: GridOption[] = [
  { value: "active", label: "Active", icon: <CheckCircle2 />, tone: "success" },
  { value: "inactive", label: "Inactive", icon: <XCircle /> },
  { value: "invited", label: "Invited", icon: <Clock /> },
]

export function StaffEditor({
  member,
  roles,
  canWrite,
}: {
  member: StaffMember
  roles: { name: string; label: string }[]
  canWrite: boolean
}) {
  const [role, setRole] = useState(member.role)
  const status: UserStatus = userStatus(member)

  const dirty = role !== member.role
  const roleOptions: GridOption[] = roles.map((r) => ({ value: r.name, label: r.label }))

  const { mode } = useEditMode({
    canWrite,
    dirty,
    onSave: () => setUserRole(member.id, role),
    onReset: () => setRole(member.role),
    successMessage: "Member updated",
    saveLabel: "Save member",
    editLabel: "Edit member",
  })
  const readOnly = !canWrite || mode === "display"

  return (
    <div className="space-y-7 p-6">
      <EditorHeader
        initials={toInitials(member.name?.trim() || member.email)}
        title={member.name ?? member.email}
        subtitle={member.email}
      />

      <div className="space-y-2">
        <FieldLabel>
          Display name
        </FieldLabel>
        {/* Read-only: no setName write path for staff yet. */}
        <Input value={member.name ?? ""} readOnly disabled aria-label="Display name" />
      </div>

      <div className="space-y-2">
        <FieldLabel>Role</FieldLabel>
        <OptionGrid
          label="Role"
          options={roleOptions}
          value={[role]}
          onChange={(next) => setRole(next[0] ?? role)}
          columns={4}
          disabled={readOnly}
        />
      </div>

      <div className="space-y-2">
        <FieldLabel>Status</FieldLabel>
        {/* Derived from emailVerified/banned — read-only until a setBanned port method exists. */}
        <OptionGrid label="Status" options={STATUS_OPTIONS} value={[status]} columns={3} disabled />
      </div>
    </div>
  )
}
