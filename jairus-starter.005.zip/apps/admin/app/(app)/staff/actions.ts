"use server"

import { revalidatePath } from "next/cache"
import { actionLimit, requirePermission, auth } from "@app/auth"
import { can, PERMISSIONS } from "@app/domain"
import { dbAdminPort, dbPort } from "@app/adapters/db"
import { auditStaff } from "../_lib/audit"

/** A filtered dropdown is not a boundary: these actions are reachable directly,
 *  so the role is re-checked here. */
async function requireStaffRole(roleName: string): Promise<{ error?: string }> {
  const role = await dbPort.roles.getByName(roleName)
  if (!role) return { error: "That role no longer exists" }
  if (!can(role, PERMISSIONS.ADMIN_ACCESS)) {
    return { error: `${role.label} has no admin access — it is not a staff role` }
  }
  return {}
}

// Invite/create a staff user: create the account, then assign the chosen role.
export async function createStaff(input: {
  email: string
  name: string
  password: string
  role: string
}): Promise<{ error?: string }> {
  const session = await requirePermission(PERMISSIONS.STAFF_WRITE)
  const limited = await actionLimit(session)
  if (limited) return { error: limited }
  const roleCheck = await requireStaffRole(input.role)
  if (roleCheck.error) return roleCheck
  try {
    await auth.api.signUpEmail({
      body: { email: input.email, password: input.password, name: input.name },
    })
    const created = await dbAdminPort.users.findByEmail(input.email)
    if (created) {
      await dbAdminPort.users.setRole(created.id, input.role)
      await auditStaff(session, { action: "staff.created", targetType: "user", targetId: created.id, metadata: { role: input.role } })
    }
  } catch (e) {
    return { error: e instanceof Error ? e.message : "Could not create staff user" }
  }
  revalidatePath("/staff")
  return {}
}

/** Both ends are checked: the target must already be staff, and the new role
 *  must be one too — demoting into the portal would drop them out of the only
 *  screen that can edit them. */
export async function setUserRole(userId: string, role: string): Promise<{ error?: string }> {
  const session = await requirePermission(PERMISSIONS.STAFF_WRITE)
  const limited = await actionLimit(session)
  if (limited) return { error: limited }

  const target = await dbAdminPort.users.findById(userId)
  if (!target) return { error: "User not found" }
  const currentCheck = await requireStaffRole(target.role)
  if (currentCheck.error) return { error: "That user is not staff and cannot be edited here" }

  const roleCheck = await requireStaffRole(role)
  if (roleCheck.error) return roleCheck

  try {
    await dbAdminPort.users.setRole(userId, role)
    await auditStaff(session, { action: "staff.role_changed", targetType: "user", targetId: userId, metadata: { before: target.role, after: role } })
  } catch (e) {
    return { error: e instanceof Error ? e.message : "Could not update role" }
  }
  revalidatePath("/staff")
  return {}
}
