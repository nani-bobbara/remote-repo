import { requirePermission } from "@app/auth"
import { PERMISSIONS } from "@app/domain"
import { dbAdminPort } from "@app/adapters/db"
import { ScrollText } from "lucide-react"
import { ContentPane, PageShell, WorkspaceLayout } from "@app/ui"

export const dynamic = "force-dynamic"

// Read-only view of the audit trail (F5). dbAdminPort reads every org's rows,
// so it is gated by its own permission. Newest 200 only — no filters yet.
export default async function AuditPage() {
  await requirePermission(PERMISSIONS.AUDIT_READ)
  const rows = await dbAdminPort.audit.listRecent(200)

  return (
    <PageShell>
      <WorkspaceLayout cardIcon={<ScrollText />} cardTitle="Audit log" cardSubtitle="The 200 most recent events.">
        <ContentPane>
          {rows.length === 0 ? (
            <p className="text-muted-foreground text-sm">No events recorded yet.</p>
          ) : (
            <table className="w-full text-sm">
              <thead className="text-muted-foreground text-left">
                <tr>
                  <th className="py-2 pr-4 font-medium">When</th>
                  <th className="py-2 pr-4 font-medium">Actor</th>
                  <th className="py-2 pr-4 font-medium">Action</th>
                  <th className="py-2 pr-4 font-medium">Target</th>
                  <th className="py-2 font-medium">Org</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} className="border-t">
                    <td className="py-2 pr-4 whitespace-nowrap">{r.createdAt.toISOString().replace("T", " ").slice(0, 19)}</td>
                    <td className="py-2 pr-4">{r.actorKind}{r.actorUserId ? ` · ${r.actorUserId.slice(0, 8)}…` : ""}</td>
                    <td className="py-2 pr-4 font-mono">{r.action}</td>
                    <td className="py-2 pr-4">{r.targetType}{r.targetId ? ` · ${r.targetId}` : ""}</td>
                    <td className="py-2">{r.orgId ? `${r.orgId.slice(0, 8)}…` : "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </ContentPane>
      </WorkspaceLayout>
    </PageShell>
  )
}
