"use client"

import { useState } from "react"
import { Badge, EditorHeader, FieldLabel, InfoPanel, Input, OptionGrid, useEditMode } from "@app/ui"
import { saveRole } from "../actions"

import type { PermissionDef, RoleDef } from "@app/domain"

export function PermissionEditor({
  role,
  catalog,
  canWrite,
}: {
  role: RoleDef
  catalog: PermissionDef[]
  canWrite: boolean
}) {
  const editable = canWrite && !role.isSystem
  // fullAccess is its own column now, not a '*' entry smuggled into the list.
  const fullAccess = role.fullAccess
  const originalPerms = role.permissions

  const [label, setLabel] = useState(role.label)
  const [description, setDescription] = useState(role.description ?? "")
  const [selected, setSelected] = useState<Set<string>>(new Set(originalPerms))

  // A role can still hold a key that has since been deleted from the catalog.
  // Surface it as an orphan rather than silently dropping it on the next save.
  const byKey = new Map(catalog.map((p) => [p.key, p]))
  const orphans: PermissionDef[] = originalPerms
    .filter((p) => !byKey.has(p))
    .map((p) => ({
      key: p,
      label: p,
      description: "no longer in the catalog",
      resource: "orphaned",
      isSystem: false,
    }))

  const groups = new Map<string, PermissionDef[]>()
  for (const def of [...catalog, ...orphans]) {
    const list = groups.get(def.resource) ?? []
    list.push(def)
    groups.set(def.resource, list)
  }
  const groupEntries = [...groups.entries()].sort(([a], [b]) => a.localeCompare(b))

  const dirty =
    label !== role.label ||
    description !== (role.description ?? "") ||
    selected.size !== originalPerms.length ||
    originalPerms.some((p) => !selected.has(p))

  function reset() {
    setLabel(role.label)
    setDescription(role.description ?? "")
    setSelected(new Set(originalPerms))
  }

  // Drive the shared header toolbar: Edit is disabled for protected system /
  // full-access roles.
  const { mode } = useEditMode({
    canWrite,
    dirty,
    onSave: () => saveRole({ name: role.name, label, description, permissions: [...selected] }),
    onReset: reset,
    successMessage: "Role saved",
    saveLabel: "Save role",
    editLabel: !editable || fullAccess ? "System role — read-only" : "Edit role",
    editDisabled: !editable || fullAccess,
  })
  const readOnly = !editable || mode === "display"

  return (
    <div className="space-y-7 p-6">
      <EditorHeader
        initials={(label || role.name).slice(0, 2).toUpperCase()}
        title={label || role.name}
        badges={
          <>
            {role.isSystem ? <Badge variant="secondary">system</Badge> : null}
            {fullAccess ? <Badge variant="outline">full access</Badge> : null}
          </>
        }
        subtitle={
          <>
            <code className="text-xs">{role.name}</code>
            {description ? ` · ${description}` : null}
          </>
        }
      />

      {fullAccess ? (
        <InfoPanel>
          <span className="text-foreground font-medium">This role grants everything.</span> Full
          access is a flag on the role, not a permission in the matrix, so it cannot be assigned or
          revoked here — and it covers permissions added in future releases automatically.
        </InfoPanel>
      ) : (
        <>
          {!role.isSystem ? (
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <FieldLabel>
                  Display name
                </FieldLabel>
                <Input value={label} onChange={(e) => setLabel(e.target.value)} disabled={readOnly} />
              </div>
              <div className="space-y-2">
                <FieldLabel>
                  Description
                </FieldLabel>
                <Input
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  disabled={readOnly}
                />
              </div>
            </div>
          ) : null}
          <div className="space-y-5">
            {groupEntries.map(([resource, defs]) => (
              <div key={resource} className="space-y-2">
                <FieldLabel>
                  {resource}
                </FieldLabel>
                  <OptionGrid
                    label={resource}
                    multiple
                    showCheckbox
                    columns={3}
                    options={defs.map((d) => ({
                      value: d.key,
                      label: d.label,
                      description: d.isSystem ? (d.description ?? undefined) : "not yet enforced",
                    }))}
                    value={defs.filter((d) => selected.has(d.key)).map((d) => d.key)}
                    onChange={(next) => {
                      // Each grid owns only its own group's keys, so merge with
                      // the rest of the selection instead of replacing it.
                      const owned = new Set(defs.map((d) => d.key))
                      setSelected((prev) => {
                        const merged = new Set([...prev].filter((k) => !owned.has(k)))
                        for (const k of next) merged.add(k)
                        return merged
                      })
                    }}
                    disabled={readOnly}
                  />
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
