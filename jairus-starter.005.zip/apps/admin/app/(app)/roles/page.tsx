import { getSession } from "@app/auth"
import { can, PERMISSIONS } from "@app/domain"
import { dbPort } from "@app/adapters/db"
import { ShieldCheck } from "lucide-react"
import { Badge, InitialsAvatar, ListWorkspace } from "@app/ui"
import { RefreshButton } from "../_components/refresh-button"
import { NewRoleForm } from "./_components/new-role-form"
import { PermissionEditor } from "./_components/permission-editor"

export const dynamic = "force-dynamic"

export default async function RolesPage({
  searchParams,
}: {
  searchParams: Promise<{ name?: string; mode?: string }>
}) {
  const session = await getSession()
  if (!session || !can(session, PERMISSIONS.ROLES_READ)) {
    return <p className="text-muted-foreground text-sm">You don&apos;t have access to role control.</p>
  }
  const canWrite = can(session, PERMISSIONS.ROLES_WRITE)
  const roles = await dbPort.roles.list()
  // The permission vocabulary is data now, not a code constant — see
  // /permissions for where it is curated.
  const catalog = await dbPort.permissions.list()
  const { name, mode } = await searchParams
  const creating = mode === "new" && canWrite
  const selected = creating ? null : (roles.find((r) => r.name === name) ?? roles[0] ?? null)

  return (
    <ListWorkspace
      icon={<ShieldCheck />}
      title="Role Control Engine"
      subtitle="Define access levels, custom roles, and permission hierarchies."
      actions={<RefreshButton />}
      create={canWrite ? { href: "/roles?mode=new", label: "New role" } : null}
      searchPlaceholder="Search roles…"
      items={roles.map((r) => ({
        id: r.name,
        label: r.label,
        icon: <InitialsAvatar label={r.label} />,
        // Same density as the Permissions list: the stable id as meta,
        // and a badge for the rows that behave differently.
        meta: r.name,
        badge: r.fullAccess ? (
          <Badge variant="outline">full access</Badge>
        ) : r.isSystem ? (
          <Badge variant="secondary">system</Badge>
        ) : null,
        href: `/roles?name=${r.name}`,
        active: selected?.name === r.name,
      }))}
      emptyMessage="No roles yet."
      creating={
        creating
          ? { title: "New role", description: "Create a custom role, then set its permissions.", form: <NewRoleForm /> }
          : null
      }
      detail={
        selected ? (
          <PermissionEditor key={selected.name} role={selected} catalog={catalog} canWrite={canWrite} />
        ) : null
      }
      emptyTitle="No roles yet"
      emptyDescription="Create a role from the header to begin."
    />
  )
}
