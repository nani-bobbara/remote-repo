"use server"

import { revalidatePath } from "next/cache"
import { actionLimit, requirePermission } from "@app/auth"
import { PERMISSIONS, slugify } from "@app/domain"
import { dbPort } from "@app/adapters/db"
import { auditStaff } from "../_lib/audit"

// Returns the slugged role id on success so the caller navigates to the row it
// actually created. The client must NOT re-derive the slug (see slugify).
export async function createRole(input: {
  name: string
  label: string
}): Promise<{ error?: string; name?: string }> {
  const session = await requirePermission(PERMISSIONS.ROLES_WRITE)
  const limited = await actionLimit(session)
  if (limited) return { error: limited }
  const name = slugify(input.name)
  if (!name) return { error: "A role id is required" }
  if (await dbPort.roles.getByName(name)) return { error: "That role id already exists" }
  await dbPort.roles.upsert({
    name,
    label: input.label.trim() || name,
    description: null,
    permissions: [],
    // Superuser is never grantable through the admin UI — only the seed sets it.
    fullAccess: false,
    isSystem: false,
  })
  await auditStaff(session, { action: "role.created", targetType: "role", targetId: name })
  revalidatePath("/roles")
  return { name }
}

export async function saveRole(input: {
  name: string
  label: string
  description: string
  permissions: string[]
}): Promise<{ error?: string }> {
  const session = await requirePermission(PERMISSIONS.ROLES_WRITE)
  const limited = await actionLimit(session)
  if (limited) return { error: limited }
  const existing = await dbPort.roles.getByName(input.name)
  if (!existing) return { error: "Role not found" }
  if (existing.isSystem) return { error: "System roles can't be edited" }
  await dbPort.roles.upsert({
    name: input.name,
    label: input.label.trim() || input.name,
    description: input.description.trim() || null,
    permissions: input.permissions,
    // Preserved from the stored row, never taken from the client.
    fullAccess: existing.fullAccess,
    isSystem: false,
  })
  await auditStaff(session, {
    action: "role.saved", targetType: "role", targetId: input.name,
    metadata: { before: existing.permissions, after: input.permissions },
  })
  revalidatePath("/roles")
  return {}
}
