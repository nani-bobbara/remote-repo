"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Trash2 } from "lucide-react"
import {
  Badge,
  Button,
  EditorHeader,
  FieldLabel,
  InfoPanel,
  Input,
  toast,
  useEditMode,
} from "@app/ui"
import { deletePermission, savePermission } from "../actions"

import type { PermissionDef } from "@app/domain"

export function PermissionDetail({
  permission,
  canWrite,
}: {
  permission: PermissionDef
  canWrite: boolean
}) {
  const router = useRouter()
  const [label, setLabel] = useState(permission.label)
  const [description, setDescription] = useState(permission.description ?? "")
  const [resource, setResource] = useState(permission.resource)

  const dirty =
    label !== permission.label ||
    description !== (permission.description ?? "") ||
    resource !== permission.resource

  function reset() {
    setLabel(permission.label)
    setDescription(permission.description ?? "")
    setResource(permission.resource)
  }

  const { mode, pending, start } = useEditMode({
    canWrite,
    dirty,
    onSave: () => savePermission({ key: permission.key, label, description, resource }),
    onReset: reset,
    successMessage: "Permission saved",
    saveLabel: "Save permission",
    editLabel: "Edit permission",
  })
  const readOnly = !canWrite || mode === "display"

  function remove() {
    start(async () => {
      const res = await deletePermission(permission.key)
      if (res.error) {
        toast.error(res.error)
        return
      }
      toast.success("Permission deleted")
      router.push("/permissions")
    })
  }

  return (
    <div className="space-y-7 p-6">
      <EditorHeader
        initials={permission.resource.slice(0, 2).toUpperCase()}
        title={label || permission.key}
        badges={
          permission.isSystem ? (
            <Badge variant="secondary">enforced</Badge>
          ) : (
            <Badge variant="outline">not yet enforced</Badge>
          )
        }
        subtitle={
          <>
            <code className="text-xs">{permission.key}</code>
            {` · ${permission.resource}`}
          </>
        }
      />

      <InfoPanel>
        {permission.isSystem ? (
          <>
            <span className="text-foreground font-medium">A code path checks this key.</span> The
            key itself can&apos;t be changed or deleted, but its display name, description and
            grouping can — those are yours to curate and a redeploy will not overwrite them.
          </>
        ) : (
          <>
            <span className="text-foreground font-medium">Nothing enforces this key yet.</span> No
            code calls <code className="text-xs">can()</code> with it, so assigning it to a role
            grants nothing. It becomes live when a developer ships a check for it.
          </>
        )}
      </InfoPanel>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <FieldLabel>
            Display name
          </FieldLabel>
          <Input value={label} onChange={(e) => setLabel(e.target.value)} disabled={readOnly} />
        </div>
        <div className="space-y-2">
          <FieldLabel>
            Resource group
          </FieldLabel>
          <Input
            value={resource}
            onChange={(e) => setResource(e.target.value)}
            disabled={readOnly}
          />
        </div>
      </div>

      <div className="space-y-2">
        <FieldLabel>
          Description
        </FieldLabel>
        <Input
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          disabled={readOnly}
        />
      </div>

      {canWrite && !permission.isSystem ? (
        <div className="space-y-2">
          <FieldLabel>
            Danger zone
          </FieldLabel>
          <div className="border-destructive/30 bg-destructive/5 flex items-center justify-between gap-4 rounded-md border p-3">
            <p className="text-muted-foreground text-sm">
              Removes the key from the catalog. Refused while any role still holds it.
            </p>
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={remove}
              disabled={pending}
              title="Delete permission"
              aria-label="Delete permission"
            >
              <Trash2 />
            </Button>
          </div>
        </div>
      ) : null}
    </div>
  )
}
