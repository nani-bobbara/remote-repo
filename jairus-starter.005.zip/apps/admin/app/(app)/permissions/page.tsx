import { getSession } from "@app/auth"
import { can, PERMISSIONS } from "@app/domain"
import { dbPort } from "@app/adapters/db"
import { KeyRound } from "lucide-react"
import { Badge, InitialsAvatar, ListWorkspace } from "@app/ui"
import { RefreshButton } from "../_components/refresh-button"
import { NewPermissionForm } from "./_components/new-permission-form"
import { PermissionDetail } from "./_components/permission-detail"

export const dynamic = "force-dynamic"

export default async function PermissionsPage({
  searchParams,
}: {
  searchParams: Promise<{ key?: string; mode?: string }>
}) {
  const session = await getSession()
  if (!session || !can(session, PERMISSIONS.PERMISSIONS_READ)) {
    return <p className="text-muted-foreground text-sm">You don&apos;t have access to permissions.</p>
  }
  const canWrite = can(session, PERMISSIONS.PERMISSIONS_WRITE)
  const permissions = await dbPort.permissions.list()
  const { key, mode } = await searchParams
  const creating = mode === "new" && canWrite
  const selected = creating
    ? null
    : (permissions.find((p) => p.key === key) ?? permissions[0] ?? null)

  return (
    <ListWorkspace
      icon={<KeyRound />}
      title="Permission Catalog"
      subtitle="The vocabulary roles are built from. Enforcement ships in code."
      actions={<RefreshButton />}
      create={canWrite ? { href: "/permissions?mode=new", label: "New permission" } : null}
      searchPlaceholder="Search permissions…"
      items={permissions.map((p) => ({
        id: p.key,
        label: p.label,
        icon: <InitialsAvatar label={p.resource} />,
        meta: p.resource,
        // Enforcement status must be visible while scanning the list, not
        // only after clicking into a row.
        badge: p.isSystem ? null : <Badge variant="outline">not enforced</Badge>,
        href: `/permissions?key=${encodeURIComponent(p.key)}`,
        active: selected?.key === p.key,
      }))}
      emptyMessage="No permissions yet. Run the seed."
      creating={
        creating
          ? {
              title: "New permission",
              description: "Adds a key to the catalog so it can be assigned to roles.",
              form: <NewPermissionForm />,
            }
          : null
      }
      detail={
        selected ? <PermissionDetail key={selected.key} permission={selected} canWrite={canWrite} /> : null
      }
      emptyTitle="No permissions yet"
      emptyDescription="Run pnpm --filter @app/adapters seed:admin to populate the catalog."
    />
  )
}
