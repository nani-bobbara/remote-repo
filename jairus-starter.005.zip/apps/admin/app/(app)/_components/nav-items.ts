import { BarChart3, LayoutDashboard, Users, Shield, Settings2, Settings, Database, User, KeyRound, ScrollText } from "lucide-react"
import { PERMISSIONS } from "@app/domain"
import type { NavGroup } from "@app/ui"

/** Admin's gating field on top of the shared nav item shape. */
export type AdminNavExtra = { permission?: string } // hide unless the session has it

// Grouped operator-console nav, rendered by @app/ui's AppShell. Items with a
// permission are hidden for roles that lack it (see admin-shell's isVisible).
export const navGroups: NavGroup<AdminNavExtra>[] = [
  {
    id: "analytics",
    label: "Analytics",
    icon: BarChart3,
    items: [{ href: "/overview", label: "Overview", icon: LayoutDashboard }],
  },
  {
    id: "management",
    label: "Management",
    icon: Settings2,
    // Ordered by dependency, which is also the order you configure a fresh
    // install: permissions are the vocabulary, roles group them, staff are
    // assigned roles. Each item depends only on the ones above it. Listing
    // Role control before Permissions showed the group before its parts.
    items: [
      { href: "/system-setup", label: "System Setup", icon: Database, permission: PERMISSIONS.ADMIN_ACCESS },
      { href: "/permissions", label: "Permissions", icon: KeyRound, permission: PERMISSIONS.PERMISSIONS_READ },
      { href: "/roles", label: "Role control", icon: Shield, permission: PERMISSIONS.ROLES_READ },
      { href: "/staff", label: "Staff", icon: Users, permission: PERMISSIONS.STAFF_READ },
      { href: "/audit", label: "Audit log", icon: ScrollText, permission: PERMISSIONS.AUDIT_READ },
    ],
  },
  {
    id: "settings",
    label: "Settings",
    icon: Settings,
    items: [{ href: "/settings/profile", label: "Profile", icon: User }],
  },
]

// AppShell reads this config only through @app/ui's visibleGroups(), which
// applies the permission filter. Don't export a raw flattened list — it
// bypasses that and can leak a hidden destination.
