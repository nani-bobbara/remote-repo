"use client"

import { LogOut, Rocket } from "lucide-react"
import { SignOutButton } from "@app/auth/client"
import { brand } from "@app/config/brand"
import { can } from "@app/domain"
import { AppShell } from "@app/ui"
import { navGroups } from "./nav-items"

/** An object rather than a bare `string[]`: a full-access role carries an empty
 *  permission list, so filtering on the list alone would hide every item from
 *  it. Requiring both makes omitting the flag a type error. */
export type NavAccess = { permissions: string[]; fullAccess: boolean }

// Client wrapper over the shared AppShell (mirrors the portal's PortalShell).
// Admin uses the `workspace` layout — the chevron ribbon; the portal uses
// `page` — the classic header. Everything else is the same shared frame.
// The nav config holds icon components, which cannot cross from the server
// layout, so it is attached here.
export function AdminShell({
  email,
  role,
  access,
  children,
}: {
  email: string
  role: string
  access: NavAccess
  children: React.ReactNode
}) {
  return (
    <AppShell
      layout="workspace"
      groups={navGroups}
      isVisible={(item) => !item.permission || can(access, item.permission)}
      homeHref="/overview"
      brandName={brand.name}
      brandIcon={Rocket}
      actions={
        <SignOutButton redirectTo="/sign-in" size="icon" aria-label="Logout" title="Logout">
          <LogOut className="size-4" />
        </SignOutButton>
      }
      drawerFooter={
        <>
          <div className="mb-2 px-1">
            <p className="text-foreground truncate text-sm font-medium">{email}</p>
            <p className="text-muted-foreground truncate text-xs capitalize">{role.replace("_", " ")}</p>
          </div>
          <SignOutButton redirectTo="/sign-in" className="w-full justify-start gap-2">
            <LogOut className="size-4" />
            Logout
          </SignOutButton>
        </>
      }
    >
      {children}
    </AppShell>
  )
}
