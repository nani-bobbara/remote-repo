import { dbAdminPort } from "@app/adapters/db"
import type { AuditEvent, Session } from "@app/domain"

/** Record a staff action (F5). Call AFTER the guarded mutation succeeds, and
 *  whenever a screen reads a specific org's or user's data through
 *  dbAdminPort (cross-tenant access) — pass that org as `orgId`. */
export function auditStaff(
  session: Session,
  e: Pick<AuditEvent, "action" | "targetType" | "targetId"> & Partial<Pick<AuditEvent, "orgId" | "metadata">>,
): Promise<void> {
  return dbAdminPort.audit.record({ orgId: null, ...e, actorUserId: session.userId, actorKind: "staff" })
}
