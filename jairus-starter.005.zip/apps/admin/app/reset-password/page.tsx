import { Suspense } from "react"
import Link from "next/link"
import { ShieldCheck } from "lucide-react"
import { brand } from "@app/config/brand"
import { AuthLayout, Card, CardHeader, CardTitle, CardDescription, CardContent } from "@app/ui"
import { NewPasswordForm } from "../_components/new-password-form"

export default function ResetPasswordPage() {
  return (
    <AuthLayout
      heroIcon={<ShieldCheck className="size-8" />}
      heroTitle={brand.name}
      heroCaption="Admin console"
      title="Choose a new password"
      description="This signs out your other sessions."
    >
      <Card className="w-full shadow-sm">
        <CardHeader className="gap-2">
          <CardTitle>New password</CardTitle>
          <CardDescription>At least 8 characters.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4">
          {/* useSearchParams needs a Suspense boundary to keep the route
              from opting the whole page into client-side rendering. */}
          <Suspense fallback={null}>
            <NewPasswordForm />
          </Suspense>
          <Link href="/forgot-password" className="text-muted-foreground hover:text-foreground text-sm underline-offset-4 hover:underline">
            Request a new link
          </Link>
        </CardContent>
      </Card>
    </AuthLayout>
  )
}
