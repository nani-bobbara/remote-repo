"use client"

import { useEffect } from "react"
import Link from "next/link"
import { Button, StatusPage } from "@app/ui"

// Route-segment error boundary. The server already reported the error
// (instrumentation.ts → onRequestError); in production the browser gets a
// redacted error, so only the digest is shown — it matches the server log line.
export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error(error)
  }, [error])

  return (
    <StatusPage
      title="Something went wrong"
      description="An unexpected error stopped this page from loading. Try again, or come back in a moment."
      footnote={error.digest ? `Reference: ${error.digest}` : undefined}
    >
      <Button onClick={reset}>Try again</Button>
      <Button variant="outline" asChild>
        <Link href="/overview">Go home</Link>
      </Button>
    </StatusPage>
  )
}
