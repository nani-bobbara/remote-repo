export const dynamic = "force-dynamic"

import { redirect } from "next/navigation"
import { getSession } from "@app/auth"
import { can, PERMISSIONS } from "@app/domain"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@app/ui"
import { SignOutButton } from "@app/auth/client"

export default async function Home() {
  const session = await getSession()
  if (!session) redirect("/sign-in")

  // Staff → the console. Everyone else → generic denial (don't reveal validity).
  if (can(session, PERMISSIONS.ADMIN_ACCESS)) redirect("/overview")

  return (
    <main className="mx-auto flex min-h-dvh max-w-2xl flex-col items-center justify-center gap-6 p-8">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Unknown user</CardTitle>
          <CardDescription>This account isn&apos;t recognized for the admin app.</CardDescription>
        </CardHeader>
        <CardContent>
          <SignOutButton />
        </CardContent>
      </Card>
    </main>
  )
}
