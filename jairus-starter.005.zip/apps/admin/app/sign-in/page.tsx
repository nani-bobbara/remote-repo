import Link from "next/link"
import { ShieldCheck } from "lucide-react"
import { brand } from "@app/config/brand"
import { AuthLayout, Card, CardHeader, CardTitle, CardDescription, CardContent } from "@app/ui"
import { SignInForm } from "../_components/sign-in-form"

export default function SignInPage() {
  return (
    <AuthLayout
      heroIcon={<ShieldCheck className="size-8" />}
      heroTitle={brand.name}
      heroCaption="Admin console"
      title="Welcome back"
      description="Sign in to manage your workspace."
    >
      <Card className="w-full shadow-sm">
        <CardHeader className="gap-2">
          <CardTitle>Admin sign in</CardTitle>
          <CardDescription>Use your staff account to continue.</CardDescription>
        </CardHeader>
        <CardContent>
          <SignInForm />
          <p className="text-muted-foreground mt-4 text-center text-sm">
            <Link href="/forgot-password" className="text-foreground underline underline-offset-4">
              Forgot password?
            </Link>
          </p>
        </CardContent>
      </Card>
    </AuthLayout>
  )
}
