import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { brand } from "@app/config/brand";
import { Toaster } from "@app/ui";
import { THEME_INIT_SCRIPT } from "@app/ui/lib/theme-script";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: `${brand.name} Admin`,
  description: `${brand.name} back-office`,
  appleWebApp: { capable: true, title: `${brand.name} Admin`, statusBarStyle: "default" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#0a0a0a" },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
      // Selects the design-token palette from @app/ui themes/. Rendered on the
      // server, so it is correct on first paint with no script — unlike light/dark
      // below, which is a per-user preference the server cannot know.
      data-palette={brand.palette}
      // The inline script below mutates this element's class list before React
      // hydrates, which is a deliberate mismatch.
      suppressHydrationWarning
    >
      <head>
        {/* Applies the saved/system theme before first paint — prevents a flash
            of the wrong theme. Must stay inline and render-blocking. */}
        <script dangerouslySetInnerHTML={{ __html: THEME_INIT_SCRIPT }} />
      </head>
      <body className="min-h-dvh">
        {children}
        <Toaster />
      </body>
    </html>
  );
}
