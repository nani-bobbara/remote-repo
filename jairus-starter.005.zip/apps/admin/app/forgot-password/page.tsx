import Link from "next/link"
import { ShieldCheck } from "lucide-react"
import { brand } from "@app/config/brand"
import { AuthLayout, Card, CardHeader, CardTitle, CardDescription, CardContent } from "@app/ui"
import { RequestResetForm } from "../_components/request-reset-form"

export default function ForgotPasswordPage() {
  return (
    <AuthLayout
      heroIcon={<ShieldCheck className="size-8" />}
      heroTitle={brand.name}
      heroCaption="Admin console"
      title="Forgot your password?"
      description="We'll email you a link to set a new one."
    >
      <Card className="w-full shadow-sm">
        <CardHeader className="gap-2">
          <CardTitle>Reset password</CardTitle>
          <CardDescription>Enter the email on your staff account.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4">
          <RequestResetForm />
          <Link href="/sign-in" className="text-muted-foreground hover:text-foreground text-sm underline-offset-4 hover:underline">
            Back to sign in
          </Link>
        </CardContent>
      </Card>
    </AuthLayout>
  )
}
