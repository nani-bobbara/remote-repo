"use client"

import { Button, StatusPage } from "@app/ui"
import "./globals.css"

// Last-resort boundary: replaces the root layout when it throws, so it renders
// its own <html>/<body>. Kept dependency-light — the layout may be what broke.
export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <html lang="en">
      <body className="min-h-dvh antialiased">
        <StatusPage
          title="Something went wrong"
          description="The application failed to load. Try again in a moment."
          footnote={error.digest ? `Reference: ${error.digest}` : undefined}
        >
          <Button onClick={reset}>Try again</Button>
        </StatusPage>
      </body>
    </html>
  )
}
