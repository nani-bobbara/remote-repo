import Link from "next/link"
import { Button, StatusPage } from "@app/ui"

export default function NotFound() {
  return (
    <StatusPage title="Page not found" description="This page doesn't exist or has moved.">
      <Button asChild>
        <Link href="/">Go home</Link>
      </Button>
    </StatusPage>
  )
}
