import type { NextConfig } from "next";
import { securityHeaders } from "@app/config/security-headers";

const nextConfig: NextConfig = {
  transpilePackages: ["@app/ui", "@app/auth", "@app/adapters", "@app/domain", "@app/config"],
  headers: securityHeaders,
};

export default nextConfig;
