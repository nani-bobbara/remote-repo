import type { Instrumentation } from 'next'

// OpenTelemetry bootstrap — Next.js auto-loads this file on server start.
// Flag-gated: OBSERVABILITY_ENABLED=false emits nothing (zero overhead).
// Vendor-neutral OTLP — point OTEL_EXPORTER_OTLP_ENDPOINT at any collector
// (Grafana, Honeycomb, a local otel-collector). No backend lock-in.
export async function register() {
  // Fail-fast config check at server boot (Node runtime; the proxy
  // needs no secrets). Reports every missing/invalid variable at once.
  // The portal takes payments and must NOT require the owner URL.
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    const { assertEnv } = await import('@app/config/env')
    assertEnv(['db', 'auth', 'billing', 'email', 'errors'])
  }

  if (process.env.OBSERVABILITY_ENABLED !== 'true') return
  const { registerOTel } = await import('@vercel/otel')
  registerOTel({ serviceName: process.env.OTEL_SERVICE_NAME ?? 'portal' })
}

// Every uncaught server error (render, route handler, server action, proxy)
// goes to the error reporter: a structured log line, plus Sentry when
// SENTRY_DSN is set. Node runtime only — the reporter reads server env.
export const onRequestError: Instrumentation.onRequestError = async (err, request, context) => {
  if (process.env.NEXT_RUNTIME !== 'nodejs') return
  const { errorReporter } = await import('@app/adapters/errors')
  errorReporter.capture(err, {
    method: request.method,
    path: request.path,
    route: context.routePath,
    routeType: context.routeType,
    digest: (err as { digest?: string }).digest,
  })
}
