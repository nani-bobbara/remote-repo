import { createSessionProxy } from "@app/auth/edge"

// Outer bounce for signed-out requests. `(app)/layout.tsx` resolves the real
// session and blocks staff accounts.
export const proxy = createSessionProxy()

export const config = {
  // Membership area only; landing, auth pages and the Stripe webhook are public.
  matcher: ["/dashboard/:path*", "/profile/:path*", "/settings/:path*"],
}
