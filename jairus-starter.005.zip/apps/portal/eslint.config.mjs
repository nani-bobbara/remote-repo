import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";
import { appBoundaries } from "@app/config/eslint-boundaries";

const eslintConfig = defineConfig([
  ...nextVitals,
  ...nextTs,
  // Portal: dbPort.withUser/withOrg only — no dbAdminPort, vendor SDKs or
  // raw clients; systemDbPort only in the Stripe webhook route.
  ...appBoundaries({ allowAdminPort: false, systemPortFiles: ["app/api/stripe/webhook/route.ts"] }),
  // Override default ignores of eslint-config-next.
  globalIgnores([
    // Default ignores of eslint-config-next:
    ".next/**",
    "out/**",
    "build/**",
    "next-env.d.ts",
  ]),
]);

export default eslintConfig;
