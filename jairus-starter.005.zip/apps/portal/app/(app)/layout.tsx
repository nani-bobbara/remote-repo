import { redirect } from "next/navigation"
import { getSession, requireOrg } from "@app/auth"
import { can, PERMISSIONS } from "@app/domain"
import { PortalShell } from "./_components/portal-shell"
import { StaffBlocked } from "./_components/staff-blocked"
import { getPlan } from "./_lib/get-plan"

export const dynamic = "force-dynamic"

// Auth gate for the whole membership area.
export default async function AppLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const session = await getSession()
  if (!session) redirect("/sign-in")

  // Staff/admin accounts belong to the admin app only — never the customer portal.
  if (can(session, PERMISSIONS.ADMIN_ACCESS)) {
    return <StaffBlocked email={session.email} />
  }

  const { organization } = await requireOrg()
  const plan = await getPlan(session.userId, organization.id)

  return (
    <PortalShell email={session.email} plan={plan}>
      {children}
    </PortalShell>
  )
}
