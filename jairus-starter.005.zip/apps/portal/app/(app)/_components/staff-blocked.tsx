import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@app/ui"
import { SignOutButton } from "@app/auth/client"

// Shown when an admin/staff account signs into the customer portal. Staff belong
// to the admin app only; we don't let them use the portal member area.
export function StaffBlocked({ email }: { email: string }) {
  return (
    <main className="flex min-h-dvh items-center justify-center px-6">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Admin account</CardTitle>
          <CardDescription>
            {email} is an admin account. Please use the admin app — this customer portal
            is for member accounts only.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <SignOutButton />
        </CardContent>
      </Card>
    </main>
  )
}
