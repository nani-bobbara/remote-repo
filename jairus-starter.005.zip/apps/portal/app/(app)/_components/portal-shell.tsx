"use client"

import { Rocket } from "lucide-react"
import { brand } from "@app/config/brand"
import { AppShell, Badge } from "@app/ui"
import { navGroups } from "./nav-items"
import { UserMenu } from "./user-menu"

// Client wrapper: the nav config holds icon components, which cannot be passed
// down from the server layout, so the menu is attached here.
export function PortalShell({ email, plan, children }: { email: string; plan: string; children: React.ReactNode }) {
  return (
    <AppShell
      layout="page"
      groups={navGroups}
      homeHref="/dashboard"
      brandName={brand.name}
      brandIcon={Rocket}
      actions={
        <>
          <Badge variant="secondary" className="hidden capitalize sm:inline-flex">
            {plan}
          </Badge>
          <UserMenu email={email} />
        </>
      }
    >
      {children}
    </AppShell>
  )
}
