import { CircleUser, LayoutDashboard, Settings, User } from "lucide-react"
import type { NavGroup } from "@app/ui"

// Grouped member nav, rendered by AppShell. Add a group per domain as features
// are built; items can later be gated by plan via AppShell's isVisible.
export const navGroups: NavGroup[] = [
  {
    id: "overview",
    label: "Overview",
    icon: LayoutDashboard,
    items: [{ href: "/dashboard", label: "Dashboard", icon: LayoutDashboard }],
  },
  {
    id: "account",
    label: "Account",
    icon: CircleUser,
    items: [
      { href: "/profile", label: "Profile", icon: User },
      { href: "/settings", label: "Settings", icon: Settings },
    ],
  },
]
