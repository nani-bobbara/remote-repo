import { cache } from "react"
import { dbPort } from "@app/adapters/db"
import { makeGetSubscription } from "@app/application"
import type { PlanTier } from "@app/domain"
import { DEFAULT_PLAN } from "@app/config/plans"

// The plan belongs to the ORGANIZATION. Read through withOrg, which re-checks
// membership in the transaction. Cached per request: the shell layout and the
// page both read it, but it only queries once per render.
export const getPlan = cache(async (userId: string, orgId: string): Promise<PlanTier> => {
  const sub = await makeGetSubscription(dbPort)(userId, orgId)
  return sub?.tier ?? DEFAULT_PLAN
})
