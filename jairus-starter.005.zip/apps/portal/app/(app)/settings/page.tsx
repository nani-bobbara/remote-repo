import { requireOrg } from "@app/auth"
import { canInOrg } from "@app/domain"
import { PLANS, upgradesFrom } from "@app/config/plans"
import {
  Badge,
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
} from "@app/ui"
import { UpgradeButton } from "./_components/upgrade-button"
import { DangerZone } from "./_components/danger-zone"
import { getPlan } from "../_lib/get-plan"

export const dynamic = "force-dynamic"

export default async function SettingsPage({
  searchParams,
}: {
  searchParams: Promise<{ upgraded?: string }>
}) {
  const { session, organization, role } = await requireOrg()
  const plan = await getPlan(session.userId, organization.id)
  // Billing is the organization owner's call; everyone else sees no plan card.
  const canBill = canInOrg(role, "billing:manage")
  const { upgraded } = await searchParams

  const upgrades = upgradesFrom(plan)

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">Account and billing.</p>
      </div>

      {upgraded ? (
        <div className="border-primary/40 bg-primary/5 rounded-md border px-4 py-3 text-sm">
          Subscription updated — thanks! It may take a moment to reflect.
        </div>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle>Account</CardTitle>
          <CardDescription>Your sign-in email.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm">{session.email}</p>
        </CardContent>
      </Card>

      {canBill ? (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              Plan
              <Badge variant="secondary">{PLANS[plan].label}</Badge>
            </CardTitle>
            <CardDescription>Manage {organization.name}&apos;s subscription.</CardDescription>
          </CardHeader>
          <CardFooter className="gap-3">
            {upgrades.length > 0 ? (
              upgrades.map((t) => (
                <UpgradeButton key={t} tier={t} label={`Upgrade to ${PLANS[t].label}`} />
              ))
            ) : (
              <p className="text-muted-foreground text-sm">You&apos;re on the top plan.</p>
            )}
          </CardFooter>
        </Card>
      ) : null}

      <Card className="border-destructive/40">
        <CardHeader>
          <CardTitle>Danger zone</CardTitle>
          <CardDescription>Export or permanently delete your data.</CardDescription>
        </CardHeader>
        <CardFooter>
          <DangerZone isOwner={canInOrg(role, "org:delete")} orgName={organization.name} />
        </CardFooter>
      </Card>
    </div>
  )
}
