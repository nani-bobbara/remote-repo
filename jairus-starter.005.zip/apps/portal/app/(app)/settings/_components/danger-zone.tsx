"use client"

import { useTransition } from "react"
import { Button, toast } from "@app/ui"
import { deleteAccount, deleteOrganization, exportOrgData } from "../actions"

// Owner-only controls are hidden for other roles; every action re-checks on
// the server. window.confirm is the confirmation step — irreversible actions
// never run on a single click.
export function DangerZone({ isOwner, orgName }: { isOwner: boolean; orgName: string }) {
  const [pending, start] = useTransition()

  const onExport = () =>
    start(async () => {
      const res = await exportOrgData()
      if ("error" in res) return void toast.error(res.error)
      const url = URL.createObjectURL(new Blob([res.json], { type: "application/json" }))
      const a = Object.assign(document.createElement("a"), { href: url, download: res.filename })
      a.click()
      URL.revokeObjectURL(url)
    })

  const confirmThen = (message: string, run: () => Promise<{ error: string } | void>) => () => {
    if (!window.confirm(message)) return
    start(async () => {
      const res = await run()
      if (res?.error) toast.error(res.error)
    })
  }

  return (
    <div className="flex flex-wrap gap-3">
      {isOwner ? (
        <>
          <Button variant="outline" disabled={pending} onClick={onExport}>
            Export data
          </Button>
          <Button
            variant="destructive"
            disabled={pending}
            onClick={confirmThen(
              `Delete "${orgName}" and all its data? Any subscription is cancelled immediately. This cannot be undone.`,
              deleteOrganization,
            )}
          >
            Delete organization
          </Button>
        </>
      ) : null}
      <Button
        variant="destructive"
        disabled={pending}
        onClick={confirmThen(
          "Delete your account? Organizations you alone own are deleted with it. This cannot be undone.",
          deleteAccount,
        )}
      >
        Delete account
      </Button>
    </div>
  )
}
