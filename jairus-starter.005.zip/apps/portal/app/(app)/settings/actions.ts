"use server"

import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { ACTIVE_ORG_COOKIE, actionLimit, requireOrg } from "@app/auth"
import { billing } from "@app/adapters/billing"
import { dbPort } from "@app/adapters/db"
import { errorReporter } from "@app/adapters/errors"
import { makeDeleteAccount, makeDeleteOrg, makeExportOrg } from "@app/application"
import { DomainError, userMessage, type PlanTier } from "@app/domain"

// Returns { error } if checkout can't start (e.g. Stripe not configured) so the
// client can toast it; on success it redirects to Stripe and never returns.
export async function startCheckout(
  tier: PlanTier
): Promise<{ error: string } | void> {
  let ctx
  try {
    // The subscription is the organization's: only its owner may buy one.
    ctx = await requireOrg("billing:manage")
  } catch (e) {
    return { error: userMessage(e) }
  }
  const { session, organization } = ctx
  const limited = await actionLimit(session)
  if (limited) return { error: limited }
  let url: string
  try {
    const res = await billing.createCheckout({ orgId: organization.id, userId: session.userId }, tier)
    url = res.url
  } catch (e) {
    // Vendor errors can carry internals; report them, show a safe line.
    errorReporter.capture(e, { userId: session.userId, orgId: organization.id, action: "startCheckout" })
    return { error: userMessage(e, "Could not start checkout") }
  }
  redirect(url) // throws NEXT_REDIRECT — must stay outside the try/catch
}

// ── Danger zone (F8) ──────────────────────────────────────────────────────
// Each action re-checks the org role itself (via requireOrg + the use-case);
// the UI only hides what the role cannot do.

function fail(e: unknown, ctx: { userId?: string; orgId?: string; action: string }) {
  if (!(e instanceof DomainError)) errorReporter.capture(e, ctx)
  return { error: userMessage(e) }
}

export async function exportOrgData(): Promise<{ error: string } | { json: string; filename: string }> {
  let ctx
  try {
    ctx = await requireOrg("data:export")
  } catch (e) {
    return fail(e, { action: "exportOrgData" })
  }
  const { session, organization } = ctx
  const limited = await actionLimit(session)
  if (limited) return { error: limited }
  try {
    const data = await makeExportOrg(dbPort)(session.userId, organization.id)
    return { json: JSON.stringify(data, null, 2), filename: `${organization.slug}-export.json` }
  } catch (e) {
    return fail(e, { userId: session.userId, orgId: organization.id, action: "exportOrgData" })
  }
}

export async function deleteOrganization(): Promise<{ error: string } | void> {
  let ctx
  try {
    ctx = await requireOrg("org:delete")
  } catch (e) {
    return fail(e, { action: "deleteOrganization" })
  }
  const { session, organization } = ctx
  const limited = await actionLimit(session)
  if (limited) return { error: limited }
  try {
    await makeDeleteOrg(dbPort, billing)(session.userId, organization.id)
  } catch (e) {
    return fail(e, { userId: session.userId, orgId: organization.id, action: "deleteOrganization" })
  }
  ;(await cookies()).delete(ACTIVE_ORG_COOKIE)
  // With no membership left, requireOrg() gives the user a fresh personal org.
  redirect("/dashboard")
}

export async function deleteAccount(): Promise<{ error: string } | void> {
  let ctx
  try {
    ctx = await requireOrg() // portal users only — staff are rejected here
  } catch (e) {
    return fail(e, { action: "deleteAccount" })
  }
  const { session } = ctx
  const limited = await actionLimit(session)
  if (limited) return { error: limited }
  try {
    await makeDeleteAccount(dbPort, billing)(session.userId)
  } catch (e) {
    return fail(e, { userId: session.userId, action: "deleteAccount" })
  }
  // Sessions cascaded with the user, so the cookie no longer resolves.
  ;(await cookies()).delete(ACTIVE_ORG_COOKIE)
  redirect("/sign-in")
}
