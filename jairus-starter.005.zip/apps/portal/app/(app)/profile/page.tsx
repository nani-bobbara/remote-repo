import { getSession } from "@app/auth"
import { dbPort } from "@app/adapters/db"
import { Card, CardHeader, CardTitle, CardDescription, CardContent, ThemeToggle } from "@app/ui"
import { ProfileForm } from "./profile-form"
import { PasswordCard } from "./password-card"

export const dynamic = "force-dynamic"

export default async function ProfilePage() {
  const session = await getSession()
  // OAuth-only accounts have no password to change; resolved server-side so
  // the form never flashes a section the user cannot use.
  const hasPassword = session
    ? await dbPort.withUser(session.userId, (repos) => repos.users.hasCredential(session.userId))
    : false

  return (
    <div className="max-w-lg space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Profile</h1>
        <p className="text-muted-foreground">Manage your account details.</p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Your details</CardTitle>
          <CardDescription>{session?.email}</CardDescription>
        </CardHeader>
        <CardContent>
          <ProfileForm />
        </CardContent>
      </Card>
      <PasswordCard hasPassword={hasPassword} />
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4">
          <div className="grid gap-1.5">
            <CardTitle>Appearance</CardTitle>
            <CardDescription>Switch between light and dark. Saved on this device.</CardDescription>
          </div>
          <ThemeToggle />
        </CardHeader>
      </Card>
    </div>
  )
}
