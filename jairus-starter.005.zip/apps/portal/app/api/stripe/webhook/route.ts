import { billing } from "@app/adapters/billing"
// The ONE file allowed to import systemDbPort (eslint-boundaries override).
import { systemDbPort } from "@app/adapters/db"
import { LIMITS, rateLimit } from "@app/adapters/rate-limit"
import { makeHandleBillingEvent } from "@app/application"

// Stripe webhook — a thin edge. The adapter verifies the signature and
// normalises the payload; the use-case applies it exactly once. No business
// logic and no Stripe payload shape live here.
const handleBillingEvent = makeHandleBillingEvent(systemDbPort)

export async function POST(req: Request) {
  // Unauthenticated until the signature checks out, so cap per source IP first.
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown"
  const { ok, retryAfterSec } = await rateLimit.hit(`webhook:stripe:${ip}`, LIMITS.webhook)
  if (!ok) return new Response("Too many requests", { status: 429, headers: { "Retry-After": String(retryAfterSec) } })

  const signature = req.headers.get("stripe-signature")
  if (!signature) return new Response("Missing signature", { status: 400 })

  let event
  try {
    event = await billing.parseWebhook(await req.text(), signature)
  } catch {
    return new Response("Invalid signature", { status: 400 })
  }

  // applied / duplicate / ignored all acknowledge with 200 so Stripe stops
  // retrying. A thrown error (e.g. DB down) returns 500 and Stripe retries —
  // safe, because the ledger record rolled back with the failed effect.
  const outcome = await handleBillingEvent(event)
  return new Response(outcome, { status: 200 })
}
