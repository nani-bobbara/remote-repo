import { ShieldCheck } from "lucide-react"
import { brand } from "@app/config/brand"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@app/ui"
import { SignInForm } from "../_components/sign-in-form"

export default function SignInPage() {
  return (
    <main className="bg-background grid min-h-dvh lg:grid-cols-2">
      <section className="bg-muted/20 relative hidden overflow-hidden lg:flex lg:items-center lg:justify-center">
        <div className="relative z-10 flex items-center gap-4">
          <span className="bg-primary/10 text-primary flex size-16 items-center justify-center rounded-2xl border border-primary/20">
            <ShieldCheck className="size-8" />
          </span>
          <div>
            <p className="text-4xl font-bold tracking-tight">{brand.name}</p>
            <p className="text-primary mt-1 text-sm font-semibold uppercase tracking-[0.22em]">Admin console</p>
          </div>
        </div>
        <div className="bg-primary/5 pointer-events-none absolute -left-32 -top-32 size-96 rounded-full blur-3xl" />
        <div className="bg-primary/5 pointer-events-none absolute -bottom-40 -right-24 size-96 rounded-full blur-3xl" />
      </section>

      <section className="flex items-center justify-center px-6 py-12 sm:px-10 lg:px-16">
        <div className="w-full max-w-sm">
          <div className="mb-8">
            <h1 className="text-3xl font-bold tracking-tight">Welcome back</h1>
            <p className="text-muted-foreground mt-2 text-sm">Sign in to manage your workspace.</p>
          </div>
          <Card className="w-full shadow-sm">
          <CardHeader className="gap-2">
            <CardTitle>Admin sign in</CardTitle>
            <CardDescription>Use your staff account to continue.</CardDescription>
          </CardHeader>
          <CardContent>
            <SignInForm />
          </CardContent>
          </Card>
        </div>
      </section>
    </main>
  )
}
