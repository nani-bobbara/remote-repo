"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { Input, Label, toast, useRegisterWorkspaceActions } from "@app/ui"
import { createStaff } from "../actions"

type Role = { name: string; label: string }

/** Invite-staff fields. Cancel/Invite are surfaced in the workspace header (edit mode). */
export function InviteForm({ roles }: { roles: Role[] }) {
  const router = useRouter()
  const [pending, start] = useTransition()
  const [email, setEmail] = useState("")
  const [name, setName] = useState("")
  const [password, setPassword] = useState("")
  // No hardcoded fallback: if the catalog is somehow empty there is no valid
  // role to preselect, and the submit button below is disabled without one.
  const [role, setRole] = useState(roles[0]?.name ?? "")

  function submit() {
    start(async () => {
      const res = await createStaff({ email, name, password, role })
      if (res.error) {
        toast.error(res.error)
        return
      }
      toast.success(`Invited ${email}`)
      router.push("/staff")
    })
  }

  const invalid = !email || !name || password.length < 8
  useRegisterWorkspaceActions({
    mode: "edit",
    onSave: submit,
    onCancel: () => router.push("/staff"),
    saveDisabled: invalid,
    savePending: pending,
    saveLabel: "Invite staff",
  })

  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <div className="grid gap-2">
        <Label htmlFor="inv-name">Name</Label>
        <Input id="inv-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Operator" />
      </div>
      <div className="grid gap-2">
        <Label htmlFor="inv-email">Email</Label>
        <Input id="inv-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="jane@example.com" />
      </div>
      <div className="grid gap-2">
        <Label htmlFor="inv-pass">Temporary password</Label>
        <Input id="inv-pass" type="text" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="min 8 characters" />
      </div>
      <div className="grid gap-2">
        <Label htmlFor="inv-role">Role</Label>
        <select
          id="inv-role"
          value={role}
          onChange={(e) => setRole(e.target.value)}
          className="border-input bg-background focus-visible:ring-ring/50 h-9 rounded-md border px-3 text-sm capitalize outline-none focus-visible:ring-[3px]"
        >
          {roles.map((r) => (
            <option key={r.name} value={r.name}>
              {r.label}
            </option>
          ))}
        </select>
      </div>
    </div>
  )
}
