"use server"

import { revalidatePath } from "next/cache"
import { requirePermission, auth } from "@app/auth"
import { can, PERMISSIONS } from "@app/domain"
import { dbAdminPort, dbPort } from "@app/adapters/db"

/**
 * Is this role part of the admin plane?
 *
 * The staff page filters its list and its dropdowns to these, but a filtered
 * dropdown is not a boundary — these actions are reachable directly. Without
 * this check a crafted request could re-role a portal subscriber, or invite one
 * into a page that would then refuse to show them.
 */
async function requireStaffRole(roleName: string): Promise<{ error?: string }> {
  const role = await dbPort.roles.getByName(roleName)
  if (!role) return { error: "That role no longer exists" }
  if (!can(role, PERMISSIONS.ADMIN_ACCESS)) {
    return { error: `${role.label} has no admin access — it is not a staff role` }
  }
  return {}
}

// Invite/create a staff user: create the account, then assign the chosen role.
export async function createStaff(input: {
  email: string
  name: string
  password: string
  role: string
}): Promise<{ error?: string }> {
  await requirePermission(PERMISSIONS.STAFF_WRITE)
  const roleCheck = await requireStaffRole(input.role)
  if (roleCheck.error) return roleCheck
  try {
    await auth.api.signUpEmail({
      body: { email: input.email, password: input.password, name: input.name },
    })
    const created = await dbAdminPort.users.findByEmail(input.email)
    if (created) await dbAdminPort.users.setRole(created.id, input.role)
  } catch (e) {
    return { error: e instanceof Error ? e.message : "Could not create staff user" }
  }
  revalidatePath("/staff")
  return {}
}

/**
 * Move a staff member between staff roles.
 *
 * Both ends are checked: the target must already be staff, and the new role
 * must be a staff role. This page manages the admin plane only — a portal
 * subscriber is not listed here and cannot be re-roled from here, and a staff
 * member cannot be demoted into the portal, which would drop them out of the
 * one screen that can edit them.
 */
export async function setUserRole(userId: string, role: string): Promise<{ error?: string }> {
  await requirePermission(PERMISSIONS.STAFF_WRITE)

  const target = await dbAdminPort.users.findById(userId)
  if (!target) return { error: "User not found" }
  const currentCheck = await requireStaffRole(target.role)
  if (currentCheck.error) return { error: "That user is not staff and cannot be edited here" }

  const roleCheck = await requireStaffRole(role)
  if (roleCheck.error) return roleCheck

  try {
    await dbAdminPort.users.setRole(userId, role)
  } catch (e) {
    return { error: e instanceof Error ? e.message : "Could not update role" }
  }
  revalidatePath("/staff")
  return {}
}
