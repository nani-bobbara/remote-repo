import { can } from "@app/domain"
import { navGroups, type NavGroup, type NavItem } from "./nav-items"

export type ActiveNav = {
  group: NavGroup
  items: NavItem[]
  activeIndex: number
}

/**
 * What the nav needs to know about the session in order to filter.
 *
 * Deliberately an object rather than a bare `string[]`: a role's access is its
 * permission list PLUS its fullAccess flag, and passing only the list silently
 * hid every item from power_user (whose list is empty) when fullAccess replaced
 * the old '*' sentinel. Keeping them together makes that omission a type error.
 */
export type NavAccess = { permissions: string[]; fullAccess: boolean }

/**
 * Single source of truth for "where am I in the nav".
 *
 * Both the sidebar and the chevron ribbon call these, so the two surfaces cannot
 * disagree about the active group the way a second hardcoded list would.
 *
 * `groups` is injectable so tests supply fixtures instead of the live config.
 */

/**
 * Groups the session may see, each with its items permission-filtered.
 *
 * Two kinds of empty group, treated differently:
 * - natively empty (`items: []` in config, e.g. sales/systems) — a deliberate
 *   placeholder for a section not built yet. KEPT, so the sidebar renders its header.
 * - emptied by permissions (had items, all filtered out) — the session may see none
 *   of it. DROPPED, header included.
 */
export function visibleGroups(access: NavAccess, groups: NavGroup[] = navGroups): NavGroup[] {
  const grants = (item: NavItem) => !item.permission || can(access, item.permission)

  return groups
    .filter((group) => group.items.length === 0 || group.items.some(grants))
    .map((group) => ({ ...group, items: group.items.filter(grants) }))
}

/**
 * Which group and item own `pathname`. Matches the LONGEST href first, so
 * `/reports/archive` wins over `/reports` instead of whichever happens to come
 * first in the config. Returns null when no group owns the path (e.g. /sign-in),
 * and never returns a natively empty group, since such a group owns no routes.
 */
export function resolveActive(
  pathname: string,
  access: NavAccess,
  groups: NavGroup[] = navGroups,
): ActiveNav | null {
  let best: ActiveNav | null = null
  let bestLength = -1

  for (const group of visibleGroups(access, groups)) {
    for (const [index, item] of group.items.entries()) {
      const matches = pathname === item.href || pathname.startsWith(`${item.href}/`)
      if (!matches || item.href.length <= bestLength) continue
      bestLength = item.href.length
      best = { group, items: group.items, activeIndex: index }
    }
  }

  return best
}
