"use client"

import { useCallback } from "react"
import { Moon, Sun } from "lucide-react"
import { Button } from "@app/ui"

/**
 * Theme toggle with zero React state.
 *
 * The `.dark` class on <html> is the single source of truth — it's applied before
 * paint by the inline script in the root layout, and flipped directly here. Both
 * icons are always rendered and CSS picks one, so the server and client produce
 * byte-identical markup and there is nothing to hydrate-mismatch.
 *
 * (The previous version seeded useState from localStorage, which the server
 * cannot read: SSR rendered Moon, the client rendered Sun, hydration failed.)
 */
export function ThemeToggle() {
  const toggle = useCallback(() => {
    const isDark = document.documentElement.classList.toggle("dark")
    try {
      window.localStorage.setItem("theme", isDark ? "dark" : "light")
    } catch {
      // Private mode / storage disabled — the class still flips for this session.
    }
  }, [])

  return (
    <Button variant="outline" size="icon" aria-label="Toggle theme" title="Toggle theme" onClick={toggle}>
      <Sun className="hidden size-4 dark:block" />
      <Moon className="size-4 dark:hidden" />
    </Button>
  )
}
