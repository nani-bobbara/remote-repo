import { User } from "lucide-react"
import { getSession } from "@app/auth"
import { dbAdminPort } from "@app/adapters/db"
import { PageShell, WorkspaceLayout } from "@app/ui"
import { ThemeToggle } from "../../_components/theme-toggle"
import { ProfileForm } from "./profile-form"

export const dynamic = "force-dynamic"

export default async function ProfilePage() {
  const session = await getSession()
  const user = session ? await dbAdminPort.users.findById(session.userId) : null

  return (
    <PageShell>
      <WorkspaceLayout
        cardIcon={<User />}
        cardTitle="Profile"
        cardSubtitle="Your account and access details."
        cardActions={<ThemeToggle />}
      >
        <ProfileForm name={user?.name ?? ""} email={session?.email ?? ""} role={session?.role ?? ""} />
      </WorkspaceLayout>
    </PageShell>
  )
}
