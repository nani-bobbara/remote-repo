"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { Input, Label, toast, useRegisterWorkspaceActions } from "@app/ui"
import { updateProfileName } from "./actions"

/** Profile details with a display/edit toggle; Edit/Save/Cancel live in the header. */
export function ProfileForm({ name, email, role }: { name: string; email: string; role: string }) {
  const router = useRouter()
  const [mode, setMode] = useState<"display" | "edit">("display")
  const [value, setValue] = useState(name)
  const [pending, start] = useTransition()

  const readOnly = mode === "display"
  const dirty = value.trim() !== name

  function save() {
    start(async () => {
      const res = await updateProfileName(value)
      if (res.error) {
        toast.error(res.error)
        return
      }
      toast.success("Profile updated")
      setMode("display")
      router.refresh()
    })
  }

  useRegisterWorkspaceActions(
    mode === "edit"
      ? {
          mode: "edit",
          onSave: save,
          onCancel: () => {
            setValue(name)
            setMode("display")
          },
          saveDisabled: !dirty || !value.trim(),
          savePending: pending,
          saveLabel: "Save profile",
        }
      : { mode: "display", onEdit: () => setMode("edit"), editLabel: "Edit profile" }
  )

  return (
    <div className="grid max-w-xl gap-5 p-6">
      <div className="grid gap-2">
        <Label htmlFor="pf-name">Display name</Label>
        <Input id="pf-name" value={value} onChange={(e) => setValue(e.target.value)} disabled={readOnly} />
      </div>
      <div className="grid gap-2">
        <Label htmlFor="pf-email">Email</Label>
        <Input id="pf-email" value={email} readOnly disabled />
      </div>
      <div className="grid gap-2">
        <Label htmlFor="pf-role">Role</Label>
        <Input id="pf-role" value={role.replace("_", " ")} readOnly disabled className="capitalize" />
      </div>
    </div>
  )
}
