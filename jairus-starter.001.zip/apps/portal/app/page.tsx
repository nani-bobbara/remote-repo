export const dynamic = "force-dynamic"

import Link from "next/link"
import { ShieldCheck, Zap, Boxes, Check } from "lucide-react"
import { brand } from "@app/config/brand"
import { getSession } from "@app/auth"
import { Badge, Button, Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@app/ui"
import { SignOutButton } from "./_components/sign-out-button"

const features = [
  { icon: ShieldCheck, title: "Secure by default", body: "Session auth, role-based access, and fail-closed row-level security out of the box." },
  { icon: Zap, title: "Ship fast", body: "A production-ready foundation — auth, billing, and a membership dashboard, ready to build on." },
  { icon: Boxes, title: "Built to scale", body: "Serverless Postgres and stateless apps that grow with you, deployed on the edge." },
]

const tiers = [
  { name: "Free", tagline: "Get started", features: ["Core features", "Community support"], featured: false },
  { name: "Basic", tagline: "For growing teams", features: ["Everything in Free", "Higher limits", "Email support"], featured: true },
  { name: "Pro", tagline: "For scale", features: ["Everything in Basic", "Advanced controls", "Priority support"], featured: false },
]

export default async function Home() {
  const session = await getSession()

  return (
    <div className="flex min-h-dvh flex-col">
      <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b bg-background/80 px-4 backdrop-blur sm:px-6">
        <span className="font-semibold tracking-tight">{brand.name}</span>
        <div className="flex items-center gap-2">
          {session ? (
            <Button asChild size="sm">
              <Link href="/dashboard">Dashboard</Link>
            </Button>
          ) : (
            <>
              <Button asChild variant="ghost" size="sm" className="hidden sm:inline-flex">
                <Link href="/sign-in">Sign in</Link>
              </Button>
              <Button asChild size="sm" className="hidden sm:inline-flex">
                <Link href="/sign-up">Get started</Link>
              </Button>
            </>
          )}
        </div>
      </header>

      <main className="flex-1 pb-24 md:pb-0">
        {/* Hero */}
        <section className="mx-auto max-w-3xl px-6 py-20 text-center sm:py-28">
          <h1 className="text-4xl font-bold tracking-tight text-balance sm:text-5xl">{brand.tagline}</h1>
          <p className="text-muted-foreground mx-auto mt-5 max-w-xl text-lg text-pretty">{brand.description}</p>
          {session ? (
            <div className="mt-8 flex flex-col items-center gap-3">
              <p className="text-sm">Signed in as <strong>{session.email}</strong></p>
              <div className="flex gap-3">
                <Button asChild size="lg"><Link href="/dashboard">Go to dashboard</Link></Button>
                <SignOutButton />
              </div>
            </div>
          ) : (
            <div className="mt-8 hidden justify-center gap-3 md:flex">
              <Button asChild size="lg"><Link href="/sign-up">Get started</Link></Button>
              <Button asChild size="lg" variant="outline"><Link href="/sign-in">Sign in</Link></Button>
            </div>
          )}
        </section>

        {/* Features */}
        <section className="mx-auto max-w-5xl px-6 py-8">
          <div className="grid gap-4 sm:grid-cols-3">
            {features.map(({ icon: Icon, title, body }) => (
              <Card key={title}>
                <CardHeader>
                  <Icon className="text-muted-foreground size-6" />
                  <CardTitle className="mt-2">{title}</CardTitle>
                  <CardDescription>{body}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </section>

        {/* Pricing */}
        <section className="mx-auto max-w-5xl px-6 py-16">
          <div className="text-center">
            <h2 className="text-2xl font-semibold tracking-tight sm:text-3xl">Simple pricing</h2>
            <p className="text-muted-foreground mt-2">Start free. Upgrade when you grow.</p>
          </div>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {tiers.map((t) => (
              <Card key={t.name} className={t.featured ? "border-primary border-2" : undefined}>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <CardTitle>{t.name}</CardTitle>
                    {t.featured ? <Badge>Popular</Badge> : null}
                  </div>
                  <CardDescription>{t.tagline}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-2">
                  {t.features.map((f) => (
                    <p key={f} className="flex items-center gap-2 text-sm">
                      <Check className="text-muted-foreground size-4 shrink-0" />
                      {f}
                    </p>
                  ))}
                </CardContent>
                <CardFooter>
                  <Button asChild className="w-full" variant={t.featured ? "default" : "outline"}>
                    <Link href="/sign-up">Get started</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </section>
      </main>

      <footer className="border-t px-6 py-8 text-center text-sm">
        <span className="text-muted-foreground">
          {brand.name} — built on the jairus starter.
        </span>
      </footer>

      {/* Mobile sticky CTA bar — prominent Get started + Sign in (signed-out only) */}
      {!session ? (
        <div
          className="bg-background/95 fixed inset-x-0 bottom-0 z-40 flex gap-3 border-t p-3 backdrop-blur md:hidden"
          style={{ paddingBottom: "calc(0.75rem + env(safe-area-inset-bottom))" }}
        >
          <Button asChild variant="outline" className="flex-1">
            <Link href="/sign-in">Sign in</Link>
          </Button>
          <Button asChild className="flex-[2]">
            <Link href="/sign-up">Get started</Link>
          </Button>
        </div>
      ) : null}
    </div>
  )
}
