import { billing } from "@app/adapters/billing"
import { dbPort } from "@app/adapters/db"
import type { PlanTier } from "@app/domain"

// Stripe webhook. Verifies the signature, then reconciles the subscription table.
// Writes via dbPort.withUser(userId) so the row is scoped to the paying user and
// satisfies RLS (we know the user from checkout metadata — no privileged path needed).
export async function POST(req: Request) {
  const signature = req.headers.get("stripe-signature")
  if (!signature) return new Response("Missing signature", { status: 400 })

  const payload = await req.text()
  let event: { type: string; data: unknown }
  try {
    event = await billing.parseWebhook(payload, signature)
  } catch {
    return new Response("Invalid signature", { status: 400 })
  }

  if (event.type === "checkout.session.completed") {
    const s = event.data as {
      client_reference_id?: string | null
      customer?: string | null
      metadata?: Record<string, string> | null
    }
    const userId = s.metadata?.userId ?? s.client_reference_id ?? undefined
    const tier = (s.metadata?.tier ?? "pro") as PlanTier
    if (userId) {
      await dbPort.withUser(userId, (repos) =>
        repos.subscriptions.upsert({
          userId,
          tier,
          status: "active",
          stripeCustomerId: typeof s.customer === "string" ? s.customer : null,
          currentPeriodEnd: null,
        })
      )
    }
  }

  // Extension points (out of template scope): customer.subscription.updated/deleted
  // and invoice.paid — map the Stripe customer back to userId via the stored
  // stripeCustomerId, then update status / currentPeriodEnd.

  return new Response("ok", { status: 200 })
}
