import Link from "next/link"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@app/ui"
import { SignInForm } from "../_components/sign-in-form"

export default function SignInPage() {
  return (
    <main className="flex min-h-dvh items-center justify-center px-6">
      <Card className="w-full max-w-sm">
        <CardHeader>
          <CardTitle>Sign in</CardTitle>
          <CardDescription>Welcome back. Enter your details to continue.</CardDescription>
        </CardHeader>
        <CardContent>
          <SignInForm />
          <p className="text-muted-foreground mt-4 text-center text-sm">
            No account?{" "}
            <Link href="/sign-up" className="text-foreground underline underline-offset-4">
              Sign up
            </Link>
          </p>
        </CardContent>
      </Card>
    </main>
  )
}
