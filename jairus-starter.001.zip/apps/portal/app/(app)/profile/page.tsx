import { getSession } from "@app/auth"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@app/ui"
import { ProfileForm } from "./profile-form"

export const dynamic = "force-dynamic"

export default async function ProfilePage() {
  const session = await getSession()
  return (
    <div className="max-w-lg space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Profile</h1>
        <p className="text-muted-foreground">Manage your account details.</p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Your details</CardTitle>
          <CardDescription>{session?.email}</CardDescription>
        </CardHeader>
        <CardContent>
          <ProfileForm />
        </CardContent>
      </Card>
    </div>
  )
}
