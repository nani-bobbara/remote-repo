# Theming — swappable design-token palettes

**Living document.** Describes the theme layer as built.
**Scope:** `packages/ui`, `packages/config`, both app root layouts

**Partially built:** admin-selected branding. A non-persisting **preview** picker
now ships in the admin **System Setup** page
(`apps/admin/app/(app)/system-setup/_components/branding-configs.tsx`): a
`NativeSelect` of the registered palettes that live-repaints via `data-palette`
and emits a copy-paste config. `brand.palette` in `@app/config` is env-driven
(`NEXT_PUBLIC_BRAND_PALETTE`), not only a code edit. Still **not built:**
*persisting* an admin's choice — that needs a settings table, a port, an adapter,
and a cached per-request read in both root layouts (see Non-goals / Phase 2).

## Problem

`packages/ui/src/styles.css` held one hard-coded palette. It had just been
swapped from the stock shadcn greyscale to a palette ported from the
MachineControl app, which meant every project generated from
`--template jairus-starter` would inherit that brand's orange rather than a
neutral starting point. The original instruction in the file header — "to apply
a tweakcn preset, replace the `:root` and `.dark` blocks" — had been removed, so
there was no documented way back.

Reverting was considered and rejected. The same file also gained three
structural changes that are not palette-specific and that seven other files now
depend on: a Tailwind v4 border reset, two additive tokens
(`--subtle-foreground`, `--border-strong`), and a `.custom-scrollbar` utility.
A wholesale revert would have removed those and degraded 15 call sites silently,
without a build error.

## Goals

- Support more than one palette, selectable without editing CSS.
- Guarantee every palette declares an identical token set, so switching can
  never leave a token undefined.
- Keep the structural layer — reset, utilities, Tailwind bridge — shared.
- Leave light/dark behaviour exactly as it is.
- Change no component and no rendered output for the default palette.

## Non-goals (deferred to Phase 2)

Admin-selectable branding via the System Setup page. That needs a settings
table, a Drizzle migration, a domain port and adapter, an RLS policy, and a
cached per-request read in both root layouts. It is a separate feature with a
much larger blast radius; this phase deliberately lands the CSS layer first so
that work starts from a stable base.

## Design

### File layout

```
packages/ui/src/
  styles.css                    entry — @imports only, declares nothing
  themes/
    _base.css                   structure shared by every palette
    neutral-zinc.css            "Neutral Zinc" — stock shadcn greyscale (default)
    industrial-orange.css       "Industrial Orange" — ported from MachineControl
    midnight-indigo.css         "Midnight Indigo"
    forest-emerald.css          "Forest Emerald"
    terracotta-sand.css         "Terracotta Sand"
    registry.ts                 display metadata, typed by PaletteId
packages/config/src/
  theme.ts                      PALETTE_IDS + PaletteId union + DEFAULT_PALETTE
  brand.ts                      brand.palette, typed against PaletteId
```

Five palettes ship today: `neutral-zinc` (default), `industrial-orange`,
`midnight-indigo`, `forest-emerald`, `terracotta-sand`.

### Selection mechanism

Every palette ships in the bundle, scoped to an attribute selector:

```css
html[data-palette="industrial-orange"]      { /* light */ }
html[data-palette="industrial-orange"].dark { /* dark  */ }
```

Each app's root layout stamps `data-palette={brand.palette}` on `<html>`. This
is server-rendered, so it is correct on first paint with no script — unlike
light/dark, which is a per-user preference the server cannot know and which
keeps its existing inline no-flash script.

Specificity is well-behaved: the dark selector (0,2,1) always beats the light
one (0,1,1) within a palette, and only one `data-palette` value matches at a
time, so `@import` order is irrelevant.

This was chosen over a single-`@import` swap specifically because Phase 2 needs
runtime switching. Phase 2 changes only where the attribute's value comes from;
no CSS is restructured.

### Unstyled-state fallback

Because no palette is unscoped, a missing `data-palette` attribute would render
the app with no tokens at all. `neutral-zinc.css` therefore carries a second
selector on each block, `html:not([data-palette])`, making it the implicit
fallback. No other palette may claim it (keep the no-attribute fallback on the default only).

`DEFAULT_PALETTE` in `@app/config/theme` and that CSS fallback must stay in
sync; both are documented as such.

### The token contract

Each palette declares the same **36 tokens** in both its light and dark block:
6 surface, 4 brand, 4 neutral, 2 additive, 3 status, 3 form, 5 chart, 8 sidebar,
1 radius.

Charts, success, and radius are per-palette rather than shared. That was a
deliberate call: `--destructive` was already per-palette, so splitting the
status colours across two layers would have been inconsistent, and radius is a
recognisable part of a brand's feel that tweakcn presets do vary.

Declaring all 36 in the dark block is redundant for values that do not change
between modes — the light selector still matches in dark mode. The repetition
is intentional: it means a complete palette for one mode can be read in one
place rather than diffed against the other.

`_base.css` holds the `dark` custom variant, the `@theme inline` bridge
(including the `--radius-sm/md/lg/xl` `calc()` derivations, which reference
whatever `--radius` the active palette supplies), the border reset, and the
scrollbar utilities. It contains no literal colour.

### Dependency direction

`PaletteId` lives in `@app/config`, not `@app/ui`, because `@app/ui` depends on
`@app/config` and not the reverse. `registry.ts` is typed
`Record<PaletteId, PaletteMeta>`, so adding an id to the union without adding a
registry entry is a compile error.

`registry.ts` imports no React and no CSS, so it can be read from a server
component, a build script, or a future admin form without pulling in the client
runtime.

### The palette contract

Every palette must satisfy the following. There is no automated check — hold it
by review when adding or editing a palette:

1. Registry ids match the CSS files on disk, each entry keyed by its own id,
   with distinct labels and descriptions.
2. Each palette has exactly one light and one dark block, both scoped to its
   own `data-palette` value.
3. Every palette's light token set equals the default palette's.
4. Every palette's dark token set equals its own light set.
5. Every token except `--radius` has a `--color-*` mapping in `_base.css`, and
   `--radius` drives the radius scale.
6. `_base.css` contains no hex or `oklch()` literal.
7. The default palette claims the no-attribute fallback and no other palette
   does.
8. **Contrast** — each palette's foreground/background token pairs stay readable
   (meet the WCAG contrast thresholds) in both light and dark.

Points 5 and 6 are the easiest to get wrong: a token added to every palette but
not exposed to Tailwind (5), or a palette value leaking into the structural
layer where it stops responding to palette changes (6). Point 8 keeps an
unreadable palette from shipping.

## Adding a palette

1. Copy an existing `themes/<id>.css`; change the selector and values.
2. Add the id to `PaletteId` in `@app/config/theme`.
3. Add an entry to `themes/registry.ts` (a compile error until you do).
4. `@import` it from `styles.css`.

Hold the new file to the same 36-token contract and readable contrast — verify
by review against the contract above.

## Verification

- `pnpm -r type-check` — all packages pass (adding a `PaletteId` without a
  matching `registry.ts` entry is a compile error).

## Consequences

The default is `neutral-zinc`, so the template is brand-free again and the
admin app renders grey until `brand.palette` is set to `"industrial-orange"` —
a one-line change intended to be made in a downstream product, not here.

`neutral-zinc` needed values for `--subtle-foreground` and `--border-strong`,
which shadcn does not ship. These are derived, not upstream: `oklch(0.708 0 0)`
and `oklch(0.87 0 0)` light, `oklch(0.556 0 0)` and `oklch(0.32 0 0)` dark,
sitting between `--muted-foreground` and `--border`.

`industrial-orange`'s chart series was carried over from the shadcn defaults
during the original port and has not been tuned to the brand. Flagged inline in
the file.

`brand.name` defaults to `"Acme"` (env-overridable via `NEXT_PUBLIC_BRAND_NAME`).
Product naming is independent of the palette and was left alone.
