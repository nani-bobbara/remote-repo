# RBAC — roles, permissions, and the two planes

**Living document.** Describes the current design, not how it was reached.
Diagram: [architecture/db-schema.html](../architecture/db-schema.html)

## Two planes, governed differently

| | Admin plane | Portal plane |
|---|---|---|
| Who | staff who run the platform | subscribers who signed up |
| Entry gate | the `admin:access` permission | an authenticated session |
| Access model | **permission-scoped** — `can()` at each call site | **ownership-scoped** — RLS via `withUser` |
| Permissions held | some | **none** |

A portal user holding zero permissions is the design, not an omission. Portal
pages check only `getSession()`; their data boundary is row ownership. The
permission vocabulary exists for the admin plane alone.

`apps/portal/app/(app)/layout.tsx` bounces anyone holding `admin:access` out of
the portal, and `apps/admin/app/(app)/layout.tsx` does the reverse.

## "Staff" is a category, not a role

Nothing is named staff. `requireStaff()` is `requirePermission(ADMIN_ACCESS)`,
and the Staff page computes its list the same way. Any role granting
`admin:access` qualifies, so a role an admin creates later — sales, IT,
systems — becomes staff the moment it is granted that permission, with no code
change.

This means the word does double duty, deliberately:

- `admin:access` — *is* staff (may enter the admin app)
- `staff:read` / `staff:write` — may *manage* staff (see the list, invite, edit)

A role can hold the first without the second: into the console, but unable to
see the people list at all.

## The three seeded roles

Defined in `packages/config/src/roles.ts` — the only place a role id is written.

| id | label | grants |
|---|---|---|
| `admin` | Admin | `fullAccess` — everything, including permissions added later |
| `support` | Support | `admin:access` plus every `*:read` key in the catalog |
| `regular` | Portal User | nothing; the portal signup default |

Support's set is **resolved against the live catalog at seed time**, not
hand-listed, so it stays a mirror of Admin as the catalog grows. Ship
`billing:read` and a fresh seed grants it to Support.

Roles seed **first-insert-only** (`onConflictDoNothing`), so edits an admin
makes in the UI survive every redeploy.

### Full access is a flag, not a wildcard

`role.full_access` replaced an earlier `'*'` sentinel stored inside the
permission list. A sentinel string cannot satisfy a foreign key, and "can do
everything" is a property of the role rather than something assignable in the
matrix.

Consequence worth knowing: **`admin`'s permission list is empty.** Anything
filtering by permissions must also honour the flag, or it will hide everything
from the superuser. `can()` short-circuits on it; `NavAccess` exists so the nav
cannot be handed a bare `string[]` and silently lock the admin out.

## Integrity lives in the database

Three tables, wired so the application cannot corrupt the model:

```
role ──< role_permission >── permission
  ^
  └── user.role
```

| Constraint | Effect |
|---|---|
| `role_permission.permission_key → permission.key` `RESTRICT` | a permission in use cannot be deleted (23001) |
| `role_permission.role_name → role.name` `CASCADE` | deleting a role takes its assignments |
| `user.role → role.name` `RESTRICT` | a role someone holds cannot be deleted; an unknown role cannot be written (23503) |

`RESTRICT` rather than `SET DEFAULT` on both: silently demoting people is a
change of access as a side effect of an unrelated edit.

Because the database keeps these invariants, the seed has no self-heal step and
the application's "still in use" check in `permissions/actions.ts` exists only
to turn a raw constraint violation into a message naming the blocking roles.

Every foreign key child column is indexed — Postgres does not do this
automatically, and `RESTRICT` checks scan the child table.

## The permission catalog

`permission` is the vocabulary: `key`, `label`, `description`, `resource`,
`isSystem`.

- **`key`** is what code checks. `can(session, PERMISSIONS.STAFF_WRITE)`.
- **`resource`** groups the matrix — one group per feature area. It is derived
  from the key prefix on first insert, so shipping `reports:read` makes a
  `reports` group appear with no extra wiring. It is free-form text: admins may
  regroup, and nothing validates it against the key.
- **`isSystem: true`** means code enforces this key. Written only by the seed.
  Admin-created keys are `false` and the UI marks them "not yet enforced" —
  they grant nothing until a developer ships a `can()` call for them.

Labels and descriptions are **admin-curated**. The seed derives a legible
starting label and, on conflict, sets `isSystem` only — redeploying never
reverts human wording to a machine-derived guess.

### Enforcement stays in code

A permission string does nothing unless code calls `can()` with it. That is why
`PERMISSIONS` in `packages/domain` remains the source of truth for enforcement
while the table carries metadata: the two are reconciled by `isSystem`.

`@app/config` is a leaf package, so `roles.ts` names no permission keys at all.
Each role declares intent (`full-access` / `read-only-mirror` / `none`) and the
seed resolves it against the catalog.

## Adding staff

Both paths are on the Staff page and require `staff:write`:

- **Invite** (`createStaff`) — creates the account and assigns a staff role.
- **Change role** (`setUserRole`) — moves a staff member between staff roles.

The page lists only staff, and both actions verify the role grants
`admin:access` server-side. A filtered dropdown is not a boundary; the actions
are reachable directly.

Portal subscribers are not listed and cannot be re-roled from there. The editor
does not offer portal roles either — demoting someone would drop them out of
the only screen that can edit them.

**Every extra `admin` is a full superuser.** For more administrators without
more superusers, create a restricted role rather than adding people to `admin`.

## Known gaps

- `permission.resource` is unenforced free-form text, so a typo creates a
  phantom group in the matrix.
- `user.must_reset_password` exists in the schema but nothing reads or writes
  it, while the invite form labels its field "Temporary password".
- Revoking staff access is not possible from the UI, by the deliberate choice
  above. It wants to be an explicit action, not a dropdown value.
