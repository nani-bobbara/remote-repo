// Auth adapter — Better Auth instance (email+password + optional Google).
// Better Auth handles credentials + sessions only. Roles/permissions are OUR concern
// (data-driven `role` table + can()), so we don't use Better Auth's admin/AC plugin:
// new users get their role from the DB column default; staff are created by an
// admin through the admin app (signUpEmail + set role). Session resolution and
// guards live in @app/auth, where request headers exist.
import { betterAuth } from 'better-auth'
import { drizzleAdapter } from 'better-auth/adapters/drizzle'
import { DEFAULT_PORTAL_ROLE } from '@app/config/roles'
import { db } from '../db/index'
import * as schema from '../db/schema'

const google = process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET
  ? { google: { clientId: process.env.GOOGLE_CLIENT_ID, clientSecret: process.env.GOOGLE_CLIENT_SECRET } }
  : undefined

export const auth = betterAuth({
  // Pass the schema so Better Auth can find the user/session/account/verification models.
  database: drizzleAdapter(db, { provider: 'pg', schema }),
  emailAndPassword: { enabled: true },
  ...(google ? { socialProviders: google } : {}),
  // Surface the role column on the session user (input:false so clients can't set it).
  // Role is assigned server-side only — signup default from @app/config/roles,
  // staff roles set by an admin through the admin app.
  user: {
    additionalFields: {
      role: { type: 'string', required: false, defaultValue: DEFAULT_PORTAL_ROLE, input: false },
    },
  },
})

export type Auth = typeof auth
