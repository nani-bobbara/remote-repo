// Drizzle schema — the single source of truth (drives migrations AND both apps' types).
// The Better Auth tables (user/session/account/verification) must match what Better Auth
// + its enabled plugins expect. Field (JS key) names must match Better Auth's model fields;
// regenerate with `npx @better-auth/cli generate` if you change the auth config/plugins.
import { sql } from 'drizzle-orm'
import { pgTable, text, timestamp, boolean, uuid, primaryKey, index, check } from 'drizzle-orm/pg-core'
import { DEFAULT_PORTAL_ROLE } from '@app/config/roles'

// ── Better Auth core + admin plugin ───────────────────────────────────────
export const user = pgTable('user', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  email: text('email').notNull().unique(),
  emailVerified: boolean('email_verified').default(false).notNull(),
  image: text('image'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
  // Role name, FK into the `role` catalog. RESTRICT rather than SET DEFAULT:
  // deleting a role that people hold must be refused, not silently demote them.
  // The default comes from @app/config/roles so the id is written in one place;
  // changing it there requires a migration to alter this column default.
  role: text('role')
    .notNull()
    .default(DEFAULT_PORTAL_ROLE)
    .references(() => role.name, { onDelete: 'restrict', onUpdate: 'cascade' }),
  banned: boolean('banned').default(false),
  banReason: text('ban_reason'),
  banExpires: timestamp('ban_expires'),
  // app-specific
  mustResetPassword: boolean('must_reset_password').default(false).notNull(),
}, (t) => [
  // Postgres does not index the child side of a foreign key. Without this,
  // deleting a role scans every user row.
  index('user_role_idx').on(t.role),
])

export const session = pgTable('session', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => user.id, { onDelete: 'cascade' }),
  token: text('token').notNull().unique(),
  expiresAt: timestamp('expires_at').notNull(),
  ipAddress: text('ip_address'),
  userAgent: text('user_agent'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
  // admin plugin (impersonation)
  impersonatedBy: text('impersonated_by'),
}, (t) => [
  // Read on session lookup and scanned on every user delete (cascade).
  index('session_user_id_idx').on(t.userId),
])

export const account = pgTable('account', {
  id: text('id').primaryKey(),
  userId: text('user_id').notNull().references(() => user.id, { onDelete: 'cascade' }),
  accountId: text('account_id').notNull(),
  providerId: text('provider_id').notNull(),
  accessToken: text('access_token'),
  refreshToken: text('refresh_token'),
  idToken: text('id_token'),
  accessTokenExpiresAt: timestamp('access_token_expires_at'),
  refreshTokenExpiresAt: timestamp('refresh_token_expires_at'),
  scope: text('scope'),
  password: text('password'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (t) => [
  index('account_user_id_idx').on(t.userId),
])

export const verification = pgTable('verification', {
  id: text('id').primaryKey(),
  identifier: text('identifier').notNull(),
  value: text('value').notNull(),
  expiresAt: timestamp('expires_at').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
})

// ── Roles (data-driven RBAC catalog) ──────────────────────────────────────
// Managed via the admin app. permissions: string[] of 'resource:action' ('*' = all).
// power_user is seeded with ['*'] and isSystem=true (undeletable superadmin).
export const role = pgTable('role', {
  name: text('name').primaryKey(),                          // 'power_user', 'regular', …
  label: text('label').notNull(),
  description: text('description'),
  // Superuser flag. Replaces the old '*' sentinel that lived in permissions[]:
  // a sentinel string cannot satisfy a foreign key, and "can do everything" is a
  // property of the role rather than a permission anyone can be granted.
  fullAccess: boolean('full_access').default(false).notNull(),
  isSystem: boolean('is_system').default(false).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
})

// Role ↔ permission assignment. Replaces role.permissions text[], which could
// hold a typo or a deleted key with nothing to stop it.
//   permission_key ON DELETE RESTRICT — the database refuses to drop a
//     permission that is still assigned, so integrity no longer depends on an
//     application-level check remembering to look.
//   role_name ON DELETE CASCADE — deleting a role takes its assignments with it.
export const rolePermission = pgTable(
  'role_permission',
  {
    roleName: text('role_name').notNull().references(() => role.name, { onDelete: 'cascade' }),
    permissionKey: text('permission_key').notNull().references(() => permission.key, { onDelete: 'restrict' }),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (t) => [
    primaryKey({ columns: [t.roleName, t.permissionKey] }),
    // The composite PK indexes role_name (leading column) but NOT
    // permission_key. That column carries ON DELETE RESTRICT, so without this
    // index every permission delete — and every "which roles use this key?"
    // lookup — scans the whole table.
    index('role_permission_permission_key_idx').on(t.permissionKey),
  ],
)

// ── Permission catalog (vocabulary for the RBAC matrix) ───────────────────
// Metadata only. Enforcement lives in code: can(session, '<key>').
// isSystem=true means a code path calls can() with this key — written only by
// the seed, for the keys in PERMISSIONS. Admin-created keys are isSystem=false
// and are surfaced in the UI as "not yet enforced".
// label/description/resource are curated by admins in the admin app; the seed
// only derives a starting value on first insert and never overwrites them.
export const permission = pgTable('permission', {
  key: text('key').primaryKey(),                            // 'staff:write'
  label: text('label').notNull(),                           // 'Manage staff'
  description: text('description'),
  resource: text('resource').notNull(),                     // 'staff' — groups the matrix
  isSystem: boolean('is_system').default(false).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
})

// ── Domain tables ─────────────────────────────────────────────────────────
export const subscription = pgTable('subscription', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: text('user_id').notNull().unique().references(() => user.id, { onDelete: 'cascade' }),  // one subscription per user (enables upsert-on-conflict)
  // Deliberately unconstrained. Tiers are THIS product's pricing, not a
  // platform invariant: a CHECK or enum would bake one price list into
  // migration history, and every rename or new tier would need a migration in
  // every environment. PlanTier in @app/domain is the compile-time guard and
  // Stripe owns the real product catalog.
  tier: text('tier').default('free').notNull(),
  // Constrained, unlike tier: this vocabulary is Stripe's, not ours, so it does
  // not change with pricing decisions.
  status: text('status').default('active').notNull(),
  stripeCustomerId: text('stripe_customer_id'),
  currentPeriodEnd: timestamp('current_period_end'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (t) => [
  check(
    'subscription_status_check',
    sql`${t.status} in ('active', 'trialing', 'past_due', 'canceled')`,
  ),
])
