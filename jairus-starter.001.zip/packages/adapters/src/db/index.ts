// DB adapter — implements the domain DbPort with Drizzle + Neon (postgres.js driver).
// Two connections: scoped (pooled, RLS-enforced via withUser) + admin (owner, cross-user/system).
import { drizzle } from 'drizzle-orm/postgres-js'
import postgres from 'postgres'
import { and, eq, inArray, sql } from 'drizzle-orm'
import type { DbPort, PermissionDef, RoleDef, Subscription, User } from '@app/domain'
import {
  permission as permT,
  role as roleT,
  rolePermission as rolePermT,
  subscription as subT,
  user as userT,
} from './schema'

const scopedClient = postgres(process.env.DATABASE_URL!, { prepare: false })
const adminClient = postgres(process.env.DATABASE_URL_ADMIN ?? process.env.DATABASE_URL!, { prepare: false })
export const db = drizzle(scopedClient, { schema: { userT, subT, roleT } })
export const dbAdmin = drizzle(adminClient, { schema: { userT, subT, roleT } })   // bypasses RLS — system/admin only

type Drizzle = typeof db

function toUser(r: typeof userT.$inferSelect): User {
  return {
    id: r.id, email: r.email, name: r.name, role: r.role, createdAt: r.createdAt,
    emailVerified: r.emailVerified, banned: r.banned ?? false,
  }
}
// Permissions live in role_permission now, so a role is only whole once its
// assigned keys are joined in. Every caller goes through loadRoles below.
function toRole(r: typeof roleT.$inferSelect, permissions: string[]): RoleDef {
  return {
    name: r.name,
    label: r.label,
    description: r.description,
    permissions,
    fullAccess: r.fullAccess,
    isSystem: r.isSystem,
  }
}

/**
 * Fetch roles with their permission keys in two queries rather than N+1.
 * `names` undefined = all roles.
 */
async function loadRoles(conn: Drizzle, names?: string[]): Promise<RoleDef[]> {
  const rows = names
    ? await conn.select().from(roleT).where(inArray(roleT.name, names)).orderBy(roleT.name)
    : await conn.select().from(roleT).orderBy(roleT.name)
  if (rows.length === 0) return []

  const links = await conn
    .select()
    .from(rolePermT)
    .where(inArray(rolePermT.roleName, rows.map((r) => r.name)))
    .orderBy(rolePermT.permissionKey)

  const byRole = new Map<string, string[]>()
  for (const l of links) {
    const list = byRole.get(l.roleName) ?? []
    list.push(l.permissionKey)
    byRole.set(l.roleName, list)
  }
  return rows.map((r) => toRole(r, byRole.get(r.name) ?? []))
}
function toPermission(r: typeof permT.$inferSelect): PermissionDef {
  return { key: r.key, label: r.label, description: r.description, resource: r.resource, isSystem: r.isSystem }
}
function toSub(r: typeof subT.$inferSelect): Subscription {
  return {
    id: r.id, userId: r.userId, tier: r.tier as Subscription['tier'],
    status: r.status as Subscription['status'], stripeCustomerId: r.stripeCustomerId,
    currentPeriodEnd: r.currentPeriodEnd,
  }
}

function makePort(conn: Drizzle): DbPort {
  return {
    users: {
      async findById(id) { const [r] = await conn.select().from(userT).where(eq(userT.id, id)); return r ? toUser(r) : null },
      async findByEmail(email) { const [r] = await conn.select().from(userT).where(eq(userT.email, email)); return r ? toUser(r) : null },
      async list() { const rs = await conn.select().from(userT).orderBy(userT.createdAt); return rs.map(toUser) },
      async setRole(userId, role) { await conn.update(userT).set({ role }).where(eq(userT.id, userId)) },
      async setName(userId, name) { await conn.update(userT).set({ name }).where(eq(userT.id, userId)) },
    },
    subscriptions: {
      async getForUser(userId) { const [r] = await conn.select().from(subT).where(eq(subT.userId, userId)); return r ? toSub(r) : null },
      async upsert(sub) {
        const [r] = await conn.insert(subT).values(sub).onConflictDoUpdate({
          target: subT.userId, set: { tier: sub.tier, status: sub.status, stripeCustomerId: sub.stripeCustomerId, currentPeriodEnd: sub.currentPeriodEnd },
        }).returning()
        return toSub(r!)
      },
    },
    roles: {
      async getByName(name) { const [r] = await loadRoles(conn, [name]); return r ?? null },
      async list() { return loadRoles(conn) },
      async upsert(r) {
        // The role row and its assignments must move together: a half-applied
        // save would leave a role holding the wrong permissions.
        return conn.transaction(async (tx) => {
          const [row] = await tx.insert(roleT).values({
            name: r.name, label: r.label, description: r.description,
            fullAccess: r.fullAccess, isSystem: r.isSystem,
          }).onConflictDoUpdate({
            target: roleT.name,
            set: { label: r.label, description: r.description, fullAccess: r.fullAccess, isSystem: r.isSystem, updatedAt: new Date() },
          }).returning()

          // Replace the assignment set. Deleting first keeps this idempotent
          // and lets the caller pass the desired end state rather than a diff.
          await tx.delete(rolePermT).where(eq(rolePermT.roleName, r.name))
          if (r.permissions.length > 0) {
            // A key that is not in the catalog raises a foreign-key violation
            // here — which is the point of the join table.
            await tx.insert(rolePermT).values(
              r.permissions.map((permissionKey) => ({ roleName: r.name, permissionKey })),
            )
          }
          return toRole(row!, [...r.permissions].sort())
        })
      },
    },
    permissions: {
      async list() {
        const rs = await conn.select().from(permT).orderBy(permT.resource, permT.key)
        return rs.map(toPermission)
      },
      async upsert(p) {
        const [row] = await conn.insert(permT).values(p).onConflictDoUpdate({
          target: permT.key,
          set: { label: p.label, description: p.description, resource: p.resource, isSystem: p.isSystem, updatedAt: new Date() },
        }).returning()
        return toPermission(row!)
      },
      async remove(key) { await conn.delete(permT).where(eq(permT.key, key)) },
    },
    // Scope every user-data query: sets app.user_id (Layer 2 RLS) inside a tx; the WHERE filter is Layer 1.
    withUser<T>(userId: string, fn: (repos: DbPort) => Promise<T>): Promise<T> {
      return conn.transaction(async (tx) => {
        await tx.execute(sql`select set_config('app.user_id', ${userId}, true)`)
        return fn(makePort(tx as unknown as Drizzle))
      })
    },
  }
}

/** Scoped, RLS-enforced port (portal + feature use-cases). Always via .withUser for user data. */
export const dbPort: DbPort = makePort(db)
/** Privileged port — bypasses RLS. System/webhook/admin cross-user ONLY (guard with requireAdmin). */
export const dbAdminPort: DbPort = makePort(dbAdmin)
