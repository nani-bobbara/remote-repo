// Email adapter — Resend, implements the domain EmailPort.
// Lazy-constructed client so importing this module is build-safe without a key.
import { Resend } from 'resend'
import type { EmailPort } from '@app/domain'

let _resend: Resend | null = null
function resend(): Resend {
  if (!_resend) {
    const key = process.env.RESEND_API_KEY
    if (!key) throw new Error('RESEND_API_KEY is not set')
    _resend = new Resend(key)
  }
  return _resend
}

export const email: EmailPort = {
  async send(to, template, data) {
    await resend().emails.send({
      from: process.env.EMAIL_FROM ?? 'noreply@example.com',
      to,
      subject: template,
      text: JSON.stringify(data),
    })
  },
}
