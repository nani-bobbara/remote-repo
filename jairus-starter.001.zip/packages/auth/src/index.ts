// @app/auth — request-scoped session resolution + route guards.
// Lives here (not in adapters) because it needs Next.js request headers.
import { cache } from 'react'
import { headers } from 'next/headers'
import { toNextJsHandler } from 'better-auth/next-js'
import { DEFAULT_PORTAL_ROLE } from '@app/config/roles'
import { auth } from '@app/adapters/auth'
import { dbPort } from '@app/adapters/db'
import {
  can,
  ForbiddenError,
  UnauthorizedError,
  PERMISSIONS,
  type Session,
} from '@app/domain'

/** Better Auth route handler — mount at app/api/auth/[...all]/route.ts. */
export const authHandler = toNextJsHandler(auth)

/** Resolve the current session (+ the role's resolved permissions) from request headers.
 *  Cached per request so layout + page share one round-trip. */
export const getSession = cache(async (): Promise<Session | null> => {
  const res = await auth.api.getSession({ headers: await headers() })
  if (!res?.user) return null
  const u = res.user as { id: string; email: string; role?: string | null }
  const role = typeof u.role === 'string' && u.role ? u.role : DEFAULT_PORTAL_ROLE
  const roleDef = await dbPort.roles.getByName(role)
  return {
    userId: u.id,
    email: u.email,
    role,
    permissions: roleDef?.permissions ?? [],
    fullAccess: roleDef?.fullAccess ?? false,
  }
})

/** Require an authenticated user; throws UnauthorizedError otherwise. */
export async function requireUser(): Promise<Session> {
  const session = await getSession()
  if (!session) throw new UnauthorizedError('Authentication required')
  return session
}

/** Require a specific permission (data-driven RBAC; power_user has '*'). */
export async function requirePermission(permission: string): Promise<Session> {
  const session = await requireUser()
  if (!can(session, permission)) throw new ForbiddenError(`Missing permission: ${permission}`)
  return session
}

/** Admin-app gate — any staff role that grants admin:access (power_user always passes). */
export async function requireStaff(): Promise<Session> {
  return requirePermission(PERMISSIONS.ADMIN_ACCESS)
}

export { auth } from '@app/adapters/auth'
