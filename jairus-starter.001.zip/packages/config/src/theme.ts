// Palette identity lives in @app/config, not @app/ui, because @app/ui depends on
// @app/config and not the other way round. Keeping the id union here lets brand.ts
// type-check `brand.palette` without inverting that dependency.

/**
 * Every palette shipped in `@app/ui/src/themes`.
 *
 * The id is used in three places that MUST agree:
 *   1. the filename            `packages/ui/src/themes/<id>.css`
 *   2. the CSS selector        `html[data-palette="<id>"]`
 *   3. the `data-palette`      attribute stamped on <html> by each root layout
 *
 * Declared as an array rather than a bare union so the runtime guard below is
 * derived from the same source — a union and a hand-written validator drift.
 *
 * Adding a palette: add the id here, create the CSS file, register it in
 * `@app/ui` themes/registry.ts, and @import it from `@app/ui/src/styles.css`.
 * `palette-parity.test.ts` fails if any of those drift apart.
 */
export const PALETTE_IDS = [
  'neutral-zinc',
  'industrial-orange',
  'midnight-indigo',
  'forest-emerald',
  'terracotta-sand',
] as const

export type PaletteId = (typeof PALETTE_IDS)[number]

/**
 * Narrow an untrusted value — an environment variable, a query param — to a
 * known palette id.
 *
 * This matters more than it looks: an unknown value is worse than none. No
 * `data-palette` attribute falls back to the default palette, because
 * neutral-zinc also matches `html:not([data-palette])`. A *wrong* attribute
 * matches no selector at all, and the app renders with no tokens.
 */
export function isPaletteId(value: unknown): value is PaletteId {
  return typeof value === 'string' && (PALETTE_IDS as readonly string[]).includes(value)
}

/**
 * Applied when nothing else selects a palette. `neutral-zinc.css` also matches
 * `html:not([data-palette])`, so this value and that CSS fallback must stay in
 * sync — if you change the default, move the fallback selector too.
 */
export const DEFAULT_PALETTE: PaletteId = 'neutral-zinc'
