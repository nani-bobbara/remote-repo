IMAGE GUIDE — CAFE (Maribel & Co.)
==================================
Drop photos here using the filenames referenced in this folder's seed.json.
Missing images show a subtle branded placeholder (nothing breaks).

  cafe-logo.png      Brand logo (round, shown in nav). Optional.
  cafe-hero.jpg      Hero showcase
  cafe-room.jpg      "A little room with big ideas" feature
  cafe-coffee.jpg    Collection: The Coffee Bar
  cafe-brunch.jpg    Collection: All-Day Brunch
  cafe-bakes.jpg     Collection: Fresh Bakes
  cafe-plates.jpg    Collection: Seasonal Plates
  cafe-g1.jpg        Gallery: The coffee bar at open
  cafe-g2.jpg        Gallery: Morning light
  cafe-g3.jpg        Gallery: Today's bakes
  cafe-g4.jpg        Gallery: Corner seating
  cafe-g5.jpg        Gallery: House roast
  cafe-g6.jpg        Gallery: The stack

NOTE: All images are optional. Any missing photo shows a subtle branded
placeholder, so the site looks intentional before you've added a single image.

TIPS
  - Lowercase names, no spaces. Match the "image" paths in seed.json exactly.
  - Landscape, ~1200-1600px wide, under ~400KB each.
  - Images are cropped to fill (object-fit: cover) — keep the subject centered.
  - To use different filenames, just change the "image" values in seed.json.
