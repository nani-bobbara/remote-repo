IMAGE GUIDE — FURNITURE
=======================
Drop photos here using the filenames referenced in this folder's seed.json.
Missing images show a subtle branded placeholder (nothing breaks).

  logo.png                  Brand logo (round, shown in nav). Optional.
  hero-bed.jpg              Hero showcase
  workshop-diwan.jpg        "The Workshop" feature
  product-bed-cart.jpg      Collection: Beds & Bed Carts
  product-diwan.jpg         Collection: Diwan Carts
  product-dining-table.jpg  Collection: Dining Tables
  product-custom.jpg        Collection: Custom Carving

NOTE: All images are optional. Any missing photo shows a subtle branded
placeholder, so the site looks intentional before you've added a single image.

TIPS
  - Lowercase names, no spaces. Match the "image" paths in seed.json exactly.
  - Landscape, ~1200-1600px wide, under ~400KB each.
  - Images are cropped to fill (object-fit: cover) — keep the subject centered.
  - To use different filenames, just change the "image" values in seed.json.
