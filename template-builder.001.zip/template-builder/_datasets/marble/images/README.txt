IMAGE GUIDE — MARBLE (Stoneworks Marble)
========================================
Drop photos here using the filenames referenced in this folder's seed.json.
Missing images show a subtle branded placeholder (nothing breaks).

  logo.png                  Brand logo (round, shown in nav). Optional.
  hero-slab.jpg             Hero showcase
  yard.jpg                  "Every slab chosen" feature
  product-marble.jpg        Collection: Marble Slabs
  product-granite.jpg       Collection: Granite
  product-countertop.jpg    Collection: Countertops
  product-bespoke.jpg       Collection: Bespoke Stonework

NOTE: All images are optional. Any missing photo shows a subtle branded
placeholder, so the site looks intentional before you've added a single image.

TIPS
  - Lowercase names, no spaces. Match the "image" paths in seed.json exactly.
  - Landscape, ~1200-1600px wide, under ~400KB each.
  - Images are cropped to fill (object-fit: cover) — keep the subject centered.
  - To use different filenames, just change the "image" values in seed.json.
