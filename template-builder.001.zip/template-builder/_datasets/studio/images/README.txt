IMAGE GUIDE — STUDIO (Còsca Studio)
===================================
Drop photos here using the filenames referenced in this folder's seed.json.
Missing images show a subtle branded placeholder (nothing breaks).

  studio-logo.png     Brand logo (round, shown in nav). Optional.
  studio-hero.jpg     Hero showcase
  studio-room.jpg     "A calm room that does one thing well" feature
  studio-facial.jpg   Collection: Signature Facials
  studio-hair.jpg     Collection: Hair & Styling
  studio-massage.jpg  Collection: Massage & Bodywork
  studio-brows.jpg    Collection: Brows, Lashes & Details
  studio-g1.jpg       Gallery: The treatment room
  studio-g2.jpg       Gallery: Clean product shelf
  studio-g3.jpg       Gallery: The quiet corner
  studio-g4.jpg       Gallery: Details
  studio-g5.jpg       Gallery: Wash station
  studio-g6.jpg       Gallery: Reception

NOTE: All images are optional. Any missing photo shows a subtle branded
placeholder, so the site looks intentional before you've added a single image.

TIPS
  - Lowercase names, no spaces. Match the "image" paths in seed.json exactly.
  - Landscape, ~1200-1600px wide, under ~400KB each.
  - Images are cropped to fill (object-fit: cover) — keep the subject centered.
  - To use different filenames, just change the "image" values in seed.json.
