<div align="center">

# Buildless Config-Driven Site Starter

**A visual editor that turns JSON into a finished static website.**
Open one HTML file, fill in a form, click **Export site** — you get a folder you can drop on any host.

[![No dependencies](https://img.shields.io/badge/dependencies-0-brightgreen)](#requirements)
[![No build step](https://img.shields.io/badge/build%20step-none-brightgreen)](#requirements)
[![Vanilla JS](https://img.shields.io/badge/stack-HTML%20%C2%B7%20CSS%20%C2%B7%20ES%20modules-blue)](#conventions)
[![License: MIT](https://img.shields.io/badge/license-MIT-lightgrey)](LICENSE)

</div>

```
      _datasets/<business>/seed.json   ──┐
      _themes/<preset>.json            ──┼──►  index.html  ──►  live preview  ──►  Export site
      _layouts/<layout>.html + .css    ──┘      (the editor)      (an iframe)          │
                                                                                       ▼
                                                              my-shop-20260908-1432.zip
                                                              └── index.html   ← real, crawlable HTML
                                                                  behaviors.js
                                                                  images/
```

No npm, no framework, no build step, no server, zero dependencies.

- **Buildless** — everything runs as-is. Nothing to install to author or to deploy.
- **Config-driven** — a business is a `seed.json` plus a folder of images. Change the JSON, change the site.
- **Three independent axes** — pick a **layout**, a **dataset** and a **theme** in any combination.
  The furniture business can wear the marble palette in any layout.
- **Layouts are HTML** — a layout is a real, hand-editable file. Its markup lives in `<template>`
  blocks, not inside JavaScript strings.
- **Exports a baked site** — real crawlable HTML with the CSS, theme and images inlined or bundled.
  The engine does not ship with it.
- **Validated** — one JSON Schema drives both editor autocomplete and runtime checks, so a bad
  config reports exact paths instead of rendering a blank page.
- **Mobile-native** — app-style top bar, slide-down menu, bottom tab bar, safe-area insets.

---

## Table of contents

| | |
|---|---|
| **Start here** | [Quick start](#quick-start) · [How it works](#how-it-works) · [Repository structure](#repository-structure) |
| **Step-by-step guides** | [Pick your task](#guides) · [New to the terminal?](#guide-0--never-used-a-terminal-start-here) |
| &nbsp;&nbsp;*no coding* | [1 · Edit a site and publish it](#guide-1--edit-a-site-and-publish-it) · [2 · Add a business](#guide-2--add-a-new-business-dataset) · [3 · Add a colour theme](#guide-3--add-a-colour-theme) · [4 · Use your own photos](#guide-4--use-your-own-photos) |
| &nbsp;&nbsp;*developer* | [5 · Add a layout](#guide-5--add-a-layout) · [6 · Add a section type](#guide-6--add-a-section-type) · [7 · Add a token, icon or binding](#guide-7--add-a-token-icon-or-binding) |
| **Reference** | [Architecture](#architecture) · [Data model](#data-model) · [Binding language](#the-binding-language) · [Theming & tokens](#theming-and-tokens) · [Paths](#assets-and-path-resolution) · [The editor](#the-editor) · [Export pipeline](#the-export-pipeline) |
| **Keeping it working** | [Tooling & verification](#tooling-and-verification) · [Troubleshooting](#troubleshooting) · [Gotchas](#gotchas) · [Conventions](#conventions) |

---

## Quick start

The editor uses `fetch()` and ES modules, so it must be **served over HTTP** — double-clicking
`index.html` shows an error screen on purpose.

```bash
python -m http.server            # or: npx serve, or VS Code's Live Server extension
```

Open **<http://localhost:8000>** and you are in the editor.

1. Pick a **dataset**, a **layout** and a **theme** from the toolbar.
2. Edit the form on the left — the preview on the right updates as you type.
3. Click **Export site** → `{business-slug}-{timestamp}.zip`.
4. Unzip it, upload the folder to any host. Done.

> [!IMPORTANT]
> **Do not deploy this repository.** It is the authoring tool. Deploy the *exported* folder — see
> [Guide 1](#guide-1--edit-a-site-and-publish-it).

### Requirements

| For | You need |
|---|---|
| Using the editor, exporting a site | Any modern browser + any static file server |
| The three maintenance scripts in `_editor/` | **Node 18+** |
| Everything else | Nothing. No `package.json`, no lockfile, nothing to install |

If you find yourself adding a dependency, that is a design change, not a chore.

---

## How it works

Three things combine, and **each is chosen independently**:

```
  LAYOUT                 ×          DATASET               ×        THEME
  the arrangement                   the content                    the palette
  _layouts/<id>.html                _datasets/<id>/                _themes/<id>.json
  _themes/<id>.css                    seed.json + images/          16 colours, 5 fonts, 3 radii
  "editorial", "bento"              "cafe", "marble", …            "warm-teak", "cool-stone", …
```

Any combination is a URL you can open, bookmark or share:

| URL | Renders |
|---|---|
| `view.html` | the first registered layout, with its `defaultData` |
| `view.html?layout=bento` | that layout, with its `defaultData` |
| `view.html?layout=bento&data=cafe` | `_datasets/cafe/seed.json` in that layout |
| `view.html?layout=bento&data=cafe&theme=cool-stone` | …in a different palette |
| `view.html?data=../my/site.json` | any config path |
| `view.html?layout=bento&editor=1` | preview mode — renders only what the editor posts to it |

A bare word means "a folder under `_datasets/`"; anything with a slash or ending in `.json` is a
path. An unknown `?theme=` warns to the console and keeps the dataset's own palette; an unknown
`?layout=` shows the error box listing the valid ids.

> `?theme=` is a **one-level merge** over the dataset's own `theme` block, so a preset that sets
> only `colors` keeps the dataset's fonts and shape. The editor's theme dropdown is a **full
> replacement** of `cfg.theme` — it is an authoring action that writes into the config, not a
> preview overlay. Both are deliberate.

---

## Repository structure

```
.
├── index.html                  🎛️  THE EDITOR — start here. Live preview, image picker, export.
├── view.html                   🖼️  The render shell. One page renders every combination.
├── config.schema.json          📋  JSON Schema — the section vocabulary. Autocomplete + validation.
│
├── _engine/                    ⚙️  The shared engine. Layout-agnostic; contains no markup.
│   ├── engine.js                   Boot: resolve dataset → fetch → validate → render → wire.
│   ├── bind.js                     The data-* binding language.
│   ├── tokens.js                   The token vocabulary — source of truth for every design token.
│   ├── theme.js                    theme block → CSS custom properties, fonts, theme-color.
│   ├── recolor.js                  Re-tints themeable SVG art to the active theme.
│   ├── paths.js                    Asset + dataset path resolution.
│   ├── icons.js                    Icon name → inline SVG.
│   ├── seo.js                      Title, description, OpenGraph/Twitter, JSON-LD LocalBusiness.
│   ├── validate.js                 Required-field checks derived from config.schema.json.
│   └── behaviors.js                Menu toggle, header scroll, reveal, scrollspy, WhatsApp form.
│
├── _layouts/                   📐  The layouts. <template> blocks only — no shell, JS, CSS or content.
│   ├── layouts.json                REGISTRY — one entry per layout.
│   ├── editorial.html              Filename stem == layout id == _themes/<id>.css
│   └── bento.html
│
├── _themes/                    🎨  Everything visual. One stylesheet per layout, plus token presets.
│   ├── base.css                    Tokens, reset, a11y, loader/error chrome, reveal. (generated region)
│   ├── editorial.css               The editorial design — inherits base.css, extends it.
│   ├── bento.css                   The bento design.
│   ├── themes.json                 REGISTRY — one entry per token preset.
│   └── warm-teak.json  cafe-clay.json  cool-stone.json  calm-sage.json
│
├── _datasets/                  📦  The businesses. Each folder is self-contained and portable.
│   ├── datasets.json               REGISTRY — one entry per dataset.
│   └── <business>/
│       ├── seed.json               The config: theme + business + nav + tabbar + sections + footer.
│       └── images/
│           ├── index.json          REGISTRY — what the editor's image picker lists.
│           └── *.svg               Its artwork.
│
├── _editor/                    🔧  Editor-only. Never loaded by a site page.
│   ├── export.js                   Bakes the live preview into a deployable file set.
│   ├── zip.js                      Store-only ZIP writer.
│   ├── make-tokens.mjs             node — regenerates base.css from tokens.js.
│   ├── make-image-index.mjs        node — rebuilds every images/index.json.
│   └── make-placeholder-images.mjs node — regenerates the placeholder artwork.
│
├── .claude/skills/designing-layouts/
│   ├── SKILL.md                    How to design a layout, and the spec to write first.
│   ├── layout-archetypes.md        Arrangement vocabulary.
│   └── check-layout.mjs            Static conformance checker for a layout.
│
├── LICENSE                     MIT.
└── README.md                   This file.
```

> [!TIP]
> **Folders starting with `_` are the four moving parts**: `_engine` (behaviour), `_layouts`
> (arrangement), `_themes` (looks), `_datasets` (content). If you are extending the project, you
> are almost always adding a file to one of them plus one line to its `REGISTRY`.

<details>
<summary><b>Why every folder has a registry JSON</b></summary>

HTTP has no directory listing, so nothing can discover files on its own. Discovery happens through
manifests: `_layouts/layouts.json`, `_themes/themes.json`, `_datasets/datasets.json`, and one
`images/index.json` per dataset.

- **Add an entry** and the thing appears in the editor's dropdowns with no code change.
- **Skip the entry** and the file still works by URL (`?data=<folder>` renders), but the editor
  cannot list it and the Node scripts ignore it.

A directory index from `python -m http.server` would work locally and break on Netlify, Vercel
or S3 — which is why the manifests exist.

</details>

<details>
<summary><b>What each file is allowed to contain (the invariants)</b></summary>

| Rule | Why |
|---|---|
| **`_engine/` contains no markup** | Only `icons.js` emits HTML, from its own fixed map. |
| **`_layouts/<id>.html` contains no JavaScript, no CSS and no content** | Its design lives in `_themes/<id>.css`; its content comes from whichever dataset the engine hands it. |
| **`_editor/` is never loaded by a site page** | It exists for the editor and for tooling only. |
| **No layout, engine module or stylesheet names a business, dataset or theme** | That is what keeps the three axes independent. `check-layout.mjs` fails the build on violations. |

</details>

---

## Guides

**Most tasks need no coding at all.** Find your task, follow that guide.

| I want to… | Guide | Coding? | Time |
|---|---|---|---|
| Change a site's words, colours, sections and publish it | [Guide 1](#guide-1--edit-a-site-and-publish-it) | None — the editor does it | 15 min |
| Set up a brand-new business in the repo | [Guide 2](#guide-2--add-a-new-business-dataset) | Copy a folder, edit JSON | 20 min |
| Add a new colour palette everyone can reuse | [Guide 3](#guide-3--add-a-colour-theme) | Copy a JSON file | 10 min |
| Replace the placeholder art with real photos | [Guide 4](#guide-4--use-your-own-photos) | One terminal command | 10 min |
| Add a whole new page arrangement | [Guide 5](#guide-5--add-a-layout) | HTML + CSS | 2–4 h |
| Add a new *kind* of section (e.g. "team", "map") | [Guide 6](#guide-6--add-a-section-type) | HTML + CSS + JSON | 1–2 h |
| Add a design token, icon, or binding attribute | [Guide 7](#guide-7--add-a-token-icon-or-binding) | JS | 20 min |

---

### Guide 0 · Never used a terminal? Start here

**One command starts everything.** Open a terminal *in this folder* and run:

<table>
<tr><th>Windows (PowerShell)</th><th>macOS / Linux</th></tr>
<tr><td>

```powershell
python -m http.server
```

</td><td>

```bash
python3 -m http.server
```

</td></tr>
</table>

Leave that window open — it is the server. Go to **<http://localhost:8000>**. To stop it, press
<kbd>Ctrl</kbd>+<kbd>C</kbd> in that window.

<details>
<summary><b>No Python? Two other one-liners</b></summary>

```bash
npx serve            # needs Node installed; it will offer to download `serve`
```

Or install the **Live Server** extension in VS Code, right-click `index.html` → *Open with Live
Server*.

</details>

**Editing JSON without breaking it.** JSON files are just text, but they are fussy. Four rules:

1. Every value is wrapped in `"double quotes"` — except `true`, `false` and plain numbers.
2. Items in a list are separated by commas, and **the last one has no comma**.
3. Curly braces `{ }` and square brackets `[ ]` must stay balanced.
4. Save, then reload the browser tab.

> [!TIP]
> Open the repo folder in **VS Code**. Every `seed.json` starts with
> `"$schema": "../../config.schema.json"`, which gives you autocomplete for every field name and a
> red squiggle the instant something is wrong — with no install. This is the single biggest
> quality-of-life win for a non-developer working in this repo.

**If the browser shows a dark error screen**, it is telling you what it could not read. Jump to
[Troubleshooting](#troubleshooting).

---

### Guide 1 · Edit a site and publish it

> **Coding:** none. **Time:** ~15 minutes. **You need:** a browser, and a host at the end.

#### Steps

1. **Start the server** and open <http://localhost:8000> ([Guide 0](#guide-0--never-used-a-terminal-start-here)).
2. **Choose what you are editing** from the toolbar dropdowns — layout, dataset, theme preset.
   The preview reloads.
3. **Edit the form on the left.** It is grouped into
   *Business · Theme · Navigation · Tab bar · Sections · Footer*, and the preview updates as you
   type — there is no save button and no refresh loop.
   - **Sections:** add, delete, reorder with the ▲▼ buttons, or untick *enabled* to hide one
     without losing its content.
   - **Theme:** colour pickers, a font-pairing dropdown, corner-radius sliders. These edit
     *on top of* whichever preset you applied.
   - **Images:** every image field is a thumbnail picker. It lists the dataset's own images, and
     **Upload…** attaches a file for this session.
4. **Watch the status pill** in the toolbar. `valid` means the config passes every required-field
   check; `N issues` means it does not — hover it to see exactly which ones.
5. **Click Export site.** You get `{business-slug}-{timestamp}.zip`.
6. **Unzip and check it.** Open the `index.html` inside — it should look identical to the preview.
   That file is now plain HTML with no engine in it.
7. **Upload the folder** to any static host:

   | Host | How |
   |---|---|
   | **Netlify** | drag the unzipped folder onto <https://app.netlify.com/drop> |
   | **Vercel** | `vercel deploy` in the folder, or drag-drop in the dashboard |
   | **Cloudflare Pages** | *Create project → Direct upload* |
   | **GitHub Pages** | commit the folder's contents to a `gh-pages` branch |
   | **S3 / any web host** | upload the three entries as-is |

✅ **Check it worked:** the live URL shows your site; the browser tab title is yours (not
"Loading…"); and **View Source** shows your real headings and copy as HTML rather than an empty
`<div id="app">` — that is the difference between the export and the preview, and it is what search
engines and link previews read.

> [!NOTE]
> The exported page still needs JavaScript for three things: the mobile menu, the enquiry form, and
> the scroll-reveal animation (`base.css` starts revealed elements at `opacity:0` and JS adds the
> class that fades them in). The *content* is real HTML either way, which is what matters for
> crawling.

> [!NOTE]
> **Re-exporting is how you change an exported site.** There is no engine in the export to re-read
> a config, by design — edit in the editor and export again.

---

### Guide 2 · Add a new business (dataset)

> **Coding:** copy a folder, edit a JSON file. **Time:** ~20 minutes.
> **Result:** your business appears in the editor's dropdown and renders in *every* layout.

#### Steps

1. **Copy an existing dataset folder.** Pick the one whose sections are closest to what you want.

   ```bash
   cp -r _datasets/cafe _datasets/bikes        # macOS / Linux
   ```
   ```powershell
   Copy-Item -Recurse _datasets/cafe _datasets/bikes    # Windows PowerShell
   ```

   > The folder name is the dataset **id**. Lower-case, no spaces — it becomes `?data=bikes`.

2. **Register it** in [`_datasets/datasets.json`](_datasets/datasets.json) — add one line:

   ```jsonc
   [
     { "id": "furniture", "name": "Raj Enterprises",   "desc": "Teak & Rosewood" },
     { "id": "cafe",      "name": "Maribel & Co.",     "desc": "Coffee · Kitchen" },
     { "id": "bikes",     "name": "Nordic Cycle Works", "desc": "Service & Repairs" }
   ]
   ```

   > [!WARNING]
   > Skip this step and `?data=bikes` still renders, but the editor's dropdown will not list it and
   > both Node scripts will ignore it.

3. **Edit `_datasets/bikes/seed.json`.** Either open the editor and use the form (easier), or edit
   the file directly. The five blocks to change:

   | Block | What to put in it |
   |---|---|
   | `business` | name, tagline, phone, `whatsapp` (full international digits, e.g. `919876543210`), email, about, motto, `seoTitle`, `seoDescription` |
   | `nav` | the header links — `href` values are the `id`s of your sections, like `#collection` |
   | `tabbar` | the mobile bottom bar; mark **exactly one** item `"cta": true` for the centre call button |
   | `sections` | the page itself, in order — see the [section catalog](#section-catalog) |
   | `theme` | the brand palette, or delete the block and apply a preset instead |

4. **Reload the editor** and pick your business from the dataset dropdown.

5. **Add your images** — see [Guide 4](#guide-4--use-your-own-photos).

✅ **Check it worked:** the dropdown lists your business; the status pill says `valid`; and
`view.html?data=bikes&layout=editorial` *and* `view.html?data=bikes&layout=bento` both render it.
Working in every layout is the point — if one breaks, the data is fine and that layout is missing a
`<template data-section>`.

<details>
<summary><b>📄 A complete minimal <code>seed.json</code> to copy (verified valid)</b></summary>

Three sections, no theme block (apply a preset instead), every path relative to its own folder:

```json
{
  "$schema": "../../config.schema.json",

  "business": {
    "name": "Nordic Cycle Works",
    "tagline": "Service & Repairs",
    "logo": "images/logo.svg",
    "phone": "9876543210",
    "whatsapp": "919876543210",
    "email": "hello@nordiccycle.example",
    "about": "A two-person workshop servicing city bikes, road bikes and e-bikes. Same-day tune-ups, honest quotes, no upselling.",
    "motto": "Ride it like it's new.",
    "seoTitle": "Nordic Cycle Works — Bicycle Service & Repairs",
    "seoDescription": "Same-day bicycle tune-ups, brake and gear work, wheel truing and e-bike diagnostics."
  },

  "nav": [
    { "label": "Services", "href": "#collection" },
    { "label": "Visit", "href": "#contact" }
  ],

  "tabbar": [
    { "label": "Home", "href": "#home", "icon": "home" },
    { "label": "Services", "href": "#collection", "icon": "grid" },
    { "label": "Call", "cta": true, "icon": "phone" },
    { "label": "Visit", "href": "#contact", "icon": "pin" }
  ],

  "sections": [
    {
      "type": "hero", "id": "home",
      "badge": "Same-day tune-ups",
      "title": "Your bike,",
      "titleAccent": "properly fixed.",
      "subtitle": "A two-person workshop for <b>city, road and e-bikes</b>. Drop it off in the morning, ride it home the same evening.",
      "image": "images/hero.svg",
      "primaryCta": { "label": "See services", "href": "#collection" },
      "secondaryCta": { "label": "Book a slot", "href": "#contact" },
      "stats": [
        { "value": "24h", "label": "Typical turnaround" },
        { "value": "12y", "label": "In the trade" }
      ]
    },
    {
      "type": "collection", "id": "collection",
      "eyebrow": "What we do",
      "heading": "Workshop services",
      "intro": "Fixed prices, quoted before we start.",
      "items": [
        { "title": "Full service", "desc": "Strip, clean, re-grease, true the wheels, set gears and brakes.", "tag": "From 45", "image": "images/service-full.svg" },
        { "title": "Brakes & gears", "desc": "Cables, pads, hanger alignment and a road test.", "tag": "From 20", "image": "images/service-brakes.svg" },
        { "title": "E-bike diagnostics", "desc": "Battery health, motor error codes and firmware.", "tag": "From 35", "image": "images/service-ebike.svg" }
      ]
    },
    {
      "type": "contact", "id": "contact",
      "eyebrow": "Book it",
      "heading": "Bring it in <em>this week</em>",
      "body": "Message us with the bike and the problem and we'll tell you the price before you come.",
      "formTitle": "Book a service",
      "formOptions": ["Full service", "Brakes & gears", "E-bike diagnostics", "Something else"],
      "formButton": "Send on WhatsApp"
    }
  ],

  "footer": {
    "columns": [
      { "title": "Workshop", "links": [
        { "label": "Services", "href": "#collection" },
        { "label": "Book a slot", "href": "#contact" }
      ]}
    ]
  }
}
```

Two details that matter: a section you link to **needs an `id`** (that is what `#collection`
matches), and inline `<b>` / `<em>` only work in the fields marked as rich-text in the
[section catalog](#section-catalog) — everywhere else the tags would show as visible characters.

</details>

---

### Guide 3 · Add a colour theme

> **Coding:** copy one JSON file, add one line. **Time:** ~10 minutes.
> **Result:** your palette appears in the editor's theme dropdown and works with `?theme=<id>` on
> every layout and dataset.

#### Steps

1. **Copy the closest existing preset** — do not start from a blank file. A preset holds
   **16 colours, 5 font settings and 3 radii**, and it is much faster to retune a coherent palette
   than to invent one:

   ```bash
   cp _themes/cool-stone.json _themes/forest-ink.json
   ```

2. **Change the values.** If you only change five, change these — the rest follow:

   | Key | What it drives | Rule of thumb |
   |---|---|---|
   | `accent` | buttons, links, highlights | your brand colour |
   | `accentBright` | accent **on dark** backgrounds and focus rings | a lighter version of `accent` |
   | `accentSoft` | accent **on light** backgrounds | a darker version of `accent` |
   | `dark` | inverted section backgrounds, `themeColor` | near-black, tinted toward your brand |
   | `bg` | the page background | near-white, tinted the same way |

   Then sanity-check the pairs: `ink`/`muted` are text **on light**, `onDark`/`onDarkDim` are text
   **on dark**. Getting those four wrong is the only way to make text unreadable.

3. **Register it** in [`_themes/themes.json`](_themes/themes.json):

   ```jsonc
   { "id": "forest-ink", "name": "Forest Ink", "desc": "Deep green and warm paper — quiet and natural." }
   ```

   The `id` must equal the filename stem.

4. **Try it.** Reload the editor and pick it from the theme dropdown, or open
   `view.html?theme=forest-ink&data=cafe` directly.

✅ **Check it worked:** it appears in the dropdown; text is readable on both the light and the dark
sections; and the placeholder artwork **changes colour with it** (see
[artwork follows the theme](#artwork-follows-the-theme)).

> [!NOTE]
> **A preset is a starting point, not a live link.** Picking one *copies* its tokens into the
> config, so `seed.json` stays self-contained and portable and every individual value stays
> editable. Editing the preset file later does not reach back into sites already built from it.

<details>
<summary><b>🎨 The full shape of a theme file</b></summary>

Every key is optional — an absent one falls back to the `base.css` default. `shape` is the fastest
way to change the whole feel: `20px`/`12px`/`100px` reads soft and organic, `4px`/`3px`/`4px` reads
sharp and architectural.

```json
{
  "themeColor": "#0e1114",
  "colors": {
    "bg": "#f4f5f7", "bg2": "#e9ebee", "surface": "#ffffff",
    "dark": "#0e1114", "dark2": "#1a1f24", "dark3": "#262d34",
    "ink": "#1a1f24", "muted": "#6b7480",
    "onDark": "#e6eaef", "onDarkDim": "rgba(230,234,239,.66)",
    "accent": "#7d8894", "accentBright": "#aeb8c2", "accentSoft": "#5c6672",
    "secondary": "#2f5d63",
    "line": "rgba(125,136,148,.24)", "lineDark": "rgba(174,184,194,.16)"
  },
  "fonts": {
    "googleFonts": "family=Syne:wght@600;700;800&family=Inter:wght@400;500;600",
    "display": "'Syne',system-ui,sans-serif",
    "sans": "'Inter',system-ui,sans-serif",
    "displayWeight": "700",
    "tracking": "-.02em"
  },
  "shape": { "radius": "4px", "radiusSm": "3px", "radiusPill": "4px" }
}
```

**Fonts:** `googleFonts` is the query part of a Google Fonts `css2` URL — the engine builds the
`<link>` and loads it automatically. Whatever families you name there must match the families in
`display` and `sans`, or the browser falls back to `system-ui`.

</details>

---

### Guide 4 · Use your own photos

> **Coding:** one terminal command. **Time:** ~10 minutes.

The images shipped in `_datasets/*/images/` are **generated placeholders, not photographs** — themed
SVG built from each dataset's palette. Replace them whenever you have real photos; only the
filenames matter.

#### Option A · Through the editor (no terminal)

1. In the form, click any image field's thumbnail → **Upload…** and pick a file.
2. It previews immediately and is bundled into the ZIP on export.

> Attachments live for the browser session only. They are perfect for a one-off export, but they
> are not saved into the dataset folder — for that, use Option B.

#### Option B · Into the dataset folder (permanent)

1. **Drop your files** into `_datasets/<your-business>/images/`.
   Use `.webp` or `.jpg` for photographs, `.svg` for logos and diagrams. Keep names lower-case with
   hyphens: `hero-shopfront.webp`.
2. **Rebuild the manifest** so the editor's picker can see them:

   ```bash
   node _editor/make-image-index.mjs
   ```

   ```
   furniture: 7 images
   cafe: 13 images
   bikes: 4 images        ← yours
   ```

   Hand-edited titles in `index.json` are preserved; only new files get a generated one.
3. **Point the fields at them** — in the editor's picker, or by editing `seed.json`
   (`"image": "images/hero-shopfront.webp"`).

✅ **Check it worked:** the picker lists your files, the preview shows them, and the exported
`images/` folder contains exactly the ones you used and nothing else.

> [!TIP]
> **Paths are relative to the dataset, not the page.** `images/hero.webp` inside
> `_datasets/bikes/seed.json` always means `_datasets/bikes/images/hero.webp`, whichever layout
> renders it. That is what makes a dataset portable. See
> [Assets and path resolution](#assets-and-path-resolution).

<details>
<summary><b>Regenerating the placeholder artwork</b></summary>

```bash
node _editor/make-placeholder-images.mjs
```

It draws every image a dataset's `seed.json` references, coloured from that dataset's own
`theme.colors`, into that dataset's `images/` folder.

> [!CAUTION]
> **It rewrites each `seed.json`'s image paths to the `.svg` files it generates.** Commit your work
> before running it, or you will lose the paths pointing at your real photos.

</details>

---

### Guide 5 · Add a layout

> **Coding:** HTML + CSS. **Time:** 2–4 hours. **Engine changes:** none, ever.

A layout is **`<template>` blocks in `_layouts/<id>.html` plus CSS in `_themes/<id>.css`**. It is a
fragment, not a page — `view.html` owns the shell, the loader, the error box and the boot script.
It ships no content: every string comes from whichever dataset the engine hands it.

```
_layouts/<id>.html      <template data-part> + <template data-section> blocks, nothing else
_themes/<id>.css        the design
_layouts/layouts.json   one entry: { id, name, desc, defaultData }
```

`id` is the filename stem in **both** folders and the value of `?layout=`.

#### Step 1 · Write the spec first (do not skip this)

A layout is ~300 lines of markup plus ~350 of CSS. Guessing the arrangement wrong means rewriting
nearly all of it, so decide on paper:

```
id:            <slug naming the arrangement, not a business, not a number>
purpose:       <what kind of site this serves, which sections carry the weight>
spine:         <flow | tile field | rail + pane | shelf | bleed ladder | long-form measure>
nav:           desktop <top bar | left rail | minimal>   mobile <drawer | tab bar | both>
density:       <airy | compact>
sections:      <all 13, or a deliberate subset — a type with no template is skipped>
diverges from <existing layout> on: <at least three axes>
```

📖 Read [`.claude/skills/designing-layouts/SKILL.md`](.claude/skills/designing-layouts/SKILL.md)
and [`layout-archetypes.md`](.claude/skills/designing-layouts/layout-archetypes.md) before starting.
**A second layout that rearranges nothing has no reason to exist** — name three or more axes it
diverges on.

#### Step 2 · Create the two files

Start from the verified starter below, or copy `editorial.html`/`editorial.css` and rearrange.

<details>
<summary><b>📄 <code>_layouts/starter.html</code> — the smallest layout that passes the checker</b></summary>

Covers all three chrome parts and three section types. `check-layout.mjs` reports
**0 errors, 18 warnings** on it — every warning is `coverage` ("this field exists in the datasets
but nothing binds it"), which is exactly what a deliberate minimal subset should report.

```html
<!-- STARTER — templates only: /view.html owns the page shell; _themes/starter.css owns the design. -->

<template data-part="nav">
 <header class="bar" data-role="header">
  <a class="brand" href="#home"><b data-bind="business.name" data-keep></b></a>
  <nav class="links" data-role="menu" aria-label="Primary">
   <a data-each="nav" href="" data-attr-href="href" data-bind="label" data-keep></a>
  </nav>
  <button class="burger" data-role="burger" aria-label="Menu" aria-expanded="false">≡</button>
 </header>
</template>

<template data-part="footer">
 <footer class="foot">
  <p>© <span data-bind="$.year"></span> <span data-bind="business.name" data-keep></span></p>
  <p data-bind="business.motto"></p>
 </footer>
</template>

<template data-part="tabbar">
 <nav class="tabbar" aria-label="Quick actions">
  <a class="tab" data-each="tabbar" data-role="tab" href="" data-attr-href="href"><i data-if="icon" data-icon="icon"></i><span data-bind="label" data-keep></span></a>
 </nav>
</template>

<template data-section="hero">
 <section class="hero" id="home">
  <h1 data-rich="title" data-keep></h1>
  <p class="sub" data-rich="subtitle"></p>
  <a class="btn" data-if="primaryCta" href="" data-attr-href="primaryCta.href" data-bind="primaryCta.label" data-keep></a>
  <div class="shot"><img src="" alt="" data-img="image" data-alt="title" fetchpriority="high"></div>
 </section>
</template>

<template data-section="collection">
 <section class="pad" id="collection">
  <h2 data-bind="heading"></h2>
  <p class="sub" data-bind="intro"></p>
  <ul class="cards">
   <li class="card" data-each="items" data-stagger>
    <div class="shot"><img src="" alt="" data-img="image" data-alt="title" loading="lazy"></div>
    <h3 data-bind="title"></h3>
    <p data-bind="desc"></p>
    <span class="tag" data-bind="tag"></span>
   </li>
  </ul>
 </section>
</template>

<template data-section="contact">
 <section class="pad" id="contact">
  <h2 data-rich="heading" data-keep></h2>
  <p class="sub" data-rich="body"></p>
  <a class="line" data-if="$.business.phone" href="" data-attr-href="$.telLink"><i data-icon="#phone"></i><span data-bind="$.business.phone"></span></a>
  <div class="form">
   <label for="s-name">Your name</label><input id="s-name" type="text" data-field="name">
   <label for="s-phone">Phone</label><input id="s-phone" type="tel" data-field="phone">
   <div data-if="formOptions"><label for="s-item">What are you looking for?</label>
    <select id="s-item" data-field="item"><option value="">Select…</option><option data-each="formOptions" data-bind="."></option></select></div>
   <label for="s-msg">Details</label><textarea id="s-msg" rows="3" data-field="message"></textarea>
   <button class="btn" data-role="wa-form" data-if="formButton" data-bind="formButton"></button>
   <button class="btn" data-role="wa-form" data-if="!formButton">Send on WhatsApp</button>
  </div>
 </section>
</template>
```

</details>

<details>
<summary><b>🎨 <code>_themes/starter.css</code> — its stylesheet, tokens only</b></summary>

Note what is *not* here: no hex colours (every colour is a `var(--token)`), no `vh` units, no
`outline:none`. All three are hard errors in the checker.

```css
/* STARTER — colours come from var(--token) only, never a literal hex. */

.bar{position:sticky;top:0;z-index:50;display:flex;align-items:center;gap:16px;
     padding:14px clamp(16px,4vw,40px);background:var(--surface);border-bottom:1px solid var(--line)}
.bar.scrolled{box-shadow:0 2px 14px var(--line)}
.brand{font-family:var(--display);font-weight:var(--display-weight);letter-spacing:var(--tracking)}
.links{margin-left:auto;display:flex;gap:18px}
.burger{display:none;margin-left:auto;font-size:1.4rem;color:var(--ink)}

.hero,.pad{max-width:var(--maxw);margin:0 auto;padding:clamp(40px,7vw,96px) clamp(16px,4vw,40px)}
h1{font-family:var(--display);font-weight:var(--display-weight);letter-spacing:var(--tracking);
   font-size:clamp(2rem,6vw,4rem);line-height:1.05}
h2{font-family:var(--display);font-weight:var(--display-weight);letter-spacing:var(--tracking);
   font-size:clamp(1.5rem,3.5vw,2.5rem)}
.sub{color:var(--muted);max-width:60ch;margin-top:12px}
.btn{display:inline-block;margin-top:20px;padding:12px 22px;border-radius:var(--radius-pill);
     background:var(--accent);color:var(--dark);font-weight:600}

.shot{margin-top:24px;border-radius:var(--radius);overflow:hidden;background:var(--bg-2);aspect-ratio:16/10}
.shot img{width:100%;height:100%;object-fit:cover}
.shot.noimg{display:grid;place-items:center;background:var(--bg-2)}
.shot.noimg::after{content:"";width:38%;aspect-ratio:1;border-radius:var(--radius-pill);background:var(--line)}

.cards{list-style:none;margin-top:28px;display:grid;gap:18px;
       grid-template-columns:repeat(auto-fit,minmax(240px,1fr))}
.card{background:var(--surface);border:1px solid var(--line);border-radius:var(--radius);padding:14px}
.card h3{margin-top:12px;font-family:var(--display)}
.card p{color:var(--muted);font-size:.92rem;margin-top:6px}
.tag{display:inline-block;margin-top:10px;padding:3px 10px;border-radius:var(--radius-pill);
     background:var(--accent-soft);color:var(--on-dark);font-size:.72rem}

.line{display:inline-flex;align-items:center;gap:8px;margin-top:18px;color:var(--accent-soft)}
.line svg{width:18px;height:18px}
.form{display:grid;gap:6px;max-width:440px;margin-top:26px}
.form label{font-size:.78rem;color:var(--muted);margin-top:8px}
.form input,.form select,.form textarea{font:inherit;padding:10px 12px;border-radius:var(--radius-sm);
  border:1px solid var(--line);background:var(--surface);color:var(--ink);width:100%}

.foot{background:var(--dark);color:var(--on-dark);text-align:center;
      padding:36px 20px calc(36px + var(--tabbar-h))}
.foot p+p{color:var(--on-dark-dim);margin-top:6px}

.tabbar{display:none}
@media(max-width:820px){
  .links{position:fixed;inset:0 0 auto;flex-direction:column;gap:0;padding:80px 24px 24px;
         background:var(--surface);transform:translateY(-100%);transition:.3s;min-height:50dvh}
  .links.open{transform:none}
  .links a{padding:14px 0;border-bottom:1px solid var(--line)}
  .burger{display:block}
  .tabbar{position:fixed;left:0;right:0;bottom:0;z-index:60;display:flex;
          height:calc(var(--tabbar-h) + var(--safe-b));padding-bottom:var(--safe-b);
          background:var(--surface);border-top:1px solid var(--line)}
  .tab{flex:1;display:grid;place-items:center;gap:2px;font-size:.66rem;color:var(--muted)}
  .tab svg{width:20px;height:20px}
  .tab.active{color:var(--accent-soft)}
}
```

</details>

#### Step 3 · Register it

In [`_layouts/layouts.json`](_layouts/layouts.json):

```jsonc
{
  "id": "starter",
  "name": "Starter",
  "desc": "Minimal single-column arrangement — a base to build on.",
  "defaultData": "furniture"
}
```

`defaultData` is which dataset shows off the arrangement when no `?data=` is given. Describe the
**arrangement**, not a business — "Bento Grid", not "Café Layout".

#### Step 4 · Check it

```bash
node .claude/skills/designing-layouts/check-layout.mjs starter
```

```
starter — PASS (with warnings)  (0 errors, 18 warnings)
  warn   [coverage] "hero": field "badge" exists in the datasets but nothing in this template binds it
  ...
  browser pass should show:
    ?data=cafe: 3 <section> in #app, 7 console warning(s) for marquee, feature, gallery, …
```

**Exit code 1 on any ERROR. Warnings are judgement calls** — fix them or be able to say why not.
The checker encodes what the engine, exporter and editor require but do not enforce; those failures
are silent at runtime, which is why they are worth a script.

#### Step 5 · Browser pass

The checker is static — it cannot see the page. Open
`view.html?layout=starter&data=<each dataset>` and confirm:

- [ ] Every section renders, and the console shows only the expected "no template for section type"
      warnings the checker predicted.
- [ ] At a phone width: the menu opens and closes, the tab bar highlights the section you are
      looking at, nothing overflows sideways.
- [ ] The enquiry form composes a WhatsApp message with your name, phone and details in it.
- [ ] Keyboard <kbd>Tab</kbd> shows a visible focus ring on every link, button and input.
- [ ] Switch `?theme=` — nothing hardcoded stays behind.
- [ ] **Export from the editor and open the exported `index.html`.** The baked page is a different
      artifact from the preview and it is what ships.

#### The rules a layout must follow

| Rule | Why |
|---|---|
| **Only `<template data-part="nav\|footer\|tabbar">` and `<template data-section="<type>">`** | Markup outside a template never renders. |
| **Exactly one root element per section template** | `engine.js` sets the section `id` on the first one; a second root silently loses it. |
| **No `<script>`, no `<style>`, no `<link>`, no page scaffolding** | The shell is `view.html`; the design is `_themes/<id>.css`. |
| **No literal colours in the stylesheet** | Use `var(--token)`, or theme switching breaks. |
| **No business, dataset or theme names anywhere** | A layout renders *any* dataset. |
| **`dvh`/`svh`/`lvh`, never `vh`** | Mobile browser chrome resizes the viewport. |
| **Style `.noimg`** | `bind.js` adds that class to an image's parent when the photo is missing. |
| **Exactly one `<h1>`**, on the hero headline | Document outline. |

**Behaviour is declared, not scripted.** Wanting a `<script>` in a layout means you want a new
`data-*` binding in [`_engine/bind.js`](_engine/bind.js). Drop these hooks and the engine wires
them; omit one and that feature is simply absent:

| Hook | Gets |
|---|---|
| `data-role="header"` | `.scrolled` toggled past 40px of scroll |
| `data-role="burger"` + `data-role="menu"` | menu toggle (a **pair** — neither works alone), `aria-expanded` updated |
| `data-role="tab"` | `.active` from the scrollspy |
| `data-role="wa-form"` | click → composes the WhatsApp/mailto enquiry |
| `data-role="reveal"` or `class="reveal"` | `.in` when scrolled into view |
| `data-field="name\|phone\|item\|message"` | read into the enquiry message |

---

### Guide 6 · Add a section type

> **Coding:** JSON Schema + HTML + CSS. **Time:** 1–2 hours. **Engine changes:** none.

This is the widest change in the repo, because a new type must become known to the schema, the
layouts, the styles and the editor. Say you are adding `team`.

#### Step 1 · Teach the schema about it

In [`config.schema.json`](config.schema.json), three edits:

1. Add the name to `$defs.section.properties.type.enum`:

   ```jsonc
   "enum": ["hero","marquee","feature","collection","specs","process","banner","trust",
            "contact","gallery","testimonials","faq","pricing","team"]
   ```

2. Add an `allOf` entry describing its fields and which are required:

   ```jsonc
   { "if": { "properties": { "type": { "const": "team" } } }, "then": {
     "required": ["items"],
     "properties": {
       "eyebrow": { "type": "string" },
       "heading": { "type": "string" },
       "intro":   { "type": "string" },
       "items": { "type": "array", "items": {
         "type": "object",
         "properties": {
           "name":  { "type": "string" },
           "role":  { "type": "string" },
           "note":  { "type": "string" },
           "image": { "type": "string" }
         },
         "additionalProperties": false
       }}
     }
   }}
   ```

> [!IMPORTANT]
> **This step *is* the runtime validation.** [`validate.js`](_engine/validate.js) derives its
> required-field rules from exactly this `allOf` (`if.properties.type.const` → `then.required`), so
> there is no second copy to keep in sync. Add the rule here and `view.html` enforces it.

#### Step 2 · Add a template to each layout that should support it

In `_layouts/editorial.html` (and any other layout you want it in):

```html
<template data-section="team">
 <section class="pad" id="team">
  <span class="eyebrow" data-bind="eyebrow"></span>
  <h2 data-bind="heading"></h2>
  <p class="sub" data-bind="intro"></p>
  <ul class="team">
   <li data-each="items" data-stagger>
    <div class="shot"><img src="" alt="" data-img="image" data-alt="name" loading="lazy"></div>
    <b data-bind="name"></b>
    <small data-bind="role"></small>
    <p data-bind="note"></p>
   </li>
  </ul>
 </section>
</template>
```

**Layouts you skip keep working** — a type present in the data with no matching template is skipped
with a `console.warn` and the rest of the page still renders. That is what makes this change
incremental instead of a migration.

#### Step 3 · Style it

Add the rules to `_themes/<id>.css` for each layout you touched. Tokens only.

#### Step 4 · Add it to the editor

In [`index.html`](index.html), two constants near the top of the `<script>`:

- **`SECTION_TEMPLATES`** — the starter object the *Add section* dropdown inserts. Give every field
  a short, obviously-placeholder value.
- **`REQUIRED`** — `team: ['items']`, matching the schema's `required`.

> [!WARNING]
> **These two are a hand-maintained second copy of the schema's rules.** Skip this step and the type
> works in `view.html` but cannot be added in the editor, and the editor's status pill will disagree
> with the renderer about what is valid. See [Gotchas](#gotchas).

#### Step 5 · Use it and check it

Add a `team` section to a dataset, then:

```bash
node .claude/skills/designing-layouts/check-layout.mjs --all
```

✅ **Check it worked:** the type appears in the editor's *Add section* dropdown; the status pill goes
red if you clear a required field; every layout either renders it or logs one clean warning; and it
survives an export.

---

### Guide 7 · Add a token, icon or binding

> **Coding:** JS. **Time:** ~20 minutes each.

<details open>
<summary><b>Add a design token</b></summary>

[`_engine/tokens.js`](_engine/tokens.js) is the single source of truth — `base.css`,
`config.schema.json`, `theme.js` and the editor's controls all derive from it.

1. Add a row to `TOKENS`:

   ```js
   { group: 'shape', key: 'radiusLg', css: '--radius-lg', value: '32px', note: 'Large corner radius — feature panels.' },
   ```
   `group` is which `theme.<group>` block carries it; `null` means engine-owned (a theme cannot set
   it — that is how `--maxw`, `--tabbar-h` and `--safe-b` work).

2. Regenerate:

   ```bash
   node _editor/make-tokens.mjs
   ```
   ```
   wrote _themes/base.css
   ```

3. **Hand-add the key** to `config.schema.json` under
   `$defs.theme.properties.<group>.properties`. The generator *validates* that file rather than
   rewriting it — JSON has no comment syntax to scope a generated region — so it will tell you
   exactly what is missing and exit non-zero.

4. Add the same key to every `_themes/*.json` preset if it should be part of a complete palette.

✅ `node _editor/make-tokens.mjs --check` prints
`tokens: base.css and config.schema.json match _engine/tokens.js`.

</details>

<details>
<summary><b>Add an icon</b></summary>

1. Add one entry to `ICONS` in [`_engine/icons.js`](_engine/icons.js) — a 24×24 path designed for
   `fill:none; stroke:currentColor`:

   ```js
   clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
   ```
2. Add the name to `$defs.icon.enum` in `config.schema.json`.
3. Add the name to `ICON_NAMES` in `index.html` so the editor's icon dropdown offers it.

> `icons.js` is the **only** place the engine generates HTML, and only from this fixed map. Never
> add a path that interpolates anything a config can supply.

</details>

<details>
<summary><b>Add a binding attribute</b></summary>

In [`_engine/bind.js`](_engine/bind.js):

1. Handle it in `applyOne` — or in `bindElement` if it controls repetition, like `data-each`.
2. **Return `false` if the element was removed or replaced**, so descent into its children stops.
3. **Remove the attribute after use**, so it never reaches the rendered output.
4. Document it in the module header **and** in [the table below](#the-binding-language).
5. Preserve the safety rule: the engine never assigns `innerHTML` from data.

</details>

<details>
<summary><b>Add a behaviour hook</b></summary>

In [`_engine/behaviors.js`](_engine/behaviors.js):

1. Look the element up **by `data-role` only** — never by class or id, which belong to layouts.
2. **No-op when it is absent**, so layouts that do not declare the hook keep working.
3. Document the role in the `CONTRACT C` header.
4. Remember the exported page re-runs `wireUp`, and that `bake()` passes it only `business.name`,
   `whatsapp` and `email` — a hook needing more config than that needs the exporter updated too.
5. Keep the file **import-free**: the exporter turns it into a classic script by deleting the
   `export` keyword, and an `import` would break every exported site.

</details>

---

# Developer reference

## Architecture

### The render pipeline

[`_engine/engine.js`](_engine/engine.js) is the only module a layout page loads. `boot()` runs in
this order, and every step fails into the error box rather than a blank page:

1. **Fetch `_layouts/layouts.json`.** Empty or unreadable → error box; there is no fallback layout.
2. **Resolve the layout** — `?layout=` if given, else `registry[0]`. Unregistered id → error box
   listing the valid ids.
3. **`loadLayout(id)`** appends `_themes/<id>.css` **after** `base.css` (design overrides
   foundation, never the reverse) and *awaits* it — rendering into an unstyled document would
   flash. Then it fetches `_layouts/<id>.html`, parses it with `DOMParser`, and imports every
   `template[data-part]` / `template[data-section]` into `document.body`.
4. **`?editor=1` branch.** Sets `data-editor="1"` on `<html>`, subscribes to `message`, posts
   `{__siteReady:true}` to the parent, and **returns without fetching any dataset**.
5. **Resolve the dataset** via [`resolveData`](_engine/paths.js#L22), fetch it, then
   `loadRequired(config.schema.json)` + `validateConfig`. Invalid → the error list, by path.
6. **`withTheme`** layers `?theme=` over `cfg.theme`.
7. **`render(cfg, dataUrl)`.**

`render()` then:

1. `applyTheme(cfg.theme)` → CSS custom properties on `:root`, Google Fonts `<link>`,
   `meta[theme-color]`.
2. `buildRoot(cfg)` → the `$.` globals: `business`, `waLink`, `telLink`, `mailLink`, `initial`,
   `year`.
3. `applySeo(cfg.business, baseUrl)` → title, description, OG/Twitter, JSON-LD.
4. Clears `#app`, then places `data-part="nav"`, every enabled section in order, then
   `data-part="footer"` and `data-part="tabbar"`.
5. Per section: skip `enabled: false`; find `template[data-section="<type>"]`; **a type with no
   template is skipped with a `console.warn` and the rest of the page still renders**. The cloned
   fragment's first element gets `id = sec.id`.
6. `wireUp(#app, $root)` attaches behaviour, then the loader fades out.

`render()` is **idempotent and re-callable** — that is what makes the editor's live preview work.
Anything you add to it must update in place rather than append (see how `seo.js` looks up each meta
tag before creating it, and how `theme.js` guards against a duplicate font `<link>`).

The one hardcoded content behaviour in the engine is the FAQ's first `<details open>`: there is no
clean declarative form for "first child only". A *second* special case is a signal you want a new
binding attribute instead.

### Module responsibilities

| Module | Owns | Must never |
|---|---|---|
| `engine.js` | boot order, layout loading, section dispatch | know a section's fields |
| `bind.js` | the `data-*` language, scope resolution | assign `innerHTML` from data |
| `tokens.js` | the token vocabulary and its defaults | be duplicated — it is imported, not copied |
| `theme.js` | config `theme` → CSS custom properties | restate the token map |
| `recolor.js` | re-tinting `data-tokens` SVG art | touch a file with no `data-tokens` |
| `paths.js` | asset + dataset URL resolution | resolve an asset against the page URL |
| `icons.js` | name → inline SVG, from a fixed map | interpolate anything a config supplies |
| `seo.js` | head metadata and JSON-LD | emit config data as markup |
| `validate.js` | required-field checks | hold a second copy of the rules |
| `behaviors.js` | menu, scroll, reveal, scrollspy, form | name a class or id owned by a layout |

### The three contracts

Everything a layout author needs is one of three fixed interfaces, each documented in the header of
its own module — read those first when changing behaviour.

| Contract | Defined in | What it fixes |
|---|---|---|
| **Binding** | [`_engine/bind.js`](_engine/bind.js) | the `data-*` attributes, path syntax and scope rules |
| **Tokens** (`CONTRACT B`) | [`_engine/tokens.js`](_engine/tokens.js) | every design token: config key, CSS var, default |
| **Behaviour** (`CONTRACT C`) | [`_engine/behaviors.js`](_engine/behaviors.js) | the `data-role` / `data-field` hooks the engine wires |

A layout consumes contracts; it never extends them.

## Data model

```jsonc
{
  "$schema": "../../config.schema.json",   // editor autocomplete, no install
  "theme":    { /* themeColor, colors, fonts, shape — see Theming */ },
  "business": { /* name, tagline, logo, phone, whatsapp, email, about, motto, seo* */ },
  "nav":      [ { "label": "…", "href": "#…" } ],
  "tabbar":   [ { "label": "…", "href": "#…", "icon": "home", "cta": true } ],
  "sections": [ { "type": "hero", "id": "home", "enabled": true, /* … */ } ],
  "footer":   { /* columns: [ { title, links: [ { label, href } ] } ] */ }
}
```

`additionalProperties: false` at the root and on most `$defs` — an unknown key is a schema error in
your editor, though the runtime checker only enforces required fields.

`sections` is an ordered array. Reorder freely, or set `"enabled": false` to hide one. A section's
`id` becomes the rendered element's `id`, which is what `nav`/`tabbar` anchors and the scrollspy
match against — **a section you link to needs an `id`**. Mark exactly one `tabbar` item
`"cta": true` for the centre call/WhatsApp button.

### Section catalog

`*` marks fields required for that type. **Bold** fields carry inline markup in the bundled
datasets, so a layout must bind them with `data-rich`, not `data-bind`. See
[`config.schema.json`](config.schema.json) for the complete field list.

| `type`        | Purpose                                   | Key fields |
|---------------|-------------------------------------------|------------|
| `hero`        | Top banner with headline, image, stats    | `title`*, `titleAccent`, **`subtitle`**, `image`, `primaryCta`, `stats`, `floatCards` |
| `marquee`     | Scrolling keyword strip                    | `items`* |
| `feature`     | Image + text + feature list ("about")      | **`heading`***, `body`, `image`, `stamp`, `features` |
| `collection`  | Product / service cards (supports `wide`)  | `heading`, `intro`, `items`* (`title`, `desc`, `tag`, `image`, `wide`) |
| `specs`       | Two comparison cards (materials, tiers)    | **`heading`**, `items`* (`title`, `swatch`, `body`, `points`) |
| `process`     | Numbered step cards                        | `heading`, `steps`* (`title`, `desc`) |
| `banner`      | Full-width slogan band                     | **`text`*** |
| `trust`       | Row of icon + label trust badges           | `heading`, `items`* (`icon`, `title`, `note`) |
| `gallery`     | Responsive image grid                      | `heading`, `items`* (`image`, `caption`) |
| `testimonials`| Customer quote cards                       | `heading`, `items`* (`quote`, `author`, `role`, `rating`) |
| `faq`         | Accordion (native, keyboard-accessible)    | `heading`, `items`* (`q`, `a`) |
| `pricing`     | Tiered plan / package cards                | `heading`, `items`* (`name`, `price`, `unit`, `features`, `featured`, `cta`) |
| `contact`     | Contact details + WhatsApp enquiry form    | **`heading`***, `body`, `formOptions`, `formButton` |

**Icons** (any `icon` field): `phone, mail, pin, truck, shield, shieldcheck, tools, tree, box,
check, arrow, star, home, grid, info, sparkle`.

### Validation

Two layers, one source:

- **Authoring time.** `"$schema": "../../config.schema.json"` gives field autocomplete and inline
  errors in VS Code and anything else that speaks JSON Schema. No install.
- **Runtime.** [`validate.js`](_engine/validate.js) is a purpose-built checker, *not* a JSON-Schema
  engine — that keeps the site zero-dependency. Its per-type required-field rules are **derived**
  from `config.schema.json`'s `$defs.section.allOf`, so there is no second copy to drift. If the
  schema cannot be fetched, every type is accepted and only the structural checks run.

```
sections[3]: unknown type "gallry" — did you mean "gallery"?
sections[0] (hero): missing required field "title"
```

## The binding language

[`bind.js`](_engine/bind.js) clones a template and fills it in. Order within an element:
`data-if` → `data-attr-*`/`data-class-*`/`data-style-*` → `data-icon` → `data-img` → `data-stars` →
`data-text` → `data-rich` → `data-bind`.

| Attribute | Effect |
|---|---|
| `data-bind="path"` | sets text content; **removes the element** when the value is empty |
| `data-keep` | opt out of that removal |
| `data-text="path"` | replaces the element with a bare text node, so bound text can sit beside an icon |
| `data-rich="path"` | allowlisted inline markup (`b`, `strong`, `em`, `i`, `br`, `span`, `small`, `u`, `mark`), rebuilt node by node with no attributes copied |
| `data-attr-<name>="path"` | sets any attribute (`data-attr-href`, `data-attr-src`…) |
| `data-class-<name>="path"` | adds that class when the path is truthy |
| `data-style-<prop>="path"` | sets that CSS property |
| `data-if="path"` / `data-if="!path"` | removes the element when falsy / truthy |
| `data-each="path"` | clones **this element** once per item, in place |
| `data-stagger` / `data-stagger="d1"` | on a `data-each` element: adds `reveal`, then `d1`…`d4` by index — or the given class on every item after the first |
| `data-icon="path"` or `"#name"` | replaces the element with an inline SVG (`#` = literal name) |
| `data-img="path"` | sets src (resolved against the dataset), alt, and the placeholder fallback |
| `data-alt="path"` | alt-text source for `data-img` |
| `data-stars="path"` | N → N filled stars plus an accessible label |
| `data-role` / `data-field` | behaviour hooks — see [`behaviors.js`](_engine/behaviors.js) |

**Paths and scope.** A bare path resolves against the current scope. `@.` reaches the enclosing
section, `$.` reaches globals, `.` is the current item (for arrays of plain strings), and
`$index` / `$n` / `$nn` are the repeat counters — 0-based, 1-based, and 1-based zero-padded to two
digits. Globals: `$.business.*`, `$.waLink`, `$.telLink`, `$.mailLink`, `$.initial`, `$.year`.

**Emptiness is a rendering decision.** `null`, `''`, `false` and `[]` are all empty; an empty
`data-bind` removes its element, so an optional field needs no `data-if`. Use `data-keep` where the
element must survive.

**Escaping is not something a layout author can forget.** The engine never assigns `innerHTML` from
data: `data-bind` sets `textContent`, attributes are set one at a time, `data-rich` *rebuilds* an
allowlisted subset of inline elements copying no attributes, `alt`/`title` are flattened to plain
text, and JSON-LD goes out through `textContent`. If you add a binding, hold that line.

**The layout owns loading hints.** `loading`, `fetchpriority` and `decoding` go on the `<img>` in
your template; the engine supplies only `src`, `alt` and the error fallback. A missing image drops
the `<img>` and adds `.noimg` to its parent, so your stylesheet must style `.noimg`.

## Theming and tokens

### `_engine/tokens.js` is the source of truth

One table defines every token: which `theme.<group>` block carries it, the config key, the CSS
custom property, the default, and the schema description. Everything else derives from it:

```
_engine/tokens.js
   ├── _themes/base.css        GENERATED — the :root block between @tokens markers
   ├── config.schema.json      VALIDATED — theme.* keys must match (hand-formatted, so
   │                           make-tokens.mjs reports drift instead of rewriting)
   ├── _engine/theme.js        imported via mapFor(group) — never copied
   └── the editor's controls   which pickers to render
```

```bash
node _editor/make-tokens.mjs            # rewrite base.css, validate the schema
node _editor/make-tokens.mjs --check    # verify only; non-zero exit on drift
```

Tokens with `group: null` (`--maxw`, `--tabbar-h`, `--safe-b`) are **engine-owned**: layouts read
them, themes cannot set them.

### Artwork follows the theme

Generated placeholder art carries `data-tokens="role:hex;…"` on its root. CSS cannot reach inside an
SVG loaded through `<img src>` — it is an isolated document — so art with baked-in colours would
clash the moment you switched themes. [`recolor.js`](_engine/recolor.js) fetches those files,
substitutes the active theme's colour for each role, and serves the result as a `data:` URI:

- only `.svg` files are considered, and only if they declare `data-tokens`;
- substitutable roles are `dark`, `dark2`, `accent`, `secondary`, `onDark` (`RECOLOR_ROLES`);
- results are cached per `url + theme signature`, because the editor re-renders on every keystroke;
- it **never rejects** — a failed re-tint falls back to the original URL;
- `bind.js` records the pre-tint URL in `data-img-src`, which is how the exporter turns a `data:`
  URI back into a bundled file.

Files without `data-tokens` — every real photograph — are left untouched.

## Assets and path resolution

**A relative asset path in a config resolves against that config's own URL, not the page's.** That
single rule ([`paths.js`](_engine/paths.js)) is what makes a dataset portable.

| Input | `resolveAsset` |
|---|---|
| `images/hero.svg` | resolved against the config URL |
| `/assets/hero.jpg`, `https://…`, `//cdn/…`, `blob:…`, `data:…` | passed through untouched |
| `''` / `null` | empty → the `<img>` is dropped and `.noimg` set on the parent |

| `?data=` | `resolveData` |
|---|---|
| absent | `_datasets/<layout.defaultData>/seed.json` |
| `cafe` (bare word, no slash, no `.json`) | `_datasets/cafe/seed.json` |
| `../my/site.json`, `foo/bar.json` | that path, relative to the repo root |

Because the `blob:` URLs the editor uses for freshly attached images pass straight through, image
attachment needed no engine change at all.

## The editor

[`index.html`](index.html) is a single self-contained page: inline CSS, one `<script type=module>`
importing only `_editor/zip.js` and `_editor/export.js`. The form is **generated from the config's
own shape** — `renderField` dispatches on value type and key name, so a hex string becomes a colour
picker, `icon` becomes an icon select, `image`/`logo` become a thumbnail picker, a long string
becomes a textarea, and a string array becomes one-per-line.

### The live-preview protocol

```
editor                                            view.html?layout=<id>&editor=1
  │  iframe src = view.html?…&editor=1  ──────────►
  │                                                sets <html data-editor="1">
  │  ◄──────────────  { __siteReady: true }        loads layout, fetches NO dataset
  │  { __siteConfig: true, config, baseUrl } ─────► render(config, baseUrl)
  │  …debounced 120ms on every keystroke ─────────► render() again, in place
```

Two consequences worth knowing:

- The editor supplies `baseUrl` with every message, because preview mode never fetched a config and
  so has no URL of its own to resolve images against.
- In editor mode `wireUp` **does not strip** `data-role` attributes — the exporter bakes that DOM
  and re-runs `wireUp` on the baked page, so the hooks must survive. On a normal page they are
  removed after wiring.

A config opened by file picker or drag-drop has no folder of its own, so its image library is empty
and unattached images show the placeholder.

## The export pipeline

```
maribel-co-20260823-1432/
  index.html      the whole page — content, CSS, theme, SEO meta and JSON-LD inline
  behaviors.js    menu, scrollspy, reveal, WhatsApp form
  images/         the artwork it uses
```

The click handler in `index.html` gathers the inputs; [`_editor/export.js`](_editor/export.js)
`bake()` does the work on a **clone** of the preview document:

1. Fetch every referenced image that is not an attachment, from the dataset folder. Anything
   unfetchable is confirmed with the user first — the exported site would show a placeholder there.
2. Fetch `_themes/base.css`, `_themes/<layoutId>.css` and `_engine/behaviors.js` as text.
3. `bake()`:
   1. Remove engine scaffolding — `#loader`, `#errbox`, every `<template data-part|data-section>`
      (already rendered into `#app`; shipping them would roughly double the page), every
      `<script type=module>`, `data-editor`, and all comments.
   2. Clear `.reveal.in`, so the animation actually plays on the real site.
   3. Rewrite image `src`s to `images/<name>`. Re-tinted art is decoded back out of its `data:` URI
      via `data-img-src` and written as a real file, **as themed**.
   4. Inline `base.css` (minus its `@export-strip` region, which styles the loader and error box
      that no longer exist) and the layout stylesheet into one `<style>`, and drop the `<link>`s.
      The Google Fonts link stays — it is a real external dependency.
   5. Append `behaviors.js` plus a boot call carrying the three business fields `wireUp` reads.
      `export function` is rewritten to `function` so it works as a classic script — an ES module
      would be CORS-blocked from `file://`.
4. [`zip.js`](_editor/zip.js) writes a store-only (method 0) ZIP. No compression: an export is a few
   small text files plus already-compressed images, so deflate would buy little and cost either a
   dependency or a second implementation.

The result is **baked, not config-driven**: no engine, no `<template>` blocks, no config fetch. Real
HTML from the first byte — it needs no server logic, opens from `file://`, and is fully crawlable,
which the live `view.html` preview is not.

`.gitignore` already ignores `/*-20??????-????/`, so an export dropped in the repo root stays out of
git.

---

## Tooling and verification

| Command | Purpose |
|---|---|
| `python -m http.server` | serve the repo (the editor needs HTTP) |
| `node _editor/make-tokens.mjs` | regenerate `base.css` from `tokens.js`, validate the schema |
| `node _editor/make-tokens.mjs --check` | verify without writing; exits non-zero on drift |
| `node _editor/make-image-index.mjs` | rebuild every dataset's `images/index.json` |
| `node _editor/make-placeholder-images.mjs` | regenerate the placeholder artwork ⚠️ rewrites `seed.json` image paths to `.svg` |
| `node .claude/skills/designing-layouts/check-layout.mjs --all` | static conformance check on every layout |

`check-layout.mjs` encodes what the engine, exporter and editor require but do not enforce — the
failures it catches are silent at runtime. Rule families: `files`, `registry`, `fragment`, `nojs`,
`sections`, `rich`, `coverage`, `hooks`, `a11y`, `tokens`, `mobile`, `css`, `modern`, `distinct`,
`axes`, `agnostic`. It learns which fields carry inline markup from the bundled datasets rather than
guessing. **Exit code 1 on any ERROR; WARNs are judgement calls.**

There is no automated browser test — see the [browser-pass checklist](#step-5--browser-pass) in
Guide 5, and run it before calling any engine or layout change done.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Dark screen: *"Couldn't load site content"* | opened from `file://`, or a path in the error list is wrong | serve over HTTP; check the paths it names |
| *"is not a registered layout — try one of: …"* | `?layout=` id has no `_layouts/layouts.json` entry | add the entry, or use a listed id |
| Editor toolbar shows **(no datasets)** / **(no layouts)** | a registry JSON is missing or malformed | hover the red status pill for the exact error; validate the JSON |
| A business renders by URL but is missing from the dropdown | not registered in `_datasets/datasets.json` | add the one-line entry |
| An image shows a plain shape instead of a photo | the file is missing, or the field's path is wrong | check the path is relative to the *dataset* folder; run `make-image-index.mjs` |
| Uploaded images vanished after a reload | attachments are session-only | put the files in the dataset's `images/` folder ([Guide 4](#guide-4--use-your-own-photos)) |
| A section is in the JSON but not on the page | `"enabled": false`, or that layout has no template for the type | untick/enable it; check the console for *"layout has no template for section type"* |
| Visible `<b>` or `<em>` characters in the text | a rich-text field bound with `data-bind` | bind it with `data-rich` (see the **bold** fields in the [catalog](#section-catalog)) |
| Tab bar highlights nothing; nav links jump nowhere | the target sections have no `id` | add `"id": "collection"` etc. to those sections |
| Status pill says `N issues` | required fields are empty | hover it — it lists each one by path |
| Exported page is unstyled | the layout id, its `_themes/<id>.css` filename, or the registry entry disagree | make all three the same stem |
| Exported page has no fonts | `googleFonts` names families that `display`/`sans` do not use | make them match |
| Theme switch leaves some colours behind | a literal hex in the layout stylesheet | replace it with `var(--token)`; the checker finds these |

## Gotchas

- **The editor keeps its own copy of the section rules.** `SECTION_TEMPLATES` and `REQUIRED` in
  `index.html` are hand-maintained, while `view.html` derives its rules from `config.schema.json`.
  Add a section type or a required field and you must update both, or the editor and the renderer
  will disagree about what is valid. (Deriving the editor's copy from the schema too is the obvious
  fix and has not been done.)
- **`make-placeholder-images.mjs` edits your data.** It rewrites each `seed.json`'s image paths to
  the `.svg` files it generates. Commit before running it.
- **Both Node scripts iterate `_datasets/datasets.json`.** An unregistered dataset folder is
  invisible to them, even though `?data=<folder>` renders it.
- **The layout stylesheet path is load-bearing.** `engine.js` appends `_themes/<id>.css` and the
  exporter matches on that exact relative href to inline it. Rename one without the other and the
  export silently ships an unstyled page.
- **`_engine/behaviors.js` must stay import-free.** The exporter turns it into a classic script by
  deleting the `export` keyword.
- **`render()` runs repeatedly.** Anything that appends to `<head>` or `<body>` needs a guard, or
  the editor preview accumulates duplicates over a session.
- **Section templates need exactly one root element**, or the section `id` lands on the wrong node
  and both anchors and scrollspy break.
- **`vh` units are wrong on mobile** — use `dvh`/`svh`/`lvh`.

## Conventions

- **Zero dependencies, no build step.** Both are load-bearing features, not accidents.
- **Vanilla ES modules, no transpilation.** Evergreen browsers; Node 18+ for the `.mjs` scripts.
- **Comments explain *why*, not what.** Every module opens with a header stating what it owns and
  which rule it exists to enforce. Match that when you add one.
- **Generate, never duplicate.** When a value must appear in two files, one generates or validates
  the other (`tokens.js` → `base.css`; `config.schema.json` → `validate.js`; `datasets.json` →
  `images/index.json`). New duplication needs a generator or a check.
- **Config data is never markup.** `textContent` and individual attributes only.
- **The engine knows nothing about a vertical.** No dataset name, theme id or business word belongs
  in `_engine/`, `_layouts/` or `_themes/*.css`.

## Mobile, accessibility, SEO

- **Mobile:** on phones the site becomes app-like — a top bar with a slide-down menu, a bottom tab
  bar (from the `tabbar` array, with one centre call/WhatsApp button), and safe-area insets for
  notched devices.
- **Accessibility:** skip-to-content link, visible focus rings, semantic landmarks, ARIA on the menu
  toggle / tab bar / FAQ accordion, and `prefers-reduced-motion` support. `base.css` owns the focus
  ring; a layout that sets `outline:none` fails the checker.
- **SEO:** the engine emits JSON-LD `LocalBusiness` plus OpenGraph and Twitter meta from your
  `business` block. Exported sites ship real HTML, so they are fully crawlable — the JS-rendering
  caveat applies only to the live `view.html` preview, which is not what you deploy.

## License

MIT — see [`LICENSE`](LICENSE). Edit the copyright line before you ship.
