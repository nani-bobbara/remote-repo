# Layout archetypes and the responsive toolkit

Reference for `designing-layouts`. Offer the catalog when writing the spec's `spine:` line; use
the toolkit while writing `_themes/<id>.css`.

---

## The catalog

Eight arrangements that cover essentially every current marketing-site design. They combine —
"bento hero, shelf collection, single-column FAQ" is a normal answer.

### 1. Split hero (asymmetric)

**This is the bundled `editorial` layout.** Copy dominant on one side, media on the other, stacking on mobile.

```
┌──────────────┬─────────────┐
│ eyebrow      │             │
│ HEADLINE     │   [media]   │
│ subtitle     │             │
│ [cta] [cta]  │             │
│ stat stat    │             │
└──────────────┴─────────────┘
```

**Fits:** trades, makers, anything where a photograph sells. **Mobile:** stack, media first or
second — decide deliberately, media-first delays the headline.
**Skeleton:** `grid-template-columns: 1.1fr .9fr` → `1fr` under ~900px.
**Pitfall:** with no image the column collapses; give the media cell a `min-height` or `aspect-ratio`.

### 2. Centered stack

Centred eyebrow, headline, subhead, one CTA, media below. The dominant SaaS pattern.

```
┌─────────────────────────────┐
│         eyebrow             │
│        HEADLINE             │
│        subtitle             │
│          [cta]              │
│  ┌───────────────────────┐  │
│  │       [media]         │  │
└──┴───────────────────────┴──┘
```

**Fits:** services, software, single-offer businesses. **Mobile:** already correct — nothing to
reflow, which makes it the safest choice.
**Skeleton:** `max-width: 62ch; margin-inline: auto; text-align: center`.
**Pitfall:** centred body text over ~70 characters is hard to read; constrain with `ch`.

### 3. Bento grid

Modular tiles of varied span in one dense block. Currently the most fashionable arrangement.

```
┌─────────┬────┬────┐
│         │    │    │
│  large  ├────┴────┤
│         │  wide   │
├────┬────┼─────────┤
│    │    │         │
└────┴────┴─────────┘
```

**Fits:** collection / gallery / trust sections; businesses with several equal offerings.
**Mobile:** collapse to one or two columns — a 4-across bento at 380px is unreadable.
**Skeleton:** `grid-template-columns: repeat(4, 1fr)` with `grid-column: span N` per tile; the
`collection` section already supports a `wide` flag per item.
**Pitfall:** tile counts vary by dataset. Use `:nth-child()` span rules that degrade gracefully
rather than hand-placing every tile.

### 4. Sidebar rail

Persistent vertical nav on desktop, bottom tab bar on mobile. The most "app-like" option and the
closest fit to this starter's mobile-native goal.

```
┌────┬────────────────────┐      mobile:
│ ▪  │                    │      ┌──────────────┐
│ ▪  │      content       │      │   content    │
│ ▪  │                    │      ├──────────────┤
│ ▪  │                    │      │ ▪  ▪  ▪  ▪   │
└────┴────────────────────┘      └──────────────┘
```

**Fits:** many sections, catalogue-heavy sites. **Mobile:** rail becomes the tab bar — the
`tabbar` data already exists, so this is mostly CSS.
**Skeleton:** `grid-template-columns: var(--rail) 1fr`, rail `position: sticky; top: 0;
height: 100dvh`. Below the breakpoint, rail → `position: fixed; bottom: 0` full-width.
**Pitfall:** reserve `padding-bottom: calc(var(--tabbar-h) + var(--safe-b))` on content or the
bar covers the footer.

### 5. Magazine / full-bleed

Full-bleed imagery, large serif display type, deliberately asymmetric columns, generous space.

**Fits:** hospitality, studios, craft, anything selling atmosphere. **Mobile:** single column;
keep the full-bleed images, drop the asymmetry.
**Skeleton:** a `grid-template-columns: [full-start] 1fr [content-start] minmax(0, 68ch)
[content-end] 1fr [full-end]` ladder lets a child opt into `grid-column: full` for bleed.
**Pitfall:** serif display at small sizes on low-DPI screens reads poorly — floor it with
`clamp()`.

### 6. Sticky-scroll (pinned media)

Media pins while copy scrolls past it. Strong for `process` and `specs`.

**Fits:** step-by-step explanation, comparisons. **Mobile:** unpin entirely — stacked cards.
Pinned panes on a short viewport feel broken.
**Skeleton:** `position: sticky; top: 12vh` on the media column inside a tall grid row.
**Pitfall:** sticky fails silently if any ancestor has `overflow: hidden`.

### 7. Horizontal shelves

Rows that scroll sideways with snap points. Native CSS, no carousel JS.

**Fits:** `collection`, `gallery`, `testimonials` with many items. **Mobile:** its natural home —
this is the one pattern that is *better* on a phone.
**Skeleton:** `display: flex; overflow-x: auto; scroll-snap-type: x mandatory;` children
`scroll-snap-align: start; flex: 0 0 clamp(240px, 70vw, 340px)`.
**Pitfall:** always leave a visible peek of the next card, or users don't know it scrolls. Add
`scroll-padding-inline` so snapped cards aren't flush to the edge.

### 8. Single-column long-form

One measure, strong vertical rhythm, minimal chrome.

**Fits:** consultants, practitioners, text-led businesses. **Mobile:** identical — zero reflow
risk. **Skeleton:** `max-width: 68ch; margin-inline: auto`, spacing scale on `+ *`.
**Pitfall:** needs genuinely good typography, since nothing else carries it.

---

## Responsive toolkit

Where the two bundled layouts actually stand, measured — `bento` is the one to read:

| | `bento` | `editorial` |
|---|---|---|
| `clamp()` | 18 | 6 |
| `color-mix()` | 2 | 0 |
| `@container` | 1 | 0 |
| `dvh` | 1 | 0 (2× `100vh`) |
| `:has()` | 1 | 0 |
| literal colours | 4 | 53 |

### Fluid type and space — no breakpoints needed

```css
h2 { font-size: clamp(1.6rem, 1.1rem + 2.4vw, 3rem); }
.pad { padding-block: clamp(48px, 8vw, 120px); }
```

Prefer this over stepping sizes at each breakpoint. Fewer media queries, smoother between them.

### Intrinsic grids — let the content decide

```css
.cards { display: grid; gap: 18px;
         grid-template-columns: repeat(auto-fit, minmax(min(260px, 100%), 1fr)); }
```

`auto-fit` + `minmax` reflows at every width with no media query. The `min(260px, 100%)` guard
prevents overflow on very narrow screens — omit it and 260px wins on a 240px viewport.

### Container queries — components that don't care where they are

```css
.card-host { container-type: inline-size; }
@container (min-width: 420px) { .card { grid-template-columns: 120px 1fr; } }
```

The right tool when the same card appears in a wide grid *and* a narrow rail. Viewport media
queries can't express that. Baseline across all current browsers.

### Mobile viewport units

```css
.hero { min-height: 100dvh; }   /* not 100vh — chrome hides/shows */
```

`dvh` tracks the dynamic viewport; `svh`/`lvh` give the small/large extremes.

### Safe areas and the tab bar

```css
.tabs   { padding-bottom: var(--safe-b); height: calc(var(--tabbar-h) + var(--safe-b)); }
#app    { padding-bottom: calc(var(--tabbar-h) + var(--safe-b)); }
```

Both tokens already exist in `_themes/base.css`.

### Parent-conditional styling

```css
.stage:has(img) { background: none; }
.stage:not(:has(img)) { display: grid; place-items: center; }
```

Cleaner than the `.noimg` class, but not a replacement: `bind.js` adds `.noimg` when the dataset
supplies no image at all, and the export depends on it. Style both.

### Motion

```css
@media (prefers-reduced-motion: reduce) { * { animation: none !important; transition: none !important; } }
```

`_themes/base.css` already declares this globally. Don't re-declare; just don't fight it.

### Breakpoints

`editorial` uses desktop-first `max-width: 980px / 760px / 480px`; `bento` adds container queries
on top of the same ladder. Either is fine — **pick one and stay with it.** Mixing desktop-first
media queries with container queries in the same file is where specificity bugs come from.

---

## Accessibility floor

Non-negotiable, and cheap:

- One `<h1>` per page — the hero headline. Sections use `<h2>`.
- Landmarks: `<header>`, `<nav>`, `<main id="app">`, `<footer>`.
- `.skip` link is in `_themes/base.css`; keep it first in `<body>` and pointed at `#home`.
- Menu toggle needs `aria-expanded`; the tab bar needs `aria-current` or `.active`.
- Focus rings come from `_themes/base.css` `:focus-visible` — never `outline: none`.
- Contrast: `--muted` on `--bg` and `--on-dark-dim` on `--dark` are the two pairs that get close
  to the 4.5:1 line. Check them against any new theme, not just the default.
- Tap targets ≥ 44px, especially tab bar items.

## Performance floor

- Hero image: `fetchpriority="high" decoding="async"`, no `loading="lazy"`.
- Everything below the fold: `loading="lazy"`.
- The layout owns `loading` / `fetchpriority` / `decoding` — the engine only sets `src`, `alt`
  and the error fallback.
- Give every media box an `aspect-ratio` so nothing shifts as images arrive.
