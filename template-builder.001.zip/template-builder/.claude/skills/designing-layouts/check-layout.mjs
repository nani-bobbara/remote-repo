#!/usr/bin/env node
/* Static conformance checker for a layout: _layouts/<id>.html + _themes/<id>.css.

   Every rule here encodes something the engine, the exporter or the editor
   requires but does not enforce — the failures are silent at runtime, which is
   why they are worth a script rather than a paragraph.

   Usage, from the repo root:
     node .claude/skills/designing-layouts/check-layout.mjs <id> [...]
     node .claude/skills/designing-layouts/check-layout.mjs --all

   Exit code 1 if any ERROR fired. WARNs are judgement calls: read them, then
   either fix them or say in the PR why not.
*/

import { readFileSync, existsSync, readdirSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../../..');
const R = p => join(ROOT, p);

/* ---------- reporting ---------- */

let errors = 0, warns = 0;
const say = [];
const err = (rule, msg) => { errors++; say.push(`  ERROR  [${rule}] ${msg}`); };
const warn = (rule, msg) => { warns++; say.push(`  warn   [${rule}] ${msg}`); };

/* ---------- tiny HTML helpers (templates are well-formed; regex is enough) ---------- */

// All <template data-<kind>="name"> blocks -> { name: innerHTML }
function templates(html, kind) {
  const out = {};
  const re = new RegExp(`<template\\s+data-${kind}="([^"]+)"\\s*>([\\s\\S]*?)</template>`, 'g');
  for (const m of html.matchAll(re)) out[m[1]] = m[2];
  return out;
}

// Values of one data-* attribute inside a chunk of markup.
const attrValues = (chunk, attr) =>
  [...chunk.matchAll(new RegExp(`\\b${attr}="([^"]*)"`, 'g'))].map(m => m[1]);

// The tag name of the first element in a fragment, and how many roots it has.
function roots(chunk) {
  const names = [];
  let depth = 0;
  const VOID = /^(area|base|br|col|embed|hr|img|input|link|meta|source|track|wbr)$/i;
  for (const m of chunk.matchAll(/<(\/?)([a-zA-Z][\w-]*)([^>]*?)(\/?)>/g)) {
    const [, close, name, rest, selfClose] = m;
    if (close) { depth--; continue; }
    if (depth === 0) names.push(name.toLowerCase());
    if (!selfClose && !VOID.test(name) && !/\/$/.test(rest)) depth++;
  }
  return names;
}

/* ---------- dataset intelligence ---------- */

const DATASETS = readdirSync(R('_datasets'), { withFileTypes: true })
  .filter(d => d.isDirectory()).map(d => d.name);

const SCHEMA = JSON.parse(readFileSync(R('config.schema.json'), 'utf8'));
const SECTION_TYPES = SCHEMA.$defs.section.properties.type.enum;

/* Which fields actually carry inline markup, learned from the bundled data
   rather than guessed. A field in here MUST be bound with data-rich: data-bind
   sets textContent, so "<em>x</em>" would render as visible angle brackets. */
const richFields = {};   // type -> Set(fieldName)
const seenFields = {};   // type -> Set(fieldName)  — every leaf key in the data

function walk(type, node) {
  if (Array.isArray(node)) { node.forEach(n => walk(type, n)); return; }
  if (!node || typeof node !== 'object') return;
  for (const [k, v] of Object.entries(node)) {
    if (k === 'type' || k === 'id' || k === 'enabled') continue;
    (seenFields[type] ??= new Set()).add(k);
    if (typeof v === 'string' && /<[a-z]+[\s/>]/i.test(v)) (richFields[type] ??= new Set()).add(k);
    if (v && typeof v === 'object') walk(type, v);
  }
}

const enabledTypes = {};    // dataset -> [type, ...] in render order
for (const ds of DATASETS) {
  const seedPath = R(join('_datasets', ds, 'seed.json'));
  if (!existsSync(seedPath)) continue;
  const seed = JSON.parse(readFileSync(seedPath, 'utf8'));
  const enabled = (seed.sections || []).filter(s => s.enabled !== false);
  enabledTypes[ds] = enabled.map(s => s.type);
  for (const sec of enabled) walk(sec.type, sec);
}

/* ---------- rules ---------- */

function checkLayout(id) {
  say.length = 0;
  const before = [errors, warns];

  const htmlPath = R(join('_layouts', `${id}.html`));
  const cssPath = R(join('_themes', `${id}.css`));

  if (!existsSync(htmlPath)) { err('files', `_layouts/${id}.html is missing`); return report(id, before); }
  if (!existsSync(cssPath)) {
    err('files', `_themes/${id}.css is missing — the exporter fetches that exact path ` +
                 `(index.html: fetch('_themes/'+layoutId+'.css')), so the stylesheet must be named after the layout id`);
    return report(id, before);
  }

  const raw = readFileSync(htmlPath, 'utf8');
  // Comments in these files document the contract by quoting it; parse past them.
  const html = raw.replace(/<!--[\s\S]*?-->/g, '');
  const css = readFileSync(cssPath, 'utf8');
  const secs = templates(html, 'section');
  const parts = templates(html, 'part');
  // Markup outside the <template> blocks: the boot shell.
  const shell = html.replace(/<template[\s\S]*?<\/template>/g, '');

  /* --- registry --- */
  const reg = JSON.parse(readFileSync(R('_layouts/layouts.json'), 'utf8'));
  const entry = reg.find(l => l.id === id);
  if (!entry) {
    err('registry', `no entry with "id": "${id}" in _layouts/layouts.json — ?layout=${id} is rejected before ` +
                    `the fragment is even fetched, so view.html shows the error box`);
  } else {
    for (const k of ['name', 'desc', 'defaultData']) if (!entry[k]) err('registry', `layouts.json entry is missing "${k}"`);
    if (entry.defaultData && !DATASETS.includes(entry.defaultData))
      err('registry', `defaultData "${entry.defaultData}" is not a folder under _datasets/`);
    if (/furniture|cafe|marble|studio|salon|wood|stone/i.test(`${entry.name} ${entry.desc}`))
      warn('agnostic', `layouts.json name/desc names a vertical — describe the arrangement, not the business`);
  }

  /* --- a layout is a fragment: <template> blocks and nothing else ---
     The page shell, the loader, the error box, the stylesheet links and the
     boot script all live once in /view.html. Anything else here is either
     ignored at runtime or a copy of something the shell already owns. */
  if (/<(?:!doctype|html|head|body)\b/i.test(shell))
    err('fragment', 'page scaffolding (<!DOCTYPE>/<html>/<head>/<body>) in a layout — the shell is /view.html; ' +
                    'a layout is only its <template> blocks');
  for (const stray of shell.match(/<link\b[^>]*>/gi) || [])
    err('fragment', `stray ${stray.slice(0, 50)} — view.html links _themes/base.css and engine.js appends ` +
                    `_themes/${id}.css; a third stylesheet is not inlined on export`);
  for (const stray of shell.match(/<script\b[^>]*>/gi) || [])
    err('nojs', `a layout is markup only — found ${stray.slice(0, 50)}. If you need behaviour, add a data-* ` +
                `binding to _engine/bind.js, or a data-role hook read by _engine/behaviors.js`);
  // Markup outside a <template> never renders: the engine only clones templates.
  const orphan = shell.replace(/<!--[\s\S]*?-->/g, '').replace(/\s+/g, '');
  if (orphan) err('fragment', `markup outside any <template> ("${orphan.slice(0, 40)}…") — the engine clones ` +
                              `templates and ignores everything else, so this never renders`);
  if (!Object.keys(secs).length) err('fragment', 'no <template data-section="…"> blocks — nothing would render');

  /* --- section templates --- */
  const h1s = (html.match(/<h1\b/g) || []).length;
  if (h1s !== 1) err('a11y', `${h1s} <h1> in the page — exactly one, on the hero headline`);

  const rootTag = {};
  for (const [type, chunk] of Object.entries(secs)) {
    if (!SECTION_TYPES.includes(type)) { err('sections', `<template data-section="${type}"> is not a schema section type`); continue; }
    const rs = roots(chunk);
    rootTag[type] = rs[0];
    if (rs.length !== 1)
      err('sections', `"${type}" template has ${rs.length} root elements — engine.js sets the section id on the first ` +
                      `child only, so anchors and scrollspy break on the rest`);
    // The root's tag name is the layout's choice: scrollspy observes
    // ':scope > [id]' under #app, not a tag, so <section>/<article>/<div> all work.

    // Rich fields must not go through data-bind (textContent) or into alt text.
    const rich = richFields[type] || new Set();
    for (const path of attrValues(chunk, 'data-bind'))
      if (rich.has(path.replace(/^[@$]\./, '').split('.').pop()))
        err('rich', `"${type}": data-bind="${path}" — the datasets put inline markup in this field, so data-bind ` +
                    `renders literal <em>/<b>/<br>. Use data-rich="${path}"`);
    // alt/title need no rule here: bind.js flattens markup out of them, so any
    // field is safe as an image description.

    // Coverage: a field the data supplies and the template never mentions is dropped silently.
    const referenced = new Set(
      [...chunk.matchAll(/\bdata-(?:bind|rich|text|img|alt|each|if|icon|stars|attr-[\w-]+|class-[\w-]+|style-[\w-]+)="([^"]*)"/g)]
        .flatMap(m => m[1].replace(/^!/, '').replace(/^[@$]\./, '').split('.')));
    for (const field of seenFields[type] || [])
      if (!referenced.has(field)) warn('coverage', `"${type}": field "${field}" exists in the datasets but nothing in this template binds it`);
  }

  /* --- CONTRACT C: the behaviour interface. Every miss here fails silently. --- */
  if (secs.contact) {
    for (const field of ['name', 'phone', 'message'])
      if (!new RegExp(`data-field="${field}"`).test(secs.contact))
        err('hooks', `contact form has no data-field="${field}" — behaviors.js reads the enquiry by data-field, ` +
                     `so the WhatsApp message would send "-" for that line`);
    if (/data-each="formOptions"/.test(secs.contact) && !/data-field="item"/.test(secs.contact))
      err('hooks', 'contact binds formOptions but no control carries data-field="item" — the selection never reaches the message');
    if (!/data-role="wa-form"/.test(secs.contact))
      err('hooks', 'contact has no data-role="wa-form" — the send button is never wired');
  }
  if (parts.tabbar) {
    if (!/data-role="tab"/.test(parts.tabbar))
      err('hooks', 'tab bar links need data-role="tab" — that is how behaviors.js finds them for scrollspy');
    if (!/data-attr-href="href"/.test(parts.tabbar))
      warn('hooks', 'tab links should bind data-attr-href="href" so scrollspy can match them to section ids');
  }
  if (parts.nav) {
    const hasBurger = /data-role="burger"/.test(parts.nav);
    const hasMenu = /data-role="menu"/.test(parts.nav);
    if (hasBurger !== hasMenu) err('hooks', 'burger and menu hooks come as a pair — behaviors.js wires neither unless it finds both');
    if (hasBurger && !/aria-expanded/.test(parts.nav)) err('a11y', 'the menu toggle needs aria-expanded — behaviors.js updates it but will not create it');
    if (!/data-role="header"/.test(parts.nav)) warn('hooks', 'no data-role="header" — the .scrolled class is never applied on scroll');
  }
  // The engine must never need to know a layout's ids. An id kept for a genuine
  // markup reference (aria-controls, <label for>) is fine; a bare one is a leftover.
  for (const legacy of ['header', 'burger', 'menu', 'sendBtn'])
    if (new RegExp(`id="${legacy}"`).test(html)
        && !new RegExp(`(aria-controls|for)="${legacy}"`).test(html))
      warn('hooks', `id="${legacy}" is a pre-contract engine hook that nothing references — ` +
                    `behaviours resolve by data-role now, so drop it`);
  if (/data-img=/.test(html) && !/\.noimg\b/.test(css))
    err('hooks', 'templates use data-img but the stylesheet never styles .noimg — bind.js adds that class to the image\'s ' +
                 'parent when the dataset has no photo, and an unstyled empty box is what ships');

  /* --- tokens --- */
  const cssNoComments = css.replace(/\/\*[\s\S]*?\*\//g, '');
  const literals = [
    ...cssNoComments.matchAll(/#[0-9a-fA-F]{3,8}\b/g),
    ...cssNoComments.matchAll(/\brgba?\(\s*\d/g),
    ...cssNoComments.matchAll(/\bhsla?\(\s*\d/g),
  ].map(m => m[0]);
  if (literals.length)
    err('tokens', `${literals.length} literal colour(s) in the stylesheet (${[...new Set(literals)].slice(0, 4).join(', ')}…). ` +
                  `Config themes and SVG re-tinting only reach var(--token). For a tint use ` +
                  `color-mix(in oklab, var(--accent) 24%, transparent), not rgba(230,191,114,.24)`);

  const vh = (cssNoComments.match(/\b\d+vh\b/g) || []).length;
  if (vh) err('mobile', `${vh} use(s) of vh — mobile browser chrome resizes the viewport. Use dvh (or svh/lvh)`);
  // outline:none is fine when scoped to pointer focus — :focus:not(:focus-visible)
  // still leaves keyboard users the ring base.css draws.
  for (const rule of cssNoComments.match(/[^{}]+\{[^{}]*outline\s*:\s*none[^{}]*\}/g) || [])
    if (!/:not\(\s*:focus-visible\s*\)/.test(rule.split('{')[0]))
      err('a11y', `outline:none on "${rule.split('{')[0].trim().slice(0, 60)}" removes the :focus-visible ring ` +
                  `base.css provides — scope it with :focus:not(:focus-visible) if you only meant pointer focus`);
  const bangs = (cssNoComments.match(/!important/g) || []).length;
  if (bangs > 2) warn('css', `${bangs} !important declarations — usually a specificity problem, not a fix`);

  /* --- modern floor --- */
  if (!/clamp\(/.test(cssNoComments)) warn('modern', 'no clamp() — fluid type and spacing beat stepping sizes at each breakpoint');
  if (!/container-type|@container/.test(cssNoComments))
    warn('modern', 'no container queries — if any component appears at two different widths, @container expresses that and media queries cannot');
  if (!/repeat\(auto-fit|repeat\(auto-fill/.test(cssNoComments))
    warn('modern', 'no auto-fit/auto-fill grid — intrinsic grids reflow with no breakpoint');

  /* --- distinctness: a new layout must be a different design, not a re-skin ---

     Classes the engine or base.css owns are shared by contract, so they are
     excluded. What is left is the author's own vocabulary; heavy overlap there
     means the arrangement was copied rather than designed. editorial vs bento
     — two genuinely different layouts — sit at 0.28, which sets the bar. */
  const CONTRACT = new Set(['skip', 'spin', 'reveal', 'in', 'd1', 'd2', 'd3', 'd4',
    'tab', 'active', 'noimg', 'locked', 'open', 'x', 'scrolled', 'hide', 'show']);
  const vocab = src => new Set([...src.matchAll(/\bclass="([^"]*)"/g)]
    .flatMap(m => m[1].split(/\s+/)).filter(c => c && !CONTRACT.has(c)));
  const mine = vocab(html);
  for (const other of reg.filter(l => l.id !== id)) {
    const theirPath = R(join('_layouts', `${other.id}.html`));
    if (!existsSync(theirPath)) continue;
    const theirs = vocab(readFileSync(theirPath, 'utf8').replace(/<!--[\s\S]*?-->/g, ''));
    const shared = [...mine].filter(c => theirs.has(c));
    const j = shared.length / new Set([...mine, ...theirs]).size;
    if (j > 0.45)
      warn('distinct', `class vocabulary is ${(j * 100).toFixed(0)}% shared with "${other.id}" ` +
                       `(${shared.length} classes). Two designed-apart layouts sit near 28%. ` +
                       `Either this is a re-skin, or say in the spec which axes it diverges on`);
  }

  /* --- THE INVARIANT: an artifact may name a contract, never another artifact. --- */
  const themeIds = JSON.parse(readFileSync(R('_themes/themes.json'), 'utf8')).map(t => t.id);
  for (const [label, text] of [[`_layouts/${id}.html`, html], [`_themes/${id}.css`, css]]) {
    for (const ds of DATASETS)
      if (new RegExp(`\\b${ds}\\b`).test(text))
        err('axes', `${label} names the dataset "${ds}" — a layout renders any dataset and must not know one exists`);
    for (const th of themeIds)
      if (text.includes(th))
        err('axes', `${label} names the theme "${th}" — a layout consumes var(--token) and must not know a preset exists`);
  }

  /* --- business-agnostic --- */
  const vertical = /\b(furniture|teak|rosewood|cafe|coffee|brunch|marble|granite|slab|salon|facial|massage|woodwork|carpenter)\b/gi;
  for (const [label, text] of [[`_layouts/${id}.html`, html], [`_themes/${id}.css`, css]])
    for (const m of new Set((text.match(vertical) || []).map(s => s.toLowerCase())))
      err('agnostic', `"${m}" appears in ${label} — a layout renders any dataset; that word belongs in the data`);

  /* --- what the rendered page must contain, so the browser pass has numbers --- */
  const expect = Object.entries(enabledTypes).map(([ds, types]) => {
    const rendered = types.filter(t => secs[t]);
    const skipped = types.filter(t => !secs[t]);
    return `    ?data=${ds}: ${rendered.filter(t => rootTag[t] === 'section').length} <section> in #app` +
           (skipped.length ? `, ${skipped.length} console warning(s) for ${[...new Set(skipped)].join(', ')}` : ', 0 console warnings');
  });

  return report(id, before, expect);
}

function report(id, [e0, w0], expect = []) {
  const de = errors - e0, dw = warns - w0;
  const mark = de ? 'FAIL' : dw ? 'PASS (with warnings)' : 'PASS';
  console.log(`\n${id} — ${mark}  (${de} error${de === 1 ? '' : 's'}, ${dw} warning${dw === 1 ? '' : 's'})`);
  for (const line of say) console.log(line);
  if (expect.length) { console.log('  browser pass should show:'); for (const l of expect) console.log(l); }
  return de === 0;
}

/* ---------- main ---------- */

const argv = process.argv.slice(2);
const ids = argv.includes('--all')
  ? JSON.parse(readFileSync(R('_layouts/layouts.json'), 'utf8')).map(l => l.id)
  : argv;

if (!ids.length) {
  console.error('usage: node check-layout.mjs <layout-id> [...]  |  --all');
  process.exit(2);
}

for (const id of ids) checkLayout(id);

console.log(`\n${errors} error(s), ${warns} warning(s) across ${ids.length} layout(s).`);
process.exit(errors ? 1 : 0);
