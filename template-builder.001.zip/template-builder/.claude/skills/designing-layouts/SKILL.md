---
name: designing-layouts
description: Use when adding or designing a new layout for this site starter — adding a page under _layouts/ with its stylesheet in _themes/, arranging the same datasets a different way, or a request like "add a bento layout", "make a sidebar version", "new layout", "second design".
---

# Designing Layouts

## Overview

A layout is **`<template>` blocks in `_layouts/<id>.html` and CSS in `_themes/<id>.css`**. It is
a fragment, not a page: `/view.html` owns the shell, the loader, the error box and the boot
script. No JavaScript, no content. Adding one requires **zero engine changes**.

```
_layouts/<id>.html      <template data-part> + <template data-section> blocks, nothing else
_themes/<id>.css        the design
_layouts/layouts.json   one entry: { id, name, desc, defaultData }
```

`id` is the filename stem in both folders, and the value of `?layout=`.
Preview it at `view.html?layout=<id>&data=<dataset>&theme=<preset>`.

Wanting to write JS in a layout means you want a new `data-*` binding in `_engine/bind.js`, not a
script tag.

## The gate: write the spec before the markup

**The first output of this skill is a spec, not a file.** A layout is ~300 lines of markup plus
~350 lines of CSS; guessing wrong on arrangement means rewriting nearly all of it.

The spec is also what makes the result *deterministic*: two authors handed the same spec should
produce layouts that bind identically and differ only in arrangement. Fill in every line — write
it into the PR description and the stylesheet header comment:

```
id:            <slug naming the arrangement, not a vertical, not a number>
purpose:       <what kind of site this serves, which sections carry the weight>
spine:         <flow | tile field | rail + pane | shelf | bleed ladder | long-form measure>
nav:           desktop <top bar | left rail | minimal>  mobile <drawer | tab bar | both>
density:       <airy | compact>
sections:      <all 13, or the deliberate subset — a type with no template is skipped>
diverges from <existing layout> on: <at least three axes, from the list below>
```

Ask the user for anything the request does not already answer. Only skip asking when the request
is already this specific.

**Red flags — you are about to build the wrong thing:**

- "I'll start with a hero and figure out the rest" → write the spec first
- "editorial is a reasonable default, I'll follow it" → that is a *choice*; put it in the spec
- "The request said 'modern', that's enough to go on" → modern *what*? ask
- "I'll build it and they can tell me what to change" → a rewrite costs more than a question

## Distinctness: a new layout is a new design, not a re-skin

A second layout that rearranges nothing has no reason to exist. Name **three or more** axes it
diverges on, in the spec, before building:

| Axis | Options |
|---|---|
| Structural spine | continuous flow · tile field · rail + pane · horizontal shelves · full-bleed ladder · single measure |
| Section rhythm | left-aligned heads · centred heads · heads in a sticky gutter · no heads at all |
| Media treatment | inset cards · full-bleed · masked shapes · duotone panels · no media |
| Surface language | borders · shadows · filled blocks · flat, separated by space alone |
| Type personality | display-dominant · body-dominant · all-caps micro-labels · numeric emphasis |
| Nav model | top bar · left rail · bottom tabs · minimal / anchor-free |

The checker reports class-vocabulary overlap against every registered layout. `editorial` vs
`bento` — two genuinely different designs — sit at **28%**. Above ~45% you built a re-skin.

**Do not copy an existing layout.** There is no boilerplate left to justify it — the shell is
`/view.html`. Copying the fragment is how someone else's class vocabulary and arrangement come
along with it.

See [layout-archetypes.md](layout-archetypes.md) for the arrangement catalog and the responsive
toolkit.

## The contract the engine does not enforce

Everything here fails **silently** — the page still renders, something just quietly stops working.
`check-layout.mjs` tests all of it; this table is why each rule exists.

| Requirement | What breaks without it |
|---|---|
| **only `<template>` blocks** — no `<html>`/`<head>`/`<link>`/`<script>` | the shell owns those; markup outside a template never renders |
| each `<template data-section>` has **exactly one root element** | `engine.js` puts `sec.id` on the first child only — anchors break on the rest |
| contact controls carry **`data-field="name\|phone\|message"`** (plus `"item"` if you bind `formOptions`) | `behaviors.js` reads the enquiry by `data-field` — the WhatsApp message sends `-` for every missing one |
| send button carries `data-role="wa-form"` | the button does nothing |
| tab links carry `data-role="tab"` and an in-page `href` | scrollspy never highlights the tab bar |
| `data-role="burger"` **and** `data-role="menu"` together, with `aria-expanded` | the menu is wired only when both are found |
| `_themes/<id>.css` styles `.noimg` | `bind.js` adds it to the image's *parent* when a dataset has no photo; unstyled, an empty box ships |
| exactly one `<h1>` | the hero headline |

`data-role="header"` is optional but gives you the `.scrolled` class on scroll.

**The engine names no class of yours.** Every hook resolves through `data-role` / `data-field`,
so a section root can be `<section>`, `<article>` or `<div>` — scrollspy observes `:scope > [id]`
under `#app`, not a tag name. The full list of roles is documented at the top of
`_engine/behaviors.js`.

## The invariant: never name another artifact

Layouts, themes and datasets are three independent axes. Any combination must render, so:

Selection is per-axis: the layout is the page, `?data=` picks the business, `?theme=` picks the
palette. Any combination must render.

| An artifact may not name | Instead it names |
|---|---|
| a layout naming a dataset or a theme id | the section vocabulary (`config.schema.json`) and `var(--token)` |
| a theme containing a selector | token values only |
| a dataset naming a layout | section `type`s from the schema |
| the engine naming your classes | `data-role` / `data-field` |

The checker fails on any of these. It is what keeps "any dataset × any layout × any theme" true
as the three folders grow.

## Bindings: match the binding to the field

The full attribute table is in `README.md`. The rule that is easy to get wrong, and that both
bundled layouts got wrong:

> **A field the datasets fill with inline markup must use `data-rich`, never `data-bind`.**
> `data-bind` sets `textContent`, so `<em>big ideas</em>` renders as visible angle brackets.
> **And such a field must never be an `alt` source** — a screen reader reads the tags aloud.

`heading`, `subtitle` and `text` carry `<em>`, `<b>` and `<br>` across all four datasets. The
checker derives that list from the data rather than a hardcoded guess, so it stays true as
datasets change.

Everything else, one line each:

| Attribute | Effect |
|---|---|
| `data-bind="path"` | text; **removes the element when empty** — `data-keep` opts out |
| `data-rich="path"` | allowlisted inline markup (`b i em strong br span small u mark`) |
| `data-each="path"` | clones *this element* per item, in place; `data-stagger` adds `.reveal` + `d1..d4` |
| `data-if="path"` / `"!path"` | drop the element when falsy / truthy |
| `data-img="path"` + `data-alt="path"` | src resolved against the *dataset*, alt, `.noimg` fallback |
| `data-icon="path"` or `"#name"` | replace with an inline SVG |
| `data-attr-<n>` / `data-class-<n>` / `data-style-<prop>` | attribute, conditional class, style property |
| `data-stars="path"` | N filled stars + an accessible label |

Scope: `@.` is the enclosing section, `$.` is globals (`$.business.*`, `$.waLink`, `$.telLink`,
`$.mailLink`, `$.initial`, `$.year`), `.` is the current item, `$index` / `$n` / `$nn` are repeat
counters.

The layout owns `loading` / `fetchpriority` / `decoding` on every `<img>` — the engine sets only
`src`, `alt` and the error fallback. Hero image `fetchpriority="high" decoding="async"`,
everything below the fold `loading="lazy"`. Give every media box an `aspect-ratio` so nothing
shifts as images arrive.

**Bind every field the datasets supply.** A field you never reference is content silently
dropped; the checker warns once per unbound field.

## Style from tokens, and from this decade

26 tokens are defined once in **`_engine/tokens.js`** — the single source. `_themes/base.css`'s
`:root` block is generated from it (`node _editor/make-tokens.mjs`), `theme.js` imports the same
table, and `config.schema.json` is validated against it. Add a token there, not in three places:

```
--bg --bg-2 --surface --dark --dark-2 --dark-3 --ink --muted --on-dark --on-dark-dim
--accent --accent-bright --accent-soft --secondary --line --line-dark
--display --sans --display-weight --tracking --radius --radius-sm --radius-pill
--maxw --tabbar-h --safe-b
```

**No literal colour, ever — not `#hex`, not `rgba()`, not `hsl()`.** Theme presets and SVG
re-tinting only reach `var(--token)`. For a tint, derive it:

```css
/* not this */  border: 1px solid rgba(230,191,114,.24);
/* this */      border: 1px solid color-mix(in oklab, var(--accent-bright) 24%, transparent);
```

That one substitution is the difference between a layout that re-themes and one that only looks
like it does.

The floor, all baseline in every current browser:

| Use | Instead of |
|---|---|
| `clamp()` for type and section padding | stepping sizes at each breakpoint |
| `repeat(auto-fit, minmax(min(260px,100%), 1fr))` | fixed column counts per breakpoint |
| `@container` when a component appears at two widths | viewport media queries, which cannot express it |
| `100dvh` | `100vh` — mobile chrome resizes the viewport |
| `:has()` for parent-conditional styling | extra wrapper classes |
| `text-wrap: balance` on headings, `pretty` on body | manual `<br>` |
| logical properties (`padding-inline`, `margin-block`) | physical sides |

Pick desktop-first media queries **or** container-query-first and stay with it. Mixing them in one
file is where specificity bugs come from.

## Build order

1. Write the spec above. Get it agreed.
2. Add the `layouts.json` entry **first** — `?layout=<id>` is rejected without it.
3. Create `_layouts/<id>.html`: `<template>` blocks only, written fresh. There is no shell to copy.
4. Create `_themes/<id>.css`: tokens only, modern floor.
5. Verify against **all four datasets**.

## Verify before claiming done

```bash
node .claude/skills/designing-layouts/check-layout.mjs <id>
```

Exit 1 on any error. It prints the exact `<section>` count and console-warning count to expect per
dataset — carry those numbers into the browser pass:

```bash
python -m http.server 8765          # any static server; the engine needs http, not file://
CH="/c/Program Files/Google/Chrome/Application/chrome.exe"
"$CH" --headless=new --disable-gpu --virtual-time-budget=9000 --user-data-dir=/tmp/cdl \
  --dump-dom "http://localhost:8765/view.html?layout=<id>&data=cafe" > out.html
```

For each of `furniture cafe marble studio`, read `out.html` and confirm:

| Check | Expected |
|---|---|
| `<section>` inside `<main id="app">` | the count the checker printed |
| `id="errbox" class="…show"` | absent |
| `class="…noimg…"` **applied** to an element | 0 — count the class, not the `onerror` attribute text |
| console warnings | exactly the types you deliberately omitted |
| `<img>` src values | all resolve under `_datasets/<ds>/images/` |

Then open the editor at `/`, switch dataset and theme preset, toggle the phone view, and run one
export — the export is the only path that exercises `_themes/<id>.css` being inlined by filename.

## Common mistakes

| Mistake | Consequence |
|---|---|
| `data-bind` on `heading` / `subtitle` / `text` | literal `<em>` in the rendered page |
| `data-alt="heading"` | a screen reader reads the tags aloud |
| `rgba()` or `#hex` in the stylesheet | theme presets and SVG re-tinting stop working |
| Dropping a `data-field` from a form control | the enquiry sends `-` for that line, silently |
| `cp -r` an existing layout | you ship a re-skin carrying someone else's class vocabulary |
| A label or icon that fits one vertical | reads absurdly on another dataset |
| Testing one dataset | the others have different section counts and optional fields |
| `id` in `layouts.json` ≠ filename stem | no `defaultData`; the error box shows |
| Naming a dataset or theme id in a layout | breaks the axis invariant; the checker fails |
| `100vh` | mobile browser chrome clips it |
| Grepping `noimg` without `class="` | matches the `onerror` attribute text and reads as a failure |

## State of the bundled layouts

Run the checker before trusting either as a reference:

- **`bento`** — clean apart from one `data-alt` on a rich field and four `rgba()` scrims. Read
  this one.
- **`editorial`** — currently **9 errors**: five rich-field bindings, 53 literal colours (13 of
  them hardcoding `--accent-bright`'s value, so themes only half-apply), two `100vh`, one
  `outline:none`. It predates these rules. **Do not use it as a model.**
