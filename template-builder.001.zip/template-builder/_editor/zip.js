/* Store-only ZIP writer.

   No compression (method 0) — an export is a handful of small text files plus
   already-compressed images, so deflate would buy little and cost either a
   dependency or a second implementation. Knows nothing about this project:
   it takes paths and bytes and returns a Blob.
*/

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    t[i] = c >>> 0;
  }
  return t;
})();

export function crc32(bytes) {
  let c = 0xFFFFFFFF;
  for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}

// MS-DOS packed date/time, as the ZIP format requires. Seconds have 2s
// resolution; years are counted from 1980.
const dosTime = d => ((d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1)) & 0xFFFF;
const dosDate = d => (((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()) & 0xFFFF;

/* files: [{ path, bytes }] — paths use "/" and are stored verbatim, so the
   caller decides whether they sit inside a top-level folder. */
export function zip(files, date = new Date()) {
  const enc = new TextEncoder();
  const time = dosTime(date), day = dosDate(date);
  const parts = [];    // local headers + names + data, in output order
  const central = [];  // central directory, written after all entries
  let offset = 0;

  for (const f of files) {
    const name = enc.encode(f.path);
    const data = f.bytes;
    const sum = crc32(data);

    const local = new DataView(new ArrayBuffer(30));
    local.setUint32(0, 0x04034b50, true);    // local file header signature
    local.setUint16(4, 20, true);            // version needed to extract
    local.setUint16(6, 0x0800, true);        // flags: UTF-8 filenames
    local.setUint16(8, 0, true);             // method: store
    local.setUint16(10, time, true);
    local.setUint16(12, day, true);
    local.setUint32(14, sum, true);
    local.setUint32(18, data.length, true);  // compressed size
    local.setUint32(22, data.length, true);  // uncompressed size
    local.setUint16(26, name.length, true);
    local.setUint16(28, 0, true);            // extra field length
    parts.push(new Uint8Array(local.buffer), name, data);

    const cd = new DataView(new ArrayBuffer(46));
    cd.setUint32(0, 0x02014b50, true);       // central directory signature
    cd.setUint16(4, 20, true);               // version made by
    cd.setUint16(6, 20, true);               // version needed
    cd.setUint16(8, 0x0800, true);
    cd.setUint16(10, 0, true);
    cd.setUint16(12, time, true);
    cd.setUint16(14, day, true);
    cd.setUint32(16, sum, true);
    cd.setUint32(20, data.length, true);
    cd.setUint32(24, data.length, true);
    cd.setUint16(28, name.length, true);
    cd.setUint16(30, 0, true);               // extra field length
    cd.setUint16(32, 0, true);               // file comment length
    cd.setUint16(34, 0, true);               // disk number start
    cd.setUint16(36, 0, true);               // internal attributes
    cd.setUint32(38, 0, true);               // external attributes
    cd.setUint32(42, offset, true);          // offset of local header
    central.push(new Uint8Array(cd.buffer), name);

    offset += 30 + name.length + data.length;
  }

  const cdSize = central.reduce((n, a) => n + a.length, 0);
  const end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true);        // end of central directory
  end.setUint16(4, 0, true);                 // number of this disk
  end.setUint16(6, 0, true);                 // disk where CD starts
  end.setUint16(8, files.length, true);      // entries on this disk
  end.setUint16(10, files.length, true);     // entries total
  end.setUint32(12, cdSize, true);
  end.setUint32(16, offset, true);           // offset of central directory
  end.setUint16(20, 0, true);                // comment length

  return new Blob([...parts, ...central, new Uint8Array(end.buffer)],
                  { type: 'application/zip' });
}
