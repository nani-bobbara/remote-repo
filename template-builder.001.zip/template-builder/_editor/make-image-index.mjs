/* Rebuild each dataset's images/index.json from its folder contents.

   HTTP has no directory listing, so the editor cannot discover a dataset's
   images on its own. This manifest is how it learns what exists — the same
   pattern as _layouts/layouts.json and _datasets/datasets.json. A
   directory index from `python -m http.server` would work locally and break
   on Netlify, Vercel or S3.

   Hand-edited titles are preserved; only new files get a generated one.

   Run: node _editor/make-image-index.mjs
*/
import { readFileSync, writeFileSync, readdirSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const IMG = /\.(svg|png|jpe?g|webp|avif)$/i;

const titleFor = file => file
  .replace(IMG, '')
  .replace(/[-_]+/g, ' ')
  .replace(/\s+/g, ' ')
  .trim()
  .replace(/\b\w/g, ch => ch.toUpperCase());

const datasets = JSON.parse(readFileSync(join(ROOT, '_datasets/datasets.json'), 'utf8'));

for (const { id } of datasets) {
  const dir = join(ROOT, '_datasets', id, 'images');
  if (!existsSync(dir)) continue;
  const manifestPath = join(dir, 'index.json');

  // Keep any title someone edited by hand.
  const existing = new Map();
  if (existsSync(manifestPath)) {
    try {
      for (const e of JSON.parse(readFileSync(manifestPath, 'utf8'))) existing.set(e.file, e.title);
    } catch { /* unreadable manifest — rebuild from scratch */ }
  }

  const list = readdirSync(dir).filter(f => IMG.test(f)).sort()
    .map(file => ({ file, title: existing.get(file) || titleFor(file) }));

  writeFileSync(manifestPath, JSON.stringify(list, null, 2) + '\n', 'utf8');
  console.log(`${id}: ${list.length} images`);
}
