#!/usr/bin/env node
/* Regenerate everything that derives from the token vocabulary.

   _engine/tokens.js is the source.

     _themes/base.css      GENERATED — the :root block, between @tokens markers
     config.schema.json    VALIDATED — its theme.* keys must match, but the file
                           is hand-formatted for reading and JSON has no comment
                           syntax to scope a generated region, so this reports
                           drift rather than rewriting it

   Run after editing tokens.js:  node _editor/make-tokens.mjs
   Run with --check to verify without writing (used by check-layout.mjs).

   Same pattern as make-image-index.mjs: a generator, so the derived copies
   cannot drift from the source.
*/

import { readFileSync, writeFileSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { TOKENS, THEME_EXTRAS } from '../_engine/tokens.js';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const R = p => join(ROOT, p);
const check = process.argv.includes('--check');

const GROUP_LABEL = {
  colors: 'colour tokens (overridden by config.theme.colors)',
  fonts: 'type tokens (overridden by config.theme.fonts)',
  shape: 'shape tokens (overridden by config.theme.shape)',
  null: 'app tokens — the engine owns these; a theme cannot set them',
};

/* ---------- :root block for base.css ---------- */

function rootBlock() {
  const lines = [':root{'];
  for (const group of ['colors', 'fonts', 'shape', null]) {
    const list = TOKENS.filter(t => t.group === group);
    if (!list.length) continue;
    lines.push(`  /* ${GROUP_LABEL[String(group)]} */`);
    // Wrap at a comfortable width rather than one declaration per line.
    let line = ' ';
    for (const t of list) {
      const decl = ` ${t.css}:${t.value};`;
      if (line.length + decl.length > 96) { lines.push(line); line = ' '; }
      line += decl;
    }
    if (line.trim()) lines.push(line);
  }
  lines.push('}');
  return lines.join('\n');
}

/* ---------- expected theme keys, for validating config.schema.json ---------- */

function expectedKeys(group) {
  return [
    ...Object.keys(THEME_EXTRAS[group] || {}),
    ...TOKENS.filter(t => t.group === group).map(t => t.key),
  ].sort();
}

/* ---------- apply ---------- */

const problems = [];

function patch(path, next, describe) {
  const current = readFileSync(R(path), 'utf8');
  if (current === next) return;
  if (check) { problems.push(`${path} is out of date — ${describe}`); return; }
  writeFileSync(R(path), next, 'utf8');
  console.log(`wrote ${path}`);
}

// base.css — replace between the markers, leave the rest of the file alone.
{
  const css = readFileSync(R('_themes/base.css'), 'utf8');
  // Match the whole start comment, however many lines it spans — matching only
  // its first line would leave it unterminated and comment out the :root rule.
  const re = /(\/\* @tokens:start[\s\S]*?\*\/\n)[\s\S]*?(\/\* @tokens:end \*\/)/;
  if (!re.test(css)) {
    problems.push('_themes/base.css has no @tokens:start / @tokens:end markers');
  } else {
    patch('_themes/base.css', css.replace(re, `$1${rootBlock()}\n$2`), 'run node _editor/make-tokens.mjs');
  }
}

// config.schema.json — validated, never rewritten.
{
  const theme = JSON.parse(readFileSync(R('config.schema.json'), 'utf8')).$defs.theme.properties;
  for (const g of ['colors', 'fonts', 'shape']) {
    const want = expectedKeys(g);
    const have = Object.keys(theme[g].properties).sort();
    const missing = want.filter(k => !have.includes(k));
    const extra = have.filter(k => !want.includes(k));
    if (missing.length) problems.push(`config.schema.json theme.${g} is missing: ${missing.join(', ')}`);
    if (extra.length) problems.push(`config.schema.json theme.${g} has keys not in tokens.js: ${extra.join(', ')}`);
  }
  const extras = Object.keys(THEME_EXTRAS).filter(k => typeof THEME_EXTRAS[k].note === 'string');
  for (const k of extras)
    if (!(k in theme)) problems.push(`config.schema.json theme is missing "${k}"`);
}

if (problems.length) {
  for (const p of problems) console.error('ERROR  ' + p);
  process.exit(1);
}
if (check) console.log('tokens: base.css and config.schema.json match _engine/tokens.js');
