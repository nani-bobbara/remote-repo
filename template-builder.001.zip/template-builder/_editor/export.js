/* Bake the editor's live preview into a deployable static site.

   The preview iframe already holds the rendered, themed DOM — theme tokens as
   inline style on <html> (see _engine/theme.js), SEO meta and JSON-LD in
   <head> (see _engine/seo.js). Serializing that document captures all of it,
   so the exported page needs no engine, no config fetch and no build step.

   Markup here is built with DOM APIs and fixed literals only. Config values
   reach the output as text nodes or JSON.stringify'd script data, never by
   interpolation into an HTML string.
*/

const enc = new TextEncoder();
const bytes = s => enc.encode(s);

export function slugify(name) {
  const s = String(name || '').toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return s || 'site';
}

export function folderName(business, date = new Date()) {
  const p = n => String(n).padStart(2, '0');
  const stamp = `${date.getFullYear()}${p(date.getMonth() + 1)}${p(date.getDate())}`
              + `-${p(date.getHours())}${p(date.getMinutes())}`;
  return `${slugify(business && business.name)}-${stamp}`;
}

/* behaviors.js ships as a classic script so the exported folder also works
   from file://, where an ES module would be blocked by CORS. It has no
   imports of its own, so dropping the `export` keyword is sufficient. */
function asClassicScript(src) {
  return src.replace(/^export\s+function\s/m, 'function ');
}

/* Rules the exporter marked as source-only. _themes/base.css styles #loader and
   #errbox, which are stripped from the baked page, so shipping them would
   style nothing. */
function stripExportOnly(css) {
  return String(css || '').replace(/\/\*\s*@export-strip:start[\s\S]*?@export-strip:end\s*\*\//g, '');
}

/* The svg text back out of a data: URI the engine produced. */
function decodeDataUri(src) {
  const comma = src.indexOf(',');
  const body = src.slice(comma + 1);
  return /;base64/i.test(src.slice(0, comma)) ? atob(body) : decodeURIComponent(body);
}

/* An absolute preview URL reduced to a bundle-relative path. The export
   always keeps images in images/, so only the filename carries over. */
function localImagePath(src) {
  let name = '';
  try { name = new URL(src).pathname.split('/').pop() || ''; }
  catch { name = String(src).split('/').pop() || ''; }
  name = decodeURIComponent(name.split('?')[0]);
  return name ? `images/${name}` : src;
}

/* bake({doc, cfg, attachments, library, layoutId, assets}) -> [{path, bytes}]

   doc          the preview Document — cloned, never mutated
   cfg          the config object
   attachments  Map<filename, {url, data}> — files attached in this session
   library      Map<filename, Uint8Array>  — dataset images the caller fetched
   layoutId     which layout rendered it — names its stylesheet in _themes/
   assets       {baseCss, layoutCss, behaviors} — raw text the caller fetched
*/
export function bake({ doc, cfg, attachments, library, layoutId, assets }) {
  const root = doc.documentElement.cloneNode(true);

  // 1. engine scaffolding has no place in a static page. The <template> blocks
  //    are the layout's source, already rendered into #app — shipping them
  //    would roughly double the page for markup that never displays.
  root.querySelectorAll('#loader, #errbox').forEach(el => el.remove());
  root.querySelectorAll('template[data-part], template[data-section]').forEach(el => el.remove());
  root.querySelectorAll('script[type="module"]').forEach(el => el.remove());
  root.removeAttribute('data-editor');
  // Comments in the shell and the layout explain this repo to its maintainers;
  // they are not part of the site someone deploys.
  const walker = doc.createTreeWalker(root, NodeFilter.SHOW_COMMENT);
  const comments = [];
  while (walker.nextNode()) comments.push(walker.currentNode);
  for (const c of comments) c.remove();

  // 2. the preview's IntersectionObserver has already revealed everything;
  //    clear it so the animation plays on the real site
  root.querySelectorAll('.reveal.in').forEach(el => el.classList.remove('in'));

  // 3. images -> bundled local paths. Attached files map by the blob URL the
  //    preview used; anything else still resolved to an absolute URL against
  //    the dataset, which must not be baked into a deployed page — reduce it
  //    to images/<name> so the path is right even when the file is absent.
  const byUrl = new Map();
  for (const [filename, rec] of attachments) byUrl.set(rec.url, `images/${filename}`);

  // Art the engine re-tinted to the active theme. The export must carry it as
  // themed, not as originally generated, so decode it back out of the data URI.
  const retinted = new Map();

  root.querySelectorAll('img[src]').forEach(img => {
    const src = img.getAttribute('src');
    const origin = img.getAttribute('data-img-src');
    img.removeAttribute('data-img-src');

    if (origin && src.startsWith('data:')) {
      const name = localImagePath(origin).replace(/^images\//, '');
      retinted.set(name, decodeDataUri(src));
      img.setAttribute('src', `images/${name}`);
      return;
    }
    const attached = byUrl.get(src);
    if (attached) { img.setAttribute('src', attached); return; }
    if (/^(?:https?:|blob:)/i.test(src)) img.setAttribute('src', localImagePath(src));
  });

  // 4. An export is one frozen layout+dataset, so the source's split between
  //    token defaults, layout css and the config's theme block has no consumer
  //    here. Fold both stylesheets into the page and drop the <link>s. The
  //    Google Fonts link stays — it is a real external dependency.
  const sheets = [];
  root.querySelectorAll('link[rel="stylesheet"]').forEach(l => {
    const href = l.getAttribute('href') || '';
    if (href.endsWith('_themes/base.css')) { sheets[0] = stripExportOnly(assets.baseCss); l.remove(); }
    else if (href.endsWith(`_themes/${layoutId}.css`)) { sheets[1] = assets.layoutCss; l.remove(); }
  });
  if (sheets.length) {
    const style = doc.createElement('style');
    style.textContent = sheets.filter(Boolean).join('\n');
    root.querySelector('head').appendChild(style);
  }

  // 5. wire behaviour. wireUp() reads only these three business fields.
  const b = (cfg && cfg.business) || {};
  const body = root.querySelector('body');
  const tag = doc.createElement('script');
  tag.setAttribute('src', 'behaviors.js');
  const boot = doc.createElement('script');
  boot.textContent = 'wireUp(document.getElementById("app"), {business:'
    + JSON.stringify({ name: b.name || '', whatsapp: b.whatsapp || '', email: b.email || '' })
    + '});';
  body.append(tag, boot);

  const files = [
    { path: 'index.html', bytes: bytes('<!DOCTYPE html>\n' + root.outerHTML) },
    { path: 'behaviors.js', bytes: bytes(asClassicScript(assets.behaviors)) },
  ];
  for (const [filename, rec] of attachments) {
    files.push({ path: `images/${filename}`, bytes: rec.data });
  }
  // Re-tinted art wins over the library copy: it matches the theme as exported.
  for (const [filename, text] of retinted) {
    if (!attachments.has(filename)) files.push({ path: `images/${filename}`, bytes: bytes(text) });
  }
  // Whatever the caller fetched from the dataset folder and nothing above covers.
  for (const [filename, data] of (library || new Map())) {
    if (!attachments.has(filename) && !retinted.has(filename))
      files.push({ path: `images/${filename}`, bytes: data });
  }
  return files;
}
