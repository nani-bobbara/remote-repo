/* Generate themed placeholder artwork for the sample datasets.

   Node only — never loaded by a page. Writes one SVG per image path referenced
   by a dataset's seed.json, coloured from that dataset's own theme.colors, into
   that dataset's own images/ folder, then rewrites the seed.json paths to .svg.

   This is placeholder art, not photography. Replace the files with real photos
   whenever you have them; the filenames are all that matter.

   Run: node _editor/make-placeholder-images.mjs
*/
import { readFileSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');

const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const stripTags = s => String(s).replace(/<[^>]*>/g, '');

// SVG text does not wrap. Split a label into at most 3 lines of ~18 characters.
function lines(label, max = 18, cap = 3) {
  const words = stripTags(label).trim().split(/\s+/).filter(Boolean);
  const out = [];
  let cur = '';
  for (const w of words) {
    if (!cur) cur = w;
    else if ((cur + ' ' + w).length <= max) cur += ' ' + w;
    else { out.push(cur); cur = w; if (out.length === cap) break; }
  }
  if (cur && out.length < cap) out.push(cur);
  return out.length ? out : ['Image'];
}

// The motif varies by section type so hero, feature, collection and gallery
// images are distinguishable at thumbnail size.
function motif(kind, c) {
  if (kind === 'hero')
    return `<circle cx="880" cy="300" r="260" fill="${c.accent}" opacity=".22"/>`
         + `<circle cx="980" cy="470" r="150" fill="${c.secondary}" opacity=".3"/>`;
  if (kind === 'feature')
    return `<rect x="140" y="150" width="420" height="420" rx="28" fill="${c.accent}" opacity=".2"/>`
         + `<rect x="330" y="280" width="420" height="380" rx="28" fill="${c.secondary}" opacity=".26"/>`;
  if (kind === 'collection')
    return `<rect x="700" y="170" width="180" height="180" rx="22" fill="${c.accent}" opacity=".26"/>`
         + `<rect x="910" y="170" width="180" height="180" rx="22" fill="${c.secondary}" opacity=".26"/>`
         + `<rect x="700" y="380" width="390" height="180" rx="22" fill="${c.accent}" opacity=".16"/>`;
  if (kind === 'gallery')
    return `<path d="M0 800 L400 200 L560 200 L160 800 Z" fill="${c.accent}" opacity=".18"/>`
         + `<path d="M300 800 L700 200 L860 200 L460 800 Z" fill="${c.secondary}" opacity=".18"/>`;
  return `<circle cx="600" cy="400" r="220" fill="${c.accent}" opacity=".2"/>`;
}

/* Role -> native hex, so _engine/recolor.js can re-tint this art to whatever
   theme is active. The file keeps real colours, so it stays valid and correct
   when opened on its own. */
function tokens(c) {
  return ['dark', 'dark2', 'accent', 'secondary', 'onDark']
    .filter(k => c[k])
    .map(k => `${k}:${c[k]}`)
    .join(';');
}

function sectionSvg(label, kind, c) {
  const ls = lines(label);
  const startY = 700 - (ls.length - 1) * 56;
  const text = ls.map((l, i) =>
    `<text x="90" y="${startY + i * 56}" font-family="Georgia,'Times New Roman',serif" `
    + `font-size="46" fill="${c.onDark}">${esc(l)}</text>`).join('');
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 800" width="1200" height="800" `
    + `data-tokens="${tokens(c)}" `
    + `role="img" aria-label="${esc(stripTags(label))}">`
    + `<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">`
    + `<stop offset="0" stop-color="${c.dark}"/><stop offset="1" stop-color="${c.dark2}"/>`
    + `</linearGradient></defs>`
    + `<rect width="1200" height="800" fill="url(#g)"/>`
    + motif(kind, c)
    + `<rect x="90" y="${startY - 92}" width="76" height="6" rx="3" fill="${c.accent}"/>`
    + text
    + `</svg>`;
}

function logoSvg(name, c) {
  const initial = (stripTags(name).trim()[0] || '?').toUpperCase();
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400" `
    + `data-tokens="${tokens(c)}" `
    + `role="img" aria-label="${esc(name)}">`
    + `<rect width="400" height="400" rx="72" fill="${c.dark}"/>`
    + `<circle cx="200" cy="200" r="132" fill="${c.accent}" opacity=".22"/>`
    + `<text x="200" y="258" text-anchor="middle" font-family="Georgia,'Times New Roman',serif" `
    + `font-size="180" fill="${c.onDark}">${esc(initial)}</text>`
    + `</svg>`;
}

// Every image path in a config, with the nearest label and its section type.
function refs(cfg) {
  const out = [];
  if (cfg.business && typeof cfg.business.logo === 'string')
    out.push({ path: cfg.business.logo, kind: 'logo', label: cfg.business.name || '?' });
  for (const s of cfg.sections || []) {
    // A hero's headline is stored split across title + titleAccent.
    const head = s.type === 'hero'
      ? [s.title, s.titleAccent].filter(Boolean).join(' ')
      : (s.title || s.heading || s.type);
    if (typeof s.image === 'string') out.push({ path: s.image, kind: s.type, label: head });
    for (const it of s.items || []) {
      if (it && typeof it.image === 'string')
        out.push({ path: it.image, kind: s.type, label: it.title || it.caption || head });
    }
  }
  return out;
}

const datasets = JSON.parse(readFileSync(join(ROOT, '_datasets/datasets.json'), 'utf8'));
let count = 0;

for (const { id } of datasets) {
  const dir = join(ROOT, '_datasets', id);
  const seedPath = join(dir, 'seed.json');
  let raw = readFileSync(seedPath, 'utf8');
  const cfg = JSON.parse(raw);
  const c = cfg.theme.colors;
  const list = refs(cfg);

  for (const r of list) {
    const svgName = r.path.replace(/\.(jpe?g|png|webp|avif)$/i, '.svg');
    const svg = r.kind === 'logo' ? logoSvg(r.label, c) : sectionSvg(r.label, r.kind, c);
    writeFileSync(join(dir, svgName), svg + '\n', 'utf8');
    // Rewrite in the raw text so the file's own formatting survives.
    raw = raw.split(`"${r.path}"`).join(`"${svgName}"`);
    count++;
  }
  writeFileSync(seedPath, raw, 'utf8');
  console.log(`${id}: wrote ${list.length} svgs`);
}
console.log(`done — ${count} images`);
