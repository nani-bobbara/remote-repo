/* CONTRACT C — the behaviour interface between a layout and the engine.

   A layout declares what it wants wired by putting data-role / data-field on
   its own elements. This module reads only those attributes: it never names a
   class or an id that belongs to a particular layout, so any layout can drop
   any hook and the rest still works.

   Roles a layout may declare
     data-role="header"    gets .scrolled toggled past 40px of scroll
     data-role="burger"    menu toggle; needs aria-expanded, wired with "menu"
     data-role="menu"      the panel the burger opens; its links close it
     data-role="tab"       a bottom-tab link; gets .active by scrollspy
     data-role="wa-form"   the send button of the enquiry form
     data-role="reveal"    (or class="reveal") gets .in when scrolled into view

   Fields the enquiry form may declare
     data-field="name" | "phone" | "item" | "message"

   Anything absent is simply not wired. data-role/data-field are stripped after
   wiring so they never reach the rendered output — except in the editor
   preview, where export bakes that DOM and needs the hooks intact.
*/

const one = (root, role) => root.querySelector(`[data-role="${role}"]`);
const all = (root, role) => [...root.querySelectorAll(`[data-role="${role}"]`)];

export function wireUp(root, $root) {
  const biz = ($root && $root.business) || {};

  const header = one(root, 'header');
  if (header) addEventListener('scroll',
    () => header.classList.toggle('scrolled', scrollY > 40), { passive: true });

  const burger = one(root, 'burger');
  const menu = one(root, 'menu');
  if (burger && menu) {
    const close = () => {
      menu.classList.remove('open');
      burger.classList.remove('x');
      burger.setAttribute('aria-expanded', 'false');
      document.body.classList.remove('locked');
    };
    burger.addEventListener('click', () => {
      const open = menu.classList.toggle('open');
      burger.classList.toggle('x');
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
      document.body.classList.toggle('locked', open);
    });
    menu.querySelectorAll('a').forEach(a => a.addEventListener('click', close));
  }

  // .reveal is engine-owned: base.css defines the transition, data-stagger adds
  // the class. A layout may also mark an element with data-role="reveal".
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
  }), { threshold: .12 });
  for (const el of [...root.querySelectorAll('.reveal'), ...all(root, 'reveal')]) {
    el.classList.add('reveal');
    io.observe(el);
  }

  // Active tab tracks the section in the middle of the viewport. Sections are
  // whatever the engine appended with an id — not a tag name, so a layout is
  // free to use <section>, <article> or <div> as its section root.
  const tabs = all(root, 'tab');
  if (tabs.length) {
    const secIO = new IntersectionObserver(es => es.forEach(e => {
      if (e.isIntersecting) {
        const id = '#' + e.target.id;
        tabs.forEach(t => t.classList.toggle('active', t.getAttribute('href') === id));
      }
    }), { rootMargin: '-45% 0px -45% 0px' });
    root.querySelectorAll(':scope > [id]').forEach(s => secIO.observe(s));
  }

  // Enquiry form -> WhatsApp, falling back to mailto.
  const send = one(root, 'wa-form');
  if (send) {
    send.addEventListener('click', () => {
      const g = name => {
        const el = root.querySelector(`[data-field="${name}"]`);
        return el ? String(el.value || '').trim() : '';
      };
      const has = name => !!root.querySelector(`[data-field="${name}"]`);
      const wa = String(biz.whatsapp || '').replace(/[^0-9]/g, '');
      const msg = `Hello ${biz.name || ''},\nName: ${g('name') || '-'}\nPhone: ${g('phone') || '-'}`
        + (has('item') ? `\nLooking for: ${g('item') || '-'}` : '')
        + `\nDetails: ${g('message') || '-'}`;
      if (wa) window.open('https://wa.me/' + wa + '?text=' + encodeURIComponent(msg), '_blank');
      else if (biz.email) window.location.href = 'mailto:' + biz.email
        + '?subject=' + encodeURIComponent('Enquiry') + '&body=' + encodeURIComponent(msg);
    });
  }

  // Plumbing, not content — keep it out of the output. The editor preview keeps
  // it: export bakes that DOM and re-runs wireUp on the baked page.
  if (document.documentElement.getAttribute('data-editor') !== '1') {
    root.querySelectorAll('[data-role]').forEach(el => el.removeAttribute('data-role'));
  }
}
