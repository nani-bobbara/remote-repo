// ============ CONFIG VALIDATION ============
// Purpose-built checker (NOT a general JSON-Schema engine) — keeps the site zero-dep.
// The per-section required-field rules are DERIVED from config.schema.json, so there
// is a single source of truth.

export function requiredFromSchema(schema) {
  const out = {};
  const all = schema?.$defs?.section?.allOf || [];
  for (const rule of all) {
    const type = rule?.if?.properties?.type?.const;
    const req = rule?.then?.required;
    if (type && Array.isArray(req)) out[type] = req.filter(f => f !== 'type');
  }
  return out;
}

export async function loadRequired(schemaUrl) {
  try {
    const r = await fetch(schemaUrl, { cache: 'no-cache' });
    if (!r.ok) throw new Error(r.status);
    return requiredFromSchema(await r.json());
  } catch { return {}; }
}

function nearest(word, list) {
  word = String(word || '').toLowerCase();
  return list.find(t => t.startsWith(word[0] || '~') && Math.abs(t.length - word.length) <= 3) || null;
}

export function validateConfig(cfg, required) {
  const e = [];
  const known = Object.keys(required);
  if (!cfg || typeof cfg !== 'object' || Array.isArray(cfg))
    return { ok: false, errors: [{ path: '(root)', msg: 'config is not a JSON object' }] };
  if (!cfg.business || typeof cfg.business !== 'object')
    e.push({ path: 'business', msg: 'is required (object with name, phone, …)' });
  if (!Array.isArray(cfg.sections))
    e.push({ path: 'sections', msg: 'is required and must be an array' });
  (Array.isArray(cfg.sections) ? cfg.sections : []).forEach((s, i) => {
    const p = 'sections[' + i + ']';
    if (!s || !s.type) { e.push({ path: p, msg: 'missing "type"' }); return; }
    // With no schema loaded, every type is accepted — the layout decides what it renders.
    if (known.length && !known.includes(s.type)) {
      const g = nearest(s.type, known);
      e.push({ path: p, msg: 'unknown type "' + s.type + '"' + (g ? ' — did you mean "' + g + '"?' : '') });
      return;
    }
    (required[s.type] || []).forEach(f => {
      const v = s[f];
      const empty = v == null || (Array.isArray(v) && !v.length) || v === '';
      if (empty) e.push({ path: p + ' (' + s.type + ')', msg: 'missing required field "' + f + '"' });
    });
  });
  return { ok: e.length === 0, errors: e };
}
