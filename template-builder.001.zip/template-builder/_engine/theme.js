/* Theme application.

   Writes the config's `theme` block onto :root as CSS custom properties, so a
   dataset can restyle the site without touching the stylesheet. Every token is
   optional — an absent key leaves the base.css default in place.

   The key -> custom-property mapping is NOT restated here; it comes from
   tokens.js, which is the one place the vocabulary is defined.
*/

import { mapFor } from './tokens.js';

const COLORS = mapFor('colors');
const FONTS = mapFor('fonts');
const SHAPE = mapFor('shape');

export function applyTheme(t = {}) {
  const root = document.documentElement.style;
  const set = (src = {}, map) => { for (const k in map) if (src[k]) root.setProperty(map[k], src[k]); };
  set(t.colors, COLORS); set(t.fonts, FONTS); set(t.shape, SHAPE);

  const gf = t.fonts && t.fonts.googleFonts;
  if (gf) {
    const href = 'https://fonts.googleapis.com/css2?' + gf + '&display=swap';
    // Guard against a second <link> when applyTheme runs again (editor live preview).
    if (!document.querySelector(`link[href="${href}"]`)) {
      const l = document.createElement('link');
      l.rel = 'stylesheet'; l.href = href;
      document.head.appendChild(l);
    }
  }
  if (t.themeColor) {
    let m = document.querySelector('meta[name=theme-color]');
    if (!m) { m = document.createElement('meta'); m.name = 'theme-color'; document.head.appendChild(m); }
    m.content = t.themeColor;
  }
}
