/* CONTRACT B — the token vocabulary.

   The single source of truth for every design token. A theme supplies values
   for these names; a layout consumes them with var(--name). Neither knows the
   other exists — this table is the whole interface between them.

   Everything downstream derives from here:
     _themes/base.css       the :root defaults      (generated — see make-tokens.mjs)
     config.schema.json     theme.* properties      (generated)
     _engine/theme.js       config key -> CSS var   (imported, not copied)
     the editor's controls  which pickers to render (imported)

   Add a token here and run `node _editor/make-tokens.mjs`; nothing else needs
   editing. `check-layout.mjs --tokens` fails if the generated files drift.

   group     which theme.<group> block in the config carries it; null = not
             themeable, the engine owns the value
   key       the config key inside that group (camelCase, JSON-ish)
   css       the custom property name (kebab-case, CSS-ish)
   value     the default, used when no theme overrides it
   note      shown as the description in config.schema.json
*/

export const TOKENS = [
  // ---- colours -------------------------------------------------------------
  { group: 'colors', key: 'bg',          css: '--bg',           value: '#f8f3e9', note: 'Page background.' },
  { group: 'colors', key: 'bg2',         css: '--bg-2',         value: '#f1e8d6', note: 'Alternate band background.' },
  { group: 'colors', key: 'surface',     css: '--surface',      value: '#ffffff', note: 'Cards and raised surfaces.' },
  { group: 'colors', key: 'dark',        css: '--dark',         value: '#150c07', note: 'Darkest ground, used for inverted sections.' },
  { group: 'colors', key: 'dark2',       css: '--dark-2',       value: '#241610', note: 'Second dark step.' },
  { group: 'colors', key: 'dark3',       css: '--dark-3',       value: '#33200f', note: 'Third dark step.' },
  { group: 'colors', key: 'ink',         css: '--ink',          value: '#2a1c12', note: 'Primary text on light backgrounds.' },
  { group: 'colors', key: 'muted',       css: '--muted',        value: '#7a6650', note: 'Secondary text on light backgrounds.' },
  { group: 'colors', key: 'onDark',      css: '--on-dark',      value: '#e9dcc3', note: 'Primary text on dark backgrounds.' },
  { group: 'colors', key: 'onDarkDim',   css: '--on-dark-dim',  value: 'rgba(233,220,195,.66)', note: 'Secondary text on dark backgrounds.' },
  { group: 'colors', key: 'accent',      css: '--accent',       value: '#c79a4d', note: 'Primary accent.' },
  { group: 'colors', key: 'accentBright',css: '--accent-bright',value: '#e6bf72', note: 'Accent for dark grounds and focus rings.' },
  { group: 'colors', key: 'accentSoft',  css: '--accent-soft',  value: '#a07f38', note: 'Accent for light grounds.' },
  { group: 'colors', key: 'secondary',   css: '--secondary',    value: '#7a2f24', note: 'Secondary accent.' },
  { group: 'colors', key: 'line',        css: '--line',         value: 'rgba(199,154,77,.24)', note: 'Hairline on light grounds.' },
  { group: 'colors', key: 'lineDark',    css: '--line-dark',    value: 'rgba(230,191,114,.16)', note: 'Hairline on dark grounds.' },

  // ---- type ----------------------------------------------------------------
  { group: 'fonts', key: 'display',       css: '--display',        value: "'Bricolage Grotesque',system-ui,sans-serif", note: 'CSS font-family for headings.' },
  { group: 'fonts', key: 'sans',          css: '--sans',           value: "'Instrument Sans',system-ui,sans-serif", note: 'CSS font-family for body text.' },
  { group: 'fonts', key: 'displayWeight', css: '--display-weight', value: '700', note: 'Heading font weight.' },
  { group: 'fonts', key: 'tracking',      css: '--tracking',       value: '-.035em', note: 'Heading letter-spacing, e.g. -.02em.' },

  // ---- shape ---------------------------------------------------------------
  { group: 'shape', key: 'radius',      css: '--radius',      value: '20px',  note: 'Card corner radius, e.g. 20px (rounded) or 4px (sharp).' },
  { group: 'shape', key: 'radiusSm',    css: '--radius-sm',   value: '12px',  note: 'Small corner radius — inputs, chips.' },
  { group: 'shape', key: 'radiusPill',  css: '--radius-pill', value: '100px', note: 'Fully rounded — pills and round buttons.' },

  // ---- engine-owned: layouts read these, themes cannot set them ------------
  { group: null, key: 'maxw',     css: '--maxw',     value: '1280px', note: 'Content max width.' },
  { group: null, key: 'tabbarH',  css: '--tabbar-h', value: '64px',   note: 'Mobile tab bar height.' },
  { group: null, key: 'safeB',    css: '--safe-b',   value: 'env(safe-area-inset-bottom,0px)', note: 'Bottom safe-area inset.' },
];

/* Config keys that are not tokens but belong to the theme block. */
export const THEME_EXTRAS = {
  themeColor: { note: 'Mobile browser chrome colour (meta theme-color).' },
  fonts: {
    googleFonts: { note: 'Query part of a Google Fonts css2 URL, e.g. family=Inter:wght@400;600. Loaded automatically.' },
  },
};

/* group -> { configKey: cssVar } — what theme.js applies. */
export function mapFor(group) {
  return Object.fromEntries(TOKENS.filter(t => t.group === group).map(t => [t.key, t.css]));
}

/* Colour roles recolor.js can substitute inside themeable SVG art. */
export const RECOLOR_ROLES = ['dark', 'dark2', 'accent', 'secondary', 'onDark'];
