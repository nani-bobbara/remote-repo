/* Path resolution.

   The rule that makes datasets portable across layouts: a relative asset path
   in a config resolves against THAT CONFIG'S url, not against the page. So
   `images/hero.jpg` inside _datasets/cafe/seed.json always means
   _datasets/cafe/images/hero.jpg, no matter which layout renders it.
*/

// Anything already absolute — scheme, protocol-relative, or site-root.
const PASSTHROUGH = /^(?:[a-z][a-z0-9+.-]*:|\/\/|\/)/i;

export function resolveAsset(path, baseUrl) {
  const p = path == null ? '' : String(path).trim();
  if (!p) return '';
  if (PASSTHROUGH.test(p)) return p;
  return new URL(p, baseUrl).href;
}

// A bare word (no slash, no .json) names a folder under _datasets/.
// Anything else is treated as a path relative to the repo root.
export function resolveData(param, rootUrl, defaultData) {
  const p = param == null ? '' : String(param).trim();
  if (!p) return new URL(`_datasets/${defaultData}/seed.json`, rootUrl).href;
  const bare = !p.includes('/') && !p.endsWith('.json');
  return bare
    ? new URL(`_datasets/${p}/seed.json`, rootUrl).href
    : new URL(p, rootUrl).href;
}
