/* Boot orchestration — the only module a layout page loads.

   Resolves which dataset to render, fetches and validates it, then binds the
   layout's <template> blocks into #app and wires behaviour.

   A layout declares which section types it supports simply by which
   <template data-section="..."> blocks it contains; a type present in the data
   with no matching template is skipped with a warning and the page still
   renders.

   Data resolution:
     index.html                      -> _datasets/<defaultData>/seed.json
     index.html?data=cafe            -> _datasets/cafe/seed.json
     index.html?data=../../x.json    -> that path
     index.html?editor=1             -> renders from postMessage only
*/

import { applyTheme } from './theme.js';
import { applySeo } from './seo.js';
import { bindElement } from './bind.js';
import { loadRequired, validateConfig } from './validate.js';
import { wireUp } from './behaviors.js';
import { resolveData } from './paths.js';

const ROOT_URL = new URL('../', import.meta.url).href;
const params = new URLSearchParams(location.search);

// Values a layout can reach with the `$.` prefix, so markup stays declarative
// instead of re-deriving business logic.
export function buildRoot(cfg) {
  const b = (cfg && cfg.business) || {};
  const wa = String(b.whatsapp || '').replace(/[^0-9]/g, '');
  return {
    business: b,
    waLink: wa ? 'https://wa.me/' + wa : '',
    telLink: b.phone ? 'tel:' + b.phone : '',
    mailLink: b.email ? 'mailto:' + b.email : '',
    initial: (b.name || '?')[0],
    year: new Date().getFullYear(),
  };
}

export function render(cfg, baseUrl) {
  applyTheme(cfg.theme || {});
  // Themeable SVG art is re-tinted to these; see _engine/recolor.js.
  const themeColors = (cfg.theme && cfg.theme.colors) || {};
  const $root = buildRoot(cfg);
  // applySeo also sets document.title and the description meta.
  applySeo(cfg.business || {}, baseUrl);

  const app = document.getElementById('app');
  app.textContent = '';

  const tpl = name => document.querySelector(`template[data-section="${name}"]`);
  const part = name => document.querySelector(`template[data-part="${name}"]`);

  const place = (template, data, section, id) => {
    if (!template) return null;
    const node = template.content.cloneNode(true);
    const roots = [...node.children];
    for (const el of roots)
      bindElement(el, { data, $section: section ?? data, $root, baseUrl, themeColors });
    // roots[0] may have been removed by its own data-if; re-read from the fragment.
    const first = node.firstElementChild;
    if (id && first) first.id = id;
    app.appendChild(node);
    return first;
  };

  place(part('nav'), { nav: cfg.nav || [], business: cfg.business || {} });

  for (const sec of cfg.sections || []) {
    if (sec.enabled === false) continue;
    const t = tpl(sec.type);
    if (!t) { console.warn(`layout has no template for section type "${sec.type}" — skipped`); continue; }
    const added = place(t, sec, sec, sec.id);
    // The monolith opened the first FAQ item; there is no clean declarative
    // form for "first child only", so it is set here.
    if (sec.type === 'faq' && added) {
      const first = added.querySelector('details');
      if (first) first.setAttribute('open', '');
    }
  }

  place(part('footer'), { footer: cfg.footer || {}, business: cfg.business || {} });
  place(part('tabbar'), { tabbar: cfg.tabbar || [], business: cfg.business || {} });

  wireUp(app, $root);

  const ld = document.getElementById('loader');
  if (ld) { ld.classList.add('hide'); setTimeout(() => ld.remove(), 600); }
}

/* Pull in a layout: its stylesheet, then its <template> blocks.

   A layout is a fragment of <template>s, not a page — the shell, the chrome and
   this script live once in /view.html. So the engine appends the layout's
   stylesheet after base.css (design overrides foundation) and imports its
   templates into the document before anything tries to render them.

   The stylesheet is awaited: rendering into an unstyled document and then
   restyling it is a visible flash, and the loader is already covering us. */
async function loadLayout(id) {
  await new Promise((resolve, reject) => {
    const href = `_themes/${id}.css`;
    if (document.querySelector(`link[href="${href}"]`)) return resolve();
    const l = document.createElement('link');
    l.rel = 'stylesheet';
    l.href = href;                        // relative: the exporter matches on this
    l.onload = resolve;
    l.onerror = () => reject(new Error(`_themes/${id}.css could not be loaded`));
    document.head.appendChild(l);
  });

  const r = await fetch(new URL(`_layouts/${id}.html`, ROOT_URL), { cache: 'no-cache' });
  if (!r.ok) throw new Error(`_layouts/${id}.html — ${r.status}`);
  const parsed = new DOMParser().parseFromString(await r.text(), 'text/html');
  const blocks = parsed.querySelectorAll('template[data-part],template[data-section]');
  if (!blocks.length) throw new Error(`_layouts/${id}.html has no <template> blocks`);
  for (const t of blocks) document.body.appendChild(document.importNode(t, true));
}

/* The three axes are independent, so each is selected on its own: ?layout= picks
   the arrangement, ?data= picks the business, ?theme= picks the palette.

   A dataset's own `theme` block is that business's brand, which is content —
   it stays the default. ?theme= layers a generic preset over it, so any
   business can be previewed in any palette without editing the dataset. */
async function withTheme(datasetTheme, themeId) {
  const base = datasetTheme || {};
  if (!themeId) return base;
  try {
    const r = await fetch(new URL(`_themes/${themeId}.json`, ROOT_URL), { cache: 'no-cache' });
    if (!r.ok) throw new Error(r.status);
    const preset = await r.json();
    // Merge one level down so a preset that sets only `colors` keeps the
    // dataset's fonts and shape rather than blanking them.
    return {
      ...base, ...preset,
      colors: { ...base.colors, ...preset.colors },
      fonts: { ...base.fonts, ...preset.fonts },
      shape: { ...base.shape, ...preset.shape },
    };
  } catch (err) {
    console.warn(`theme "${themeId}" could not be loaded — using the dataset's own`, err);
    return base;
  }
}

function showErrors(errors) {
  const list = document.getElementById('errlist');
  if (list) {
    list.textContent = '';
    for (const x of errors) {
      const li = document.createElement('li');
      const code = document.createElement('code');
      code.textContent = x.path;
      li.append(code, ' — ' + x.msg);
      list.appendChild(li);
    }
  }
  const ld = document.getElementById('loader'); if (ld) ld.style.display = 'none';
  const box = document.getElementById('errbox'); if (box) box.classList.add('show');
}

function failHard() {
  const ld = document.getElementById('loader'); if (ld) ld.style.display = 'none';
  const box = document.getElementById('errbox'); if (box) box.classList.add('show');
}

async function boot() {
  // The registry answers both "is this a real layout?" and, when no ?data= was
  // given, "which business should this arrangement show off?".
  let registry = [];
  try {
    registry = await (await fetch(new URL('_layouts/layouts.json', ROOT_URL),
                                  { cache: 'no-cache' })).json();
  } catch { /* reported below */ }

  if (!registry.length) {
    showErrors([{ path: '_layouts/layouts.json', msg: 'could not be read — no layout is available' }]);
    return;
  }

  // ?layout= picks the arrangement; with none, the first registered one.
  const wanted = params.get('layout');
  const entry = wanted ? registry.find(l => l.id === wanted) : registry[0];
  if (!entry) {
    showErrors([{ path: `?layout=${wanted}`,
      msg: `is not a registered layout — try one of: ${registry.map(l => l.id).join(', ')}` }]);
    return;
  }

  try {
    await loadLayout(entry.id);
  } catch (err) {
    console.error('Layout load failed:', err);
    showErrors([{ path: `_layouts/${entry.id}.html`, msg: String(err.message || err) }]);
    return;
  }

  // Editor live-preview: the layout is now in place; content arrives by
  // postMessage on every keystroke, so never fetch a dataset here.
  if (params.get('editor') === '1') {
    document.documentElement.setAttribute('data-editor', '1');
    addEventListener('message', e => {
      if (e && e.data && e.data.__siteConfig) {
        try { render(e.data.config, e.data.baseUrl || location.href); }
        catch (err) { console.error('editor render failed', err); }
      }
    });
    const ld = document.getElementById('loader'); if (ld) ld.classList.add('hide');
    if (window.parent !== window) window.parent.postMessage({ __siteReady: true }, '*');
    return;
  }

  const dataUrl = resolveData(params.get('data'), ROOT_URL, entry.defaultData || '');
  try {
    const r = await fetch(dataUrl, { cache: 'no-cache' });
    if (!r.ok) throw new Error(r.status);
    const cfg = await r.json();
    const required = await loadRequired(new URL('config.schema.json', ROOT_URL).href);
    const v = validateConfig(cfg, required);
    if (!v.ok) { console.error('Invalid config:', v.errors); showErrors(v.errors); return; }
    cfg.theme = await withTheme(cfg.theme, params.get('theme'));
    render(cfg, dataUrl);
  } catch (err) {
    console.error('Config load failed:', err);
    failHard();
  }
}

boot();
