/* SEO / social metadata.

   Emits the document title, description, OpenGraph + Twitter cards and a
   JSON-LD LocalBusiness block from config.business. Re-callable: every tag is
   looked up first and updated in place, so the editor's live preview never
   accumulates duplicates.

   Image fields resolve against the CONFIG's url (not the page), so a dataset
   that says `images/og.jpg` keeps working from any layout — see paths.js.
*/

import { resolveAsset } from './paths.js';

export function applySeo(business, baseUrl) {
  const biz = business || {};

  // Selector, attribute kind ('property'|'name'), key, value. Missing tags are
  // created; falsy values are skipped so an absent field never blanks a tag.
  const set = (sel, kind, key, val) => {
    if (!val) return;
    let m = document.querySelector(sel);
    if (!m) { m = document.createElement('meta'); m.setAttribute(kind, key); document.head.appendChild(m); }
    m.setAttribute('content', val);
  };

  document.title = biz.seoTitle || ((biz.name || '') + (biz.tagline ? ' — ' + biz.tagline : ''));
  const title = document.title, desc = (biz.seoDescription || biz.about || '');
  set('meta[name=description]', 'name', 'description', desc);

  const image = resolveAsset(biz.seoImage, baseUrl);

  set('meta[property="og:title"]', 'property', 'og:title', title);
  set('meta[property="og:description"]', 'property', 'og:description', desc);
  set('meta[property="og:type"]', 'property', 'og:type', 'website');
  set('meta[property="og:image"]', 'property', 'og:image', image);
  set('meta[name="twitter:card"]', 'name', 'twitter:card', 'summary_large_image');
  set('meta[name="twitter:title"]', 'name', 'twitter:title', title);
  set('meta[name="twitter:description"]', 'name', 'twitter:description', desc);
  set('meta[name="twitter:image"]', 'name', 'twitter:image', image);

  const ld = {
    '@context': 'https://schema.org', '@type': 'LocalBusiness',
    name: biz.name || '', description: desc || undefined,
    telephone: biz.phone || undefined, email: biz.email || undefined, slogan: biz.motto || undefined,
  };
  let s = document.querySelector('#ld');
  if (!s) { s = document.createElement('script'); s.id = 'ld'; s.type = 'application/ld+json'; document.head.appendChild(s); }
  // textContent, never innerHTML: config data must never be parsed as markup.
  s.textContent = JSON.stringify(ld, (k, v) => v === undefined ? undefined : v);
}
