/* Re-tint themeable SVG assets to the active theme.

   CSS cannot reach inside an SVG loaded through <img src>: it is an isolated
   document, so custom properties and currentColor do not apply. An image whose
   colours were baked at generation time therefore clashes as soon as the theme
   block changes.

   An SVG that opts in carries data-tokens="role:hex;role:hex" on its root. This
   module fetches it, swaps each native hex for the theme's colour for that
   role, and hands back a data: URI. Files that carry no data-tokens are left
   alone — a photograph cannot be re-tinted and should not be.

   Results are cached per url+theme because the editor re-renders on every
   keystroke; without the cache each one would refetch every image.
*/

import { RECOLOR_ROLES } from './tokens.js';

const cache = new Map();

const isThemeable = url => /\.svg(?:[?#]|$)/i.test(url);

function signature(colors) {
  // Only the roles this module can substitute affect the result.
  return RECOLOR_ROLES.map(k => k + ':' + (colors[k] || '')).join(';');
}

async function build(url, colors) {
  const res = await fetch(url, { cache: 'no-cache' });
  if (!res.ok) throw new Error(String(res.status));
  const text = await res.text();

  const decl = /<svg[^>]*\sdata-tokens="([^"]*)"/.exec(text);
  if (!decl) return url;                      // not themeable — use it as-is

  let out = text;
  for (const pair of decl[1].split(';')) {
    const [role, native] = pair.split(':');
    const next = colors[role];
    if (!role || !native || !next || next.toLowerCase() === native.toLowerCase()) continue;
    out = out.split(native).join(next);
    // hexes may appear upper-cased in hand-edited files
    out = out.split(native.toUpperCase()).join(next);
  }
  if (out === text) return url;

  return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(out);
}

/* recolored(url, colors) -> Promise<string>
   Resolves to a data: URI, or to the original url when the asset is not
   themeable or cannot be read. Never rejects: a failed re-tint must not stop
   the page from showing the image it already has. */
export function recolored(url, colors) {
  if (!url || !colors || !isThemeable(url)) return Promise.resolve(url);
  const key = url + '|' + signature(colors);
  let hit = cache.get(key);
  if (!hit) {
    hit = build(url, colors).catch(() => url);
    cache.set(key, hit);
  }
  return hit;
}
