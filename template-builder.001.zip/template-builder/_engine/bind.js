/* The data-binding language.

   A layout is real, hand-editable HTML. Its <template> blocks carry data-*
   attributes; this module clones a template and fills it in from JSON.

   Safety rule: the engine never inserts config data as markup. data-bind sets
   text, attributes are set individually, and data-rich re-BUILDS an allowlisted
   subset of inline elements node by node, copying no attributes. icons.js is the
   only place markup is generated, and only from its own fixed map.

   Attributes:
     data-bind="path"          textContent; removes the element when empty
     data-keep                 opt out of that removal
     data-text="path"          replaces the element with a bare text node
     data-rich="path"          allowlisted inline markup (b/strong/em/i/br/…)
     data-attr-<name>="path"   any attribute (href, src, alt, …)
     data-class-<name>="path"  add that class when the path is truthy
     data-style-<prop>="path"  set that CSS property
     data-if="path" / "!path"  remove the element when falsy / truthy
     data-each="path"          clone this element once per item, in place
     data-stagger[="d1"]       on data-each: add reveal, then d1..d4 by index
                               (or the given class for every item after the first)
     data-icon="path"|"#name"  replace the element with an inline SVG
     data-img="path"           src + alt + placeholder fallback; nothing else
     data-alt="path"           alt source for data-img
     data-stars="path"         N -> N filled stars + an accessible label

   Paths resolve against the current scope. `@.` reaches the enclosing section,
   `$.` reaches globals, `.` is the current item, and `$index` / `$n` / `$nn` are
   the repeat counters (0-based, 1-based, 1-based zero-padded to two digits).
*/

import { resolveAsset } from './paths.js';
import { recolored } from './recolor.js';

/* Set an <img> source, then swap in a theme-tinted copy once it is ready.

   The real src goes on first so nothing waits for the fetch; data-img-src
   records where the art came from, which is how the exporter turns the data
   URI back into a bundled file. */
function setImageSrc(el, src, scope) {
  el.setAttribute('src', src);
  if (!scope.themeColors) return;
  recolored(src, scope.themeColors).then(tinted => {
    if (tinted !== src && el.isConnected) {
      el.setAttribute('data-img-src', src);
      el.setAttribute('src', tinted);
    }
  });
}
import { icon } from './icons.js';

const isEmpty = v =>
  v == null || v === '' || v === false || (Array.isArray(v) && v.length === 0);

/* Alt text is read aloud, so it must never carry markup. Several config fields
   legitimately contain inline tags (a heading with <em>), and a layout is
   entitled to reuse one as an image's description — flatten it here rather than
   making every layout pick a different field. */
function plainText(v) {
  const t = document.createElement('template');
  t.innerHTML = String(v ?? '');
  return (t.content.textContent || '').replace(/\s+/g, ' ').trim();
}

// Inline formatting the datasets legitimately use inside headings and body copy.
// Everything else is unwrapped to its text; no attribute is ever carried over,
// so there is no vector for href/onerror/style injection.
const RICH_TAGS = new Set(['B', 'STRONG', 'EM', 'I', 'BR', 'SPAN', 'SMALL', 'U', 'MARK']);

export function get(scope, path) {
  let src = scope.data, p = String(path || '');
  if (p === '$index') return scope.$index;
  if (p === '$n') return scope.$n;
  if (p === '$nn') return scope.$n == null ? undefined : String(scope.$n).padStart(2, '0');
  if (p === '.') return scope.data;
  if (p.startsWith('$.')) { src = scope.$root; p = p.slice(2); }
  else if (p.startsWith('@.')) { src = scope.$section; p = p.slice(2); }
  return p.split('.').reduce((o, k) => (o == null ? undefined : o[k]), src);
}

function setRich(el, value) {
  const parsed = document.createElement('template');
  parsed.innerHTML = String(value);

  const rebuild = (from, to) => {
    for (const n of [...from.childNodes]) {
      if (n.nodeType === Node.TEXT_NODE) {
        to.appendChild(document.createTextNode(n.nodeValue));
      } else if (n.nodeType === Node.ELEMENT_NODE) {
        if (RICH_TAGS.has(n.tagName)) {
          const fresh = document.createElement(n.tagName.toLowerCase());
          rebuild(n, fresh);
          to.appendChild(fresh);
        } else {
          rebuild(n, to); // unwrap: keep the words, drop the element
        }
      }
    }
  };

  el.textContent = '';
  const out = document.createDocumentFragment();
  rebuild(parsed.content, out);
  el.appendChild(out);
}

// Returns false when the element was removed or replaced — stop descending.
function applyOne(el, scope) {
  const cond = el.getAttribute('data-if');
  if (cond != null) {
    const neg = cond.startsWith('!');
    const v = get(scope, neg ? cond.slice(1) : cond);
    if (isEmpty(v) !== neg) { el.remove(); return false; }
    el.removeAttribute('data-if');
  }

  for (const { name, value } of [...el.attributes]) {
    if (name.startsWith('data-attr-')) {
      const v = get(scope, value);
      const attr = name.slice(10);
      el.removeAttribute(name);
      if (isEmpty(v)) continue;
      // An image source is an asset, so it obeys the same rule as data-img:
      // relative paths resolve against the config's url, not the page's.
      if (attr === 'src' && el.tagName === 'IMG') setImageSrc(el, resolveAsset(v, scope.baseUrl), scope);
      else if (attr === 'alt' || attr === 'title') el.setAttribute(attr, plainText(v));
      else el.setAttribute(attr, String(v));
    } else if (name.startsWith('data-class-')) {
      const v = get(scope, value);
      el.removeAttribute(name);
      if (!isEmpty(v)) el.classList.add(name.slice(11));
    } else if (name.startsWith('data-style-')) {
      const v = get(scope, value);
      el.removeAttribute(name);
      if (!isEmpty(v)) el.style.setProperty(name.slice(11), String(v));
    }
  }

  const iconPath = el.getAttribute('data-icon');
  if (iconPath != null) {
    const name = iconPath.startsWith('#') ? iconPath.slice(1) : get(scope, iconPath);
    const holder = document.createElement('template');
    holder.innerHTML = icon(name || 'info', el.getAttribute('class') || '');
    el.replaceWith(holder.content.firstElementChild);
    return false;
  }

  const imgPath = el.getAttribute('data-img');
  if (imgPath != null) {
    el.removeAttribute('data-img');
    const src = resolveAsset(get(scope, imgPath), scope.baseUrl);
    if (!src) {
      // No photo for this slot: drop the <img> and let the host show the
      // branded placeholder, matching the original onerror behaviour.
      const host = el.parentElement;
      if (host) host.classList.add('noimg');
      el.remove();
      return false;
    }
    setImageSrc(el, src, scope);
    // loading / fetchpriority / decoding are the layout's call — declare them
    // on the <img> in the template. The engine only supplies src, alt, onerror.
    const altPath = el.getAttribute('data-alt');
    if (altPath) {
      el.setAttribute('alt', plainText(get(scope, altPath)));
      el.removeAttribute('data-alt');
    } else if (!el.hasAttribute('alt')) el.setAttribute('alt', '');
    el.setAttribute('onerror', "this.style.display='none';this.parentElement.classList.add('noimg')");
  }

  const starPath = el.getAttribute('data-stars');
  if (starPath != null) {
    el.removeAttribute('data-stars');
    const n = Number(get(scope, starPath)) || 0;
    el.textContent = '★'.repeat(n);
    el.setAttribute('aria-label', n + ' out of 5 stars');
    return true;
  }

  const textPath = el.getAttribute('data-text');
  if (textPath != null) {
    // A bare text node, so bound text can sit beside an element (icon + label)
    // without textContent wiping its siblings.
    const v = get(scope, textPath);
    el.replaceWith(document.createTextNode(isEmpty(v) ? '' : String(v)));
    return false;
  }

  const richPath = el.getAttribute('data-rich');
  if (richPath != null) {
    const v = get(scope, richPath);
    el.removeAttribute('data-rich');
    if (isEmpty(v) && !el.hasAttribute('data-keep')) { el.remove(); return false; }
    el.removeAttribute('data-keep');
    setRich(el, isEmpty(v) ? '' : v);
    return true;
  }

  const bindPath = el.getAttribute('data-bind');
  if (bindPath != null) {
    const v = get(scope, bindPath);
    el.removeAttribute('data-bind');
    if (isEmpty(v) && !el.hasAttribute('data-keep')) { el.remove(); return false; }
    el.removeAttribute('data-keep');
    el.textContent = isEmpty(v) ? '' : String(v);
  }
  return true;
}

export function bindElement(el, scope) {
  const eachPath = el.getAttribute('data-each');
  if (eachPath != null) {
    const list = get(scope, eachPath);
    const stagger = el.getAttribute('data-stagger');
    el.removeAttribute('data-each');
    el.removeAttribute('data-stagger');
    if (!Array.isArray(list) || list.length === 0) { el.remove(); return; }
    const parent = el.parentNode;
    for (let i = 0; i < list.length; i++) {
      const clone = el.cloneNode(true);
      parent.insertBefore(clone, el);
      bindElement(clone, { ...scope, data: list[i], $index: i, $n: i + 1 });
      // Added last so that classes from data-class-* keep the token order the
      // original string template produced. Skipped if data-if removed the clone.
      if (stagger !== null && clone.parentNode) {
        clone.classList.add('reveal');
        if (i > 0) clone.classList.add(stagger || ('d' + Math.min(i, 4)));
      }
    }
    el.remove();
    return;
  }
  if (!applyOne(el, scope)) return;
  for (const child of [...el.children]) bindElement(child, scope);
}
