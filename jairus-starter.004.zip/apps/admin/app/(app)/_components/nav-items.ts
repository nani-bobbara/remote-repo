import { BarChart3, LayoutDashboard, Users, Shield, Settings2, Settings, Database, User, KeyRound, type LucideIcon } from "lucide-react"
import { PERMISSIONS } from "@app/domain"

export type NavItem = {
  href: string
  label: string
  icon: LucideIcon
  permission?: string // hide unless the session has it
}
export type NavGroup = { id: string; label: string; icon: LucideIcon; items: NavItem[] }

// Grouped operator-console nav. Items with a permission are hidden for roles that lack it.
export const navGroups: NavGroup[] = [
  {
    id: "analytics",
    label: "Analytics",
    icon: BarChart3,
    items: [{ href: "/overview", label: "Overview", icon: LayoutDashboard }],
  },
  {
    id: "management",
    label: "Management",
    icon: Settings2,
    // Ordered by dependency, which is also the order you configure a fresh
    // install: permissions are the vocabulary, roles group them, staff are
    // assigned roles. Each item depends only on the ones above it. Listing
    // Role control before Permissions showed the group before its parts.
    items: [
      { href: "/system-setup", label: "System Setup", icon: Database, permission: PERMISSIONS.ADMIN_ACCESS },
      { href: "/permissions", label: "Permissions", icon: KeyRound, permission: PERMISSIONS.PERMISSIONS_READ },
      { href: "/roles", label: "Role control", icon: Shield, permission: PERMISSIONS.ROLES_READ },
      { href: "/staff", label: "Staff", icon: Users, permission: PERMISSIONS.STAFF_READ },
    ],
  },
  {
    id: "settings",
    label: "Settings",
    icon: Settings,
    items: [{ href: "/settings/profile", label: "Profile", icon: User }],
  },
]

// Consumers (sidebar, chevron ribbon, bottom tabs) read this config only through
// `nav-resolve.ts`, which applies permission filtering. Don't export a raw
// flattened list — it bypasses that and can leak a hidden destination.
