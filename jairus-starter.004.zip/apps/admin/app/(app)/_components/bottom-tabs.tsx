"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@app/ui"
import { visibleGroups, type NavAccess } from "./nav-resolve"

// Mobile bottom key-menu (plain tabs — no center CTA in the member/admin space).
export function BottomTabs({ access }: { access: NavAccess }) {
  const pathname = usePathname()
  const items = visibleGroups(access).flatMap((g) => g.items)
  return (
    <nav
      className="bg-background fixed inset-x-0 bottom-0 z-40 flex border-t md:hidden"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      {items.map(({ href, label, icon: Icon }) => {
        const active = pathname === href || pathname.startsWith(href + "/")
        return (
          <Link
            key={href}
            href={href}
            className={cn(
              "flex flex-1 flex-col items-center justify-center gap-1 py-2 text-[11px] transition-colors",
              active ? "text-foreground font-medium" : "text-muted-foreground"
            )}
          >
            <Icon className="size-5" />
            {label}
          </Link>
        )
      })}
    </nav>
  )
}
