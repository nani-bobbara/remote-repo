import { User } from "lucide-react"
import { getSession } from "@app/auth"
import { dbPort } from "@app/adapters/db"
import { PageShell, WorkspaceLayout } from "@app/ui"
import { ThemeToggle } from "../../_components/theme-toggle"
import { ProfileForm } from "./profile-form"

export const dynamic = "force-dynamic"

export default async function ProfilePage() {
  const session = await getSession()
  // Reading your own row is user-scoped, so it goes through withUser rather
  // than the privileged port.
  const { user, hasPassword } = session
    ? await dbPort.withUser(session.userId, async (repos) => ({
        user: await repos.users.findById(session.userId),
        hasPassword: await repos.users.hasCredential(session.userId),
      }))
    : { user: null, hasPassword: false }

  return (
    <PageShell>
      <WorkspaceLayout
        cardIcon={<User />}
        cardTitle="Profile"
        cardSubtitle="Your account and access details."
        cardActions={<ThemeToggle />}
      >
        <ProfileForm
          name={user?.name ?? ""}
          email={session?.email ?? ""}
          role={session?.role ?? ""}
          hasPassword={hasPassword}
        />
      </WorkspaceLayout>
    </PageShell>
  )
}
