import crypto from 'node:crypto'
import { loadEnvFile } from 'node:process'
try { loadEnvFile() } catch { /* env from shell */ }
const { auth } = await import('./src/auth/index.ts')
const { dbAdmin } = await import('./src/db/index.ts')
const { user } = await import('./src/db/schema.ts')
const { eq } = await import('drizzle-orm')
const [u] = await dbAdmin.select().from(user).where(eq(user.email, 'admin@example.com'))
if (!u) throw new Error('admin@example.com not found')
const pw = crypto.randomBytes(12).toString('base64url')       // 16 chars
const ctx = await auth.$context
await ctx.internalAdapter.updatePassword(u.id, await ctx.password.hash(pw))
console.log('NEW_PASSWORD=' + pw)
process.exit(0)
